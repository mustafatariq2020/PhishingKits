var AuthFormValidator;

$(document).ready(function() {
    
    $('#au-v2-modal-btn').on('click',function(){

        // Get the <span> element that closes the modal
        //var span = document.getElementsByClassName("close")[0];
        
        $('body').css('overflow','hidden');
        $('#modal-login').show();

        // When the user clicks anywhere outside of the modal, close it
        $('#modal-login, .close-modal').on('click',function(event) {
            if(event.target == this){
                $('#modal-login').off('click');
                $('#modal-login').hide();
                $('body').css('overflow','auto');
            }
        });
    });


    //change labels based on user input
    if($('[check-user-pass]').length == 1){
        
        var isCod = new RegExp('^[0-9]{1,8}$');
        var aUsrInput = $('[check-user-pass]');
                
        var labelsBOTH = {
            'both': [$('#usrLabel').text(),$('#passLabel').text()],
            'cod': ['Codice cliente','PIN'],
            'usr': ['Username','Password']
        }

        var currentVal, index;
        aUsrInput.on('keyup paste',function(){
            currentVal = aUsrInput.val();
            
            index = currentVal.length > 1 ? isCod.test(currentVal) ? 'cod' : 'usr' : 'both';
            
            $('#usrLabel').text(labelsBOTH[index][0]);
            $('#passLabel').text(labelsBOTH[index][1]);
        });
    }

    //form validation
    $.validate({
        form: "#form_autenticazione",
        showHelpOnFocus: false,
        addSuggestions: false,
        errorMessageClass:'a-authError',
        onSuccess : function(form) {
            $('.a-btn-submit').prop('disabled', true);
            return true; 
        }
    });

});