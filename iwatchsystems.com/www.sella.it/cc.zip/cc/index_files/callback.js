/*
 * La funzione consente di tenere attiva la sessione utente
 * Per eseguire la funzione � necessario avere JQuery con ver >= 1.0
 */

function pingSession()
{
	try {
		$.ajax({
		  url: '/banca-online/common/callback.jsp',
		  success: function(data) {								
		  }
		});      
	} catch(er) {}
}