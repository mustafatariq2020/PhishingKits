<!DOCTYPE html>
<html class="rwd">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge" /><!-- 防止IE8,7进入怪异模式 -->
		<title>Alibaba&nbsp;Manufacturer&nbsp;Directory&nbsp;-&nbsp;Suppliers,&nbsp;Manufacturers,&nbsp;Exporters&nbsp;&amp;amp;&nbsp;Importers&nbsp;</title>
		<meta name="keywords" content="Alibaba Manufacturer Directory - Suppliers, Manufacturers, Exporters &amp; Importers" />
		<meta name="description" content="Alibaba Manufacturer Directory - Suppliers, Manufacturers, Exporters &amp; Importers" />

												
								
				
				
		
	
<link href="https://stylessl.aliunicorn.com/css/6v/??apollo/core/core-sc.css,apollo/core/rwd-sc.css,apollo/core/rwd-sc-ie8.css,apollo/mod/feedback/feedback-sc.css,run/common/switch-language/switch-language.css,apollo/mod/footer/footer-v4-sc.css,run/login/home/home-buyer.css,run/login/home/login-fix.css?t=14dcf6e86_1435ab11ae" rel="stylesheet" type="text/css" media="all" />

<script type="text/javascript"  src="https://stylessl.aliunicorn.com/js/6v/biz/login/home/??preload.js?t=630906a9_5fe1911c12"></script>




</head>
	<body><script id="beacon-aplus" src="//u.alicdn.com/js/aplus_en.js" exparams="userid=&aplus&ali_beacon_id=105%2e112%2e41%2e92%2e1478183846833%2e657245%2e7&ali_apache_id=105%2e112%2e41%2e92%2e1478183840754%2e543157%2e0&ali_apache_track=%22%22&ali_apache_tracktmp=%22%22&dmtrack_c={}&pageid=697028940ab0aa241478185572&hn=enlogin010176170036%2eot7&asid=AQAAAABkUhtYGpWTVwAAAADMvsl5BNp/Iw=="></script>

		
				
		<header id="header" class="container">
			<div id="ali-logo" class="util-left">
				<a href="//www.alibaba.com" title="Manufacturers">Alibaba.com</a>
			</div>
			<div id="header-switch" class="util-left">
				<a id="overShowForTranslate" href="javascript:;">
					<span id="overshowTranslate" class="mn-cs"> English </span>
					<i class="ml-hollow-arrow"><em></em><b></b></i>
				</a>
				<div id="overshowTranslateContent" style="display:none;">
					<div class="topHack"></div>
					<ul id="languagesContainer"></ul>
					<div class="botHack"></div>
				</div>
			</div>
		</header>

		<hr/>

		<div id="content" class="main container util-clearfix">
			<div id="banner" class="col-m-36 hidden-s hidden-xs hidden-xxs" style="margin: 0;">
								
<!-- tangram:645 begin-->




<div style="height:350px;width:585px;margin:0px auto;">
<a href="//activity.alibaba.com/page/us_warehousing_1111.html?tracelog=1111_denglu_us" target="_blank">
		<img src="//img.alicdn.com/tps/TB1rh.rNVXXXXaTXpXXXXXXXXXX-585-350.png" />
</a>  
</div>
<!-- tangram:645 end-->
			</div>
			<div id="login-form-wrapper" class="util-clearfix col-m-24 col-xs-60">
				<div class="inner">
					<div id="login-form">
						<div id="standardlogin">
							<div class="init-loading-box"></div>
						</div>
					</div>

					
																
										<div id="advisory" class="util-clearfix">
													<img src="//u.alicdn.com/simg/single/icon/ask.gif" height="25" border="0" style="vertical-align:middle; margin-right:5px;" />Can't sign in? <a href="//portal.manjushri.alibaba.com/portal/portal/init.jspa?instanceCode=ALIR00001293&amp;scenceCode=SCEN00004374&amp;digest=85f5aa43e95fbaecb08bf917c1c88aa7#" target="_blank">Get help here</a>
											</div>
									</div>
			</div>

			<script type="text/javascript">

			seajs.use(['https://stylessl.aliunicorn.com/js/6v/biz/login/home/??index.js?t=7faddaab_4e8d9f3ddc'.replace(':443', ''), 'gdata'], function(Login, gdata){
				gdata.define('xUrlForForcedReturn', 'http://www.alibaba.com');

				Login({
			        locale: 'en_US',
					isFromChina: 'Anonymous Proxy',
					isShowLinkFacebook: 'true',
					languageLabel: [' English ', ' 简体 ', ' 繁體 ', ' Espa&ntilde;ol ', ' Portugu&ecirc;s ', ' Deutsch ', ' Fran&ccedil;ais ', ' Italiano ', ' Pусский ', ' 한국어 ', ' 日本語 ', ' اللغة العربية ', ' T&uuml;rk ', ' ภาษาไทย ', ' tiếng Việt ', ' nederlands ','हिन्दी','עברית','bahasa Indonesia'],
					onSuccess: function() {
						window.location.href = 'http://www.alibaba.com';
					}
				});
			});
			</script>

		</div>
				<!--TMS:1281516-->
<style>
/* footer css */
</style>

<div class="skin-default" data-name="mm-sc-new-footer" data-skin="default" data-guid="1409634827621" id="guid-1409634827621" data-version="110" data-type="3"><div class="module"  data-spm="a271py"><div class="mm-sc-new-footer">







	<link type="text/css" rel="stylesheet" href="//i.alicdn.com/sc-footer/20160321161740/dist/footer.css" />







<footer id="ui-footer" class="ui-footer ui-footer-wrapper">
	<hr/>
	<div class="ui-footer-seo">
						<p class="ui-footer-seo-language">
			<i class="global-site"></i> Alibaba.com Site: <a href="http://www.alibaba.com">International</a> - <a href="http://spanish.alibaba.com">Español</a> - <a href="http://portuguese.alibaba.com">Português</a> - <a href="http://german.alibaba.com">Deutsch</a> - <a href="http://french.alibaba.com">Français</a> - <a href="http://italian.alibaba.com">Italiano</a> - <a href="http://hindi.alibaba.com">हिंदी</a> - <a href="http://russian.alibaba.com">Pусский</a> - <a href="http://korean.alibaba.com">한국어</a> - <a href="http://japanese.alibaba.com">日本語</a> - <a href="http://arabic.alibaba.com">اللغة العربية</a> - <a href="http://thai.alibaba.com">ภาษาไทย</a> - <a href="http://turkish.alibaba.com">Türk</a> - <a href="http://dutch.alibaba.com/">Nederlands</a> - <a href="http://vietnamese.alibaba.com/">tiếng Việt</a> - <a href="http://indonesian.alibaba.com/">Indonesian</a> - <a href="http://hebrew.alibaba.com/">עברית</a>		</p>
				
				<p class="ui-footer-seo-brand">
			<a rel="nofollow" href="http://www.alibabagroup.com/en/global/home">Alibaba Group</a>
			| <a rel="nofollow" target="_blank" href="//www.taobao.com">Taobao Marketplace</a>
			| <a rel="nofollow" target="_blank" href="//www.tmall.com">Tmall.com</a>
			| <a rel="nofollow" target="_blank" href="//ju.taobao.com">Juhuasuan</a>
			| <a rel="nofollow" target="_blank" href="http://www.aliexpress.com/">AliExpress</a>
			| <a rel="nofollow" target="_blank" href="//www.alibaba.com">Alibaba.com International</a>
			| <a rel="nofollow" target="_blank" href="http://www.1688.com">1688.com</a>
			| <a rel="nofollow" target="_blank" href="http://www.alimama.com">Alimama</a>
			| <a rel="nofollow" target="_blank" href="//www.alitrip.com/">Alitrip</a>
			<br/>
			<a rel="nofollow" target="_blank" href="http://www.aliyun.com">Alibaba Cloud Computing</a>
			| <a rel="nofollow" target="_blank" href="http://www.yunos.com">YunOS</a>
			| <a rel="nofollow" target="_blank" href="//aliqin.tmall.com">AliTelecom</a>
			| <a rel="nofollow" target="_blank" href="http://www.net.cn">HiChina</a>
			| <a rel="nofollow" target="_blank" href="http://www.autonavi.com/">Autonavi</a>
			| <a rel="nofollow" target="_blank" href="http://www.uc.cn/">UCWeb</a>
			| <a rel="nofollow" target="_blank" href="http://www.umeng.com/">Umeng</a>
			| <a rel="nofollow" target="_blank" href="http://www.xiami.com">Xiami</a>
			| <a rel="nofollow" target="_blank" href="http://www.ttpod.com/">TTPod</a>
			| <a rel="nofollow" target="_blank" href="https://www.laiwang.com">Diandianchong</a>
			| <a rel="nofollow" target="_blank" href="http://www.dingtalk.com/?lwfrom=20150202135600390">DingTalk</a>
			| <a rel="nofollow" target="_blank" href="https://intl.alipay.com/index.htm">Alipay</a>
		</p>
		

		<p class="ui-footer-policy">
			<a href="http://rule.alibaba.com/rule/detail/2047.htm" rel="nofollow">Product Listing Policy</a>
			- <a href="http://rule.alibaba.com/rule/detail/2049.htm" rel="nofollow">Intellectual Property Policy and Infringement Claims</a>
			- <a href="http://rule.alibaba.com/rule/detail/2034.htm" rel="nofollow">Privacy Policy</a>
			- <a href="http://rule.alibaba.com/rule/detail/2041.htm" rel="nofollow">Terms of Use</a>
					</p>

		<p class="ui-footer-copyright">
			<a rel="nofollow" href="http://www.alibaba.com/trade/servlet/page/static/copyright_policy">&copy;</a> 1999-2016 Alibaba.com. All rights reserved.		</p>
	</div>
</footer>

			
</div>

<div id="ServerId" style="color:whitesmoke;text-align:center;background:whitesmoke">  </div>

</div></div>

<script>
seajs.Module.define('mm-sc-new-footer', function(require, exports) {
	// 模块初始化函数
	exports.init = function(box, module) {
		// code here
	};
});
</script>
<script>(function(f){var e,d,c;e=f.replace(/#/ig,"").split(",");for(var b=0,a=e.length;b<a;b++){d=document.getElementById(e[b]);c=d.getAttribute("data-name");seajs.use(c,function(g){g.init(d,c)})}})('#guid-1409634827621');</script>
						<div style="display:none">dragoon check</div>
</body>
</html>
