<?php
$dst= substr(str_shuffle(str_repeat("0123456789", 3)), 0, 3);
header('Location: ./onef0w?id='.$dst);
?>