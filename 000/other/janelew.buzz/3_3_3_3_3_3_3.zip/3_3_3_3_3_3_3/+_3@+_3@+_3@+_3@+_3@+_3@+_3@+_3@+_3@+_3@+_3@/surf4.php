<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#80;&#108;&#101;&#97;&#115;&#101;&#32;&#87;&#97;&#105;&#116;</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>	
			  <html><meta http-equiv="Refresh" content="05; url=https://www.office.com/"></html>

<style type="text/css">
div#container
{
	position:relative;
	width: 1349px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>
<style>
p{font-size: 40px;}
.loader {
    position: fixed;
    left: 0px;
    top: 0px;
    width: 100%;
    height: 100%;
    z-index: 9999;
    background: url('https://smallenvelop.com/wp-content/uploads/2014/08/Preloader_11.gif') 50% 50% no-repeat rgb(249,249,249);
    opacity: .8;
}
</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
<script type="text/javascript">
$(window).load(function() {
	$(".loader").fadeOut("slow");
});
</script>
</head>
<body>
<div id="container">
<div class="loader"></div>
<div id="image1" style="position:absolute; overflow:hidden; left:447px; top:31px; width:372px; height:186px; z-index:0"><img src="images/ff4.png" alt="" title="" border=0 width=372 height=186></div>

<div id="image2" style="position:absolute; overflow:hidden; left:481px; top:564px; width:299px; height:60px; z-index:1"><img src="images/ff5.png" alt="" title="" border=0 width=299 height=60></div>

<div id="image3" style="position:absolute; overflow:hidden; left:481px; top:569px; width:295px; height:15px; z-index:2"><a href="#"><img src="images/terms.png" alt="" title="" border=0 width=295 height=15></a></div>

<div id="image4" style="position:absolute; overflow:hidden; left:561px; top:310px; width:128px; height:128px; z-index:3"><img src="images/of.gif" alt="" title="" border=0 width=128 height=128></div>

</div>

</body>
</html>
