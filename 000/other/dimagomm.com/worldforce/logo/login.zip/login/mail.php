<?php

#Your email in here ""
$to = "ponniariguru@gmail.com, js.bedi@aol.com";


?>