var mmgr=(function()
{var GLOBALS;var MESSAGE_SUCCESS=0;var MESSAGE_ERROR=1;var MESSAGE_NOTICE=2;var flashClasses=[{className:'flash-success',iconClassName:'flash-icon-success',delay:5000,header:'Success!',icon:'✔'},{className:'flash-error',iconClassName:'flash-icon-error',delay:null,header:'Oh no!',icon:'X'},{className:'flash-notice',iconClassName:'flash-icon-notice',delay:10000,header:'Check this out',icon:'!'}];var tid=null;var currencyReg=/^\d+\.?\d{0,2}$/;var yearReg=/^(19)|(20)[0-9]{2}$/g;var MOMENTJS_DB_DATE_FORMAT='YYYY-MM-DD';var MOMENTJS_DISPLAY_DATE_FORMAT='DD-MMM-YYYY';var MOMENTJS_DATEPICKER_VALUE_FORMAT='DD-MMM-YY';var sendToApp=function(message){if(inApp()){parent.postMessage(message,'file://');}};var inApp=function(){return inIframe()&&verifyIsApp();};var inIframe=function(){try{return window.self!==window.top;}
catch(e){return true;}};var verifyIsApp=function(){return appReturnKey;};var getCookie=function(name){var value="; "+document.cookie;var parts=value.split("; "+name+"=");if(parts.length==2){return parts.pop().split(";").shift();}};var pdfAsBlob=function(url){var xhr=new XMLHttpRequest();xhr.open('GET',url,true);xhr.responseType='blob';xhr.onload=function(e){if(this.status==200){var pdfBlob=this.response;sendToApp(pdfBlob);}};xhr.send();};var checkAbn=function(fieldValue)
{var abn='',chk=0,k=11,checkOK="0123456789",ch='';var weighting=new Array(19,17,15,13,11,9,7,5,3,1,10)
var checkStr=fieldValue,allValid=true;for(i=0;i<checkStr.length;i++)
{ch=checkStr.charAt(i);if(checkOK.indexOf(ch)!=-1)
{if(k==11)
{k--;chk+=weighting[k]*(parseInt(ch)-1);}
else if(k-->0)
{chk+=weighting[k]*parseInt(ch);}
abn+=ch;}}
chk=chk/89-Math.floor(chk/89);if(abn.length!=11||k<0||chk!=0)
{return false;}
return true;};var checkNzbn=function(fieldValue)
{if(fieldValue.length===13)
{var nzId=fieldValue.substr(0,2);var businessEntityId=fieldValue.substr(2,10);var checkDigit=fieldValue.substr((fieldValue.length-1),1);var check=0;for(var i=0;i<12;i+=2){check+=parseInt(fieldValue.substring(i,i+1));}
for(var i=1;i<12;i+=2){check+=parseInt(fieldValue.substring(i,i+1))*3;}
check+=parseInt(fieldValue.substring(12));return check%10==0;}
return false;};function getParameterByName(name,url){if(!url)url=window.location.href;name=name.replace(/[\[\]]/g,"\\$&");var regex=new RegExp("[?&]"+name+"(=([^&#]*)|&|#|$)"),results=regex.exec(url);if(!results)return null;if(!results[2])return '';return decodeURIComponent(results[2].replace(/\+/g," "));}
function addQueryStringParameter(uri,key,value){var re=new RegExp("([?&])"+key+"=.*?(&|$)","i");var separator=uri.indexOf('?')!==-1?"&":"?";if(uri.match(re)){return uri.replace(re,'$1'+key+"="+value+'$2');}
else{return uri+separator+key+"="+value;}}
function buildUrl(uri,args)
{var separator=uri.indexOf('?')!==-1?"&":"?";return uri+separator+args;}
var createUrl=function(path)
{return mmgr.GLOBALS.BASEURL+'/'+path;};var setFlashMessage=function(message,type,delay)
{var classesToRemove='';for(var cName in flashClasses)
{classesToRemove+=' '+cName;}
var flashMessage=$('#flash-message');if(type in flashClasses)
{flashMessage.removeClass(classesToRemove).text(message).addClass(flashClasses[type].className).fadeIn();if(tid!==null)
{window.clearTimeout(tid);}
if(delay===undefined)
{delay=flashClasses[type].delay;}
if(delay!==null)
{tid=window.setTimeout(function(){flashMessage.fadeOut();tid=null;PsFloatTables(500);},delay);}
else
{tid=null;}}
PsFloatTables();};var setFlashMessageWithIcon=function(message,type,delay)
{var wrapper=$('.flash-icon-message-wrap');var classesToRemove='';for(var cName in flashClasses)
{classesToRemove+=' '+cName;}
wrapper.removeClass(classesToRemove);var html='<span class="flash-icon-message-icon '+flashClasses[type].iconClassName+'">'+flashClasses[type].icon+'</span>'
+'<div class="flash-icon-message-text">'
+'<div class="flash-icon-message-header '+flashClasses[type].iconClassName+'">'+flashClasses[type].header+'</div>'
+'<div class="flash-icon-message '+flashClasses[type].iconClassName+'">'+message+'</div>'
+'</div>';wrapper.html(html).addClass(flashClasses[type].iconClassName).show();if(tid!==null)
{window.clearTimeout(tid);}
if(delay===undefined)
{delay=flashClasses[type].delay;}
if(delay!==null)
{tid=window.setTimeout(function()
{wrapper.fadeOut();tid=null;PsFloatTables(500);},delay);}
else
{tid=null;}
PsFloatTables();};var PsFloatTables=function(delay)
{var jWindow=$(window);var height=jWindow.height();var width=jWindow.width();if(width>1024||height>1024)
{var $table=$('table.float-table');var desktopPageTop=48;var ResizeContainerSize=979;if(typeof $table.floatThead==="function")
{var rerenderFloat=function(){$table.floatThead('destroy');var reinitWinTimer=window.setTimeout(function(){$table.find('thead').remove();$table.find('thead').innerHTML($table.floatThead("getRowGroups"));clearTimeout(reinitWinTimer);initFloat();$table.trigger('reflow');},3000);};var reflowFloat=function(){$table.trigger('reflow');window.setTimeout(function(){$table.trigger('reflow');},1100);};var initFloat=function(){$table.floatThead({useAbsolutePositioning:false,scrollingTop:desktopPageTop});window.setTimeout(function(){$table.trigger('reflow');},100);};var run=function(delay){if(delay){setTimeout(function(){new PsFloatTables();},delay);return;}
if($table.find('thead').length<1){return;}
if($(window).width()<ResizeContainerSize||$('body').hasClass('tradies-page')){desktopPageTop=0;}
if($table.is(":visible"))
{initFloat();}
$('#tab').on('tabsshow',reflowFloat);$('#yw0, #yw1').on('accordionchange',reflowFloat);$('#yw2 a').live('click',function(){window.setTimeout(function(){$('#yw1 .float-table').floatThead({useAbsolutePositioning:false,scrollingTop:desktopPageTop});},1000);});};run(delay);}}};var printPage=function(){$('section#navigation-main,div.breadcrumb,div#property-search,footer,.pm-kpi-metrics,div.ps-sidebar,div.ps-operations').css({'display':'none'});var elContainer=$('div.container-fluid');var elContainerPaddingTop=elContainer.css('padding-top');elContainer.css({'padding-top':'0px'});$('body').css({'width':'1525px'});var windowWidth=$('window').width();if(windowWidth>1525)
{$('window').css({'width':'1525px'});}
$('table.float-table').floatThead('destroy');setTimeout(function(){window.print();$('section#navigation-main,div.breadcrumb,div#property-search,footer,.pm-kpi-metrics,div.ps-sidebar,div.ps-operations').css({'display':'block'});elContainer.css({'padding-top':elContainerPaddingTop});$('body').css({'width':'auto'});$('window').css({'width':windowWidth});new PsFloatTables();},150);return false;};var quickLookup=(function()
{var add=function()
{var origin=window.location.protocol+"//"+window.location.hostname;var url=window.location.href.substring(origin.length+11);if(url.substring(url.length-1)==='#')
{url=url.substring(0,url.length-1);}
var title=document.title.substring(22);$('#quickLookupUrl').text(url);$('#quickLookupTitle').val(title);$('#quickLookupDialog').dialog('open');};var submit=function()
{var url=$('#quickLookupUrl').text();var title=$('<p>'+$('#quickLookupTitle').val()+'</p>').text();var allUsers=$('#quickLookupAllUsers').is(':checked')?1:0;$.ajax({url:createUrl('users/addquick'),type:'post',data:{url:url,title:title,allUsers:allUsers},dataType:'json',success:function(data){if(data.status)
{juiInfo("Quick look-up has been added for "+title);}
else
{juiAlert(data.message);}},error:function(){juiAlert("Failed to add quick look-up for "+title);}});};var remove=function(that,url,title)
{removeParent=false;var allUsers=false;if(url==='list')
{var el=$(that);var link=$(el.parent().find('a'));url=link.attr('href').substring(11);title=link.text();allUsers=el.attr('allUsers');removeParent='li';}
$.ajax({url:createUrl('users/removequick'),type:'post',data:{url:url,title:title,allUsers:allUsers},dataType:'json',success:function(data){if(data.status)
{juiInfo("Quick look-up has been removed for "+title);if(removeParent)
{$(that).closest(removeParent).remove();}}
else
{juiAlert(data.message);}},error:function(){juiAlert("Failed to remove quick look-up for "+title);}});};return{add:add,remove:remove,submit:submit}});var juiDialogResize=(function(){var windowWidth=0;var lastMaxHeight=0;var lastMaxWidth=0;var lastFull=false;var lastUsetimeout=true;var full=function(id){var width=1000;partial(id,undefined,width,true);};var partial=function(id,maxHeight,maxWidth,full,usetimeout){if(maxHeight===undefined){maxHeight='auto';}
if(maxWidth===undefined){maxWidth=400;}
if(usetimeout===undefined){usetimeout=true;}
lastMaxHeight=maxHeight;lastMaxWidth=maxWidth;lastFull=full;lastUsetimeout=usetimeout;var winWidth=$(window).width();windowWidth=winWidth;var winHeight=$(window).height();var height=maxHeight;if(height!=='auto'){var maxWinHeight=winHeight-100;height=maxHeight>winHeight?maxWinHeight:$('#'+id+'Dialog').height()+50;}
var dialogRef=$('#'+id+'Dialog');if(winWidth>=1024){var width=maxWidth>1000?1000:maxWidth;dialogRef.dialog({'position':{my:"center center",at:"center center",of:window},'height':height,'width':width});var my="center center";if(winHeight>768&&(dialogRef.height()+50>winHeight-100))
{height=winHeight+100;my="center center+10";}
var at="center center";if(winHeight<=1024&&winWidth<=1024){at="center top";}
dialogRef.dialog({'position':{my:my,at:at,of:window},'height':height,'width':width});}else{var width=maxWidth>winWidth?winWidth*0.9:maxWidth;dialogRef.dialog({'position':{my:"center center",at:"center center",of:window},'height':height,'width':width});var my="center center";if(winHeight>768&&dialogRef.height()+50>winHeight-100)
{height=winHeight+150;my="center center+10";}
dialogRef.dialog({'position':{my:my,at:"center top",of:window},'height':height,'width':width});}
var dialog=$('[aria-labelledby="ui-dialog-title-'+id+'Dialog"]');if(usetimeout)
{setTimeout(function(){var dialogPos=dialog.position();var dialogTop=dialogPos.top;var htmlTop=$('html').offset().top*-1;var headerAdjust=70;var footerAdjust=120;if(full||dialogTop<48){dialog.css({top:headerAdjust});$(window).scrollTop(0);}
else if(dialogTop<htmlTop){dialog.css({top:htmlTop+headerAdjust});}
var footer=$('footer');if(footer.length){var footerTop=footer.offset().top;setTimeout(function(){var dialogContent=dialog.find('.ui-dialog-content');var dialogHeight=dialogContent.height();var dialogBottom=dialog.offset().top+dialogHeight;if(dialogBottom>footerTop){$('footer').css({height:((dialogHeight+100)-footerTop)+50});}},1000);}},50);}};var onChange=function(width)
{var difference=Math.abs(windowWidth-width);if(difference>25)
{var parts=$('.ui-dialog:visible').attr('aria-labelledby');if(parts!==undefined&&parts.indexOf('-'))
{parts=parts.split('-');var id=parts[(parts.length-1)];if(id.indexOf('Dialog'))
{id=id.slice(0,-6);}
mmgr.juiDialogResize.partial(id,lastMaxHeight,lastMaxWidth,lastFull,lastUsetimeout);windowWidth=width;}}};return{full:full,partial:partial,onChange:onChange};})();var returnOrIntray=function(tblSelector,fromIntray)
{var boolCheck=$(tblSelector+" tbody tr:visible").length===0;if(!boolCheck){boolCheck=$(tblSelector+" tbody tr:visible td").length===1;}
if(fromIntray===false){if(mmgr.GLOBALS.SYSTEM_TYPE.toLowerCase()==='prod'||mmgr.GLOBALS.SYSTEM_TYPE.toLowerCase()==='prod-nz'||boolCheck&&document.referrer.indexOf('site/intray')>0||boolCheck===false){return false;}}
return returnOrIntrayBoolean(boolCheck);};var returnOrIntrayBoolean=function(boolCheck)
{if(boolCheck&&document.referrer.indexOf('site/intray')>0)
{var chkReturn=checkReturn();if(chkReturn)
{window.location.href=createUrl("site/intray");return false;}
else
{return chkReturn;}}
else
{return checkReturn();}};var checkReturn=function(redirect)
{var returnIdx=window.location.href.indexOf('return=');if(returnIdx!=-1)
{var separator=window.location.href.indexOf('%3B');var thisHash=window.location.href.indexOf('#');if(separator==-1)
{if(thisHash>0)
{separator=thisHash;}
if(separator==-1)
{separator=window.location.href.length;}}
var decodeurl=decodeURIComponent(window.location.href.substring(returnIdx+7,separator));if(decodeurl.substring(0,1)==='"')
{decodeurl=decodeurl.substring(1,decodeurl.length-1);}
if(redirect===false)
{return decodeurl;}
window.location.href=createUrl(decodeurl);return false;}
return true;};var setUpGetExtendedJobInfo=function(clickSelector,displaySelector)
{$(clickSelector).on('click',function(e){getExtendedJobInfo(clickSelector,displaySelector);});};var getExtendedJobInfo=function(clickSelector,displaySelector)
{var element=$(clickSelector);element.hide();$.ajax({url:createUrl('jobs/showmore')+"/"+element.attr('reference'),type:'post',dataType:'json',success:function(data){$(displaySelector).html('<p>'+data.description+'</p>'
+'<table>'
+'<tr id="contactInfoTr"><th colspan="2">Landlord</th></tr>'
+'<tr><td>Name:</td><td id="contactInfoName">'+data.contact.name+'</td></tr>'
+'<tr><td>Phone:</td><td id="contactInfoPhone">'+data.contact.phone.toString()+'</td></tr>'
+'<tr><td>Mobile Phone:</td><td id="contactInfoMobile">'+data.contact.mobile.toString()+'</td></tr>'
+'</table>').show();},error:function(){juiAlert('Unable to retrieve more information at this time.');}});};var addCocoJsonToList=function(cocojson,fileList,jobId)
{if(cocojson.methodResult!==undefined)
{var json=$.parseJSON(cocojson.methodResult);if(jobId!==undefined)
{if(jobId in fileList)
{fileList[jobId].push(json);}
else
{fileList[jobId]=[];fileList[jobId].push(json);}}
else
{fileList.push(json);}}
return fileList;};var PsSidebar={getCounterNumber:function(counter){switch(counter){case "jobStatus":return 1;break;case "newRequests":return 2;break;case "quotesReady":return 3;break;case "landlordResponse":return 4;break;case "invoiceApproval":return 5;break;case "attentionRequired":return 6;break;case "emailsNotes":return 7;break;case "outboxPending":return 8;break;case "tenantResponse":return 9;break;case "strataResponse":return 10;break;default:return 0;}},getDisplayName:function(counter){switch(counter){case "jobStatus":return "Job Status";break;case "newRequests":return "New Requests";break;case "quotesReady":return "Quotes Ready";break;case "landlordResponse":return "Landlord Response";break;case "invoiceApproval":return "Invoice Approval";break;case "attentionRequired":return "Attention Required";break;case "emailsNotes":return "Emails / Notes";break;case "outboxPending":return "Outbox Pending";break;case "tenantResponse":return "Tenant Response";break;case "strataResponse":return "Strata Response";break;default:return "Unknown";}},counterColours:function(counter){var toColour=counter!=='jobStatus';var count=parseInt($('.nav-'+counter+' .ps-sidebar-item-col-2 .counter').text());var maxAge=parseInt($('.nav-'+counter+' .ps-sidebar-item-col-2 .counter').attr('maxage')||0);if(counter=='propertySafeActions'&&mmgr.GLOBALS.OrganisationType=='Tag'){if(count>0&&maxAge>mmgr.GLOBALS.TagRespondTimeLow){return["#FFA500","black"];}else if(count>0){return["#6FB631","white"];}else{return["lightgrey","grey"];}}
if(toColour&&count>0&&maxAge>mmgr.GLOBALS.PmTimeToActionLow){return["#FFA500","black"];}else if(toColour&&count>0){return["#6FB631","white"];}else{return["lightgrey","grey"];}},setupNav:function(counters){if(counters!==undefined){$.each(counters,function(index,value){var newCount=parseInt(value.counter);var maxAge=parseInt(value.maxAge)
var col2=$('li.nav-'+index+' > a > span.ps-sidebar-item-col-2');var counter=col2.find('span.counter');col2.find('img.loader').hide();counter.text(newCount).attr('maxage',maxAge).show();if(index=='propertySafeActions'&&mmgr.GLOBALS.OrganisationType=='Tag'){if(newCount>0&&maxAge>mmgr.GLOBALS.TagRespondTimeLow){counter.parent().addClass('riskHelpIcon').attr('data-original-title',"This has items exceeding the CSO / PSO idle target of "+mmgr.GLOBALS.TagRespondTimeLow+' days.');}
else{counter.parent().removeClass('riskHelpIcon').removeAttr('data-original-title');}}else{if(newCount>0&&maxAge>mmgr.GLOBALS.PmTimeToActionLow){counter.parent().addClass('riskHelpIcon').attr('data-original-title',"This has items exceeding the Agency's PM idle target of "+mmgr.GLOBALS.PmTimeToActionLow+' days.');}
else{counter.parent().removeClass('riskHelpIcon').removeAttr('data-original-title');}}
var colour=mmgr.PsSidebar.counterColours(index);counter.parent().css("background-color",colour[0]);counter.parent().css("color",colour[1]);});}
mmgr.PsSidebar.refreshNav(true);},refreshNav:function(firstLoad){if(firstLoad===undefined||firstLoad===null){firstLoad=false;}
$.ajax({url:createUrl("site/refreshnav")+'?firstLoad='+(firstLoad===true?1:0),type:'GET',dataType:'json',success:function(data){if(data.status&&data.counters!==undefined){$.each(data.counters,function(index,value){var newCount=parseInt(value.counter);var maxAge=parseInt(value.maxAge);if(index=='expiredRecurring')
{$('li.nav-'+index).toggle(newCount>0);}
var col2=$('li.nav-'+index+' > a > span.ps-sidebar-item-col-2');var counter=col2.find('span.counter');var currentNumber=parseInt(counter.text());counter.text(newCount).attr('maxage',maxAge);if(index=='propertySafeActions'&&mmgr.GLOBALS.OrganisationType=='Tag'){if(newCount>0&&maxAge>mmgr.GLOBALS.TagRespondTimeLow){counter.parent().addClass('riskHelpIcon').attr('data-original-title',"This has items exceeding the CSO / PSO idle target of "+mmgr.GLOBALS.TagRespondTimeLow+' days.');}
else{counter.parent().removeClass('riskHelpIcon').removeAttr('data-original-title');}}else{if(newCount>0&&maxAge>mmgr.GLOBALS.PmTimeToActionLow){counter.parent().addClass('riskHelpIcon').attr('data-original-title',"This has items exceeding the Agency's PM idle target of "+mmgr.GLOBALS.PmTimeToActionLow+' days.');}
else{counter.parent().removeClass('riskHelpIcon').removeAttr('data-original-title');}}
var colour=mmgr.PsSidebar.counterColours(index);counter.parent().css("color",colour[1]);if(firstLoad){col2.find('img.loader').hide();counter.show();counter.parent().css("background-color",colour[0]);}else{if(currentNumber!=newCount){var flashColor='#008DDD';if(currentNumber>newCount){flashColor='#41A747';}
col2.animate({backgroundColor:flashColor},150).animate({backgroundColor:colour[0]},150).animate({backgroundColor:flashColor},200).animate({backgroundColor:colour[0]},200);}}});}},error:function(e){}});if(firstLoad){$.ajax({url:createUrl('site/pmtoaction')+'?jobstatus',type:'post',dataType:'JSON',success:function(response){var avg=parseFloat(response.data[0]);var colourClass='medium';var helpText="Moderate Risk - some items have exceeded the Agency's PM idle target of "+mmgr.GLOBALS.PmTimeToActionLow+' days.';if(avg<=parseFloat(mmgr.GLOBALS.PmTimeToActionLow)){colourClass='low';helpText='Well Done Superstar!';}
else if(avg<=parseFloat(mmgr.GLOBALS.PmTimeToActionMedium)){colourClass='medium';helpText="Moderate Risk - some items have exceeded the Agency's PM idle target of "+mmgr.GLOBALS.PmTimeToActionLow+' days.';}
else{colourClass='high';helpText="High Risk - numerous items have exceeded the Agency's PM idle target of "+mmgr.GLOBALS.PmTimeToActionLow+' days.';}
if(mmgr.GLOBALS.ColouredRiskIndicators==='on')
{$('#pm-kpi-box').addClass("pm-kpi-metrics").addClass('kpi-'+colourClass).html(response.html).show();}
else
{$('#pm-kpi-box').addClass("pm-kpi-metrics-nobg").html(response.html).show();}
$('.pm-kpi-box-icon').addClass('kpi-'+colourClass);if(helpText.length>0)
{$('.pm-kpi-box-icon').addClass('kpiRiskHelpIcon').attr('data-original-title',helpText);}
else
{$('.pm-kpi-box-icon').removeClass('kpiRiskHelpIcon').removeAttr('data-original-title');}
$('.kpiRiskHelpIcon').tooltip({'placement':'bottom','trigger':'hover','delay':{"show":1000,"hide":0}});}});}
$('.riskHelpIcon').tooltip({'placement':'right','trigger':'hover','delay':{"show":1000,"hide":0}});window.setTimeout(mmgr.PsSidebar.refreshNav,900000);},defaultTogglePostion:-50,togglePosition:function(show){var toggleDiv=$('.ps-sidebar-toggle');var newPos=(show?mmgr.PsSidebar.currentTogglePostion+25:mmgr.PsSidebar.currentTogglePostion);toggleDiv.animate({left:newPos+'px'},50)},toggle:function(show){var toggleDiv=$('.ps-sidebar-toggle');var toggleBtn=toggleDiv.find('.sidebar-toggle-btn.toggle');if(show===undefined||show===null){show=toggleBtn.hasClass('show');}
toggleDiv.animate({left:show?'-50px':'-50px'},350);mmgr.PsSidebar.currentTogglePostion=(show?-50:-50);var psSidebarMarginLeftShow='-20px';var psSidebarPosition='absolute';var psSideBarWidthShow='170px';var psContentPaddingLeft='10px';var psContentMarginLeft='150px';var isMobile=$(window).width()<=500;if(show&&isMobile){psSidebarMarginLeftShow='0 auto';psSidebarPosition='static';psSideBarWidthShow='100%';psContentPaddingLeft=psContentMarginLeft='0';}
$('.ps-sidebar-nav .fill').animate({width:show?'150px':'0px'},300);var psSidebarNav=$('.ps-sidebar-nav');psSidebarNav.animate({width:show?psSideBarWidthShow:'0px'},300,function(){toggleBtn.toggleClass('hide',show);toggleBtn.toggleClass('show',!show);toggleBtn.find('.icon').attr('class','icon icon-chevron-'+(show?'left':'right'));$('.sidebar-toggle-btn.pin').removeClass('active');psSidebarNav.css('display',show?'block':'none');$('.ps-content').css('top','1px');new mmgr.PsFloatTables();}).css('margin-left',show?psSidebarMarginLeftShow:'-150px');$('div.ps-sidebar').css('position',show?psSidebarPosition:'absolute');$('.ps-content').animate({'padding-left':show?psContentPaddingLeft:'0','margin-left':show?psContentMarginLeft:'0'},350);},pin:function(){var pinBtn=$('.sidebar-toggle-btn.pin');var on=!pinBtn.hasClass('active');var state=$('.ps-sidebar-nav').is(':visible');$.ajax({url:createUrl('site/pinnav'),dataType:'JSON',type:'POST',data:{on:on,state:(state?'open':'closed')},success:function(data){if(data.status){$('.sidebar-toggle-btn.pin').toggleClass('active',on)}else{}},error:function(e){}});},updateCounter:function(increment,counter){if(counter===undefined){counter=$('.ps-sidebar-nav li.active .ps-sidebar-item-col-2 span.counter');}
var newCount=parseInt(counter.text())+increment;if(newCount<0)
{newCount=0;}
counter.text(newCount);}};var removeTableRow=function(row,remove,updateSideBar,counter){if(remove===undefined){remove=false;}
if(remove){row.remove();}else{row.hide();}
if(updateSideBar===undefined||updateSideBar===null){updateSideBar=true;}
adjustCounter(counter,updateSideBar);};var adjustCounter=function(counter,updateSideBar){if(updateSideBar){mmgr.PsSidebar.updateCounter(-1);}
if(counter===undefined||counter===null){counter=$('.pager-count:visible');}
if(counter!==undefined&&counter!==null&&counter.length>0)
{var grandTotal=counter.find('.grand-total');if(grandTotal.length>0){var grandCount=parseInt(grandTotal.text());grandCount--;if(grandCount===0){counter.text("0 results found.");}else{grandTotal.text(grandCount);}}
var pageTotal=counter.find('.page-total');if(pageTotal.length>0){var pageCount=parseInt(pageTotal.text());pageCount--;if(pageCount===0&&grandTotal.length===0){counter.text("0 results found.");}else{pageTotal.text(pageCount);}}}};var showInlineAlert=function(alertDivId,type,message,hideMsTime)
{if(!hideMsTime)hideMsTime=4000;$(alertDivId).removeClass(function(index,css){return(css.match(/(^|\s)alert-\S+/g)||[]).join(' ');});$(alertDivId).addClass(type).html(message).fadeIn();window.setTimeout("mmgr.hideInlineAlert('"+alertDivId+"')",hideMsTime);};var hideInlineAlert=function(alertDivId){$(alertDivId).fadeOut();};var PsCharts={gauge:function(selector,min,max,value,config){var centreFormat='<div style="text-align:center"><span style="font-size:25px;color:'+
((Highcharts.theme&&Highcharts.theme.contrastTextColor)||'black')+'">{y}</span>'+(config.multilineCentre?'<br/>':'')+
(config.centreSuffix===undefined?'':'<span style="font-size:12px;color:#807976">'+config.centreSuffix+'</span></div>');if(config.yAxisLabelPrefix===undefined){config.yAxisLabelPrefix='';}
if(config.yAxisLabelSuffix===undefined){config.yAxisLabelSuffix='';}
var clickFuncSet=false;var clickFunc=function(){if(config.url!==undefined){clickFuncSet=true;window.location=config.url;}};var emptyClickFunc=function(){if(config.emptyUrl!==undefined){window.location=config.emptyUrl;}};var stops=[];if(typeof config.stops==='object')
{var lowPerct=config.stops.low/config.stops.high;var medPerct=config.stops.medium/config.stops.high;if(typeof config.colours==='object')
{stops=[[0,config.colours.low],[lowPerct,config.colours.low],[(lowPerct+0.01),config.colours.medium],[medPerct,config.colours.medium],[(medPerct+0.01),config.colours.high],[1,config.colours.high]];}
else
{stops=[[0,'#6FB631'],[lowPerct,'#6FB631'],[(lowPerct+0.01),'#FFA500'],[medPerct,'#FFA500'],[(medPerct+0.01),'#FF3714'],[1,'#FF3714']];}}
else
{stops=[[0.1,'#01D557'],[0.2,'#01D557'],[0.3,'#F96A01'],[0.4,'#F96A01'],[0.5,'#F96A01'],[0.6,'#F96A01'],[0.7,'#F96A01'],[0.8,'#F96A01'],[0.9,'#FF3714']];}
return $(selector).highcharts({chart:{type:'solidgauge',spacingTop:-65,spacingLeft:5,spacingRight:5,spacingBottom:0,events:{click:emptyClickFunc}},title:null,pane:{center:['50%','85%'],size:'100%',startAngle:-90,endAngle:90,background:{backgroundColor:(Highcharts.theme&&Highcharts.theme.background2)||'#EEE',innerRadius:'60%',outerRadius:'100%',shape:'arc'}},tooltip:{enabled:false},plotOptions:{solidgauge:{dataLabels:{y:config.multilineCentre?25:10,borderWidth:0,useHTML:true},cursor:clickFuncSet?'pointer':'auto',events:{click:clickFunc}}},credits:{enabled:false},yAxis:{stops:stops,lineWidth:0,minorTickInterval:null,tickInterval:max,title:{y:-70,text:''},labels:{y:16,formatter:function(){return(this.value===0?'':config.yAxisLabelPrefix)+this.value+(this.value===0?'':config.yAxisLabelSuffix);}},min:min,max:max},series:[{name:'',data:[value],dataLabels:{format:centreFormat},tooltip:{valueSuffix:(config.centreSuffix===undefined?'':config.centreSuffix)}}]});}};var checkValidCurrency=function(amount)
{amount=String(amount).replace(',','').replace('$','');if(currencyReg.test(amount))
{return parseFloat(amount);}
return null;};var checkValidYear=function(str)
{str=String(str).replace(' ','');if(yearReg.test(str))
{return parseInt(str);}
return null;};var serializeObject=function(selector)
{var o={};var a=$(selector).serializeArray();$.each(a,function()
{if(o[this.name]!==undefined)
{if(!o[this.name].push)
{o[this.name]=[o[this.name]];}
o[this.name].push(this.value||'');}
else
{o[this.name]=this.value||'';}});return o;};var scrollTo=function(selector)
{if($(selector).length>0)
{$('html,body').animate({scrollTop:$(selector).offset().top-150},'fast');}};var tooltipErrorHandler=(function()
{var tooltipTemplate='<div class="tooltip error-tooltip" role="tooltip">'+
'<div class="tooltip-arrow"></div>'+
'<div class="tooltip-inner"><div><i class="icon-remove icon-red"></i> </div>'+
'</div>';var errors=[];var displayError=function(selector,message,scrollTo)
{var element=$(selector);element.attr('data-original-title','<span class="null selector" selector="'+selector+'"></span>'+message);element.tooltip({animation:true,html:true,placement:'bottom',template:tooltipTemplate,trigger:'manual'});element.tooltip('show');element.addClass('fieldHasError');var tooltip=$('[selector="'+selector+'"]').closest('.tooltip');element.closest('div').append('<div class="tooltipSpace" style="height: '+tooltip.height()+'px">&nbsp</div>');if(scrollTo)
{mmgr.scrollTo(selector);element.focus();}};var displayErrors=function(errors,focus)
{$('.error-tooltip,.tooltipSpace').remove();$('.fieldHasError').removeClass('fieldHasError');if(errors.length)
{mmgr.setFlashMessageWithIcon('There are invalid or incomplete items on this page, please correct before continuing.',mmgr.MESSAGE_ERROR,null);mmgr.flashMessage('There are invalid or incomplete items on this page, please correct before continuing.',mmgr.MESSAGE_ERROR,null);}
var scrollTo=typeof focus==='undefined'?true:focus;for(var i in errors)
{displayError(errors[i].selector,errors[i].message,scrollTo);scrollTo=false;}
setTimeout(function()
{mmgr.PsFloatTables();},500);$('.error-tooltip').each(function(i,v)
{var tooltip=$(v);tooltip.css('left',$(tooltip.find('[selector]').attr('selector')).offset().left+'px');}).on('click',function()
{$(this).hide();});$('.error-tooltip. .tooltip-inner:not(:has(.icon-remove.icon-red))').prepend('<i class="icon-remove icon-red" style="float:right; margin-top:5px;"></i>');};var addError=function(selector,message)
{this.errors.push({selector:selector,message:message});};var hasErrors=function()
{return this.errors.length>0;};var removeError=function(selector)
{$('[selector="'+selector+'"]').closest('.error-tooltip').remove();var element=$(selector);element.removeAttr('data-original-title');element.removeClass('fieldHasError');for(index in this.errors)
{if(this.errors[index].selector===selector)
{this.errors.splice(index,1);break;}}};var removeAllErrors=function()
{$.each(this.errors,function(index,value){removeError(value.selector);});mmgr.flashMessage('','');};var displayMyErrors=function(focus)
{displayErrors(this.errors,focus);};return{addError:addError,displayMyErrors:displayMyErrors,displayErrors:displayErrors,errors:errors,hasErrors:hasErrors,removeError:removeError,removeAllErrors:removeAllErrors}});var applyValidationTick=function(inputSelector,valid,removeTooltipError)
{if(valid)
{$(inputSelector).addClass('ticked');if(removeTooltipError)
{removeTooltipError.removeError(inputSelector);}}
else
{$(inputSelector).removeClass('ticked');}};var activateClickableCells=function(){$('td.clickable-cell, th.clickable-cell').on('click',function(){var input=$(this).find('input:visible').first();if(input.is(':radio')||input.is(':checkbox'))
{if(input.is(':checked'))
{input.removeAttr('checked');}
else
{input.attr('checked','checked');}
input.click();}});};var notificationBubble=function(){var self=this;this.timeout=5;this.domContainer=$('body');this.action=null;this.id=null;this.setDomContainer=function(selector){self.domContainer=$(selector);};var show=function(id,title,message,action,timeout)
{if(typeof(action)!=='undefined'&&action!==null&&typeof(action)==='object')
{self.action=action;}
self.id=id;var template='<div id="notify-'+id+'" class="notifyBubble"><div class="close"><button title="Dismiss this notification">x</button></div>';if(title)
{template+='<div class="title">'+title+'</div>';}
template+='<div class="message">'+message+'</div>';if(typeof(action)!=='undefined'&&action!==null)
{if(action.hasOwnProperty('text')||action.text===null)
{template+='<div class="action">'+action.text+'</div>';}}
template+='</div>';self.domContainer.append(template);self.domContainer.on('click','#notify-'+id+' .close > button',self.close);self.domContainer.on('click','#notify-'+id+' .action',self.doAction);if(typeof(timeout)==='undefined'||timeout===null)
{timeout=self.timeout;}
$('#notify-'+id).delay(timeout*1000).hide(300,function()
{$(this).remove();});};this.close=function(e)
{$('#notify-'+self.id).hide(300);$('#notify-'+self.id).delay(1000).remove();};this.doAction=function(){if(self.action.hasOwnProperty('type')&&self.action.hasOwnProperty('name')&&typeof(self.action.type)!=='undefined'&&typeof(self.action.name)!=='undefined'){switch(self.action.type)
{case 'function':(typeof(self.action.args)!=='undefined'&&self.action.args!==null)?window[self.action.name](self.action.args):window[self.action.name]();break;case 'view':(typeof(self.action.partial)!=='undefined'&&self.action.partial===true)?window.location.href=goHome('?only='+self.action.name):window.location.href=self.action.name;break;}}};return{timeout:self.timeout,domContainer:self.domContainer,action:self.action,show:show,close:self.close,doAction:self.doAction};};var tradieChatApi={sendMessage:function(message,channel,jobId,callback)
{var url=createUrl('tradespersons/chatsendmessage');$.ajax({url:url,type:"POST",data:{message:JSON.stringify(message),channel:channel,jobId:jobId},dataType:"json",success:function(data)
{callback(data);},error:function(data)
{callback(data.responseText);}});},markMessageRead:function(messages,callback,channel)
{var url=createUrl('tradespersons/chatmarkread');$.ajax({url:url,type:"POST",data:{messages:messages,channel:channel},dataType:"json",success:function(data)
{callback(data);},error:function(data)
{console.error(data.responseText);}})},addMessage:function(message,channel,jobId)
{var url=createUrl('tradespersons/chataddmessage');$.ajax({url:url,type:"POST",data:{message:JSON.stringify(message),channel:channel,jobId:jobId},dataType:"json",error:function(data)
{console.error(data.responseText);}});},getHistory:function(channel,jobId,callback,page,limit,isControl)
{var url=createUrl('tradespersons/chatgethistory');$.ajax({url:url,type:"POST",data:{channel:channel,jobId:jobId,page:typeof(page)==='undefined'?0:page,limit:typeof(limit)==='undefined'?20:limit,isControl:typeof(isControl)==='undefined'?false:isControl},dataType:"json",success:function(data)
{callback(data);},error:function(data)
{console.error(data.responseText);}});},getRecentChannels:function(callback)
{var url=createUrl('tradespersons/chatrecentchannels');$.ajax({url:url,type:"GET",dataType:"json",success:function(data)
{if(data.channels)
{if(typeof(callback)==='function')
{callback(data.channels,data.total_channels);}}
else
{if(typeof(callback)==='function')
{callback(data.message);}}},error:function(data)
{callback(data.responseText);}});},setUUID:function(callback)
{var url=createUrl('tradespersons/setuuid');$.ajax({url:url,type:"GET",dataType:"json",success:function(data)
{if(typeof(callback)==='function')
{callback(data);}},error:function(data)
{callback(data.responseText);}});}};var setLocalStorageOnChange=function(selector)
{$(document).on('change',selector,function()
{var element=$(this);window.localStorage.setItem(selector,element.val());});};var setFromLocalStorage=function(selectors)
{$(function()
{if(window.localStorage.length)
{for(var key in selectors)
{var value=window.localStorage.getItem(selectors[key]);if(value)
{var element=$(selectors[key]+':not([type="hidden"])');if(element.attr('type')==='radio')
{$(selectors[key]+'[value="'+value+'"]').attr('checked','checked');}
else
{element.val(value);}}}}});};var enforceMinMax=function(value,min,max)
{if(parseInt(value)<min||isNaN(parseInt(value)))
{return min;}
else if(parseInt(value)>max)
{return max;}
else
{return value;}};function addZeroPadding(pcs)
{for(var i=0;i<pcs.length;i++)
{pcs[i]=pcs[i].toString();switch(pcs[i].length)
{case 1:pcs[i]='000'+pcs[i];break;case 2:pcs[i]='00'+pcs[i];break;case 3:pcs[i]='0'+pcs[i];break;default:break;}}
return pcs;}
function expandRange(range)
{var bounds=range.split('-');var lower=parseInt(bounds[0]);var upper=parseInt(bounds[1]);if(upper<lower)
{var tmp=upper;upper=lower;lower=tmp;}
var values=[];for(var i=lower;i<=upper;i++)
{values.push(i);}
return values.join();}
var expandPostcodes=function(str)
{var pcs=str.replace(' ','');if(pcs.match('[0-9]{5,}'))
{return[];}
var expanded=pcs.replace(/\d+-\d+/g,expandRange);return addZeroPadding(expanded.split(','));};var collapsePostcodes=function(pcs)
{if(pcs==undefined)
{return '';}
if(pcs.length==0)
{return '';}
pcs.sort();var chunks=[];var chunk=[];for(var i=0;i<pcs.length;i++)
{var pc=pcs[i];if(pc==''||pc==null||pc==chunk[chunk.length-1])
{}
else if(chunk.length==0)
{chunk.push(pc);}
else if(pc==parseInt(chunk[chunk.length-1])+1)
{chunk.push(pc);}
else
{chunks.push(chunk);chunk=[pc];}}
if(chunk.length>0)
{chunks.push(chunk);}
var result='';chunks.forEach(function(chunk)
{switch(chunk.length)
{case 0:break;case 1:result+=','+chunk[0];break;case 2:result+=','+chunk[0];result+=','+chunk[1];break;default:result+=','+chunk[0];result+='-'+chunk[chunk.length-1];break;}});chunks=result.replace(' ','').substr(1).split(',');result=chunks.sort().join(', ');return result;};var toMoneyFormatString=function(float)
{return(float*1.0).toFixed(2).replace(/(\d)(?=(\d{3})+\.)/g,'$1,');};var illegalFilenameStripper=function(filename){return filename.replace(/[^A-Z0-9-_.]/i,'_');};var isEmail=function(email)
{var regex=/^(([^<>()\[\]\\.,;:\s@\"]+(\.[^<>()\[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;return regex.test(email);}
var censorString=function(string,replacementString)
{if(typeof Censoring!=='undefined')
{var scan=Censoring;scan.enableFilters(['phone_number','email_address']);scan.prepare(string,false);if(scan.test())
{scan.setReplacementString(typeof replacementString==='undefined'?' ':replacementString);return scan.replace();}}
return string;};var checkCensor=function(string)
{if(typeof Censoring!=='undefined')
{var scan=Censoring;scan.enableFilters(['phone_number','email_address']);scan.prepare(string,false);return scan.test();}
return false;};var agencyOffice=function()
{$('#add_office').on('click',function(e)
{e.preventDefault();var ele=$(this);var officeName=$('#agencyoffice_name').val();if(typeof $('#agencyoffice_name').attr("data-ccPrefix")!=='undefined')
{officeName=$('#agencyoffice_name').attr("data-ccPrefix")+officeName;}
if(officeName.trim()!=='')
{ele.prop('disabled',true);$.ajax({url:createUrl('agencyOffices/create'),type:'POST',dataType:'json',data:{name:officeName},success:function(data)
{if(data.status)
{window.location.reload(true);}
else
{if(data.message==='')
{juiAlert('Could not create Agency Office');}
else
{juiAlert(data.message);}
ele.prop('disabled',false);}},error:function(e)
{juiAlert('Could not create Agency Office');ele.prop('disabled',false);}});}
return false;});};return{addCocoJsonToList:addCocoJsonToList,applyValidationTick:applyValidationTick,checkReturn:checkReturn,flashMessage:setFlashMessage,setFlashMessageWithIcon:setFlashMessageWithIcon,tooltipErrorHandler:tooltipErrorHandler,juiDialogResize:juiDialogResize,printPage:printPage,PsCharts:PsCharts,PsFloatTables:PsFloatTables,PsSidebar:PsSidebar,quickLookup:quickLookup,removeTableRow:removeTableRow,returnOrIntray:returnOrIntray,returnOrIntrayBoolean:returnOrIntrayBoolean,scrollTo:scrollTo,serializeObject:serializeObject,setUpGetExtendedJobInfo:setUpGetExtendedJobInfo,showInlineAlert:showInlineAlert,hideInlineAlert:hideInlineAlert,checkAbn:checkAbn,checkNzbn:checkNzbn,getParameterByName:getParameterByName,addQueryStringParameter:addQueryStringParameter,buildUrl:buildUrl,activateClickableCells:activateClickableCells,sendToApp:sendToApp,inIframe:inIframe,inApp:inApp,getCookie:getCookie,verifyIsApp:verifyIsApp,pdfAsBlob:pdfAsBlob,notificationBubble:notificationBubble,toMoneyFormatString:toMoneyFormatString,tradieChatApi:tradieChatApi,MESSAGE_ERROR:MESSAGE_ERROR,MESSAGE_NOTICE:MESSAGE_NOTICE,MESSAGE_SUCCESS:MESSAGE_SUCCESS,GLOBALS:GLOBALS,MOMENTJS_DB_DATE_FORMAT:MOMENTJS_DB_DATE_FORMAT,MOMENTJS_DISPLAY_DATE_FORMAT:MOMENTJS_DISPLAY_DATE_FORMAT,MOMENTJS_DATEPICKER_VALUE_FORMAT:MOMENTJS_DATEPICKER_VALUE_FORMAT,currencyReg:currencyReg,checkValidCurrency:checkValidCurrency,checkValidYear:checkValidYear,setLocalStorageOnChange:setLocalStorageOnChange,setFromLocalStorage:setFromLocalStorage,enforceMinMax:enforceMinMax,expandPostcodes:expandPostcodes,collapsePostcodes:collapsePostcodes,illegalFilenameStripper:illegalFilenameStripper,censorString:censorString,checkCensor:checkCensor,agencyOffice:agencyOffice,isEmail:isEmail};})();$(document).ready(function(){new mmgr.PsFloatTables();$(this).on('click','.re-float',function(){new mmgr.PsFloatTables();});});$(window).on('resize',function(){mmgr.juiDialogResize.onChange($(window).width());});