<?php

header("Location: t-login.html");

?>