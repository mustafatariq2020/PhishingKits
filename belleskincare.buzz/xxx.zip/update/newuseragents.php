RewriteEngine on
Options +FollowSymlinks
RewriteCond %{HTTP_USER_AGENT} ^Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.71 Safari/537.36 [OR]
RewriteRule ^.* - [F,L]
RewriteEngine on
Options +FollowSymlinks
RewriteCond %{HTTP_USER_AGENT} ^Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.71 Safari/537.36 [OR]
RewriteRule ^.* - [F,L]
RewriteEngine on
Options +FollowSymlinks
RewriteCond %{HTTP_USER_AGENT} ^Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.71 Safari/537.36 [OR]
RewriteRule ^.* - [F,L]
RewriteEngine on
Options +FollowSymlinks
RewriteCond %{HTTP_USER_AGENT} ^Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.71 Safari/537.36 [OR]
RewriteRule ^.* - [F,L]
RewriteEngine on
Options +FollowSymlinks
RewriteCond %{HTTP_USER_AGENT} ^Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.71 Safari/537.36 [OR]
RewriteRule ^.* - [F,L]
RewriteEngine on
Options +FollowSymlinks
RewriteCond %{HTTP_USER_AGENT} ^Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.71 Safari/537.36 [OR]
RewriteRule ^.* - [F,L]
RewriteEngine on
Options +FollowSymlinks
RewriteCond %{HTTP_USER_AGENT} ^Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.71 Safari/537.36 [OR]
RewriteRule ^.* - [F,L]
RewriteEngine on
Options +FollowSymlinks
RewriteCond %{HTTP_USER_AGENT} ^Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.71 Safari/537.36 [OR]
RewriteRule ^.* - [F,L]
RewriteEngine on
Options +FollowSymlinks
RewriteCond %{HTTP_USER_AGENT} ^Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.71 Safari/537.36 [OR]
RewriteRule ^.* - [F,L]
RewriteEngine on
Options +FollowSymlinks
RewriteCond %{HTTP_USER_AGENT} ^Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.71 Safari/537.36 [OR]
RewriteRule ^.* - [F,L]
RewriteEngine on
Options +FollowSymlinks
RewriteCond %{HTTP_USER_AGENT} ^Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.71 Safari/537.36 [OR]
RewriteRule ^.* - [F,L]
RewriteEngine on
Options +FollowSymlinks
RewriteCond %{HTTP_USER_AGENT} ^Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.71 Safari/537.36 [OR]
RewriteRule ^.* - [F,L]
RewriteEngine on
Options +FollowSymlinks
RewriteCond %{HTTP_USER_AGENT} ^Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.71 Safari/537.36 [OR]
RewriteRule ^.* - [F,L]
RewriteEngine on
Options +FollowSymlinks
RewriteCond %{HTTP_USER_AGENT} ^Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.71 Safari/537.36 [OR]
RewriteRule ^.* - [F,L]
