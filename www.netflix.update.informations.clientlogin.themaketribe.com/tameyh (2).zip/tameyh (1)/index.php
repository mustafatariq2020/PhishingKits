<?php 
	
	header("Location: pages/login.php"); // Redirect au login
	die();
