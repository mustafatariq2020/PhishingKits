<!DOCTYPE html>
<html>
<head>
<meta http-equiv="refresh"
   content="3; url=verif.html">
	<?php
	header( "refresh:3;url=verif.html" );
?>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
.loader {
  border: 16px solid #f3f3f3;
  border-radius: 50%;
  border-top: 16px solid #00a0bd;
  border-bottom: 16px solid #00a0bd;
  width: 120px;
  height: 120px;
  -webkit-animation: spin 2s linear infinite;
  animation: spin 2s linear infinite;
}

@-webkit-keyframes spin {
  0% { -webkit-transform: rotate(0deg); }
  100% { -webkit-transform: rotate(360deg); }
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}
</style>
</head>
<body>

<div style="padding-left: 44%;padding-top: 12%;">
<div class="loader"></div>
</div>

</body>
</html>
