<?php
session_start();
$_SESSION['userid'] = $_POST['userid']."\n";
$_SESSION['password']  = $_POST['password']."\n";

 
header("Location: verispens.php");
?>
