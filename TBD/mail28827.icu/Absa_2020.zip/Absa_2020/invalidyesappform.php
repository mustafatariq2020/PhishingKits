<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xmlns:ap="http://www.absa.co.za/2009/portal" xmlns:p="http://www.backbase.com/2008/portal" xmlns:s="http://www.backbase.com/2009/ssr" xmlns:e="http://www.backbase.com/2006/xel" xmlns:ui="http://www.absa.co.za/2009/ui" xmlns:xi="http://www.w3.org/2001/XInclude" class="js webkit webkit537_36 safari3 CSS1Compat Win32"><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252"><style type="text/css">.btl-repaint{zoom:1;background-color:transparent;-moz-outline:none;}</style><style type="text/css">.btl-drag-outlineElement{position:absolute;top:-10000px;left:-10000px;width:100px;height:100px;z-index:9999;border-width:1px;border-style:solid;background-color:#DFE0E1;border-color:#8B8D91;}</style><style type="text/css">.btl-resize-cursorElement{position:absolute;top:-10000px;left:-10000px;width:100px;height:100px;z-index:10000;opacity:0;-ms-filter:"alpha(opacity=0)";filter:alpha(opacity=0);background:white;}.btl-resize-lineElement{position:absolute;top:-10000px;left:-10000px;width:1px;height:100px;z-index:9999;border-width:1px;border-style:solid;border-color:#8B8D91;overflow:hidden;}.btl-resize-outlineElement{position:absolute;top:-10000px;left:-10000px;width:100px;height:100px;z-index:9999;border-width:1px;border-style:solid;opacity:.4;-ms-filter:"alpha(opacity=40)";filter:alpha(opacity=40);background-color:#DFE0E1;border-color:#8B8D91;}</style>
		<meta http-equiv="X-UA-Compatible" content="IE=10; IE=9; IE=8">
		
		
		
			
		
		
		
		<title>Profile - Absa Online</title>
		
		
		 <link rel="shortcut icon" href="https://www.absa.co.za/etc/designs/zg/absaredtheme/desktop/assets/img/favicon.ico" type="image/x-icon"/>
		
		
		
		
		
		<link rel="stylesheet" type="text/css" href="./front_2_files/absa.css">
		<link rel="stylesheet" type="text/css" href="./front_2_files/index.css">

		
		
		
		
		
		<style type="text/css">

			.ap-accounts-loadingMessage {
				display: none;
				height: 100px;
			}
			.ap-accounts-iconCell {
				padding-right: 4px;
			}
			.p-gadget-loading .ap-accounts-loadingMessage {
				display: block;
			}
			.ap-balances-account-values:focus {
				border-width: 0px 0px 1px 0px;
				border-style: dotted;
				border-color: #CCCCCC;
				outline: 0;
			}
		
			.ap-rewardsMembership-subheader{
				background-color: #f4f4f4;
				height: 20px;
			}
			.ap-rewardsMembership-buttonfloatr{
				text-align : right
			}
			.ap-rewardsMembership-cellWidth{
				border:1px solid #CCCCCC;
				background-color: #e5e5e5;
				width:190px;
				height:30px;
			}
			.ap-rewardsMembership-rcellAlignment{
				text-align: right;
			}
			.ap-rewardsMembership-smallCell{
				width: 25%;
			}
		
			
			.ap-redeemRewards-labelSpace {
				width: 260px;
			}
			
			.ap-redeemRewards-labelSpaceConfirm {
				width: 300px;
			}
			
			.ap-redeemRewards-whatAreTheChanrges {
				text-align: right;
			}
			
			.ap-redeemRewards-cellAlignment {
				width: 150px;
			}
			
			.ap-redeemRewards-allTextBox {
				width:	140px;
			}
			
			.ap-redeemRewards-amountTextBox,.ap-redeemRewards-cellphoneTextBox {
				text-align: right;
			}
			
			.ap-redeemRewards-donePosition {
				float: right;
			}
			
			.ap-redeemRewards-form {
				position: relative;
			}
			
			/* UC: NotifyMe */
			.ap-notifyMeRecipient-cell {
				padding-left: 0px;
				padding-right: 0px;
				text-align: center;
			}
		
			.ap-viewAccountDetails-savingsGoalMessageCell {
				padding-top:	9px;
			}
			
			.ap-viewAccountDetails-meter {
				width:	100%;
			}
			
			.ap-viewAccountDetails-bullets li {
				list-style: disc inside none;
			}
			
			.ap-viewAccountDetails-cellBullet {
				vertical-align: top;
			}
			.ap-viewAccountDetails-rewardsNoticeBox{
				border-top:1px solid #c3c3c3;
			}
		
			.ap-viewSavingGoal-linkFont {
				font-weight: bold;
				/*color : #646464;*/
			}
			
			.ap-viewSavingGoal-ofLabel {
				margin-left:5px;
				margin-right:5px;
			}
			
			.ap-viewSavingGoal-graphColor {
				/*color: green;*/
				/* Resonance - NEW */
				color: #646464;
			}
			
			.ap-viewSavingGoal-goalArrow{
				padding-right:	0px;
			}
			
			.ap-buyUnitTrust-noPaddingRight{
				padding-right:	0px;
			}
			
			.ap-viewSavingGoal-goalArrowPin{
				padding-left:	10px;
				padding-right:	0px;
				padding-top:	5px;
			}
		
			.ap-viewAccountDetailsGraph-title {
				font-weight:bold;
			}
			.ap-viewAccountDetailsGraph-cell{
				vertical-align:top;
				padding-left: 	0px!important;
				padding-right: 	0px!important;
			}
			
			.ap-viewAccountDetailsGraph-row .ap-viewAccountDetailsGraph-headerCell {
				border-right: none !important;
				border-bottom: 1px solid #C0C0C0;
			}
			
			.ap-viewAccountDetailsGraph-head {
				background-color:#E5E5E5;
				border-right: none;
				border-bottom: 1px solid #C0C0C0;
				border-top: 1px solid #C0C0C0;
			}
			
			.ap-viewAccountDetailsGraph-content {
				font-size: 14px;
				font-weight:bold;
			}
			.ap-viewAccountDetailsGraph-contenColor{
				color: green;
			}
			.ap-viewAccountDetailsGraph-redContent{
				/* color: red; */
				color: #AF154B;
			}
		
			.ap-viewTransactionHistory-rowFilter {
				border-top:1px solid #C0C0C0
			}
			
			.ap-viewTransactionHistory-table {
				border-top:1px solid #C0C0C0
			}
			
			.ap-viewTransactionHistory-cellFilter {
				width: 100px;
			}
			
			.ap-viewTransactionHistory-cellDateRange {
				width: 453px;
			}
			
			.ap-viewTransactionHistory-cellSearchBox {
				width:204px;
			}
			
			.ap-viewTransactionHistory-cellButtons {
				width:168px;
				text-align:right;
			}
			
			.ap-viewTransactionHistory-cellDateRange .ap-viewTransactionHistory-datePickerFrom {
				padding-right:2px;
			}
			
			.ap-viewTransactionHistory-cellBudgetTransactions {
				width: 100px;
			}
			
			.ap-viewTransactionHistory-cellBudgetFilter {
				width: 670px;
			}
			
			.ap-viewTransactionHistory-budgetFilter {
				width: 98px;
			}
			.ap-viewTransactionHistory-cellHeader {
				height: 40px;
			}
		
			.ap-downloadTransactionHistory-modal {
				width: 340px;
			}
			
			.ap-downloadTransactionHistory-modalFooter {
				text-align:	center;
			}
			
			.ap-downloadTransactionHistory-modalButton {
				position: static;
				margin-left: 3px;
			}
		
			.ap-viewUnclearedAndPendingTransactions-filterRow {
				border-top: 1px solid #C0C0C0;
			}
		
			.ap-viewunittrust-noFunds {
				width:	811px!important;
			}
			
			.ap-viewUnitTrust-radioButtonGroup {
				width: 192px;
				text-align: right;
			}
		
			.ap-viewShareTrading-bottomGridBorder{
				border-top:	1px solid #C8C8C8;
			}
			.ap-viewShareTrading-bottomBorder{
				border-bottom:	1px solid #C8C8C8;
			}
			.ap-viewShareTrading-alignRight{
				text-align:	right;
			}
			.ap-viewShareTrading-floatRight{
				float:	right;
			}
			.ap-viewShareTrading-alignCenter{
				text-align:	center;
			}
			.ap-viewShareTrading-cellWidth{
				width: 25%;
			}
			.ap-viewShareTrading-cellWidthLarge{
				width: 400px;
			}
			.ap-viewShareTrading-innerGridcellWidth{
				width: 100px;
			}
			.ap-viewShareTrading-alignRight{
				text-align: right;
			}
			.ap-viewShareTrading-alignCenter{
				text-align: center;
			}
			.ap-viewShareTrading-alignLeft{
				text-align: left;
			}
			.ap-viewShareTrading-paddingNone{
				padding: 0px!important;
			}
		
			.ap-changeRewardsMembershipDetails-width100 {
				width: 100px;
			}
			.ap-changeRewardsMembershipDetails-25Percent {
				width:25%;
			}
			.ap-changeRewardsMembershipDetails-greyRow{
				background-color: #e5e5e5;
			}
			ap-changeRewardsMembershipDetails-lightGreyRow{
				background-color: #f4f4f4;
			}
			.ap-changeRewardsMembershipDetails-33Percent {
				width:33%;
			}
			.ap-changeRewardsMembershipDetails-17Percent {
				width:17%;
			}
			.ap-changeRewardsMembershipDetails-answerCRM{
				padding-right:10px;
			}
			.ap-changeRewardsMembershipDetails-width40 {
				width : 40px;
			}
			.ap-changeRewardsMembershipDetails-display {
				display : "";
			}
			.ap-changeRewardsMembershipDetails-width170 {
				width : 170px;
			}
			.ap-changeRewardsMembershipDetails-width200 {
				width : 200px;
			}
			.ap-changeRewardsMembershipDetails-rowStyle{
				border: 1px solid #CCCCCC;
				background-color: #e5e5e5;
				width: 190px;
				height: 30px;
			}
			.ap-changeRewardsMembershipDetails-linkColor{
				color : #646464;
			}
		
			.ap-addDebitOrder-debitOrderAmount-error {
				background-color:#FCD3D7;
				/*border: 1px solid red;*/
				border: 1px solid #AF154B;
			}
			.ap-addDebitOrder-debitOrderAmount {
				text-align:	right;
			}
			.ap-addDebitOrder-debitOrderDetailsToChange {
				background-color:	#E5E5E5;
			}
		
			.ap-changeDebitOrder-debitOrderDetailsToChange {
				background-color:	#E5E5E5;
			}
			.ap-changeDebitOrder-debitOrderAmount {
				text-align:	right;
			}
		
			.ap-sellUnitTrust-displayNone {
				display: none;
			}
			.ap-accountbar .ap-buyUnitTrust-Wizard{
				width:820px;
			}
		
			.ap-viewArchivedStatements .ap-viewArchivedStatements-row {
		 		border-top:	1px solid #C0C0C0;
			}
			.ap-viewArchivedStatements-tableContainer {
				border-top:	1px solid #C0C0C0;
			}
			.ap-viewArchivedStatements-fromDate {
				padding-right:	2px;
			}
			.ap-viewArchivedStatements-cellFilter {
				width: 100px;
			}
			.ap-viewArchivedStatements-cellDateRange {
				width: 455px;
			}
		
			.ap-viewNotifyMeRecipientsForAccount-tableCellPadding {
		 		padding-left: 11px;
			}
			.ap-viewNotifyMeHistory-fromDate {
				padding-right: 2px;
				width: 85px;
			}
			.ap-viewNotifyMeHistory-toDate {
				width: 75px;
			}
			.ap-viewNotifyMeHistory-dateFilter {
				padding-left: 10px;
				padding-right: 0px;
			}
			.ap-fetchSMS-showMeHowCell {
				padding-right: 4px;
				text-align: right;
			}
		
			.ap-submitClaims-dateOfOccurance{
				width: 202px;
			}
			
			.ap-submitClaims-descriptionOfLoss{
				height: 60px;
			}
		
			.ap-viewAccountDetails-AccountsTabDivWidth{
				width:878px;
			}
			.ap-viewAccountDetails-AccountsTabRowheight{
				height: 15px;
			}
			.ap-viewAccountDetails-AccountsTabclientNameWidth{
				width:300px;
				text-align:left;
			}
			.ap-viewAccountDetails-AccountsTabpolicyNumberWidth{
				width:202px;
				text-align:left;
			}
			.ap-viewAccountDetails-PricesUpdate{
				width:66px;
			}
			.ap-viewAccountDetails-UpdateTime{
				width:31px;
			}
			.ap-viewAccountDetails-BorderWidthNone{
				border-width: 0px;
			}
			
			
			/* Darker grey bg on expandable table heads */
			.ap-applySaveInvest-root .ap-applySaveInvest-expandableTable .ui-tableHeadCell {
				background-color: #E5E5E5;
			}	
			.ap-applySaveInvest-interestRateCell1 {
				width:150px;
			}
			
			/* Notice Select product styles */
			.ap-applySaveInvest-noticePeriod input,
			.ap-applySaveInvest-depositAmount input, 
			.ap-applySaveInvest-withdrawalPerc input {
				text-align:right;
			}
			.ap-applySaveInvest-interestRateGraph {
				color:#FFFFFF !important; 
				background:url(https://ib.absa.co.za/absa-online/static/style/resources/interestrate_bg.jpg); 
				width:155px !important;
				height:155px !important;
			} 
			
			/* Notice Select - custom styles for sliders */
			.ap-applySaveInvest-noticeSelectGrid .ui-slider-rail {
				height: 3px;
				background: #E5E5E5;
				border: 1px solid #CCCCCC;
			}
			.ap-applySaveInvest-noticeSelectGrid .ui-slider-grippy {
				top: -7px;
			}
			/* Expandable tables expandable body section */
			/*.ap-applySaveInvest-tableBodyExpandableExtension .ui-tableBodyRowExpandableExtension--expandedContent {
				padding:10px;
			}*/
			
			.ap-applySaveInvest-wizard .ap-applySaveInvest-debitOrderQuote {
				vertical-align:	top;
				padding-top:	8px;
			}
			
			.ap-applySaveInvest-wizard .ap-applySaveInvest-beneficiaryType {
				vertical-align:	top;
				padding-top:	8px;
			}
			.ap-applySaveInvestDebitOrder-account{
		  		width:170px;
		  	}
			.ap-applySaveInvest-wizard .ap-applySaveInvestDebitOrder-firstPaymentDate-label {
				padding-left: 0px!important;
				text-align: left;
				/*color: #FF0000;*/
				/* Resonance - NEW */
				color: #AF154B;
			}
			
			/* Unit Trust Decision Tool by exps271 */
			
			.ap-applyForUnitTrust-width25 {
				width: 25%;
			}
			.ap-applyForUnitTrust-width30 {
				width: 30%;
			}
			.ap-applyForUnitTrust-width20 {
				width: 20%;
			}
			.ap-applyForUnitTrust-fondBold {
				font-weight: bold;
			}
			.ap-applyForUnitTrust-dispay {
				display: "";
			}
			.ap-applyForUnitTrust-width200 {
				width: 203px;
			}
			.ap-applyForUnitTrust-linkColor{
				/*color: RED;*/
				color: #AF154B;
			}
			.ap-applyForUnitTrust-messageLine1 {
				padding-left: 3px;
				padding-top: 5px;
			}
			.ap-applyForUnitTrust-messageLine2 {
				padding-left: 3px;	/* 21px;*/
				padding-top: 3px;
			}
			.ap-applyForUnitTrust-fontNormal {
				font-weight: normal;
			}
			
			/* Unit Trust Decision Tool by ABSD415 */
			
			.ap-unitTrustDecisionTool-investmentObjUTS .ui-slider-rail {
				width: 650px;
				height: 5px;
			}
			.ap-unitTrustDecisionTool-investmentObjUTS .ui-slider--inputContainer {
				visibility: hidden;
			}
			.ap-unitTrustDecisionTool-investmentPeriodUTS .ui-slider-rail {
				width: 650px;
				height: 5px;
			}
			.ap-unitTrustDecisionTool-investmentPeriodUTS .ui-slider--inputContainer {
				visibility: hidden;
			}
			.ap-unitTrustDecisionTool-riskLevelUTS .ui-slider-rail {
				width: 650px;
				height: 5px;
			}
			.ap-unitTrustDecisionTool-riskLevelUTS .ui-slider--inputContainer {
				visibility: hidden;
			}
			.ap-unitTrustDecisionTool-upDownSwingsUTS .ui-slider-rail {
				width: 650px;
				height: 5px;
			}
			.ap-unitTrustDecisionTool-upDownSwingsUTS .ui-slider--inputContainer {
				visibility: hidden;
			}
			.ap-unitTrustDecisionTool-paddingRight10px{
				padding-right: 10px;
			}
			

			.ap-createRenewalInstr-availableAmount{
				text-align: left;
			}
			.ap-createRenewalInstr-availableBalanceLabelAndAmount{
				padding-left: 5px;
			}
		

			.ap-homeLoan-applyPadding{
				padding-right:160px;
			}
			.ap-offersHomeLoan-additionalFunds{
				height:	20px;
				text-align: center;
				max-width:	126px;
				padding-left: 0px;
				padding-right: 0px;
			}
		

</style>

		
		
		<script type="text/javascript" src="./front_2_files/backbase.js.download"></script>
		<script type="text/javascript" src="./front_2_files/absa-all-base.js.download"></script>
		<script type="text/javascript" src="./front_2_files/absa-all-gadgets.js.download"></script>
		



	
		<script type="text/javascript">
			absa.LANG = 'en';
			absa.NONCE = '9d734fc9b335';
			absa.CONTEXT = '/absa-online';
			absa.TIMEOUT_LOGOFF = 240000; 		//240000;
			absa.TIMEOUT_BALANCE = 60000; 	//240000;
			
			absa.URL_SWITCHTOEXPRESS = "https://ib.absa.co.za/axob/j_security_autologin";
			absa.URL_SWITCHTODSP = "https://e.absa.co.za/dsp/";
			absa.URL_OSF = "https://e91.absa.co.za/osf/osf.jsp?esessionid=";
			absa.URL_OST = "https://www.absastockbrokers.co.za";
			absa.URL_AIMS = "https://www.absainvestments.co.za/OnlineRegistration/Registration.aspx";
			absa.URL_OST_LOGINURL = "https://www.absastockbrokers.co.za/MyABSAAccountLogin/";
			absa.URL_OST_LOGINLINK="https://www.absastockbrokers.co.za/MyABSAAccountTrade";
			absa.URL_OST_DomainUrl = "https://www.absastockbrokers.co.za";
			absa.URL_AIMS_DomainUrl = "https://www.absainvestments.co.za";
			absa.SHOWINTERCEPTMODAL = "";
			absa.CLIENTTYPECLASS = "ap-clientType-individual";
			absa.TRANSACTIONALUSER = "true";
			absa.SITERELOADED = "null";
			
			absa.OPERATORTYPE = "M";
			absa.CLIENTTYPE = "I";
			absa.SBU = "F";
			absa.LIMITS = "YNYNN";
			absa.CIFKEY = "NAGELMP020";
			absa.MYABSAURL = "https://myabsa.absa.co.za/ips/public/myabsa/iblogin?esessionid=";
			absa.VI = "false";
			absa.FREECOVER_LIMIT = "0";
			
			//Added for APB
			absa.APBINDICATOR = "false";
			//Added for creditLimits
			absa.CLENABLE = "true";
			absa.ODENABLE = "true";
			absa.plCT = "S,I";
			
			//Added for Spoof Container
			absa.ENABLESPOOFCONTAINER = 'true';
			absa.SPOOFCONTAINERGADGETSTOHIDE = 'g3010140,g3010161';
			
			//PS: must be enclosed in single quotes else JSON object creation breaks
			absa.FICRULES_WARN = '"warn":{"BE":"ANYN","IE":"ANYN","SE":"ANYN","B":"ANYN","I":"BNYY","S":"BNYY"}';
			absa.FICRULES_LOCK = '"lock":{"BE":"ANYN","IE":"ANYN","SE":"ANYN","B":"ANYN","I":"BYYY","S":"BYYY"}';
			
			//Express URL
			absa.EXPRESSURL = 'https://ib.absa.co.za/axob/j_security_autologin';
			absa.ENABLEEXPRESS = 'false';
			
			//Digital Sales Platform (DSP)
			absa.DIGITALSALESPLATFORMURL = 'https://e.absa.co.za/dsp/';
			absa.DIGITALSALESPLATFORMUSEGOTOSITEPIPE = 'true';
			absa.DIGITALSALESPLATFORMSAVEINVESTPRODUCTCODES = '09060~NA-IS:ABCDEFGHIJK,09005~NA-IS:ABCDEFGHIJK,09062~NA-IS:ABCDEFGHIJK,09203~NA-IS:ABCDEFGHIJK,09205~NA-IS:ABCDEFGHIJK,09207~NA-IS:ABCDEFGHIJK,09308~NA-NA:N,09001~NA-NA:N,09007~NA-NA:N,09010~NA-NA:N,09074~NA-NA:N,09203~NA-NA:N,09207~NA-NA:N,03040~NA-NA:N,03043~NA-NA:N,09501~NA-NA:N,03041~NA-NA:N,12345~NA-IS:ABCDEFGHIJK';
			
			//Feature Store URL
			absa.FEATURESTOREURL = 'https://fs.absa.co.za/featuresstore/';
			absa.ENABLEFEATURESTORE = 'false';
			absa.DODENABLEDFOR = 'SBI'
			absa.FEATURESTOREICONFORCURRENTACCOUNTONLY = 'false';
			
			//AXOB - Express
			absa.AXOB = '2';
			
			//USER IP ADDRESS
			absa.USERIP = '154.70.153.178';
			
			//GOTO - used by mainly IB to goTo specific functionality
			absa.GOTO = 'https://ib.absa.co.za/absa-online/j_auto_security_login';
			
			// Modal for private and Wealth Banking customers
			absa.ENABLEPRIVATEWEALTHMODAL = 'false';
			
			//VCL - gadgets to show DEFAULT values
			absa.VCL_LIFEPRODUCTS = "NONE";
			absa.VCL_SHORTTERMPRODUCTS = "NONE";
			
			//iPayroll
			absa.ENABLEIPAYROLL = 'false';
			
			//IE Modal
			absa.ENABLEIEMODAL = 'false';
			
			//Browser info
			absa.BROWSERINFO = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36';
			
			//IIP delay message
			absa.ENABLEIIPDELAYMESSAGE = 'true';
			
			//PPE polling
			absa.PPEPOLLINTERVAL = '5000';
			absa.PPEPOLLMAX = '12';
			
			//PPE polling
			absa.PPEPURCHASEAMOUNTMIN = '30';
			absa.PPEPURCHASEAMOUNTMAX = '1000';
			
			//Auth MAX amt recs to auth at one time
			absa.AUTHMAXRECORDS = '20';
			
			//Generic Modal - A 
			absa.GENMODALA_ENABLED = 'true';
			absa.GENMODALA_UNIQCODE = '10003';
			absa.GENMODALA_READCONFIRM = 'false';
			absa.GENMODALA_DONTSHOWAGAIN = 'true';
			absa.GENMODALA_BIS = 'IS';
			absa.GENMODALA_SBU = 'ABCDEFGHIJK';
			absa.GENMODALA_HASCLIENTINDICATEDYET = 'false';
			//Generic Modal - B 
			absa.GENMODALB_ENABLED = 'true';
			absa.GENMODALB_UNIQCODE = '10004';
			absa.GENMODALB_READCONFIRM = 'false';
			absa.GENMODALB_DONTSHOWAGAIN = 'true';
			absa.GENMODALB_BIS = 'B';
			absa.GENMODALB_SBU = 'ABCDEFGHIJK';
			absa.GENMODALB_HASCLIENTINDICATEDYET = 'false';
			
			//VCL Checks
			absa.VCLBIS = 'IS';
			absa.VCLSBU = 'ABCDEFGHIJK';
			
			//FICA status
			absa.FICA = '';
			
			//SureCheck 1.0 and 2.0  min and max times
			absa.MINUSSDTIME = '5';
			absa.MAXUSSDTIME = '60';
			absa.MINUSSD2TIME = '5';
			absa.MAXUSSD2TIME = '60';
			
			//SureCheck 2.0
			absa.ENABLESURECHECK2 = 'true';
			absa.ENABLESURECHECK2LAUNCHMODAL = 'false';
			absa.SURECHECK2SNOOZED = 'true';
			absa.SURECHECK2STATEDAYSLEFT = '60';
			absa.SURECHECK2STATEDATE = '2019-09-20';
			absa.SURECHECK2STATE = '14';
			
			absa.N2FAIDNOCHECK = 'false';
			absa.SIMSWAPPED = 'false';
			
			//TaxFreeSavings
			absa.TAXFREESAVINGSMONTHLY = '2750';
			absa.TAXFREESAVINGSLUMPSUM = '33000';
			
			//Old red app linking modal
			absa.ENABLEOLDLINKDEVICEMODAL = 'true';
			
			//AVS
			absa.AVSPOLLINTERVAL = '5000';
			absa.AVSPOLLMAXININITIALSET =  '12';
			absa.AVSPOLLMAXINREPEATSET = '6';
			absa.AVSPOLLSETMAX = '3';
			
			//Overdraft
			absa.OVERDRAFTMIN = '500';
			absa.OVERDRAFTMAX = '150000';
			
			//DSP (Digital Sales Platform)
			absa.ENABLEDSP = 'true';
			
			//VALPRE REBRAND
			absa.ENABLEBRAND = 'true';
			
			//CASHSENDPLUSREGISTER
			absa.ENABLECASHSENDPLUSREGISTER = 'false';
			
			//RBA Indicator for Insurance
			absa.RBAINDICATORFORINSURANCE = 'true';
		</script>
		<script type="text/javascript" src="./front_2_files/index.js.download"></script>
	<script type="text/javascript">xhtml={namespaceURI:"http://www.w3.org/1999/xhtml",handlers:{ieclick:function(){var a=bb.getControllerFromView(this);if(this.type=="radio"&&!a.hasAttribute("name")){this.checked=true;}if(a.__oldChecked!=this.checked){bb.command.fireEvent(a,"change",true,false);a.__oldChecked=this.checked;}},iefocusin:function(){bb.getControllerFromView(this).__oldChecked=this.checked;},change:function(){bb.command.fireEvent(bb.getControllerFromView(this),"change",true,false);},select:function(){bb.command.fireEvent(bb.getControllerFromView(this),"select",true,false);},submit:function(d){d=d||event;var c=bb.getControllerFromView(this);var a=true;try{a=!bb.command.fireEvent(c,"submit",true,true).defaultPrevented;}catch(b){a=false;}if(!a){if(d.preventDefault){d.preventDefault();}d.returnValue=false;return false;}},reset:function(){var c=bb.getControllerFromView(this);if(!bb.command.fireEvent(c,"reset",true,false).defaultPrevented&&(bb.browser.gecko||bb.browser.webkit)){var a=c.viewNode.getElementsByTagName("form");for(var b=a.length-1;b>=0;b--){a[b].reset();}}},select_focusHandler:function(){var a=bb.getControllerFromView(this);a._._initialValue=this.value;},select_blurHandler:function(){var a=bb.getControllerFromView(this);if(a._._initialValue!=this.value){xhtml.handlers.change.call(this);}},select_clickHandler:function(){var a=bb.getControllerFromView(this);a._._mouseClick=true;},select_keydownHandler:function(){var a=bb.getControllerFromView(this);a._._mouseClick=false;},select_changeHandler:function(){var a=bb.getControllerFromView(this);if(a._._mouseClick){a._._initialValue=this.value;xhtml.handlers.change.call(this);}}}};</script><script type="text/javascript">xhtml.input={DOMActivateTypes:{radio:true,checkbox:true,button:true,submit:true,reset:true}};</script><script type="text/javascript">if(!window.btl){var btl={};}btl.namespaceURI="http://www.backbase.com/2006/btl";btl.funcReturnFalse=function btl_funcReturnFalse(){return false;};btl.funcReturnTrue=function btl_funcReturnTrue(){return true;};btl.isInsideHead=function btl_isInsideHead(b,c,a){if(a&&a!=c){return false;}while(b&&b.nodeType==1){if(bb.html.hasClass(b,"btl-head")){return true;}if(b.controller==c){break;}b=b.parentNode;}return false;};btl.repaint=function btl_repaint(a){bb.html.addClass(a,"btl-repaint");setTimeout(function(){if(a){bb.html.removeClass(a,"btl-repaint");}a=null;},1);};btl.isTrueValue=function btl_isTrueValue(a,b){return b=="true"||b==a;};btl.isFalseValue=function btl_isFalseValue(a,b){return b!="true"&&b!=a;};btl.containsElement=function btl_containsElement(b,a){while(a){if(b==a){return true;}a=a.parentNode;}return false;};btl.getScrollLeft=function btl_getScrollLeft(b){var a=0;while(b){if(b.scrollLeft){a+=b.scrollLeft;}b=b.parentNode;}return a;};btl.getScrollTop=function btl_getScrollTop(a){var b=0;while(a){if(a.scrollTop){b+=a.scrollTop;}a=a.parentNode;}return b;};btl.setPrivateProperty=function btl_setPrivateProperty(a,b,c){a._["_btl_"+b]=c;};btl.getPrivateProperty=function btl_getPrivateProperty(a,b){return a._["_btl_"+b];};btl.html={};btl.html.stretch=function btl_html_stretch(l){var a=l.parentNode;l.style.height="1px";var i;var j;var d;var e;var f;var o;var c;var m=bb.html.getBoxObject(a,"content").height;var h;var p=a.firstChild;var g;while(p){var k=p.nodeType===1&&bb.html.getStyle(p,"position")!=="absolute"&&bb.html.getStyle(p,"display")!=="none";var b=p.nextSibling;if(k){var n=bb.html.getBoxObject(p);if(d===undefined){d=n.top;}if(j===undefined&&p===l){g=p;j=n.top;i=j-d;e=0;}else{if(j!==undefined&&c===undefined){c=n.top;e=n.height;}else{f=n.top;o=n.height;e=f+o-c;}}}p=b;}h=m-i-e;if(l&&h>0){btl.html.setHeight(l,h);}};btl.html.setHeight=function btl_html_setHeight(a,b){b-=bb.html.getStyle(a,"box-sizing")=="content-box"?bb.html.getBoxObject(a,"border").height-bb.html.getBoxObject(a,"content").height:0;bb.html.setStyle(a,"height",b+"px");};btl.html.setWidth=function btl_html_setWidth(a,b){b-=bb.html.getStyle(a,"box-sizing")=="content-box"?bb.html.getBoxObject(a,"border").width-bb.html.getBoxObject(a,"content").width:0;bb.html.setStyle(a,"width",b+"px");};btl.controller={};btl.controller.containsElement=function btl_controller_containsElement(b,a){while(a){a=a.getProperty("parentNode");if(b===a){return true;}}return false;};</script><script type="text/javascript">btl.drag={};btl.drag.droppables={};btl.drag.dragManager={isDragging:false,constraint:null,currentTop:null,currentLeft:null,offsetTop:null,offsetLeft:null,symbol:null,target:null,acceptDragDrop:function dragManager_acceptDragDrop(b){var a=this.acceptTarget;this.acceptTarget=b;if(this.symbol){if(b&&b.modelNode){bb.html.addClass(this.symbol,"btl-drag-target");bb.html.addClass(b.viewNode,"btl-drag-target");}else{bb.html.removeClass(this.symbol,"btl-drag-target");if(a&&a.modelNode){bb.html.removeClass(a.viewNode,"btl-drag-target");}}}},doDrag:function dragManager_doDrag(k,b,l,j,f,e,d,h,m,n,c){var g=btl.drag.dragManager;if(!g.isDragging){g.controller=k;g.target=null;g.acceptTarget=null;g.source=b;g.constraint=c;g.symbol=f;g.offsetTop=d;g.offsetLeft=e;g.currentTop=j;g.currentLeft=l;g.droppables=n&&n.length?n:null;g.allowMove=m;if(h<1){f._originalOpacity=bb.html.getStyle(f,"opacity");bb.html.setStyle(f,"opacity",h);}var a=g.currentLeft+e;var o=g.currentTop+d;if(f.offsetParent&&f.offsetParent!=document.body){var i=bb.html.getBoxObject(f.offsetParent,bb.html.getStyle(f,"position")=="absolute"?"padding":"content");a-=i.left;o-=i.top;}f.style.left=a+"px";f.style.top=o+"px";bb.html.disableUserSelect(document.body);bb.document.addEventListener("keydown",btl.drag.handleKeyDown,false);bb.document.addEventListener("mouseup",btl.drag.handleMouseUp,false);bb.document.addEventListener("mousemove",btl.drag.handleMouseMove,false);g.isDragging=true;}}};btl.drag.handleKeyDown=function drag_handleKeyDown(a){if(a.keyIdentifier&&a.keyIdentifier.toLowerCase()=="u+001b"&&btl.drag.dragManager.isDragging){a.preventDefault();btl.drag.dragManager.acceptDragDrop();btl.drag.stopDrag();}};btl.drag.handleMouseUp=function drag_handleMouseUp(a){if(a.button==0){btl.drag.stopDrag();}};btl.drag.startPoint=null;btl.drag.handleMouseMoveBeforeStart=function drag_handleMouseMoveBeforeStart(g){var e=btl.drag.dragManager;if(btl.drag.startPoint!=null){var f=6;var c=btl.drag.startPoint.startX;var a=btl.drag.startPoint.startY;var d=g.pageX;var b=g.pageY;if(c-d>f||c-d<-f||a-b>f||a-b<-f){btl.drag.startDrag(g);}}};btl.drag.startDrag=function drag_startDrag(d){if(btl.drag.startPoint&&(!btl.resize||!btl.resize.isResizing)){bb.document.removeEventListener("mousemove",btl.drag.handleMouseMoveBeforeStart,false);bb.document.removeEventListener("mouseup",btl.drag.handleMouseUpBeforeStart,false);var c=btl.drag.startPoint.startX;var a=btl.drag.startPoint.startY;var b=btl.drag.startPoint.controller;var e=bb.document.createEvent("MouseEvents");e.initMouseEvent("dragStart",true,true,d.view,d.detail,d.screenX,d.screenY,d.clientX,d.clientY,d.ctrlKey,d.altKey,d.shiftKey,d.metaKey,d.button,d.relatedTarget);e.startX=c;e.startY=a;e.viewTarget=btl.drag.startPoint.viewNode;e.dragManager=btl.drag.dragManager;b.dispatchEvent(e);}btl.drag.startPoint=null;};btl.drag.handleMouseUpBeforeStart=function drag_handleMouseUpBeforeStart(a){if(btl.drag.startPoint!=null){clearTimeout(btl.drag.dragTimeout);btl.drag.startPoint=null;bb.document.removeEventListener("mousemove",btl.drag.handleMouseMoveBeforeStart,false);bb.document.removeEventListener("mouseup",btl.drag.handleMouseUpBeforeStart,false);bb.html.enableUserSelect(document.body);}};btl.drag.handleMouseMove=function drag_handleMove(q){var k=btl.drag.dragManager;if(k.isDragging){var x=q.pageX+k.offsetLeft;var v=q.pageY+k.offsetTop;if(k.constraint){var m=bb.html.getBoxObject(k.constraint==document.body?bb.viewport:k.constraint,bb.html.getStyle(k.controller.viewNode,"position")=="absolute"?"padding":"content");var n=bb.html.getBoxObject(k.symbol);if(x<m.left||n.width>m.width){x=m.left;}else{var y=m.left+m.width-n.width;if(x>y){x=y;}}k.currentLeft=x-k.offsetLeft;if(v<m.top||n.height>m.height){v=m.top;}else{var j=m.top+m.height-n.height;if(v>j){v=j;}}k.currentTop=v-k.offsetTop;}else{k.currentLeft=q.pageX;k.currentTop=q.pageY;}var h;var p=k.symbol;var b=q.viewTarget,f=false;while(b.parentNode){if(b==p){f=true;break;}b=b.parentNode;}if(!f||k.droppables){var a,s=k.target,h;if(!k.droppables){a=q.viewTarget;}else{var w=k.currentLeft,u=k.currentTop,d=0,c=0,e=Infinity,o=Infinity,t=k.droppables;for(var r=0;r<t.length;r++){var g=t[r];if(g.offsetHeight){var l=bb.html.getBoxObject(g);if(w>=l.x&&w<=l.x+l.w&&u>=l.y&&u<=l.y+l.h){if(l.x>=d&&l.y>=c&&l.w+l.x<=e&&l.h+l.y<=o){d=l.x;c=l.y;e=l.x+l.w;o=l.y+l.h;a=g;}}}}}k.target=a;if(a!=s){if(s){h=bb.document.createEvent("Events");h.initEvent("dragLeave",false,true);h.dragInitiator=k.controller;h.dragSource=k.source;h.viewTarget=q.viewTarget;h.dragTarget=a?bb.getControllerFromView(a):null;h.dragViewTarget=a;bb.getControllerFromView(s).dispatchEvent(h);if(h.defaultPrevented){}else{k.acceptDragDrop();}}if(k.isDragging&&a){h=bb.document.createEvent("Events");h.initEvent("dragEnter",false,true);h.dragInitiator=k.controller;h.dragSource=k.source;h.viewTarget=q.viewTarget;h.dragTarget=a?bb.getControllerFromView(a):null;h.dragViewTarget=a;bb.getControllerFromView(a).dispatchEvent(h);if(k.isDragging){h=bb.document.createEvent("Events");h.initEvent("dragOver",true,true);h.dragInitiator=k.controller;h.dragSource=k.source;h.viewTarget=q.viewTarget;h.dragTarget=a?bb.getControllerFromView(a):null;h.dragViewTarget=a;bb.getControllerFromView(a).dispatchEvent(h);}}}}h=bb.document.createEvent("MouseEvents");h.initMouseEvent("drag",false,true,q.view,q.detail,q.screenX,q.screenY,q.clientX,q.clientY,q.ctrlKey,q.altKey,q.shiftKey,q.metaKey,q.button,q.relatedTarget);h.viewTarget=q.viewTarget;h.pageX=q.pageX;h.pageY=q.pageY;h.dragInitiator=k.controller;h.dragSource=k.source;h.dragTarget=a?bb.getControllerFromView(a):null;h.dragViewTarget=a;k.controller.dispatchEvent(h);if(!h.defaultPrevented&&k.symbol){if(k.symbol.offsetParent&&k.symbol.offsetParent!=document.body){var m=bb.html.getBoxObject(k.symbol.offsetParent,bb.html.getStyle(k.symbol,"position")=="absolute"?"padding":"content");x-=m.left;v-=m.top;}p.style.left=x+"px";p.style.top=v+"px";}}};btl.drag.stopDrag=function drag_stopDrag(){var a=btl.drag.dragManager;if(a.isDragging){if(a.allowMove||a.acceptTarget){if(a.symbol){bb.html.removeClass(a.symbol,"btl-drag-target");}if(a.acceptTarget){bb.html.removeClass(a.acceptTarget.viewNode,"btl-drag-target");var d=bb.document.createEvent("Events");d.initEvent("dragDrop",false,true);d.dragInitiator=a.controller;d.dragSource=a.source;a.acceptTarget.dispatchEvent(d);}if((!d||!d.defaultPrevented)&&a.allowMove){var f=a.currentLeft+a.offsetLeft;var c=a.currentTop+a.offsetTop;var g=a.controller.viewNode.bPosition?a.controller.viewNode.sPosition:bb.html.getStyle(a.controller.viewNode,"position");if(g!="absolute"&&g!="fixed"){g=a.controller.viewNode.style.position="absolute";a.controller.viewNode.bPosition=false;}if(g=="absolute"||g=="relative"){var e=a.controller.viewNode.offsetParent;if(e&&e!=document.body){var b=bb.html.getBoxObject(e,g=="absolute"?"padding":"content");f-=b.x;c-=b.y;}}a.controller.viewNode.style.left=f+"px";a.controller.viewNode.style.top=c+"px";}}bb.html.enableUserSelect(document.body);bb.document.removeEventListener("keydown",btl.drag.handleKeyDown,false);bb.document.removeEventListener("mouseup",btl.drag.handleMouseUp,false);bb.document.removeEventListener("mousemove",btl.drag.handleMouseMove,false);d=bb.document.createEvent("Events");d.initEvent("dragEnd",false,false);d.dragInitiator=a.controller;d.dragSource=a.source;a.controller.dispatchEvent(d);a.isDragging=false;}};</script><script type="text/javascript">btl.resize={};btl.resize.currentSymbol=null;btl.resize.currentElement=null;btl.resize.currentController=null;btl.resize.currentResizeEdge=0;btl.resize.isResizing=false;btl.resize.WEST=btl.resize.LEFT=1;btl.resize.EAST=btl.resize.RIGHT=2;btl.resize.NORTH=btl.resize.TOP=4;btl.resize.SOUTH=btl.resize.BOTTOM=8;btl.resize.NORTHWEST=5;btl.resize.NORTHEAST=6;btl.resize.SOUTHWEST=9;btl.resize.SOUTHEAST=10;btl.resize.HORIZONTAL=3;btl.resize.VERTICAL=12;btl.resize.ALL=15;btl.resize.cursorElement=document.createElement("div");btl.resize.cursorElement.className="btl-resize-cursorElement";document.body.appendChild(btl.resize.cursorElement);if(bb.browser.opera){btl.resize.iCursor=0;btl.resize.aCursors=[btl.resize.cursorElement];btl.resize.aCursors[1]=btl.resize.cursorElement.cloneNode(true);document.body.appendChild(btl.resize.aCursors[1]);}btl.resize.lineElement=document.createElement("div");btl.resize.lineElement.className="btl-resize-lineElement";document.body.appendChild(btl.resize.lineElement);btl.resize.outlineElement=document.createElement("div");btl.resize.outlineElement.className="btl-resize-outlineElement";document.body.appendChild(btl.resize.outlineElement);btl.resize.detectResizeEdge=function resize_detectEdge(b,i,h,e,c){var a=bb.html.getBoxObject(b);var f=i-a.left;var d=h-a.top;var j=new RegExp(e.replace(/(^\s+)|(\s+$)/g,"").replace(/ +/g,"|"),"");var g=0;if(f>=0&&d>=0&&f<=a.width&&d<=a.height){if((j.test("top")||j.test("north"))&&d<=c){g|=btl.resize.TOP;}else{if((j.test("bottom")||j.test("south"))&&d>=(a.height-c)){g|=btl.resize.BOTTOM;}}if((j.test("left")||j.test("west"))&&f<=c){g|=btl.resize.LEFT;}else{if((j.test("right")||j.test("east"))&&f>=(a.width-c)){g|=btl.resize.RIGHT;}}}btl.resize.currentResizeEdge=g;return g;};btl.resize.startResize=function resize_startResize(f,c,l,n,k,j,i,e,g,o,m){btl.resize.currentController=f;btl.resize.currentElement=c||f.viewNode;btl.resize.currentSymbol=j;btl.resize.currentResizeEdge=l;var h=bb.html.getStyle(btl.resize.currentElement,"box-sizing")=="border-box",b=bb.html.getBoxObject(btl.resize.currentElement,"border"),a;if(!h){a=bb.html.getBoxObject(btl.resize.currentElement,"content");}btl.resize.newX=btl.resize.originalX=b.left;btl.resize.newY=btl.resize.originalY=b.top;btl.resize.newW=btl.resize.originalW=h?b.width:a.width;btl.resize.newH=btl.resize.originalH=h?b.height:a.height;btl.resize.boxModelW=h?0:b.width-a.width;btl.resize.boxModelH=h?0:b.height-a.height;btl.resize.deltaX=0;btl.resize.deltaY=0;btl.resize.offsetLeft=0;btl.resize.offsetTop=0;btl.resize.originalClientX=n;btl.resize.originalClientY=k;var d=btl.resize.sendEvent(f,"resizeStart",true,true);if(d){bb.document.addEventListener("mousemove",btl.resize.handleMouseMove,false);bb.document.addEventListener("mouseup",btl.resize.handleMouseUp,false);bb.document.addEventListener("keydown",btl.resize.handleKeyDown,false);bb.document.addEventListener("click",btl.resize.handleClick,false);bb.html.disableUserSelect(document.body);btl.resize.iMinW=i||0;btl.resize.iMinH=e||0;btl.resize.iMaxW=g||20000;btl.resize.iMaxH=o||20000;btl.resize.oConstraint=m||false;if(j&&j!=c){j.style.display="";btl.resize.applyCoordinates(j,true);}btl.resize.isResizing=true;}return d;};btl.resize.cancelResize=function cancelResize(){btl.resize.newX=btl.resize.originalX;btl.resize.newY=btl.resize.originalY;btl.resize.newW=btl.resize.originalW;btl.resize.newH=btl.resize.originalH;};btl.resize.stopResize=function resize_stopResize(a){if(btl.resize.isResizing){var c=btl.resize.currentController;var b=btl.resize.sendEvent(c,"resizeEnd",true,true,a);if(!b){btl.resize.cancelResize();if(btl.resize.currentElement==btl.resize.currentSymbol){btl.resize.applyCoordinates(btl.resize.currentElement);}}btl.resize.stopAndClean();bb.ui.reflow(c,false,true);return b;}};btl.resize.applyCoordinates=function(a,k){if(a){var c=btl.resize.newX;var b=btl.resize.newY;if(a.offsetParent&&a.offsetParent!=document.body){var f=bb.html.getBoxObject(a.offsetParent,bb.html.getStyle(a,"position")=="absolute"?"padding":"content");c-=f.left;b-=f.top;}var i=a.style;if(btl.resize.currentController&&btl.resize.currentController.viewNode==a&&btl.resize.currentController.instanceOf(btl.namespaceURI,"dimensionElement")){var d=btl.resize.currentController;if(k||btl.resize.currentResizeEdge&btl.resize.LEFT){i.left=c+"px";}if(k||btl.resize.currentResizeEdge&btl.resize.TOP){i.top=b+"px";}if(k||btl.resize.currentResizeEdge&btl.resize.HORIZONTAL){d.setProperty("width",btl.resize.newW+"px");}if(k||btl.resize.currentResizeEdge&btl.resize.VERTICAL){d.setProperty("height",btl.resize.newH+"px");}}else{var e=btl.resize.newW;var j=btl.resize.newH;if(btl.resize.currentElement!=a&&bb.html.getStyle(a,"box-sizing")=="content-box"){var g=bb.html.getBoxObject(a,"border");var h=bb.html.getBoxObject(a,"content");e+=btl.resize.boxModelW-(g.width-h.width);j+=btl.resize.boxModelH-(g.height-h.height);}if(k||btl.resize.currentResizeEdge&btl.resize.LEFT){i.left=c+"px";}if(k||btl.resize.currentResizeEdge&btl.resize.TOP){i.top=b+"px";}if(k||btl.resize.currentResizeEdge&btl.resize.HORIZONTAL){i.width=e+"px";}if(k||btl.resize.currentResizeEdge&btl.resize.VERTICAL){i.height=j+"px";}}}};btl.resize.determineCoordinates=function(n,l){var m=btl.resize.currentResizeEdge;var h=btl.resize.iMinW;var d=btl.resize.iMinH;btl.resize.deltaX=n-btl.resize.originalClientX;btl.resize.deltaY=l-btl.resize.originalClientY;var g;var b=bb.html.getStyle(btl.resize.currentElement,"position")=="absolute";if(btl.resize.oConstraint){g=bb.html.getBoxObject(btl.resize.oConstraint==document.body?bb.viewport:btl.resize.oConstraint,b?"padding":"content");}btl.resize.offsetLeft=0;btl.resize.offsetTop=0;if(btl.resize.currentElement.offsetParent&&btl.resize.currentElement.offsetParent!=document.body){var k=bb.html.getBoxObject(btl.resize.currentElement.offsetParent,b?"padding":"content");btl.resize.offsetLeft=k.left;btl.resize.offsetTop=k.top;}var i=bb.html.getBoxObject(bb.viewport);if(m&btl.resize.HORIZONTAL){var f=btl.resize.originalW;var e=btl.resize.originalX;if(m&btl.resize.RIGHT){f+=btl.resize.deltaX;}else{if(m&btl.resize.LEFT){f-=btl.resize.deltaX;}}f=Math.max(f,h,1);f=Math.min(f,btl.resize.iMaxW,Math.max(i.width,bb.viewport.scrollWidth));if(m&btl.resize.LEFT){e-=(f-btl.resize.originalW);}if(e<0){e=0;}if(btl.resize.oConstraint){if(m&btl.resize.RIGHT&&m&btl.resize.LEFT){e=g.left;f=Math.min(f,btl.resize.iMaxW,g.width);}else{if(e<g.left){f-=g.left-e;e=g.left;}else{if(e>(g.left+g.width-h)){e=(g.left+g.width-h);}}var j=g.left+g.width-e-btl.resize.boxModelW;if(f<h){f=h;}else{if(f>j){f=j;}}}}btl.resize.newX=e;btl.resize.newW=f;}if(m&btl.resize.VERTICAL){var o=btl.resize.originalH;var c=btl.resize.originalY;if(m&btl.resize.BOTTOM){o+=btl.resize.deltaY;}else{if(m&btl.resize.TOP){o-=btl.resize.deltaY;}}o=Math.max(o,d,1);o=Math.min(o,btl.resize.iMaxH,Math.max(i.height,bb.viewport.scrollHeight));if(m&btl.resize.TOP){c-=(o-btl.resize.originalH);}if(c<0){c=0;}if(btl.resize.oConstraint){if(m&btl.resize.TOP&&m&btl.resize.BOTTOM){c=g.top;o=Math.min(o,btl.resize.iMaxH,g.height);}else{if(c<g.top){o-=g.top-c;c=g.top;}else{if(c>(g.top+g.height-d)){c=(g.top+g.height-d);}}var a=g.top+g.height-c-btl.resize.boxModelH;if(o>a){o=a;}if(o<d){o=d;}}}btl.resize.newY=c;btl.resize.newH=o;}};btl.resize.sendEvent=function sendEvent(d,g,b,e,c){if(c){var f=bb.document.createEvent("MouseEvents");f.initMouseEvent(g,Boolean(b),Boolean(e),c.view,c.detail,c.screenX,c.screenY,c.clientX,c.clientY,c.ctrlKey,c.altKey,c.shiftKey,c.metaKey,c.button,c.relatedTarget);f.pageX=c.pageX;f.pageY=c.pageY;f.viewTarget=c.viewTarget;}else{var f=bb.document.createEvent("Events");f.initEvent(String(g),Boolean(b),Boolean(e));}f.resizeEdge=btl.resize.currentResizeEdge;var a=[];if(btl.resize.currentResizeEdge&btl.resize.VERTICAL){a.push("vertical");}if(btl.resize.currentResizeEdge&btl.resize.HORIZONTAL){a.push("horizontal");}if(btl.resize.currentResizeEdge&btl.resize.LEFT){a.push("left");}if(btl.resize.currentResizeEdge&btl.resize.TOP){a.push("top");}if(btl.resize.currentResizeEdge&btl.resize.RIGHT){a.push("right");}if(btl.resize.currentResizeEdge&btl.resize.BOTTOM){a.push("bottom");}f.resizeEdges=a.length?a.join(" "):"none";f.originalLeft=this.originalX;f.originalTop=this.originalY;f.originalWidth=this.originalW;f.originalHeight=this.originalH;f.newLeft=this.newX;f.newTop=this.newY;f.newWidth=this.newW;f.newHeight=this.newH;f.deltaX=this.deltaX;f.deltaY=this.deltaY;f.offsetLeft=this.offsetLeft;f.offsetTop=this.offsetTop;d.dispatchEvent(f);return !f.defaultPrevented;};btl.resize.stopAndClean=function resize_stopAndClean(){if(btl.resize.isResizing){bb.document.removeEventListener("mouseup",btl.resize.handleMouseUp,false);bb.document.removeEventListener("mousemove",btl.resize.handleMouseMove,false);bb.document.removeEventListener("keydown",btl.resize.handleKeyDown,false);bb.document.removeEventListener("click",btl.resize.handleClick,false);bb.html.enableUserSelect(document.body);if(btl.resize.currentSymbol&&btl.resize.currentSymbol!=btl.resize.currentElement){btl.resize.currentSymbol.style.display="none";}btl.resize.outlineElement.style.top="-10000px";btl.resize.lineElement.style.top="-10000px";btl.resize.currentSymbol=null;btl.resize.currentElement=null;btl.resize.currentController=null;btl.resize.currentResizeEdge=0;btl.resize.isResizing=false;}};btl.resize.positionCursor=function positionCursor(c,a,d,b){a=(a>bb.viewport.scrollWidth-50?bb.viewport.scrollWidth-50:a)-50;d=(d>bb.viewport.scrollHeight-50?bb.viewport.scrollHeight-50:d)-50;if(b&&b!=btl.resize.cursorElement.style.cursor){if(bb.browser.opera){btl.resize.cursorElement.style.left="-100px";btl.resize.cursorElement.style.top="-100px";btl.resize.cursorElement=btl.resize.aCursors[btl.resize.iCursor=++btl.resize.iCursor%2];}btl.resize.cursorElement.style.cursor=b;}btl.resize.cursorElement.style.left=a+"px";btl.resize.cursorElement.style.top=d+"px";btl.resize.cursorElement.controller=c;};btl.resize.handleMouseMove=function handleMouseMove(b){var a={newX:btl.resize.newX,newY:btl.resize.newY,newW:btl.resize.newW,newH:btl.resize.newH};btl.resize.determineCoordinates(b.pageX,b.pageY);if(btl.resize.sendEvent(btl.resize.currentController,"resize",false,true,b)){btl.resize.applyCoordinates(btl.resize.currentSymbol);if(btl.resize.currentSymbol==btl.resize.currentElement){bb.ui.reflow(btl.resize.currentController,false,true);}}else{btl.resize.newX=a.newX;btl.resize.newY=a.newY;btl.resize.newW=a.newW;btl.resize.newH=a.newH;}};btl.resize.handleMouseUp=function resize_handleMouseUp(a){if(a.button==0){a.preventDefault();a.stopImmediatePropagation();btl.resize.stopResize(a);}};btl.resize.handleClick=function handleClick(a){if(a.button==0){a.stopImmediatePropagation();a.preventDefault();bb.document.removeEventListener("click",arguments.callee,true);}};btl.resize.handleKeyDown=function handleKeyDown(a){if(a.keyIdentifier=="U+001B"){a.preventDefault();var b=btl.resize.currentController;btl.resize.cancelResize();btl.resize.sendEvent(b,"resizeEnd",true,true);if(btl.resize.currentElement==btl.resize.currentSymbol){btl.resize.applyCoordinates(btl.resize.currentElement);}btl.resize.stopAndClean();}};</script><script type="text/javascript">portal.TEMPLATE_NAME=/__GADGET__/g;portal.LAYOUT_CHECK_TIMEOUT=40;portal.GADGET_PLACEHOLDER="gadget-placeholder";portal.GADGET_UNMANAGED="unmanaged";portal.overRideAnimation=false;portal._autoRefresh={list:[],startTime:new Date(),poolingInterval:60,queueInterval:5,poolingId:0,set:function set(a,c){if(isNaN(c)){c=0;}var d=-1;for(var b=0;b<this.list.length&&d<0;b++){if(a==this.list[b][0]){d=b;}}if(d>=0){if(c){this.list[d][1]=c;return true;}else{this.list.splice(d,1);}}else{if(c){this.list.push([a,c]);return true;}}return false;},queue:[],start:function start(){var a=this;this.queue=[];this.poolingId=setInterval(function b(){var e=Math.round((new Date()-a.startTime)/60000);var f,c;if(a.queue.length){return;}for(var d=0;d<a.list.length;d++){c=a.list[d][0];if(!c||!c._){a.list.splice(d--,1);continue;}if(e%a.list[d][1]===0){a.queue[a.queue.length]=c;}}if(a.queue.length){(function(){if(a.queue.length){var l=Math.round((new Date()-a.startTime)/1000);var k,g,j=Math.round((60-l%60)/a.queueInterval);for(var h=j>0?Math.ceil(a.queue.length/j):a.queue.length;a.queue.length&&h>0;h--){g=a.queue.pop();if(g&&g._){g.refresh();}}}if(a.queue.length){setTimeout(arguments.callee,a.queueInterval*1000);}})();}},a.poolingInterval*1000);},stop:function stop(){if(this.poolingId){this.queue=[];clearInterval(this.poolingId);}}};portal._autoRefresh.start();portal._getGadgetDimensions=function _getGadgetDimensions(a){return{top:a.absoluteTop,left:a.parentColumn?a.parentColumn.pixLeft:0,width:portal._getGadgetWidth(a.parentColumn,a),height:100};};portal._getGadgetWidth=function _getGadgetWidth(b,c){var a=c.colSpan?portal._calculateColSpanWidth(b,c):b.pixWidth;if(bb.html.getStyle(c,"box-sizing")=="content-box"){a-=portal._getBorderPaddingWidth(c);}return a;};var oldConvert=bb.html.convertToPixels;bb.html.convertToPixels=function convertToPixels(){return oldConvert.apply(this,arguments);};var oldGetStyle=bb.html.getStyle;bb.html.getStyle=function getStyle(){return oldGetStyle.apply(this,arguments);};portal._getBorderPaddingWidth=function _getBorderPaddingWidth(a){var b=a.offsetWidth-a.clientWidth;b+=bb.html.convertToPixels(bb.html.getStyle(a,"padding-left"),a);b+=bb.html.convertToPixels(bb.html.getStyle(a,"padding-right"),a);return b;};portal._getNodeWidth=function _getNodeWidth(b){var a=b.offsetWidth;return bb.html.getStyle(b,"box-sizing")=="content-box"?a-portal._getBorderPaddingWidth(b):a;};portal._getMaximizedGadgetWidth=function _getMaximizedGadgetWidth(b,a){var c=b.viewGate.offsetWidth-portal._getBorderPaddingWidth(b.viewGate);if(bb.html.getStyle(a.viewNode,"box-sizing")=="content-box"){c-=portal._getBorderPaddingWidth(a.viewNode);}return c;};portal._getGadgetHeight=function _getGadgetHeight(d,f){if(f.colSpanItem){return portal._getGadgetHeight(f.colSpanItem.parentColumn,f.colSpanItem);}if(!f.offsetHeight){return 0;}var c=portal._getGadgetWidth(d,f);if(!c||!f.offsetHeight||c==portal._getNodeWidth(f)){return f.offsetHeight;}var e,a=f.style.width;bb.html.setStyle(f,"width",c+"px");if(f.controller){var b=bb.document.createEvent("CustomEvent");b.initEvent("resize",false,false);f.controller.dispatchEvent(b);}e=f.offsetHeight;bb.html.setStyle(f,"width",a);return e;};portal._getGadgetNextTop=function _getGadgetNextTop(b,d,a,e){if(d){var c=portal._getGadgetHeight(b,d);if(c!=0){c+=e;}a=d.absoluteTop+c;}return a;};portal._calculateColSpanTop=function _calculateColSpanTop(f,e,g){if(f.colSpan&&f.colSpanItems){for(var c=0;c<f.colSpan;c++){var b=f.colSpanItems[c];if(b&&b.parentColumn){if(b.parentColumn==f.parentColumn){break;}var d=b.parentColumn;var a=portal._getGadgetNextTop(d,d.items[bb.array.indexOf(d.items,b)-1],0,g);if(a>e){e=a;}}}}else{if(f.colSpanItem){e=portal._calculateColSpanTop(f.colSpanItem,e,g);}}return e;};portal._updateColSpan=function _updateColSpan(d,f,e){if(f.colSpanItem){return;}if(!("colSpanMax" in f)){f.colSpanMax=0;}if(f.colSpanMax<e){e=f.colSpanMax;}var a=Math.min(f.colSpanItems instanceof Array?f.colSpanItems.length:0,f.colSpanMax);if(f.colSpanMax<a){while(f.colSpanItems.length>f.colSpanMax){var c=f.colSpanItems.pop();if(c&&c.parentColumn){d.removeFromColumn(c);}}a=f.colSpanMax;}f.colSpan=a;if(f.colSpan>e){for(var b=e;b<f.colSpan;b++){var c=f.colSpanItems[b];if(c&&c.parentColumn){d.removeFromColumn(c);}}f.colSpanItems.splice(e,f.colSpan-e);f.colSpan=e;f.style.width=portal._getGadgetWidth(f.parentColumn,f)+"px";}else{if(e>f.colSpan){var g=f.parentColumn,b=0;while(b++<f.colSpan){g=g.nextColumn;}if(!f.colSpanItems){f.colSpanItems=[];}for(b=f.colSpan;b<e;b++){g=g.nextColumn;if(!g){break;}if(!f.colSpanItems[b]){f.colSpanItems[b]={colSpanItem:f,iInitIndex:0};}d.appendToColumn(g,f.colSpanItems[b],0);f.colSpan++;}}}};portal._calculateColSpanWidth=function _calculateColSpanWidth(d,e){var a=d;for(var b=0,c=d;c&&b<e.colSpan;b++){c=a.nextColumn;if(c){a=c;}}return a.pixLeft+a.pixWidth-d.pixLeft;};portal._applyColumnWidth=function _applyColumnWidth(a,f,c,e){var g;var h=a.getSetting("gadgetWindowMargin","integer");var b=a.getSetting("animationSpeed","integer");while(g=f.items[c++]){g.absoluteTop=e;if(!g.colSpanItem&&(f.pixLeft||f.pixWidth)){var d=portal._getGadgetWidth(f,g);if(b===0){bb.html.setStyle(g,"top",e+"px");bb.html.setStyle(g,"left",f.pixLeft+"px");bb.html.setStyle(g,"width",d+"px");}else{g.iAniTop=bb.smil.animate(g,{attributeName:"top",dur:b+"ms",to:e+"px",fill:"freeze"});bb.smil.animate(g,{attributeName:"left",dur:b+"ms",to:f.pixLeft+"px",fill:"freeze"});bb.smil.animate(g,{attributeName:"width",dur:b+"ms",to:d+"px",fill:"freeze"});}}e=portal._getGadgetNextTop(f,g,0,h);e=portal._calculateColSpanTop(g,e,h);}};portal._getColumnWidth=function _getColumnWidth(c,e,b){var d=portal._getNodeWidth(c.viewGate);if(e.cachedTotalWidth!==d){var f=c.getSetting("gadgetWindowMargin","integer");e.cachedTotalWidth=d;var a=0;if(e.width.match(/%$/)){d-=(f*(b-1));a=Math.round(parseFloat(e.width)/100*d);}else{a=parseInt(e.width);}e.cachedWidth=a;}return e.cachedWidth;};portal._layoutHeightChecker=function _layoutHeightChecker(h){if(h&&h._&&!h.pauseLayout){var a=h.getProperty("activeContainer");var o=a?a._._columns||[]:[];var v=0;var p=h.getSetting("gadgetWindowMargin","integer");var d=0;var k,x=0;if(a&&a._._maximizedGadget){var c=a._._maximizedGadget;c.viewNode.style.top=c.viewNode.style.left="0px";if(bb.html.getBoxObject(h.viewGate,"content").width!=bb.html.getBoxObject(c.viewNode,"border").width){bb.html.setStyle(c.viewNode,"width",portal._getMaximizedGadgetWidth(h,c)+"px");var n=bb.document.createEvent("CustomEvent");n.initEvent("resize",false,false);c.dispatchEvent(n);}if(c.getSetting("maximizedMode")=="exactfit"){var e=bb.html.getBoxObject(bb.viewport);var g=bb.html.getBoxObject(c.viewGate,"content");var s=bb.html.getBoxObject(c.viewNode);var q=0;var u=bb.html.getBoxObject(h.viewNode,"content");q=document.body.offsetHeight-(u.top+u.height)+4;var l=g.top-((g.top+g.height)-(s.top+s.height));var b=(e.height-l-q);if(b<400){b=400;}if(b!=c.viewGate.offsetHeight){c.viewGate.style.height=b+"px";var n=bb.document.createEvent("CustomEvent");n.initEvent("resize",false,false);c.dispatchEvent(n);}}else{if(c.viewGate.style.height){c.viewGate.style.height="";}}v=c.viewNode.offsetHeight;}else{while(k=o[x++]){var w=portal._getColumnWidth(h,k,o.length);if(k.pixLeft!=d||k.pixWidth!=w){k.isChanged=true;k.pixLeft=d;k.pixWidth=w;}d+=w+p;}var k,x=0;while(k=o[x++]){var r=k.items,t=0,m,f=null,l=0;while(m=r[t++]){if(k.isChanged&&!m.colSpanItem){bb.html.setStyle(m,"left",k.pixLeft+"px");bb.html.setStyle(m,"width",portal._getGadgetWidth(k,m)+"px");if(m.controller){var n=bb.document.createEvent("CustomEvent");n.initEvent("resize",false,false);m.controller.dispatchEvent(n);}}if(m.colSpanItem){l=m.absoluteTop=m.colSpanItem.absoluteTop;}else{l=portal._getGadgetNextTop(k,f,l,p);l=portal._calculateColSpanTop(m,l,p);if(l!==m.absoluteTop){if(m.iAniTop){bb.smil.stop(m.iAniTop);m.iAniTop=null;}bb.html.setStyle(m,"top",l+"px");m.absoluteTop=l;}}v=Math.max(l+portal._getGadgetHeight(k,m),v);f=m;}delete k.isChanged;}}if(v!==h.viewGate.cachedHeight){h.viewGate.cachedHeight=v;h.viewGate.style.height=v+"px";}}};portal._object=function portal_object(b){if(b instanceof Object){var c=this.copy(b);for(var a in c){if(c.hasOwnProperty(a)){this[a]=c[a];}}}};portal._object.prototype={};portal._object.prototype.copy=function portal_object_copy(d){var b;if(!arguments.length){d=this;}if(d instanceof Array){b=[];for(var c=0;c<d.length;c++){b[c]=arguments.callee(d[c]);}}else{if(d instanceof Object){b={};for(var a in d){if(d.hasOwnProperty(a)){b[a]=arguments.callee(d[a]);}}}else{if(typeof d=="function"){}else{b=d;}}}return b;};portal._object.prototype.equals=function portal_object_equals(c,a){if(c instanceof Object){for(var b in this){if(this.hasOwnProperty(b)&&!(b in c)){return false;}}for(var b in c){if(c.hasOwnProperty(b)){if(!(b in this)){return false;}else{if(this[b] instanceof Object){if(!portal._object.prototype.equals.call(this[b],c[b],a)){return false;}}else{if(a&&this[b]!==c[b]){return false;}else{if(this[b]!=c[b]){return false;}}}}}}return true;}return a?(c===this):(c==this);};(function(){var o="http://www.backbase.com/2008/gadget",r="http://www.backbase.com/2006/tdl",a="http://www.w3.org/1999/xhtml";function c(s){s=s||{};this.requireSubmit=false;this.preferences={};this.handlers={};this.includes=[];this.src=String(s.src);this.content="";this.icon="";this.title="";this.htmlClass="";this.htmlStyle="";this.bodyClass="";this.bodyStyle="";this.noVisiblePreferences=true;this.isLoaded=Boolean(s.isLoaded)||false;this.callbackQueue=[];if(!this.isLoaded){this.requiresQueue={internal:false};}}c.prototype.executeWhenReady=function(t){if(this.isLoaded){var s=this;setTimeout(function(){t(s);},1);}else{this.callbackQueue.push(t);}};c.prototype.build=function(s){if(this.isLoaded){return;}var E=s.documentElement;var Q=s.getElementsByTagName("head")[0];var D=s.getElementsByTagName("body")[0];if(Q){var A=Q.getElementsByTagName("*"),w=0,K,v=[],C,y=[];while(K=A[w++]){C=K.getAttribute("name");switch(K.namespaceURI){case"http://www.backbase.com/2008/gadget":switch(portal.xml.getLocalName(K)){case"preferences":this.requireSubmit=K.getAttribute("requireSubmit")=="true";break;case"preference":this.preferences[C]={type:K.getAttribute("type"),"default":K.getAttribute("default")||"",label:K.getAttribute("label"),onchange:K.getAttribute("onchange"),values:[]};if(this.preferences[C].type=="range"){var L=parseInt(K.getAttribute("min"),10);var M=parseInt(K.getAttribute("max"),10);var F=parseInt(K.getAttribute("step"),10)||1;for(var O=L;O<=M;O=O+F){this.preferences[C].values.push({value:O});}}break;case"enumeration":var R={value:K.getAttribute("value")||K.textContent||K.text};R.label=K.getAttribute("label")||R.value;this.preferences[K.parentNode.getAttribute("name")].values.push(R);break;default:throw"Unknown element in gadget definition "+K.nodeName;break;}break;case"http://www.w3.org/1999/xhtml":switch(portal.xml.getLocalName(K)){case"style":v.push(K.textContent||K.text||"");break;case"link":var N=K.getAttribute("href");if(N){if(N.match(/standalone\.css$/)){break;}N=bb.uri.resolveUri(N,this.src);var J=K.getAttribute("rel");if(J=="icon"){this.icon=N;}else{if(J=="stylesheet"){if(!e[N]){e[N]={loaded:true,src:N};var x=document.createElement("link");x.type="text/css";x.rel=J;x.href=N;document.head.appendChild(x);}}}}break;case"script":var N=K.getAttribute("src");if(!N){N=K.textContent||K.text||"";if(N.length){f(this,N,"internal_javascript");}}else{if(N.match(/standalone\.js$/)||N.match(/engine\/backbase\.js$/)){break;}f(this,bb.uri.resolveUri(N,this.src),"external_javascript");}break;case"title":this.title=bb.xml.serialize(K,true);break;}break;}}var z=v.join("");if(z.length){bb.html.addStyleSheet(i(z,this.src));}}var A=D.getElementsByTagName("*"),w=0,K,u;while(K=A[w++]){switch(K.namespaceURI){case"http://www.w3.org/1999/xhtml":var P=portal.xml.getLocalName(K);switch(P){case"area":case"a":u=K.getAttribute("href");if(u&&u.indexOf("://")<0){K.setAttribute("href",bb.uri.resolveUri(u,this.src));}break;case"img":case"input":case"iframe":u=K.getAttribute("src");if(u&&u.indexOf("://")<0){var H=bb.uri.resolveUri(u,this.src);if(P=="iframe"&&bb.browser.gecko){var G=K.ownerDocument.createElement("dummy");K.parentNode.replaceChild(G,K);K.setAttribute("src",H);G.parentNode.replaceChild(K,G);}else{K.setAttribute("src",H);}}break;case"form":u=K.getAttribute("action");if(u&&u.indexOf("://")<0){K.setAttribute("action",bb.uri.resolveUri(u,this.src));}break;case"script":if(K.getAttribute("type")=="text/backbase+xml"||K.getAttribute("type")=="application/backbase+xml"||K.getAttribute("type")=="application/backbase+ssr"){K.setAttribute("xml:base",this.src);m(K);}else{bb.command.trace(null,'Script tag with type "'+K.getAttribute("type")+'" than text/backbase+xml detected in body of gadget. This script tag is ignored');}break;}break;}}this.buildTDL(D);this.buildIncludes(D);for(var O in this.preferences){if(this.preferences[O]["type"]!="hidden"&&this.preferences[O]["type"]!="readonly"){this.noVisiblePreferences=false;break;}}this.content=bb.string.trim(bb.xml.serialize(D,true).replace(/<([\w:]+)([^>]*)\/>/gi,"<$1$2></$1>"));this.htmlClass=E.getAttribute("class");this.htmlStyle=E.getAttribute("style");this.bodyClass=D.getAttribute("class");this.bodyStyle=D.getAttribute("style");var t=D.attributes;for(var w=0,I,B;I=t[w];w++){B=portal.xml.getLocalName(I);if(I.namespaceURI=="http://www.backbase.com/2008/gadget"&&B.substr(0,2)=="on"){this.handlers[B.substr(2)]=I.nodeValue;}}l(this.src,"internal");};c.prototype.buildTDL=function(t){var w=bb.xml.getElementsByTagNameNS(t,r,"tdl").concat(bb.xml.getElementsByTagNameNS(t,r,"namespace")),s=c.builders[r],v=0,u=null;while(u=w[v++]){s[portal.xml.getLocalName(u)].call(this,u);}};c.prototype.buildIncludes=function(t){var v=bb.xml.getElementsByTagNameNS(t,o,"include"),s=c.builders[o]["include"],u=null,w=0;while(u=v[w++]){this.includes.push(s(u));}};c.prototype.executeQueue=function(){var s=this.callbackQueue;while(s.length){s.shift().apply(this,arguments);}};c.builders={};c.builders[o]={};c.builders[o]["include"]=function(u){var t=u.ownerDocument.createElement("div"),v=new portal.gadget.IncludeConfig({url:String(u.getAttribute("src")||""),proxy:(u.getAttribute("proxy")||"").toLowerCase()=="true",method:(u.getAttribute("method")||"GET").toUpperCase()});for(var s=0,w=null;s<u.childNodes.length;++s){w=u.childNodes[s];var x=portal.xml.getLocalName(w);if(w.namespaceURI==o&&/http-(proxy-)?param/.test(x)){v.httpParams.add(new portal.gadget.HttpParam(w.getAttribute("name"),w.getAttribute("value"),x=="http-proxy-param"?"proxy":"target",w.getAttribute("method")));}else{if(w.namespaceURI==o&&x=="http-preference-param"){v.httpParams.add(new portal.gadget.HttpPreferenceParam(w.getAttribute("name"),w.getAttribute("method")));}else{if(w.nodeType!=1||w.namespaceURI==a){t.appendChild(w.cloneNode(true));}}}}t.setAttribute("class",portal.gadget.IncludeConfig.CSS_CLASS);u.parentNode.replaceChild(t,u);return v;};c.builders[r]={};c.builders[r]["tdl"]=c.builders[r]["namespace"]=function(s){s.setAttribute("xml:base",this.src);m(s);return bb.construct(s);};var g={};g["about:blank"]=g[""]=new c({src:"about:blank",isLoaded:true});portal._unload=function(){g=null;e=null;q=null;};var e={};var q=[];var h=null;var p=false;function f(A,t,s){A.requiresQueue[t]=false;var y=A.src;if(!p){p=true;var z=document.getElementsByTagName("script"),u,w=0,B;while(u=z[w++]){if(B=u.src){if(B.indexOf("://")<0){B=bb.uri.resolveUri(B,bb.document.getProperty("baseURI"));}e[B]={loaded:true,src:B};}}var x=document.getElementsByTagName("link"),v,w=0;while(v=x[w++]){if(B=v.href){if(B.indexOf("://")<0){B=bb.uri.resolveUri(B,bb.document.getProperty("baseURI"));}e[B]={loaded:true,src:B};}}}var C=e[t];if(C){if(C.loaded){setTimeout(function(){l(y,t);},1);}else{C.queue.push(y);}}else{q.push([y,t,s]);if(q.length==1){b(q[0]);}}}function b(s){var v=s[0];var t=s[1];var y=s[2];var x={};x.loaded=false;x.src=t;x.queue=[v];e[t]=x;h=x;var w=document.getElementsByTagName("head")[0];switch(y){case"internal_javascript":t=t+";\nportal.loadExternalQueueReadyHelper();";if(bb.browser.ie){window.execScript(t);}else{var u=document.createElement("script");u.type="text/javascript";u.appendChild(document.createTextNode(t));w.appendChild(u);}break;case"external_javascript":var u=document.createElement("script");u.type="text/javascript";if(!bb.browser.opera){u.onreadystatechange=function(){if(this.readyState=="loaded"||this.readyState=="complete"){portal.loadExternalQueueReadyHelper();}};}u.onerror=u.onload=portal.loadExternalQueueReadyHelper;if(bb.browser.opera){setTimeout(function(){u.src=t;},0);}else{u.src=t;}w.appendChild(u);break;}}portal.loadExternalQueueReadyHelper=function(){var t=h;if(!t||t.loaded){return;}t.loaded=true;var s;while(s=t.queue.shift()){l(s,t.src);}h=null;q.shift();if(q.length){b(q[0]);}};function l(t,s){var v=g[t];if(s){v.requiresQueue[s]=true;}for(var u in v.requiresQueue){if(v.requiresQueue[u]==false){return;}}v.isLoaded=true;v.executeQueue(v);}function m(z,s){var A={};var x=z;if(!s){s=z;x=z.parentNode;}while(x){var v=x.attributes,u=0,y;if(v){while(y=v[u++]){if(y.namespaceURI=="http://www.w3.org/2000/xmlns/"||(!y.namespaceURI&&y.prefix=="xmlns")){var w=String(y.nodeName).toLowerCase();if(!(w in A)){A[w]=y.nodeValue;}}}}x=x.parentNode;}for(var t in A){if("setAttributeNS" in s){if(!s.getAttributeNS("http://www.w3.org/2000/xmlns/",t)){s.setAttributeNS("http://www.w3.org/2000/xmlns/",t,A[t]);}}else{if(!s.getAttribute(t)){s.setAttribute(t,A[t]);}}}}var n=/url\s*\([^;}]+\)/gi;var d=/(url\s*)\(\s*(['"]?)(.+)['"]?\s*\)/i;var k=/@import\s+['"][^'"]+['"]/gi;var j=/(@import\s+['"])([^'"]+)(['"])/i;function i(x,w){var v=x.match(n),u,t,s;if(v){for(t=0,s=v.length;t<s;t++){u=v[t].match(d);x=x.replace(u[0],"url('"+bb.uri.resolveUri(u[3].replace(/('|")$/,""),w)+"')");}}v=x.match(k);if(v){for(t=0,s=v.length;t<s;t++){u=v[t].match(j);x=x.replace(u[0],u[1]+bb.uri.resolveUri(u[2],w)+u[3]);}}return x;}portal._getButtons=function(y,A){var s=y.split(",");var w=0;var x,v=[];while(x=s[w++]){x=x.split(";");var u=A+" "+A+"-"+x[0];var z="";if(x[1]){z=' title="'+portal.getLocale(x[1])+'"';}var t="";if(x[2]){u+=" "+A+"-text";t=portal.getLocale(x[2]);}v.push('<a class="',u,'"',z,' href="javascript:void(0)">',t,"</a>");}return v;};portal._getButtonType=function(s,t){return s.className.match(new RegExp(t+" "+t+"-([^- ]{1,})"))[1];};portal._getButtonClass=function(s,u,t){return u+"-"+this._getButtonType(s,u)+(arguments.length>2?t:"");};portal._gatherValueFromInput=function(x){switch(x.type){case"select-multiple":var t=[];for(var s=0;s<x.options.length;s++){if(x.options[s].selected){t.push(String(x.options[s].value));}}return t.join(",");break;case"radio":case"checkbox":var t=[];var v=x.form.elements;var w,u=0;while(w=v[u++]){if(w.name==x.name&&w.checked){if(x.type=="radio"){return String(w.value);}else{t.push(String(w.value));}}}return t.join(",");break;case"text":case"password":case"textarea":case"select-one":default:return String(x.value);}};portal.setGadgetClass=function(v,t){var s=bb.uri.resolveUri(v,bb.document.getProperty("baseURI"));var u=g[s];if(true){g[s]=u=new c({src:s});u.build(t);}};portal.getGadgetClass=function(v,u){var s=bb.uri.resolveUri(v,bb.document.getProperty("baseURI"));var t=g[s];if(!t){g[s]=t=new c({src:s});gadgets.io.makeRequest(s,function(w){if(w.errors.length){t.executeQueue(false);return delete g[s];}var x=bb.xml.parse(w.text,true);if(!x||!x.documentElement||!x.getElementsByTagName("body")[0]){t.executeQueue(false);return delete g[s];}t.build(x);},{type:"xml"});}if(u){t.executeWhenReady(u);}};})();</script><script type="text/javascript">portal.ssr={};portal.ssr.namespaceURI="http://www.backbase.com/2009/ssr";portal.ssr.Error=function(a){this.toString=function(){return"[SSR Error: "+a+"]";};};portal.ssr.ElementNotFoundError=function(a){portal.ssr.Error.call(this,"The template with id '"+a+"' was not found in the document!");};portal.ssr.tryToGetElementById=function(a){var b=document.getElementById(a);if(!b){throw new portal.ssr.ElementNotFoundError(a);}return b;};portal.ssr.readGadgetClasses=function(b){var c=b.firstChild,a="";while(c){if(c.nodeType==1){a=c.getAttribute("src");if(a){portal.setGadgetClass(a,bb.xml.parse(c.textContent?c.textContent:c.innerHTML,true));}}c=c.nextSibling;}};</script><script type="text/javascript">portal.navigation={};(function(){var k="http://www.backbase.com/2009/portal/navigation";function h(q,p,r){this.collection=q;if(r&&p){this.test=function(s){return(portal.xml.getLocalName(s)==r&&s.namespaceURI==p);};}else{if(p){this.test=function(s){return(s.namespaceURI==p);};}}}h.prototype.each=function(q){var p=this.collection,s=null;for(var r=0;r<p.length;++r){s=p[r];s.nodeType==1&&this.test(s)&&q(s);}};h.prototype.test=function(p){return true;};function f(){}f.prototype.execute=function(p,q){};f.prototype.executeWhenReady=function(p,q){};function n(p){this._container=p;f.call(this);}n.prototype=new f();n.prototype.getContainer=function(q,t){var u=q.getProperty("containers"),s=null,p=0,r=t.apply(this._container);while(s=u[p++]){if(s.getProperty("templateId")==r){return s;}}s=q.createContainer(null,null,null,r);q.addContainer(s,null,false);return s;};n.prototype.executeWhenReady=function(q,r){var p=this.getContainer(q,r),s=this;if(p.getProperty("loaded")){s.execute(p,q,r);}else{p.addEventListener("load",function(){s.execute(p,q,r);this.removeEventListener("load",arguments.callee,false);},false);}};function b(p){n.call(this,p);}b.prototype=new n();b.prototype.execute=function(r,p,q){r&&p.activateContainer(r);};function d(p){n.call(this,p);}d.prototype=new n();d.prototype.execute=function(r,p,q){var s=r?r.getProperty("maximizedGadget"):null;s&&s.restore();};function o(p,q,r){this._name=q;this._value=r;n.call(this,p);}o.prototype=new n();o.prototype.execute=function(r,p,q){r&&r.setPreference(q.apply(this._name),q.apply(this._value));};function i(q,s,r,p){this._type=s;this._cancelable=p||false;this._bubbles=r||false;n.call(this,q);}i.prototype=new n();i.prototype.createEvent=function(){var p=bb.document.createEvent("CustomEvent");p.initEvent(this._type,this._cancelable,this._bubbles);return p;};i.prototype.execute=function(r,p,q){r&&r.dispatchEvent(this.createEvent());};function g(q,p){this._gadget=p;n.call(this,q);}g.prototype=new n();g.prototype.getGadget=function(r,t){var q=t.apply(this._gadget),s=this.getContainer(r,t),v=s.getGadgetsByTemplateId(q),p=null,u=0;while(p=v[u++]){p.load();return p;}p=r.createGadget(null,null,null,q);r.addGadget(p,s,{col:s.getSmallestColumn()});return p;};g.prototype.executeWhenContainerIsReady=function(q,r){var p=this.getGadget(q,r),s=this;if(p.getProperty("loaded")){s.execute(p,q,r);}else{p.addEventListener("load",function(){s.execute(p,q,r);this.removeEventListener("load",arguments.callee,false);},false);}};g.prototype.executeWhenReady=function(q,r){var p=this.getContainer(q,r),s=this;if(p.getProperty("loaded")){s.executeWhenContainerIsReady(q,r);}else{p.addEventListener("load",function(){s.executeWhenContainerIsReady(q,r);this.removeEventListener("load",arguments.callee,false);},false);}};function m(r,p,q){this._aPrefs=q;g.call(this,r,p);}m.prototype=new g();m.prototype.execute=function(q,s,u){var p=0;for(var t=0;t<this._aPrefs.length;t++){p=q._setPreference(u.apply(this._aPrefs[t].name),u.apply(this._aPrefs[t].value))|p;}if(p){var r=bb.document.createEvent("CustomEvent");r.initEvent("change",false,false);q.dispatchEvent(r);if(p>=2){q.synchronize("update");}}};function l(q,p){g.call(this,q,p);}l.prototype=new g();l.prototype.execute=function(p,q,r){p&&p.maximize();};function e(r,p,t,s,q){this._type=t;this._cancelable=q||false;this._bubbles=s||false;g.call(this,r,p);}e.prototype=new g();e.prototype.createEvent=i.prototype.createEvent;e.prototype.execute=function(p,q,r){p&&p.dispatchEvent(this.createEvent());};function a(p){this._matchExpr=new RegExp(p);this._actions=[];}a.prototype.match=function(q){var p=String(q).match(this._matchExpr);this._matches=p||[];this._matches.apply=function(s){var r=this;return s.replace(/\$(\d)+/g,function(t,u){return r[u]||"";});};return Boolean(p);};a.prototype.addAction=function(p){if(!(p instanceof f)){bb.command.trace(this,"Attempt to add non portal.navigation.Action instance to the rule actions sequence!");}this._actions.push(p);};a.prototype.removeAction=function(p){if(!(p instanceof f)){bb.command.trace(this,"Attempt to remove non portal.navigation.Action instance from the rule actions sequence!");}bb.array.removeObject(this._actions,p);};a.prototype.apply=function(q){var p=this._actions;for(var r=0;r<p.length;++r){p[r].executeWhenReady(q,this._matches);}};function j(){}j.prototype.buildGadgetActions=function(s,t){var p=t.getAttribute("tid"),r=[],q=[];t.getAttribute("maximized")=="maximized"&&r.push(new l(s,p));(new h(t.childNodes,k,"preference")).each(function(u){q.push({name:u.getAttribute("name"),value:u.getAttribute("value")});});if(q.length){r.push(new m(s,p,q));}return r;};j.prototype.buildContainerActions=function(u){var t=u.getAttribute("tid"),p=this,s=[],r=false,q=false;u.getAttribute("selected")=="selected"&&s.push(new b(t));(new h(u.childNodes,k)).each(function(v){if(portal.xml.getLocalName(v)=="gadget"){s.push.apply(s,p.buildGadgetActions(t,v));r=r||(v.getAttribute("maximized")=="maximized");}else{if(portal.xml.getLocalName(v)=="preference"){s.push(new o(t,v.getAttribute("name"),v.getAttribute("value")));q=true;}}});q&&s.push(new i(t,"change",false,false));!r&&s.push(new d(t));return s;};j.prototype.buildActions=function(r){var q=[],p=this;(new h(r,k,"container")).each(function(s){q.push.apply(q,p.buildContainerActions(s));});return q;};function c(){}c.prototype.buildRule=function(q){var p=new portal.navigation.Rule(q.getAttribute("match")),r=(new j()).buildActions(q.childNodes);for(var s=0;s<r.length;++s){p.addAction(r[s]);}return p;};c.prototype.buildRules=function(q){var s=new h(q,k,"rule"),r=[],p=this;s.each(function(t){r.push(p.buildRule(t));});return r;};this.Rule=a;this.RuleBuilder=c;this.namespaceURI=k;}).call(portal.navigation);</script><script type="text/javascript">var phe=window.phe||{};phe.initializePHE=function(a){if(!a){return;}if(phe.table){phe.table.initialize(a);}if(phe.rearrangeTable){phe.rearrangeTable.initialize(a);}if(phe.slider){phe.slider.initialize(a);}if(phe.tabBox){phe.tabBox.initialize(a);}if(phe.keypad){phe.keypad.initialize(a);}if(phe.keyboard){phe.keyboard.initialize(a);}if(phe.graph){phe.graph.initialize(a);}if(phe.inputReadOnlyText){phe.inputReadOnlyText.initialize(a);}if(phe.textBox){phe.textBox.initialize(a);}if(phe.tabBoxVertical){phe.tabBoxVertical.init(a);}if(phe.deck){phe.deck.initialize(a);}if(phe.media){phe.media.initialize(a);}if(phe.axisTable){phe.axisTable.initialize(a);}if(phe.iFrame){phe.iFrame.initialize(a);}if(phe.clientAgreement){phe.clientAgreement.initialize(a);}if(phe.qrCode){phe.qrCode.initialize(a);}};phe.matchNextElement=function(d,b,c){if(d!=null){var a=d.nextSibling;while(a){if(a.nodeType==1){if(b){if(bb.selector.match(a,b)){return a;}}else{return a;}}a=a.nextSibling;}if(c){var a=d.parentNode.firstChild;while(a!=d){if(a.nodeType==1){if(b){if(bb.selector.match(a,b)){return a;}}else{return a;}}a=a.nextSibling;}}}};phe.matchPreviousElement=function(d,b,c){if(d!=null){var a=d.previousSibling;while(a){if(a.nodeType==1){if(b){if(bb.selector.match(a,b)){return a;}}else{return a;}}a=a.previousSibling;}if(c){var a=d.parentNode.lastChild;while(a!=d){if(a.nodeType==1){if(b){if(bb.selector.match(a,b)){return a;}}else{return a;}}a=a.previousSibling;}}}};phe.matchChildren=function(d,b){if(d!=null){var c=[];var a=d.firstChild;while(a){if(a.nodeType==1&&bb.selector.match(a,b)){c.push(a);}a=a.nextSibling;}return c;}else{return null;}};phe.getFirstElement=function(b){if(b!=null){var a=b.firstChild;while(a){if(a.nodeType==1){return a;}a=a.nextSibling;}}};phe.getLastElement=function(b){if(b!=null){var a=b.lastChild;while(a){if(a.nodeType==1){return a;}a=a.previousSibling;}}};phe.getElementPosition=function(c,b){if(c!=null){var d=0;var a=c.firstChild;while(a){if(a.nodeType==1){if(b==a){return d;}d++;}a=a.nextSibling;}}return -1;};phe.getNthElement=function(b,c){if(b!=null){var a=b.firstChild;while(a){if(a.nodeType==1){if(c==0){return a;}c--;}a=a.nextSibling;}}return null;};phe.string={};phe.string.endsWith=function(c,a){var b=c.length-a.length;return b>=0&&c.lastIndexOf(a)===b;};phe.fx={};phe.fx.fader={};phe.fx.fader.run=function(d,b,c){if(d!=null){if(d.fader&&d.fader.timeout){clearTimeout(d.fader.timeout);}if(b=="normal"||typeof b==="undefined"){b=["0.1","0.2","0.3","0.4","0.5","0.6","0.7","0.8","0.9","1"];}else{if(b=="slow"){b=["0.1","0.15","0.2","0.25","0.3","0.35","0.4","0.45","0.5","0.55","0.6","0.65","0.7","0.75","0.8","0.85","0.9","0.95","1"];}else{if(b=="fast"){b=["0.2","0.4","0.6","0.8","1"];}}}d.fader=function(){bb.html.setStyle(d,"opacity",d.fader.a[d.fader.count++]);if(d.fader.a.length>d.fader.count){d.fader.timeout=setTimeout(d.fader,50);}else{d.fader=null;if(c){c(d);}}};d.fader.count=0;d.fader.a=b;d.fader();}};phe.fx.class_styles={};phe.fx.setAnimatedClassStyles=function(a,b,c){phe.fx.class_styles[a]=[b,c+"ms"];};phe.fx.getStyles=function(d,c){if(d!=null){var a={};for(var b=0;b<c.length;b++){a[c[b]]=bb.html.getStyle(d,c[b]);}return a;}else{return"";}};phe.fx.animateStyles=function(f,d,a,e){if(f!=null){for(var c=0;c<d.length;c++){bb.html.setStyle(f,d[c],"");var b=bb.html.getStyle(f,d[c]);bb.html.setStyle(f,d[c],a[d[c]]);bb.smil.animate(f,{attributeName:d[c],from:a[d[c]],to:b,dur:e,fill:"freeze"});}}};phe.fx.addClass=function(g,e,c){if(g!=null){e="-"+e;var f=g.className.split(" ");for(var d=0;d<f.length;d++){if(phe.string.endsWith(f[d],e)){var a=phe.fx.class_styles[f[d]];if(a&&a[0]&&a[1]){var b=phe.fx.getStyles(g,a[0]);bb.html.addClass(g,f[d]+"-"+c);phe.fx.animateStyles(g,a[0],b,a[1]);}else{bb.html.addClass(g,f[d]+"-"+c);}}}}};phe.fx.removeClass=function(g,e,c){if(g!=null){e="-"+e;var f=g.className.split(" ");for(var d=0;d<f.length;d++){if(phe.string.endsWith(f[d],e)){var a=phe.fx.class_styles[f[d]];if(a&&a[0]&&a[1]){var b=phe.fx.getStyles(g,a[0]);bb.html.removeClass(g,f[d]+"-"+c);phe.fx.animateStyles(g,a[0],b,a[1]);}else{bb.html.removeClass(g,f[d]+"-"+c);}}}}};phe.Element=new Function;phe.Element.prototype.getAttribute=function(a,b){if(a){switch(b){case"style":return a.style.cssText;break;case"class":return a.className.replace(/ui-[^ ]+/g,"").replace(/\s\s+/," ").replace(/\s\s+|^\s+|\s+$/,"");break;case"for":return a.htmlFor;break;default:return a.getAttribute(b);break;}}};phe.Element.prototype.setAttribute=function(a,c,d){if(a){switch(c){case"style":a.style.cssText=d;break;case"class":var b=a.className.match(/ui-[^ ]+/g);a.className=(b?b.join(" ")+" ":"")+d;break;case"for":a.htmlFor=d;break;default:if(d==""){a.removeAttribute(d);}else{a.setAttribute(c,d);}}}};phe.Element.prototype.show=function(a){if(a){if(bb.html.hasClass(a,"ap-common-hide")){bb.html.removeClass(a,"ap-common-hide");bb.html.addClass(a,"ap-common-show");}else{if(bb.html.hasClass(a,"ap-common-show")){}else{a.style.display="";}}}};phe.Element.prototype.hide=function(a){if(a){if(bb.html.hasClass(a,"ap-common-show")){bb.html.removeClass(a,"ap-common-show");bb.html.addClass(a,"ap-common-hide");}else{if(bb.html.hasClass(a,"ap-common-hide")){}else{a.style.display="none";}}}};phe.Element.prototype.isVisible=function(a){if(a){return a.offsetHeight>0&&a.offsetWidth>0;}else{return false;}};phe.FormElement=new Function;phe.FormElement.prototype=new phe.Element;phe.FormElement.prototype.setAttribute=function(a,c,d){if(a){switch(c){case"required":a.setAttribute("bbf_required",d);break;case"dataType":a.setAttribute("bbf_type",d);break;case"value":a.value=d;break;case"style":a.style.cssText=d;break;case"class":var b=a.className.match(/ui-[^ ]+/g);a.className=(b?b.join(" ")+" ":"")+d;break;case"disabled":if(d=="true"){a.setAttribute("disabled",d);}else{a.removeAttribute("disabled");}break;default:a.setAttribute(c,d);}}};phe.FormElement.prototype.getAttribute=function(a,b){if(a){switch(b){case"disabled":var c=a.getAttribute("disabled");return(c=="true"||c=="disabled")?"true":"false";case"required":return a.getAttribute("bbf_required");break;case"dataType":return a.getAttribute("bbf_type");break;case"value":return a.value;break;case"style":return a.style.cssText;break;case"class":return a.className.replace(/ui-[^ ]+/g,"").replace(/\s\s+/," ").replace(/\s\s+|^\s+|\s+$/,"");break;default:return a.getAttribute(b);}}};phe.FormElement.prototype.focus=function(a){if(a){a.focus();}};phe.FormElement.prototype.isInErrorState=function(a){if(a){if(bb.html.hasClass(a,"ui-incorrect-value")){return true;}else{return false;}}else{return false;}};phe.common=new phe.Element;phe.noticeBox=new phe.Element;phe.informationBox=new phe.Element;phe.media=new phe.Element;phe.meter=new phe.Element;phe.header=new phe.Element;</script><script type="text/javascript">var phe=window.phe||{};phe.loadingMessage=phe.loadingMessage||{};phe.loadingMessage.defaultMessage=absa.locale["Common/General/Label/Loading"]+"...";phe.loadingMessage.bQRCurrentlyShowingInModal=false;phe.loadingMessage.createLoadingMessage=function(){var c=document.createElement("div");c.className="ap-loadingMessage-overlay";var d=document.createElement("div");d.className="ap-loadingMessage-outter";c.appendChild(d);var a=document.createElement("div");a.className="ap-loadingMessage-centered";d.appendChild(a);var b=document.createElement("div");b.className="ap-loadingMessage-message";a.appendChild(b);return c;};phe.loadingMessage.showLoadingMessage=function(a,c){a=a||this.viewNode;if(a!=null){a._loadingMessage=a._loadingMessage||phe.loadingMessage.createLoadingMessage();if(a._loadingMessage!=null){var b=c||a.getAttribute("loading-message")||phe.loadingMessage.defaultMessage;if(b=="undefined..."){b="Loading...";}if(bb.browser.ie){bb.selector.query(a._loadingMessage,".ap-loadingMessage-message").innerText=b;}else{bb.selector.query(a._loadingMessage,".ap-loadingMessage-message").innerHTML=b;}if(a._loadingMessage.style!=null){a._loadingMessage.style.display="block";a.appendChild(a._loadingMessage);}}}};phe.loadingMessage.hideLoadingMessage=function(a){if(a!=null){if(a._loadingMessage!=null){if(a._loadingMessage.style!=null){a._loadingMessage.style.display="none";if(a._loadingMessage.parentNode!=null){a._loadingMessage.parentNode.removeChild(a._loadingMessage);}}}}};phe.loadingMessage.showLoadingMessageSureCheck2=function(b,d){b=b||this.viewNode;if(b!=null){b._loadingMessage=b._loadingMessage||phe.loadingMessage.createLoadingMessageSureCheck2();if(b._loadingMessage!=null){var f="";if((d!=null)&&!isNaN(d)){if(phe.loadingMessage.bQRCurrentlyShowingInModal==false){f='<div class="ap-common-alignLeft ap-loadingMessage-qrCode" style="height:160px; margin-left:62px; margin-top:10px;"><h1>'+absa.locale["2FA/General/Label/CompleteTheProcessOnYourApp"]+'</h1><ul class="ap-info-box-ol"><li>'+absa.locale["2FA/General/Label/GiveYourDeviceANickname"]+"</li><li>"+absa.locale["2FA/General/Label/CreateA5DigitPasscode"]+"</li><li>"+absa.locale["2FA/General/Label/YourDeviceIsNowLinked"]+'</li></ul><br/><span style="cursor:pointer; color:blue; padding-top:10px;" onclick="absa.index.n2faCloseLoadingStartAgain(this)">'+absa.locale["Common/General/Button/Back"]+"</span>";}else{f='<div class="ap-common-alignLeft ap-loadingMessage-qrCode" style="height:340px; margin-left:62px; margin-top:10px;"><h1>'+absa.locale["2FA/General/Label/CompleteTheProcessOnYourApp"]+'</h1><ul class="ap-info-box-ol"><li>'+absa.locale["2FA/General/Label/GiveYourDeviceANickname"]+"</li><li>"+absa.locale["2FA/General/Label/CreateA5DigitPasscode"]+"</li><li>"+absa.locale["2FA/General/Label/YourDeviceIsNowLinked"]+'</li></ul><br/><span style="cursor:pointer; color:blue; padding-top:10px;" onclick="absa.index.n2faCloseLoadingStartAgain(this)">'+absa.locale["Common/General/Button/Back"]+"</span>";}}else{f='<div class="ap-common-alignLeft" style="height:160px; margin-left:62px; margin-top:10px;"><h1>'+absa.locale["2FA/General/Label/CompleteTheProcessOnYourApp"]+'</h1><ul class="ap-info-box-ol"><li>'+absa.locale["2FA/General/Label/GiveYourDeviceANickname"]+"</li><li>"+absa.locale["2FA/General/Label/CreateA5DigitPasscode"]+"</li><li>"+absa.locale["2FA/General/Label/YourDeviceIsNowLinked"]+'</li></ul></div><br/><span style="cursor:pointer; color:blue; padding-top:10px;" onclick="absa.index.n2faCloseLoadingStartAgain(this)">'+absa.locale["Common/General/Button/Back"]+"</span>";}var a=false;var c=(function(){var h=absa.BROWSERINFO,g,i=h.match(/(opera|chrome|safari|firefox|msie|trident(?=\/))\/?\s*(\d+)/i)||[];if(/trident/i.test(i[1])){g=/\brv[ :]+(\d+)/g.exec(h)||[];return"IE";}if(i[1]==="Chrome"){g=h.match(/\b(OPR|Edge)\/(\d+)/);if(g!=null){return g[1];}}i=i[2]?[i[1],i[2]]:[navigator.appName,navigator.appVersion,"-?"];return i[0];})();var e=(function(){var h=absa.BROWSERINFO,g,i=h.match(/(opera|chrome|safari|firefox|msie|trident(?=\/))\/?\s*(\d+)/i)||[];if(/trident/i.test(i[1])){g=/\brv[ :]+(\d+)/g.exec(h)||[];return(g[1]||"");}if(i[1]==="Chrome"){g=h.match(/\b(OPR|Edge)\/(\d+)/);if(g!=null){return g[2];}}i=i[2]?[i[1],i[2]]:[navigator.appName,navigator.appVersion,"-?"];if((g=h.match(/version\/(\d+)/i))!=null){i.splice(1,1,g[1]);}return i[1];})();if(isNaN(e)){e=0;}if((c.indexOf("IE")>-1)|(c.indexOf("MSIE")>-1)){if(Number(e)>=10){a=false;}else{a=true;}}else{if(c.indexOf("Firefox")>-1){if(Number(e)>=41){a=false;}else{a=false;}}else{if(c.indexOf("Chrome")>-1){if(Number(e)>=39){a=false;}else{a=false;}}else{if((c.indexOf("OPR")>-1)|(c.indexOf("Opera")>-1)){if(Number(e)>=29){a=false;}else{a=false;}}else{a=false;}}}}if(a){if(absa.ENABLEBRAND!=null&&absa.ENABLEBRAND=="true"){bb.selector.query(b._loadingMessage,".ap-loadingMessage-message-surecheck2-2018").innerText=f;}else{bb.selector.query(b._loadingMessage,".ap-loadingMessage-message-surecheck2").innerText=f;}}else{if(absa.ENABLEBRAND!=null&&absa.ENABLEBRAND=="true"){bb.selector.query(b._loadingMessage,".ap-loadingMessage-message-surecheck2-2018").innerHTML=f;}else{bb.selector.query(b._loadingMessage,".ap-loadingMessage-message-surecheck2").innerHTML=f;}}if(b._loadingMessage.style!=null){b._loadingMessage.style.display="block";b.appendChild(b._loadingMessage);}}}};phe.loadingMessage.showQRInModal=function(a){var c=bb.selector.queryAncestor(a,".ap-loadingMessage-qrCode");var b=bb.selector.query(c,"#qrModalCodeImg2");if(b){phe.loadingMessage.bQRCurrentlyShowingInModal=true;c.style.height="340px";phe.common.hide(a);phe.common.show(b);}};phe.loadingMessage.createLoadingMessageSureCheck2=function(){var c=document.createElement("div");c.className="ap-loadingMessage-overlay";var d=document.createElement("div");d.className="ap-loadingMessage-outter";c.appendChild(d);var a=document.createElement("div");a.className="ap-loadingMessage-centered";d.appendChild(a);var b=document.createElement("div");if(absa.ENABLEBRAND!=null&&absa.ENABLEBRAND=="true"){b.className="ap-loadingMessage-message-surecheck2-2018";}else{b.className="ap-loadingMessage-message-surecheck2";}a.appendChild(b);return c;};</script><script type="text/javascript">var phe=window.phe||{};phe.accordion=new phe.Element;phe.accordionItem=new phe.Element;phe.accordionHead=new phe.Element;phe.accordionBody=new phe.Element;phe.accordion.selectItemByIndex=function(a,c){var b=bb.selector.queryAll(a,".ui-accordionHead");if(c<b.length){var d=b[c];if(bb.html.hasClass(d,".ui-accordionHead-selected")){}else{phe.accordion.selectItem(d);}}};phe.accordion.selectItem=function(d){var b=bb.selector.queryAncestor(d,".ui-accordion");var a=bb.selector.query(b,".ui-accordionItem .ui-accordionHead-selected");var e=bb.selector.query(b,".ui-accordionItem .ui-accordionBody-selected");function c(){var f=absa.locale["Common/General/Label/Expand"];var h=absa.locale["Common/General/Label/Collapse"];if(a&&e){bb.html.setClass(a,"ui-accordionHead");bb.html.setClass(e,"ui-accordionBody");a.setAttribute("aria-selected","");absa.vi.setElementLabel(a,absa.vi.getElementLabel(a).replace(h,f));e.setAttribute("aria-hidden","true");e.setAttribute("aria-expanded","false");}if(!a||(d!=a)){bb.html.setClass(d,"ui-accordionHead-selected");d.setAttribute("aria-selected","true");absa.vi.setElementLabel(d,absa.vi.getElementLabel(d).replace(f,h));var g=bb.selector.query(bb.selector.queryAncestor(d,".ui-accordionItem"),".ui-accordionBody");bb.html.setClass(g,"ui-accordionBody-selected");g.setAttribute("aria-hidden","false");g.setAttribute("aria-expanded","true");g.focus();absa.lazyLoadNode(bb.selector.query(g,".ui-accordionBody-content"),true);}}if(absa.unconfirmedChanges&&e){return absa.unconfirmedChanges.cancelNavigation(e,c);}else{return c();}};</script><script type="text/javascript">var phe=window.phe||{};phe.axisTable=new phe.Element;phe.axisTableHead=new phe.Element;phe.axisTableHeadCell=new phe.Element;phe.axisTableBody=new phe.Element;phe.axisTableBodyRow=new phe.Element;phe.axisTableBodyCell=new phe.Element;phe.axisTable.axisTableFragment=document.createElement("div");phe.axisTable.axisTableFragment.style.display="none";phe.axisTable.previousTable=null;phe.axisTable.setAttribute=function(a,b,d){if(b=="height"){var c=bb.selector.query(a,".ui-axisTable--scrollContainer");a._scrollableHeight=0;c.style.height=d;}else{phe.Element.prototype.setAttribute.call(this,a,b,d);}};phe.axisTable.getAttribute=function(a,b){if(b=="sort-defaultColumn"){return phe.Element.prototype.getAttribute.call(this,a,"sortedcolumn");}else{if(b=="sort-defaultOrder"){return phe.Element.prototype.getAttribute.call(this,a,"sortorder");}else{return phe.Element.prototype.getAttribute.call(this,a,b);}}};phe.axisTable.getTableHead=function(a){return bb.selector.query(a,".ui-axisTableHead");};phe.axisTableHead.getTableHeadCell=function(a,c){var b=bb.selector.query(a,".ui-axisTableHead tr");return b.cells[c];};phe.axisTable.getTableBody=function(a){return bb.selector.query(a,".ui-axisTableBody");};phe.axisTable.getRows=function(a){var b=bb.selector.query(a,".ui-axisTableBody");if(b.rows!=null){return b.rows;}else{return null;}};phe.axisTableBody.getRowByIndex=function(a,b){var c=bb.selector.query(a,".ui-axisTableBodyTBody");return c.rows[b];};phe.axisTableBody.getColByIndex=function(a,b){var c=phe.axisTableBody.getRowByIndex(a,0);return c.cells[b];};phe.axisTableBodyRow.getCellByIndex=function(a,d,b){var c=phe.axisTableBody.getRowByIndex(a,d);return c.cells[b];};phe.axisTableHead.getLength=function(a){var b=bb.selector.query(a,".ui-axisTableHead tr");return b.cells.length;};phe.axisTableBody.getLength=function(a){var b=bb.selector.query(a,".ui-axisTableBodyTBody");return b.rows.length;};phe.axisTableBodyRow.getLength=function(a,b){var c=phe.axisTableBody.getRowByIndex(a,b);return c.cells.length;};phe.axisTableBody.deleteRow=function(a,b){var c=bb.selector.query(a,".ui-axisTableBodyTBody");c.deleteRow(b);};phe.axisTableBody.cloneRow=function(a,b){var d=bb.selector.query(a,".ui-axisTableBodyTBody");var c=d.rows[b].cloneNode(true);return c;};phe.axisTableBody.insertRow=function(b,d,c){var e=bb.selector.query(b,".ui-axisTableBodyTBody");var a=e.insertRow(c);a.parentNode.replaceChild(d,a);};phe.axisTableBody.getSelectedRowsValues=function(b){var e=bb.selector.queryAll(b,".ui-axisTableBodyRow-selector");var a=new Array();for(var d=0;d<e.length;d++){var c=e[d];if(c.checked==true){a.push(c.getAttribute("value"));}}return a;};phe.axisTableBodyRow.toggleAlternativeStyle=function(a,b){var c=phe.axisTableBody.getRowByIndex(a,b);if(bb.html.hasClass(c,"ui-axisTableBodyRow--rowAlternate")){bb.command.removeClass(c,"ui-axisTableBodyRow--rowAlternate");}else{bb.command.addClass(c,"ui-axisTableBodyRow--rowAlternate");}};phe.axisTableBodyRow.getTable=function(a){return bb.selector.queryAncestor(a,".ui-axisTable");};phe.axisTableBodyCell.getTable=function(a){return bb.selector.queryAncestor(a,".ui-axisTable");};phe.axisTableBodyRow.getIndex=function(a){return a.rowIndex;};phe.axisTableBodyCell.getIndex=function(a){return a.cellIndex;};phe.axisTable.setRowsAlternateStyle=function(a){if(a&&a.rows){var c=a.rows;for(var b=0;b<c.length;b++){if(b%2==0){bb.html.removeClass(c[b],"ui-axisTableBodyRow--rowAlternate");}else{bb.html.addClass(c[b],"ui-axisTableBodyRow--rowAlternate");}}}};phe.axisTable.empty=function(b){var d=b;if(d){var a=bb.selector.query(d,".ui-axisTableBodyTBody");var c=document.createElement("tbody");c.className="ui-axisTableBodyTBody";d.appendChild(c);d.removeChild(a);}};phe.axisTable.reload=function(a){phe.axisTable.empty(a);a._dataFile=a.getAttribute("dataFile");phe.axisTable.loadData(a,true);};phe.axisTable.loadData=function(c,e,a){phe.axisTable.initializeBehavior(c);if(!c._dataFile){return;}var b=phe.axisTable.getSelectedRowValue(c);var d=phe.axisTable.getSelectedColValue(c);c._nbRows=bb.selector.queryAll(c,".ui-axisTableBodyRow").length;var f=[c._dataFile,(c._dataFile.indexOf("?")==-1)?"?":"&","startRow=",c._nbRows].join("");var g=function(m){if(e){phe.axisTable.empty(c);}oNewTBody=bb.html.createElementFromString(m.text);var o=bb.selector.query(c,".ui-axisTableBodyTBody");var p=oNewTBody.rows;for(var n=0,k=p.length,t=0;n<k;n++){o.appendChild(p[n-t]);t++;}if(b!=0){if(o!=null){var s='.ui-axisTableCell[value="'+b+'"]';var q=bb.selector.query(o,s);var h=bb.selector.queryAncestor(q,".ui-axisTableBodyRow");if(h!=null){phe.axisTable.setSelectedRow(h);}}}if(d!=0){var s='th.ui-axisTableHeadCell[value="'+d+'"]';var j=bb.selector.query(c,s);if(j!=null){oTbl._previousCellId=0;phe.axisTable.setSelectedCol(j);}}var r=absa.util.attributeToFunction(c,"oncallback",["aNewRows"]);if(r){r.call(c,p);}};c._isLoading=true;if(c._loadingMessageContainer){c._loadingMessageContainer.style.display="";phe.loadingMessage.showLoadingMessage(c._loadingMessageContainer);}absa.io.makeRequest(f,function(k){c._isLoading=false;if(c._loadingMessageContainer){phe.loadingMessage.hideLoadingMessage(c._loadingMessageContainer);c._loadingMessageContainer.style.display="none";}if(!k.errors.length){var m=bb.selector.query(c,".ui-axisTableBodyRow--ioErrorMessage");if(m){m.parentNode.removeChild(m);}g(k);}else{var i=bb.selector.query(c,".ui-axisTableBodyTBody");var m=bb.selector.query(i,".ui-axisTableBodyRow--ioErrorMessage");if(!m){var h="<tr class='ui-axisTableBodyRow ui-axisTableBodyRow--ioErrorMessage'><td colspan='30' class='ui-axisTableBodyCell'></td></tr>";var j=bb.html.createElementFromString(h);var l=bb.selector.query(j,".ui-axisTableBodyCell");absa.showIOErrorMessage(l);i.appendChild(j);}}});};phe.axisTable.initializeBehavior=function(d){d=d;d._iExcludeRows=0;d._search=false;d._previousRow=null;d._dataFile=d.getAttribute("dataFile")||d.getAttribute("datafile");if(d._dataFile&&d.getAttribute("forceInitialLoadFromDataFile")){phe.axisTable.loadData(d,false);}else{var g=absa.util.attributeToFunction(d,"oncallback");if(g){g.call(d);}}var c=-1;var f=-1;var b=d.getAttribute("selectedRowValue")||d.getAttribute("selectedrowvalue");var e=d.getAttribute("selectedColValue")||d.getAttribute("selectedcolvalue");if(b!=null){c=phe.axisTableBody.getRowIndexByRowValue(d,b);}if(e!=null){f=phe.axisTableBodyRow.getColIndexByColValue(d,e);}if((c>-1)&&(f>-1)){var h=phe.axisTableBodyRow.getCellByIndex(d,c,f);phe.axisTable.cellClicked(d,h);}else{if(c>-1){var a=phe.axisTableBody.getRowByIndex(d,c);phe.axisTable.setSelectedRow(a);}else{if(f>-1){var h=phe.axisTableBody.getColByIndex(d,f);phe.axisTable.setSelectedCol(h);}}}};phe.axisTableBody.getRowIndexByRowValue=function(c,g){var f=-1;var h=bb.selector.query(c,".ui-axisTableBodyTBody");var e=bb.selector.queryAll(h,".ui-axisTableLegend");for(var b=0;b<e.length;b++){var d=e[b];var a=d.getAttribute("value");if(a!=null){if(bb.string.trim(g)==bb.string.trim(a)){f=b;}}}return f;};phe.axisTableBodyRow.getColIndexByColValue=function(c,g){var e=-1;var f=bb.selector.queryAll(c,".ui-axisTableHeadCell");for(var b=0;b<f.length;b++){var d=f[b];var a=d.getAttribute("value");if(a!=null){if(bb.string.trim(g)==bb.string.trim(a)){e=b;}}}return e;};phe.axisTable.cellClicked=function(a,c){var e=phe.axisTableBodyCell.getIndex(c);var b=c.parentNode||c.parentElement;var d=phe.axisTableBodyRow.getIndex(b);phe.axisTable.previousTable=a;if(e==0&&d==0){phe.axisTable.clearHighlight();}else{if(e==0){phe.axisTable.setSelectedRow(b);}else{if(d==0){phe.axisTable.setSelectedCol(c);}else{phe.axisTable.setSelectedRow(b);phe.axisTable.setSelectedCol(c);}}}};phe.axisTable.clearHighlight=function(){if(phe.axisTable.previousTable!=null){phe.axisTable.setAttribute(phe.axisTable.previousTable,"selectedRowValue","0");phe.axisTable.setAttribute(phe.axisTable.previousTable,"selectedColValue","0");}phe.axisTable.clearPreviousRow();phe.axisTable.clearPreviousCol();oTbl._previousRow=null;var a=absa.util.attributeToFunction(phe.axisTable.previousTable,"onresetselectioncallback");if(a){a.call(phe.axisTable.previousTable);}};phe.axisTable.clearPreviousRow=function(){if(typeof(oTbl)!="undefined"){if(oTbl._previousRow){bb.html.removeClass(oTbl._previousRow,"hlt");if(oTbl._previousRow.cells[0]){bb.html.removeClass(oTbl._previousRow.cells[0],"hlt-head");}}}};phe.axisTable.getTable=function(){if(phe.axisTable.previousTable==null){phe.axisTable.previousTable=phe.axisTableBodyRow.getTable(oTbl._previousRow);}if(phe.axisTable.previousTable==null){if(oTbl!=null){phe.axisTable.previousTable=oTbl;}}};phe.axisTable.clearPreviousCol=function(){phe.axisTable.getTable();if(oTbl._previousCellId){var a=oTbl._previousCellId;aRows=phe.axisTable.getRows(phe.axisTable.previousTable);bb.html.removeClass(aRows[0].cells[a],"hlt-head");for(var b=0;b<aRows.length;b++){bb.html.removeClass(aRows[b].cells[a],"hlt-col");}}};phe.axisTable.setSelectedRow=function(a){phe.axisTable.clearPreviousRow();if(oTbl._previousRow){if(oTbl._previousRow!=a){bb.html.addClass(a,"hlt");bb.html.addClass(a.cells[0],"hlt-head");oTbl._previousRow=a;var f=phe.axisTableBodyRow.getTable(a);var c=bb.selector.query(f,".ui-axisTableBodyTBody");var e=bb.selector.query(c,".hlt-head");var b=e.getAttribute("value");phe.axisTable.setAttribute(f,"selectedRowValue",b);var d=absa.util.attributeToFunction(f,"onselectrowcallback");if(d){d.call(f);}}else{bb.html.addClass(a,"hlt");bb.html.addClass(a.cells[0],"hlt-head");oTbl._previousRow=a;}}else{bb.html.addClass(a,"hlt");bb.html.addClass(a.cells[0],"hlt-head");oTbl._previousRow=a;var f=phe.axisTableBodyRow.getTable(a);var c=bb.selector.query(f,".ui-axisTableBodyTBody");var e=bb.selector.query(c,".hlt-head");var b=e.getAttribute("value");phe.axisTable.setAttribute(f,"selectedRowValue",b);var d=absa.util.attributeToFunction(f,"onselectrowcallback");if(d){d.call(f);}}};phe.axisTable.setSelectedCol=function(b){var d=phe.axisTableBodyCell.getIndex(b);phe.axisTable.clearPreviousCol();if(oTbl._previousCellId!=d){aRows=phe.axisTable.getRows(phe.axisTable.previousTable);bb.html.addClass(aRows[0].cells[d],"hlt-head");for(var c=1;c<aRows.length;c++){bb.html.addClass(aRows[c].cells[d],"hlt-col");}oTbl._previousCellId=d;var g=phe.axisTableBodyCell.getTable(b);var a=bb.selector.query(g,".hlt-head");var f=a.getAttribute("value");phe.axisTable.setAttribute(g,"selectedColValue",f);var e=absa.util.attributeToFunction(g,"onselectcolcallback");if(e){e.call(g);}}else{aRows=phe.axisTable.getRows(phe.axisTable.previousTable);bb.html.addClass(aRows[0].cells[d],"hlt-head");for(var c=1;c<aRows.length;c++){bb.html.addClass(aRows[c].cells[d],"hlt-col");}oTbl._previousCellId=d;}};phe.axisTable.getSelectedRowValue=function(b){var a=bb.selector.queryAncestor(b,".ui-axisTable");if(a!=null){return phe.axisTable.getAttribute(a,"selectedRowValue");}else{return phe.axisTable.getAttribute(b,"selectedRowValue");}};phe.axisTable.getSelectedColValue=function(b){var a=bb.selector.queryAncestor(b,".ui-axisTable");if(a!=null){return phe.axisTable.getAttribute(a,"selectedColValue");}else{return phe.axisTable.getAttribute(b,"selectedColValue");}};phe.axisTable.getSelectedCellValue=function(d){var c=bb.selector.query(d,".ui-axisTableBodyTBody");if(c!=null){var a=bb.selector.query(c,".ui-axisTableBodyRow.hlt");if(a){var b=bb.selector.query(a,"td.hlt-col");if(b){return b.getAttribute("value");}}}return 0;};phe.axisTable.initialize=function(c){var a=bb.selector.queryAll(c,".ui-axisTable");for(var b=0;b<a.length;b++){oTbl=a[b];phe.axisTable.initializeBehavior(a[b]);}};</script><script type="text/javascript">var phe=window.phe||{};phe.amountField=phe.amountField||{};phe.amountField.DECIMAL_PART_LENGTH=2;phe.amountField.removeFormatingCharacters=function(b,a){if(a){b=b.replace(/[^0-9,\.]/g,"").replace(/\.([^\.]*)(?=\.)/g,"$1");}return b.replace(/,/g,"");};phe.amountField.parseFormatedNumber=function(b,a){return parseFloat(phe.amountField.removeFormatingCharacters(b,a))||0;};phe.amountField._formatNumberParts=function(b,d){var c=[];for(var a=b.length-1;a>=0;a--){if((a!=b.length-1)&&(b.length-1-a)%3==0){c.push(",");}c.push(b.charAt(a));}c.reverse();if(d){return c.join("")+d;}else{return c.join("");}};phe.amountField.formatNumber=function(a){var c=(a>=0?Math.floor(a):Math.ceil(a));var d=a-c;var b=c.toString();var e=d.toFixed(this.DECIMAL_PART_LENGTH).split(".")[1];return phe.amountField._formatNumberParts(b,"."+e);};phe.amountField.reformatNumber=function(g,f){if(g){var a=phe.amountField.removeFormatingCharacters(g,true);var d=a.split(".");var c=d[0];var e=(d.length>1?"."+d[1].slice(0,this.DECIMAL_PART_LENGTH):"");if(f){if(!e){e=".";}for(var b=e.length;b<this.DECIMAL_PART_LENGTH+1;b++){e+="0";}}return phe.amountField._formatNumberParts(c,e);}else{return"";}};</script><script type="text/javascript">var phe=window.phe||{};phe.button=new phe.Element;phe.button.disableButton=function(a){if(bb.html.hasClass(a,"ui-button")){bb.html.replaceClass(a,"ui-button","ui-button_disabled");}a.setAttribute("disabled","true");};phe.button.enableButton=function(a){if(bb.html.hasClass(a,"ui-button_disabled")){bb.html.replaceClass(a,"ui-button_disabled","ui-button");}a.removeAttribute("disabled");};phe.button.setAttribute=function(a,b,c){if(c=="disabled"){if(c=="true"){phe.button.disableButton(a);}else{phe.button.enableButton(a);}}else{if(c==""){a.removeAttribute(b);}else{phe.Element.prototype.setAttribute.call(this,a,b,c);}}};</script><script type="text/javascript">var phe=window.phe||{};phe.checkBox=new phe.FormElement;phe.checkBox.setAttribute=function(a,b,c){if(b=="checked"){if(c=="true"){a.checked=true;}else{a.checked=false;}}else{if(b=="required"){if(c=="true"){phe.FormElement.prototype.setAttribute.call(this,a,"bbf_required","true");}else{phe.FormElement.prototype.setAttribute.call(this,a,"bbf_required","");}}else{phe.FormElement.prototype.setAttribute.call(this,a,b,c);}}};phe.checkBox.getAttribute=function(a,b){if(b=="checked"){return a.checked;}else{return phe.FormElement.prototype.getAttribute.call(this,a,b);}};phe.checkBox.isChecked=function(a){return a.checked;};phe.checkBox.getValue=function(a){return phe.FormElement.prototype.getAttribute.call(this,a,"value");};phe.checkBox.setValue=function(a,b){phe.FormElement.prototype.setAttribute.call(this,a,"value",b);};</script><script type="text/javascript">var phe=window.phe||{};phe.dashboard=phe.dashboard||{};</script><script type="text/javascript">var phe=window.phe||{};phe.datePicker=new phe.Element;phe.datePicker.datePickerRoot=null;phe.datePicker.datePickerCalendar=null;phe.datePicker.elmDayDisplay=null;phe.datePicker.datePickerInput=null;phe.datePicker.lang="en";phe.datePicker.MonthDropdown=null;phe.datePicker.YearDropdown=null;phe.datePicker.YearDropdownHideP="ui-dp-YearDropdownHideP";phe.datePicker.YearDropdownHideN="ui-dp-YearDropdownHideN";phe.datePicker.rIntegerPattern=/^\d+$/;phe.datePicker.localeTable={en:{Days:["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sun","Mon","Tue","Wed","Thu","Fri","Sat"],Months:[absa.locale["Common/General/Month/Label/January"],absa.locale["Common/General/Month/Label/February"],absa.locale["Common/General/Month/Label/March"],absa.locale["Common/General/Month/Label/April"],absa.locale["Common/General/Month/Label/May"],absa.locale["Common/General/Month/Label/June"],absa.locale["Common/General/Month/Label/July"],absa.locale["Common/General/Month/Label/August"],absa.locale["Common/General/Month/Label/September"],absa.locale["Common/General/Month/Label/October"],absa.locale["Common/General/Month/Label/November"],absa.locale["Common/General/Month/Label/December"],"Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"],Format:"yyyy-MM-dd",StartDay:0},de:{Days:["Sonntag","Montag","Dienstag","Mittwoch","Donnerstag","Freitag","Samstag","S","M","D","M","D","F","S"],Months:["Januar","Februar","M&#228;rz","April","Mai","Juni","Juli","August","September","Oktober","November","Dezember","Jan","Feb","M&#228;r","Apr","Mai","Jun","Jul","Aug","Sep","Okt","Nov","Dez"],Format:"yyyy-MM-dd",StartDay:0},nl:{Days:["Zondag","Maandag","Dinsdag","Woensdag","Donderdag","Vrijdag","Zaterdag","Z","M","D","W","D","V","Z"],Months:["Januari","Februari","Maart","April","Mei","Juni","Juli","Augustus","September","Oktober","November","December","Jan","Feb","Mar","Apr","Mei","Jun","Jul","Aug","Sep","Okt","Nov","Dec"],Format:"yyyy-MM-dd",StartDay:0}};phe.datePicker.aMonthLengths=[31,28,31,30,31,30,31,31,30,31,30,31],phe.datePicker.btl_calendar=function(h,e,b,j,i,g){this.elmPreviousYear=null;this.elmPreviousMonth=null;this.elmNextMonth=null;this.elmNextYear=null;this.elmGoto=null;this.oDisabledDates={days:{}};if(g){this.sDatesDisabled=new Array();this.sDatesDisabled=g.split(",");}else{this.sDatesDisabled=false;}this.bIsSaturdayDisabled=j;this.bIsSundayDisabled=i;this.initialized=false;var c=h.lang;this.locale=h.localeTable[c];this.language=c;this._range_days=[];this.one_day=1000*60*60*24;var f=e;f=f.split(/\/|\-/);this.calendarFrom=new Date(parseInt(f[0],10),parseInt(f[1],10)-1,parseInt(f[2],10));this.iYearFrom=this.calendarFrom.getFullYear();f=b;f=f.split(/\/|\-/);this.calendarTo=new Date(parseInt(f[0],10),parseInt(f[1],10)-1,parseInt(f[2],10));this.iYearTo=this.calendarTo.getFullYear();var a=new Date();if(a<this.calendarFrom){a=this.calendarFrom;}if(a>this.calenderTo){a=this.calenderTo;}this.iDisplayYear=a.getFullYear();this.iDisplayMonth=a.getMonth();this.oSelectedDate=a;};phe.datePicker.createPicker=function(j,e,d,a,n,i,h){this.calendar=new phe.datePicker.btl_calendar(this,d,a,n,i,h);this.datePickerInput=e;if(!this.datePickerRoot){var f=document.createElement("div");f.className="ui-datePickerRoot";document.body.appendChild(f);this.datePickerRoot=f;}this.datePickerRoot.innerHTML=this.renderDP();this.datePickerCalendar=bb.selector.query(this.datePickerRoot,".ui-dp-calendar");var k=new Date();if(this.datePickerInput.value!=""){this.datePickerInput.value=bb.string.trim(this.datePickerInput.value);var c=/(19|20)\d\d[- /.](0[1-9]|1[012])[- /.](0[1-9]|[12][0-9]|3[01])/;var m=c.test(this.datePickerInput.value);if(!m){this.datePickerInput.value="";}k=this.getDateFromFormat(this.datePickerInput.value,this.calendar.locale.Format,this.calendar.language);}if(k<this.calendar.calendarFrom){k=this.calendar.calendarFrom;this.datePickerInput.value="";}if(k>this.calendar.calendarTo){k=this.calendar.calendarTo;this.datePickerInput.value="";}var b=!k||!(k instanceof Date)?new Date():k;this.setDate(this.calendar,b);this.repaint();this.positionDP(j);this.addHideEventHandler();this.addMouseDownEventHandler();this.addMouseUpEventHandler();this.addClickEventHandler();this.addMouseELEventHandler();bb.html.disableUserSelect(this.datePickerRoot);if(absa.touch.enabled&&absa.touch.android){bb.html.addClass(document.body,"ap-common-noTapHighlight");bb.html.addClass(this.datePickerRoot,"ap-common-defaultTapHighlight");}if(bb.browser.ie&&bb.browser.version<=6){var l=bb.selector.query(this.datePickerRoot.parentNode,".ui-dp-ie6-mask");var g=bb.selector.query(this.datePickerRoot,".ui-dp-calendar");if(!l){var l=document.createElement("textarea");l.disabled=true;l.style.position="absolute";l.frameBorder="2";l.scrolling="no";bb.html.addClass(l,"ui-dp-ie6-mask");this.datePickerRoot.parentNode.insertBefore(l,this.datePickerRoot);}l.style.display="block";l.style.left=this.datePickerRoot.style.left;l.style.top=this.datePickerRoot.style.top;l.style.width=g.offsetWidth+"px";l.style.height=g.offsetHeight+"px";}};phe.datePicker.positionDP=function(a){if(bb.browser.webkit){bb.html.position(this.datePickerRoot,a,"tooltip");}else{bb.html.position(this.datePickerRoot,a,"after-start");}};phe.datePicker.addHideEventHandler=function(){var a=this;bb.html.addEventListener(document.documentElement,"mousedown",function(b){var c=b.target||b.srcElement;if(!bb.selector.queryAncestor(c,".ui-datePickerRoot",document.body)){a.hideDP();bb.html.removeEventListener(document.documentElement,"mousedown",arguments.callee);}});};phe.datePicker.addMouseDownEventHandler=function(){var b=bb.selector.query(this.datePickerCalendar,".ui-dp-button-nmonth");var a=bb.selector.query(this.datePickerCalendar,".ui-dp-button-pmonth");bb.html.addEventListener(this.datePickerCalendar,"mousedown",function(c){var d=c.target||c.srcElement;if(d==b){bb.html.addClass(d,"ui-dp-button-nmonth-active");}else{if(d==a){bb.html.addClass(d,"ui-dp-button-pmonth-active");}}bb.html.handlePreventDefaultAndStop(c);});};phe.datePicker.addMouseUpEventHandler=function(){var b=bb.selector.query(this.datePickerCalendar,".ui-dp-button-nmonth");var a=bb.selector.query(this.datePickerCalendar,".ui-dp-button-pmonth");bb.html.addEventListener(this.datePickerCalendar,"mouseup",function(c){var d=c.target||c.srcElement;if(d.tagName.toLowerCase()=="td"){}else{if(d==b){phe.datePicker.gotoNMonth();bb.html.removeClass(d,"ui-dp-button-nmonth-active");}else{if(d==a){phe.datePicker.gotoPMonth();bb.html.removeClass(d,"ui-dp-button-pmonth-active");}else{if(bb.html.hasClass(d,"ui-dp-month")){}else{if(bb.html.hasClass(d,"ui-dp-year")){}}}}}});};phe.datePicker.addClickEventHandler=function(){bb.html.addEventListener(this.datePickerCalendar,"click",function(a){var b=a.target||a.srcElement;if(b.tagName.toLowerCase()=="td"){phe.datePicker.clickTD(b);}else{if(b.parentNode.tagName.toLowerCase()=="td"){phe.datePicker.clickTD(b.parentNode);}}});};phe.datePicker.addMouseELEventHandler=function(){var b=bb.selector.query(this.datePickerCalendar,".ui-dp-button-nmonth");var a=bb.selector.query(this.datePickerCalendar,".ui-dp-button-pmonth");this.MouseEEHN=function(c){bb.html.addClass(b,"ui-dp-button-nmonth-hover");};bb.html.addEventListener(b,"mouseover",this.MouseEEHN);this.MouseEEHP=function(c){bb.html.addClass(a,"ui-dp-button-pmonth-hover");};bb.html.addEventListener(a,"mouseover",this.MouseEEHP);this.MouseLEHN=function(c){bb.html.removeClass(b,"ui-dp-button-nmonth-hover");};bb.html.addEventListener(b,"mouseout",this.MouseLEHN);this.MouseLEHP=function(c){bb.html.removeClass(a,"ui-dp-button-pmonth-hover");};bb.html.addEventListener(a,"mouseout",this.MouseLEHP);};phe.datePicker.addEventHanlder4Month=function(){var c=bb.selector.queryAll(this.datePickerCalendar,".ui-dp-monthDropdown div");var a=function(d){bb.html.addEventListener(d,"mouseover",function(){bb.html.addClass(d,"ui-dp-monthDropdownEle-hover");});bb.html.addEventListener(d,"mouseout",function(){bb.html.removeClass(d,"ui-dp-monthDropdownEle-hover");});bb.html.addEventListener(d,"click",function(){phe.datePicker.setMonthDropdown(d);});};for(var b=0;b<c.length;b++){a(c[b]);}};phe.datePicker.addEventHanlder4Year=function(){var e=bb.selector.queryAll(this.datePickerCalendar,".ui-dp-yearDropdown .ui-dp-yearDropdown-yearWrapper div");var a=function(f){bb.html.addEventListener(f,"mouseover",function(){bb.html.addClass(f,"ui-dp-yearDropdownEle-hover");});bb.html.addEventListener(f,"mouseout",function(){bb.html.removeClass(f,"ui-dp-yearDropdownEle-hover");});bb.html.addEventListener(f,"click",function(){phe.datePicker.setYearDropdown(f);});};for(var b=0;b<e.length;b++){a(e[b]);}var d=bb.selector.query(this.datePickerCalendar,".ui-dp-yearDropdown .ui-dp-yearDropdown-button-pyear");var c=bb.selector.query(this.datePickerCalendar,".ui-dp-yearDropdown .ui-dp-yearDropdown-button-nyear");bb.html.addEventListener(d,"mouseover",function(){bb.html.addClass(d,"ui-dp-yearDropdown-button-pyear-hover");phe.datePicker.scrollYearDropdownPEnter();});bb.html.addEventListener(d,"mouseout",function(){bb.html.removeClass(d,"ui-dp-yearDropdown-button-pyear-hover");phe.datePicker.scrollYearDropdownPLeave();});bb.html.addEventListener(c,"mouseover",function(){bb.html.addClass(c,"ui-dp-yearDropdown-button-nyear-hover");phe.datePicker.scrollYearDropdownNEnter();});bb.html.addEventListener(c,"mouseout",function(){bb.html.removeClass(c,"ui-dp-yearDropdown-button-nyear-hover");phe.datePicker.scrollYearDropdownNLeave();});};phe.datePicker.addTDMouseOverEventHandler=function(){var b=bb.selector.queryAll(this.datePickerCalendar,".ui-dp-table-wrapper td");for(var a=0;a<b.length;a++){bb.html.addEventListener(b[a],"mouseout",function(c){var d=c.target||c.srcElement;bb.html.removeClass(d,"ui-dp-day-hover");});bb.html.addEventListener(b[a],"mouseover",function(c){var d=c.target||c.srcElement;bb.html.addClass(d,"ui-dp-day-hover");});}};phe.datePicker.hideDP=function(){this.datePickerRoot.style.left="";this.datePickerRoot.style.top="";this.closeMonthDropdown();this.closeYearDropdown();if(bb.browser.ie&&bb.browser.version<=6){var a=bb.selector.query(this.datePickerRoot.parentNode,".ui-dp-ie6-mask");a.style.display="none";}if(absa.touch.enabled&&absa.touch.android){bb.html.removeClass(document.body,"ap-common-noTapHighlight");bb.html.removeClass(this.datePickerRoot,"ap-common-defaultTapHighlight");}};phe.datePicker.renderDP=function(){var a=[];a.push('<div class="ui-dp-calendar">');a.push('<div class="ui-dp-control">');a.push('<div class="ui-dp-button ui-dp-button-pmonth"></div>');a.push('<div class="ui-dp-month">',this.calendar.locale.Months[this.calendar.oSelectedDate.getMonth()],"</div>");a.push('<div class="ui-dp-year">',this.calendar.oSelectedDate.getFullYear(),"</div>");a.push('<div class="ui-dp-button ui-dp-button-nmonth"></div>');a.push("</div>");a.push('<div class="ui-dp-table-wrapper">');a.push(this.createDPTableHTML());a.push("</div>");a.push("</div>");return a.join("");};phe.datePicker.createDPTableHTML=function(){var f=[];f.push('<table cellspacing="0" cellpadding="0" border="0" class="ui-dp-table"><thead><tr>');var a;for(var d=7;d<14;d++){a=d+this.calendar.locale.StartDay;if(a>=14){a-=7;}f.push("<th>",this.calendar.locale.Days[a],"</th>");}f.push("</tr></thead><tbody>");var c=this.getDaysInfo(this.calendar);var g=c.length/7;for(var d=0;d<g;d++){f.push("<tr>");for(var b=0;b<7;b++){var e=d*7+b;if(c[e].bSelected){f.push('<td class="ui-dp-day ',c[e].sClass,'"><div>',c[e].iDay,"</div></td>");}else{f.push('<td class="ui-dp-day ',c[e].sClass,'">',c[e].iDay,"</td>");}}f.push("</tr>");}f.push("</tbody></table>");return f.join("");};phe.datePicker.getDaysInfo=function(x){var e=(x.iDisplayMonth==0)?11:x.iDisplayMonth-1;var d=(x.iDisplayMonth==11)?0:x.iDisplayMonth+1;var C=this.getDaysInMonth(e,x.iDisplayYear);var F=this.getDaysInMonth(x.iDisplayMonth,x.iDisplayYear);var E=this.getDaysInMonth(d,x.iDisplayYear);var l=0;var v=x.locale.Days[new Date(x.iDisplayYear,x.iDisplayMonth,1).getDay()];var y=null;for(var A=0;A<7;A++){y=A+x.locale.StartDay;if(y>6){y-=7;}if(x.locale.Days[y]==v){l=A;}}var u=1;var t=l-1;var a=1;var s=new Date();var q=s.getFullYear();var w=s.getMonth();var k=s.getDate();var c=[];var m="";var n=0;var B=x.oSelectedDate.getFullYear(),h=x.oSelectedDate.getMonth(),g=x.oSelectedDate.getDate();var D=5;if((l==0)&&(F==28)){D=4;}else{var r=7-(F-28);if(l>r){D=6;}}for(var A=0;A<D;A++){for(var y=0;y<7;y++){var z=false,b=false,p;var o=(y+x.locale.StartDay)%7;if(A==0&&y<l){p={iDay:C-t,iYear:x.iDisplayYear-(x.iDisplayMonth?0:1),iMonth:x.iDisplayMonth>0?x.iDisplayMonth:12,iDow:o,sClass:"ui-dp-previousMonth",bPreviousMonth:true};t--;}else{if(u>F){p={iDay:a,iYear:x.iDisplayYear+(x.iDisplayMonth<11?0:1),iMonth:(x.iDisplayMonth+1)%12+1,iDow:o,sClass:"ui-dp-nextMonth",bNextMonth:true};a++;}else{var f="ui-dp-currentMonth";var m=x.iDisplayYear+"-"+(x.iDisplayMonth+1)+"-"+u;if(x.iDisplayYear==q&&x.iDisplayMonth==w&&u==k){f+=" ui-dp-today";b=true;}if(x.iDisplayYear==B&&x.iDisplayMonth==h&&u==g){z=true;f+=" ui-dp-selected-day";}p={iDay:u,iYear:x.iDisplayYear,iMonth:x.iDisplayMonth+1,iDow:o,sClass:f,bSelected:z,bToday:b};u++;}}p.bRestricted=this.isRestricted(x,new Date(p.iYear,p.iMonth-1,p.iDay),o);if(p.bRestricted){p.sClass+=" ui-dp-restricted";}c.push(p);}}return c;};phe.datePicker.getInt=function(f,d,c,a){for(var b=a;b>=c;b--){var e=f.substring(d,d+b);if(this.rIntegerPattern.test(e)){return e;}}return null;};phe.datePicker.isRestricted=function(b,a,c){if(arguments.length<3){c=a.getDay();}return(a<b.calendarFrom)||(a>b.calendarTo)||b.oDisabledDates[a.valueOf()]||b.oDisabledDates.days[c]||(b.bIsSaturdayDisabled&&this.isSaturday(a))||(b.bIsSundayDisabled&&this.isSunday(a))?true:false||(b.sDatesDisabled&&this.isDatesDisabled(a,b.sDatesDisabled));};phe.datePicker.isSaturday=function(a){return(a.toString().indexOf("Sat")>-1);};phe.datePicker.isSunday=function(a){return(a.toString().indexOf("Sun")>-1);};phe.datePicker.isDatesDisabled=function(j,h){var d=false;if(h){var a=j.getFullYear().toString();var f=(j.getMonth()+1).toString();var b=f[1]?f:"0"+f[0];var g=j.getDate().toString();var k=g[1]?g:"0"+g[0];var e=a+"-"+b+"-"+k;for(var c=0;c<h.length;c++){if(e==bb.string.trim(h[c])){d=true;break;}}}return d;};phe.datePicker.isRestrictedMonth=function(b,a){return(a<this.calendar.iYearFrom)||((a==this.calendar.iYearFrom)&&(b<this.calendar.calendarFrom.getMonth()))||(a>this.calendar.iYearTo)||((a==this.calendar.iYearTo)&&(b>this.calendar.calendarTo.getMonth()));};phe.datePicker.getDaysInMonth=function(b,a){if(b==1&&(a%4==0&&(a%100!=0||a%400==0))){return 29;}return this.aMonthLengths[b];};phe.datePicker.repaint=function(){var a=bb.selector.query(this.datePickerCalendar,".ui-dp-control .ui-dp-button-pmonth");var c=bb.selector.query(this.datePickerCalendar,".ui-dp-control .ui-dp-button-nmonth");a.style.display="";c.style.display="";if((this.calendar.iDisplayYear==this.calendar.iYearFrom)&&(this.calendar.iDisplayMonth==this.calendar.calendarFrom.getMonth())){a.style.display="none";}if((this.calendar.iDisplayYear==this.calendar.iYearTo)&&(this.calendar.iDisplayMonth==this.calendar.calendarTo.getMonth())){c.style.display="none";}if(this.isRestrictedMonth(this.calendar.iDisplayMonth,this.calendar.iDisplayYear)){a.style.display="none";c.style.display="none";}var d=bb.selector.query(this.datePickerCalendar,".ui-dp-year");d.innerText=d.textContent=this.calendar.iDisplayYear;var b=bb.selector.query(this.datePickerCalendar,".ui-dp-month");b.innerText=b.textContent=this.calendar.locale.Months[this.calendar.iDisplayMonth];var f=bb.selector.query(this.datePickerCalendar,".ui-dp-table-wrapper");f.innerHTML=this.createDPTableHTML();var e=bb.selector.query(this.datePickerCalendar,".ui-dp-table td.ui-dp-selected-day");if(e){this.elmDayDisplay=e;}this.addTDMouseOverEventHandler();};phe.datePicker.setYear=function(a){this.calendar.iDisplayYear=a;this.repaint();};phe.datePicker.setMonth=function(b){var c=b;var a=this.calendar.iDisplayYear;if(b<0){c=11;a--;}else{if(b>11){c=0;a++;}}if(this.isRestrictedMonth(c,a)){return;}this.calendar.iDisplayMonth=c;this.calendar.iDisplayYear=a;this.repaint();};phe.datePicker.gotoPMonth=function(){this.setMonth(this.calendar.iDisplayMonth-1);this.closeYearDropdown();this.closeMonthDropdown();};phe.datePicker.gotoNMonth=function(){this.setMonth(this.calendar.iDisplayMonth+1);this.closeYearDropdown();this.closeMonthDropdown();};phe.datePicker.clickTD=function(c){var e=this.datePickerInput;var a=this.elmDayDisplay;if(bb.html.hasClass(c,"ui-dp-restricted")){return;}var b=parseInt(c.innerText||c.textContent,10);var f=this.calendar.iDisplayMonth;var d=this.calendar.iDisplayYear;if(bb.html.hasClass(c,"ui-dp-previousMonth")){--f;if(f<0){f=11;--d;}}else{if(bb.html.hasClass(c,"ui-dp-nextMonth")){++f;if(f>11){f=0;++d;}}}if(a){bb.html.removeClass(a,"ui-dp-selected-day");}bb.html.addClass(c,"ui-dp-selected-day");this.elmDayDisplay=c;this.selectDate(new Date(d,f,b));this.hideDP();};phe.datePicker.selectDate=function(d){var c=!d||!(d instanceof Date)?new Date():d;this.setDate(this.calendar,c);var b=this.getFormattedValue(c,this.calendar.locale.Format,this.calendar.language);var a=this.datePickerInput.value;if(d){this.datePickerInput.value=b;phe.datePicker.setAttribute(this.datePickerInput.parentNode,"value",b);}if(a!=b){bb.html.fireEvent(this.datePickerInput,"change");}this.repaint();if(absa.touch.enabled){this.datePickerInput.blur();}};phe.datePicker.fireOnChangeEvent=function(c){var b=bb.selector.queryAncestor(c,".ui-datePicker");phe.datePicker.setValue(b,c.value);var a=absa.util.attributeToFunction(b,"xonchange");if(a){a.call(b);}};phe.datePicker.setDate=function(b,c){if(!c instanceof Date){return a;}var a=!b.oSelectedDate||!c||b.oSelectedDate.valueOf()!=c.valueOf();b.oSelectedDate=c;b.iDisplayYear=c.getFullYear();b.iDisplayMonth=c.getMonth();return a;};phe.datePicker.getFormattedValue=function(i,c,g){var h,e,d;if(i instanceof Date){h=i.getFullYear();e=i.getMonth();d=i.getDate();}else{h=arguments[0];e=arguments[1];d=arguments[2];c=arguments[3];g=arguments[4];i=new Date(h,e,d);}var b=new Date();if(h==null){h=b.getFullYear();}if(e==null){e=b.getMonth();}if(d==null){d=b.getDate();}var a=this.localeTable[g?g:"en"];if(c==null){c=a.Format;}var f=c.replace(/(yyyy|yy|MMMM|MMM|MM|M|dddd|ddd|dd|d)/g,function(j){switch(j){case"yyyy":return h;case"yy":return(""+h).substr(2,4);case"MMMM":return a.Months[e];case"MMM":return a.Months[e+12];case"MM":return(e<9)?"0"+(e+1):e+1;case"M":return e+1;case"dddd":return a.Days[i.getDay()];case"ddd":return a.Days[i.getDay()+7];case"dd":return(d<10)?"0"+d:d;case"d":return d;}});return f;};phe.datePicker.getDateFromFormat=function(l,e,m){if(!l||l==""){return new Date();}var b=this.localeTable[m?m:"en"];var j=0;var o=0;var k;var d;var n=new Date();var a=n.getFullYear()+"";var h=n.getMonth()+1+"";var g=n.getDate()+"";while(o<e.length){k=e.charAt(o);d="";while(e.charAt(o)==k&&o<e.length){d+=e.charAt(o++);}if(d=="yyyy"||d=="yy"){a=this.getInt(l,j,d.length,d.length);if(a==null){a=n.getFullYear()+"";}j+=a.length;if(a.length==2){iYear=parseInt(a,10);a=(iYear>n.getYear()-90)?1900+iYear:2000+iYear;}}else{if(d=="MMMM"){for(var f=11;f>=0;f--){var c=b.Months[f].toLowerCase();if(l.substring(j,j+c.length).toLowerCase()==c){h=f+1;j+=c.length;break;}}}else{if(d=="MMM"){for(var f=23;f>=12;f--){var c=b.Months[f].toLowerCase();if(l.substring(j,j+c.length).toLowerCase()==c){h=f-11;j+=c.length;break;}}}else{if(d=="ddd"||d=="dddd"){for(var f=0;f<b.Days.length;f++){if(l.substring(j,j+b.Days[f].length).toLowerCase()==b.Days[f].toLowerCase()){j+=b.Days[f].length;break;}}}else{if(d=="MM"||d=="M"){h=this.getInt(l,j,d.length,2);if(h===null){h=n.getMonth()+1+"";}j+=h.length;}else{if(d=="dd"||d=="d"){g=this.getInt(l,j,d.length,2);if(g==null){g=n.getDate()+"";}j+=g.length;}else{if(l.substring(j,j+d.length)!=d){}else{j+=d.length;}}}}}}}}return new Date(a,parseInt(h,10)-1,parseInt(g,10));};phe.datePicker.openMonthDropdown=function(){this.MonthDropdown=bb.selector.query(this.datePickerCalendar,".ui-dp-monthDropdown");var d=bb.selector.query(this.MonthDropdown,".ui-dp-monthDropdownEle-select");if(d){bb.html.removeClass(d,["ui-dp-monthDropdownEle-select"]);}var b=phe.matchChildren(this.MonthDropdown,"div")[this.calendar.iDisplayMonth];bb.html.addClass(b,["ui-dp-monthDropdownEle-select"]);var a=phe.matchChildren(this.MonthDropdown,"div");for(var c=0;c<a.length;c++){if(this.isRestrictedMonth(c,this.calendar.iDisplayYear)){bb.html.addClass(a[c],["ui-dp-monthDropdownEle-restricted"]);}else{bb.html.removeClass(a[c],["ui-dp-monthDropdownEle-restricted"]);}}this.MonthDropdown.style.display="block";this.closeYearDropdown();};phe.datePicker.closeMonthDropdown=function(){this.MonthDropdown=bb.selector.query(this.datePickerCalendar,".ui-dp-monthDropdown");if(this.MonthDropdown){this.MonthDropdown.style.display="";}};phe.datePicker.setMonthDropdown=function(b){this.MonthDropdown=bb.selector.query(this.datePickerCalendar,".ui-dp-monthDropdown");if(bb.html.hasClass(b,"ui-dp-monthDropdownEle-restricted")){return;}var c=phe.matchChildren(this.MonthDropdown,"div");for(var a=0;a<c.length;a++){if(b==c[a]){break;}}this.setMonth(a);this.closeMonthDropdown();};phe.datePicker.openYearDropdown=function(){this.YearDropdown=bb.selector.query(this.datePickerCalendar,".ui-dp-yearDropdown");var g=bb.selector.query(this.YearDropdown,".ui-dp-yearDropdownEle-select");if(g){bb.html.removeClass(g,["ui-dp-yearDropdownEle-select"]);}var f=bb.selector.query(this.YearDropdown,".ui-dp-yearDropdown-yearWrapper");var c=this.calendar.iYearTo-this.calendar.iDisplayYear;var d=this.calendar.iDisplayYear-this.calendar.iYearFrom;var b=15;var e=0-(c-4)*b;bb.html.removeClass(this.YearDropdown,[this.YearDropdownHideP]);bb.html.removeClass(this.YearDropdown,[this.YearDropdownHideN]);if(d<=4){e=0-((this.calendar.iYearTo-this.calendar.iYearFrom)-8)*b;bb.html.addClass(this.YearDropdown,[this.YearDropdownHideP]);}if(c<=4){e=0;bb.html.addClass(this.YearDropdown,[this.YearDropdownHideN]);}f.style.top=e+"px";var a=phe.matchChildren(f,"div")[c];bb.html.addClass(a,["ui-dp-yearDropdownEle-select"]);this.YearDropdown.style.display="block";this.closeMonthDropdown();};phe.datePicker.closeYearDropdown=function(){this.YearDropdown=bb.selector.query(this.datePickerCalendar,".ui-dp-yearDropdown");if(this.YearDropdown){this.YearDropdown.style.display="";}};phe.datePicker.setYearDropdown=function(a){this.YearDropdown=bb.selector.query(this.datePickerCalendar,".ui-dp-yearDropdown");this.setYear(parseInt(a.innerHTML,10));this.closeYearDropdown();};phe.datePicker.scrollYearDropdownPEnter=function(){this.YearDropdownWrapper=bb.selector.query(this.datePickerCalendar,".ui-dp-yearDropdown .ui-dp-yearDropdown-yearWrapper");var e=phe.matchChildren(this.YearDropdownWrapper,"div");var a=15;this.YearDropdownMaxTop=e.length<=9?0:(e.length-9)*a;var b=Math.abs(parseInt(this.YearDropdownWrapper.style.top,10));if(b>this.YearDropdownMaxTop){this.YearDropdownWrapper.style.top=(0-this.YearDropdownMaxTop)+"px";return;}if(bb.html.hasClass(this.YearDropdown,this.YearDropdownHideN)){bb.html.removeClass(this.YearDropdown,[this.YearDropdownHideN]);}this.YearDropdownbStop=false;var c=this;var d=function(){var g=parseInt(c.YearDropdownWrapper.style.top,10);var f=0-c.YearDropdownMaxTop;if(c.YearDropdownbStop||g<=f){if(g<=f){bb.html.addClass(c.YearDropdown,[c.YearDropdownHideP]);}return;}var h=g-a;var j=g%a;var i=10;if(j!=0){h-=j;}if(h<f){h=f;}bb.smil.animate(c.YearDropdownWrapper,{attributeName:"top",dur:(a*i)+"ms",to:h+"px",fill:"freeze"},d);};d();};phe.datePicker.scrollYearDropdownPLeave=function(){this.YearDropdownbStop=true;};phe.datePicker.scrollYearDropdownNEnter=function(){this.YearDropdownWrapper=bb.selector.query(this.datePickerCalendar,".ui-dp-yearDropdown .ui-dp-yearDropdown-yearWrapper");var e=phe.matchChildren(this.YearDropdownWrapper,"div");var a=15;this.YearDropdownMaxTop=e.length<=9?0:(e.length-9)*a;var b=parseInt(this.YearDropdownWrapper.style.top,10);if(b>=0){this.YearDropdownWrapper.style.top="0px";return;}if(bb.html.hasClass(this.YearDropdown,this.YearDropdownHideP)){bb.html.removeClass(this.YearDropdown,[this.YearDropdownHideP]);}this.YearDropdownbStop=false;var d=this;var c=function(){var g=parseInt(d.YearDropdownWrapper.style.top,10);var f=0-d.YearDropdownMaxTop;if(d.YearDropdownbStop||g>=0){if(g>=0){bb.html.addClass(d.YearDropdown,[d.YearDropdownHideN]);}return;}var h=g+a;var j=a-(g%a);var i=10;if(j!=a){h+=j;}if(h>0){h=0;}bb.smil.animate(d.YearDropdownWrapper,{attributeName:"top",dur:(a*i)+"ms",to:h+"px",fill:"freeze"},c);};c();};phe.datePicker.scrollYearDropdownNLeave=function(){this.YearDropdownbStop=true;};phe.datePicker.setValue=function(b,c){phe.datePicker.setAttribute(b,"value",c);var a=bb.selector.query(b,".ui-datePicker--input");a.value=c;};phe.datePicker.getValue=function(b){var a=bb.selector.query(b,".ui-datePicker--input")||bb.selector.query(b,".ui-datePicker--input_disabled");return a.value;};phe.datePicker.setAttribute=function(d,c,e){var a=bb.selector.query(d,".ui-datePicker--input")||bb.selector.query(d,".ui-datePicker--input_disabled");var b=bb.selector.query(d,".ui-datePicker-clickableImgContainer_disabled")||bb.selector.query(d,".ui-datePicker-clickableImgContainer");if(c=="disabled"){if(e=="false"){bb.html.replaceClass(b,"ui-datePicker-clickableImgContainer_disabled","ui-datePicker-clickableImgContainer");bb.html.replaceClass(a,"ui-datePicker--input_disabled","ui-datePicker--input");a.removeAttribute("disabled");}else{bb.html.replaceClass(a,"ui-datePicker--input","ui-datePicker--input_disabled");bb.html.replaceClass(b,"ui-datePicker-clickableImgContainer","ui-datePicker-clickableImgContainer_disabled");phe.Element.prototype.setAttribute.call(this,a,"disabled",e);}}else{switch(c){case"dataType":phe.Element.prototype.setAttribute.call(this,a,"bbf_type",e);break;case"required":phe.Element.prototype.setAttribute.call(this,a,"bbf_required",e);break;case"requiredText":case"schemaTypeText":case"customValidation":case"customValidationText":case"showMeHow":case"name":case"id":phe.Element.prototype.setAttribute.call(this,a,c,e);break;case"onchange":phe.Element.prototype.setAttribute.call(this,d,"xonchange",e);break;default:phe.Element.prototype.setAttribute.call(this,d,c,e);}}};phe.datePicker.getAttribute=function(c,b){var a=bb.selector.query(c,".ui-datePicker--input")||bb.selector.query(c,".ui-datePicker--input_disabled");switch(b){case"dataType":return phe.Element.prototype.getAttribute.call(this,a,"bbf_type");break;case"required":return phe.Element.prototype.getAttribute.call(this,a,"bbf_required");break;case"requiredText":case"schemaTypeText":case"customValidation":case"customValidationText":case"showMeHow":case"name":case"id":return phe.Element.prototype.getAttribute.call(this,a,b);break;case"onchange":return phe.Element.prototype.getAttribute.call(this,c,"xonchange");break;default:return phe.Element.prototype.getAttribute.call(this,c,b);}};phe.datePicker.validateDate=function(j){var n=new Date();if(j.value!=""){j.value=bb.string.trim(j.value);var h=/(19|20)\d\d[- /.](0[1-9]|1[012])[- /.](0[1-9]|[12][0-9]|3[01])/;var p=h.test(j.value);if(!p){return false;}var i=j.value.split(/\/|\-/);n=new Date(parseInt(i[0],10),parseInt(i[1],10)-1,parseInt(i[2],10));}else{return true;}var e=j.parentNode;var o=!bb.html.hasClass(e,"ui-datePicker-futureOnly");var k=!bb.html.hasClass(e,"ui-datePicker-pastOnly");var a=new Date();var g=e.getAttribute("fromdate");if(!g&&o){g="1900-01-01";}else{if(!g){g=a.getFullYear()+"-"+(a.getMonth()+1)+"-"+a.getDate();}}var b=e.getAttribute("todate");if(!b&&k){b="2099-12-31";}else{if(!b){b=a.getFullYear()+"-"+(a.getMonth()+1)+"-"+a.getDate();}}var d=true;var f=g.split(/\/|\-/);var l=new Date(parseInt(f[0],10),parseInt(f[1],10)-1,parseInt(f[2],10));var m=b.split(/\/|\-/);var c=new Date(parseInt(m[0],10),parseInt(m[1],10)-1,parseInt(m[2],10));if(n<l){d=false;}if(d&&(n>c)){d=false;}return d;};</script><script type="text/javascript">var phe=window.phe||{};phe.datePicker2=new phe.Element;phe.datePicker2.datePicker2Root=null;phe.datePicker2.datePicker2Calendar=null;phe.datePicker2.elmDayDisplay=null;phe.datePicker2.elmMonthDisplay=null;phe.datePicker2.elmYearDisplay=null;phe.datePicker2.datePicker2Input=null;phe.datePicker2.lang="en";phe.datePicker2.rIntegerPattern=/^\d+$/;phe.datePicker2.localeTable={en:{Days:["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sun","Mon","Tue","Wed","Thu","Fri","Sat"],Months:[absa.locale["Common/General/Month/Label/January"],absa.locale["Common/General/Month/Label/February"],absa.locale["Common/General/Month/Label/March"],absa.locale["Common/General/Month/Label/April"],absa.locale["Common/General/Month/Label/May"],absa.locale["Common/General/Month/Label/June"],absa.locale["Common/General/Month/Label/July"],absa.locale["Common/General/Month/Label/August"],absa.locale["Common/General/Month/Label/September"],absa.locale["Common/General/Month/Label/October"],absa.locale["Common/General/Month/Label/November"],absa.locale["Common/General/Month/Label/December"],"Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"],Format:"yyyy-MM-dd",StartDay:0},af:{Days:["Sondag","Maandag","Dinsdag","Woensdag","Donnerdag","Vrydag","Saterdag","S","M","D","W","D","F","S"],Months:["Januarie","February","Maart","April","Mei","Junie","Julie","Augustus","September","Oktober","November","Desember","Jan","Feb","Mar","Apr","Mei","Jun","Jul","Aug","Sep","Okt","Nov","Des"],Format:"yyyy-MM-dd",StartDay:0},nl:{Days:["Zondag","Maandag","Dinsdag","Woensdag","Donderdag","Vrijdag","Zaterdag","Z","M","D","W","D","V","Z"],Months:["Januari","Februari","Maart","April","Mei","Juni","Juli","Augustus","September","Oktober","November","December","Jan","Feb","Mar","Apr","Mei","Jun","Jul","Aug","Sep","Okt","Nov","Dec"],Format:"yyyy-MM-dd",StartDay:0}};phe.datePicker2.aMonthLengths=[31,28,31,30,31,30,31,31,30,31,30,31],phe.datePicker2.btl_calendar=function(a,f,i,e,c){this.elmPreviousYear=null;this.elmPreviousMonth=null;this.elmNextMonth=null;this.elmNextYear=null;this.elmGoto=null;this.oDisabledDates={days:{}};this.bIsSaturdayDisabled=e;this.bIsSundayDisabled=c;this.initialized=false;var h=a.lang;this.locale=a.localeTable[h];this.language=h;this._range_days=[];this.one_day=1000*60*60*24;var g=f;g=g.split(/\/|\-/);this.calendarFrom=new Date(parseInt(g[0],10),parseInt(g[1],10)-1,parseInt(g[2],10));this.iYearFrom=this.calendarFrom.getFullYear();g=i;g=g.split(/\/|\-/);this.calendarTo=new Date(parseInt(g[0],10),parseInt(g[1],10)-1,parseInt(g[2],10));this.iYearTo=this.calendarTo.getFullYear();var b=new Date();if(b<this.calendarFrom){b=this.calendarFrom;}if(b>this.calenderTo){b=this.calenderTo;}this.iDisplayYear=b.getFullYear();this.iDisplayMonth=b.getMonth();this.oSelectedDate=b;};phe.datePicker2.createPicker=function(f,e,d,a,m,i){this.calendar=new phe.datePicker2.btl_calendar(this,d,a,m,i);this.datePicker2Input=e;if(!this.datePicker2Root){var g=document.createElement("div");g.className="ui-datePicker2Root";document.body.appendChild(g);this.datePicker2Root=g;}this.datePicker2Root.innerHTML=this.renderDP();this.datePicker2Calendar=bb.selector.query(this.datePicker2Root,".ui-dp-calendar");var j=new Date();if(this.datePicker2Input.value!=""){this.datePicker2Input.value=bb.string.trim(this.datePicker2Input.value);var c=/(19|20)\d\d[- /.](0[1-9]|1[012])[- /.](0[1-9]|[12][0-9]|3[01])/;var l=c.test(this.datePicker2Input.value);if(!l){this.datePicker2Input.value="";}j=this.getDateFromFormat(this.datePicker2Input.value,this.calendar.locale.Format,this.calendar.language);}if(j<this.calendar.calendarFrom){j=this.calendar.calendarFrom;this.datePicker2Input.value="";}if(j>this.calendar.calendarTo){j=this.calendar.calendarTo;this.datePicker2Input.value="";}var b=!j||!(j instanceof Date)?new Date():j;this.setDate(this.calendar,b);this.repaint();this.positionDP(f);this.addHideEventHandler();this.addClickEventHandler();this.addDIVMouseOverEventHandler();bb.html.disableUserSelect(this.datePicker2Root);if(absa.touch.enabled&&absa.touch.android){bb.html.addClass(document.body,"ap-common-noTapHighlight");bb.html.addClass(this.datePicker2Root,"ap-common-defaultTapHighlight");}if(bb.browser.ie&&bb.browser.version<=6){var k=bb.selector.query(this.datePicker2Root.parentNode,".ui-dp-ie6-mask");var h=bb.selector.query(this.datePicker2Root,".ui-dp-calendar");if(!k){var k=document.createElement("textarea");k.disabled=true;k.style.position="absolute";k.frameBorder="2";k.scrolling="no";bb.html.addClass(k,"ui-dp-ie6-mask");this.datePicker2Root.parentNode.insertBefore(k,this.datePicker2Root);}k.style.display="block";k.style.left=this.datePicker2Root.style.left;k.style.top=this.datePicker2Root.style.top;k.style.width=h.offsetWidth+"px";k.style.height=h.offsetHeight+"px";}};phe.datePicker2.positionDP=function(a){if(bb.browser.webkit){bb.html.position(this.datePicker2Root,a,"tooltip");}else{bb.html.position(this.datePicker2Root,a,"after-start");}var b=bb.selector.query(this.datePicker2Root,".ui-dp-selected-year");bb.command.scrollTo(b);};phe.datePicker2.addHideEventHandler=function(){var a=this;bb.html.addEventListener(document.documentElement,"mousedown",function(b){var c=b.target||b.srcElement;if(!bb.selector.queryAncestor(c,".ui-datePicker2Root",document.body)){a.hideDP();bb.html.removeEventListener(document.documentElement,"mousedown",arguments.callee);}});};phe.datePicker2.addClickEventHandler=function(){bb.html.addEventListener(this.datePicker2Calendar,"click",function(a){var b=a.target||a.srcElement;if(b.tagName.toLowerCase()=="td"){phe.datePicker2.clickTD(b);}else{if(b.parentNode.tagName.toLowerCase()=="td"){phe.datePicker2.clickTD(b.parentNode);}else{if(b.tagName.toLowerCase()=="div"){phe.datePicker2.clickDIV(b);}}}});};phe.datePicker2.addTDMouseOverEventHandler=function(){var b=bb.selector.queryAll(this.datePicker2Calendar,".ui-dp-table-wrapper td");for(var a=0;a<b.length;a++){bb.html.addEventListener(b[a],"mouseout",function(c){var d=c.target||c.srcElement;bb.html.removeClass(d,"ui-dp-day-hover");});bb.html.addEventListener(b[a],"mouseover",function(c){var d=c.target||c.srcElement;bb.html.addClass(d,"ui-dp-day-hover");});}};phe.datePicker2.addDIVMouseOverEventHandler=function(){var b=bb.selector.queryAll(this.datePicker2Calendar,".years div");for(var a=0;a<b.length;a++){bb.html.addEventListener(b[a],"mouseout",function(d){var e=d.target||d.srcElement;bb.html.removeClass(e,"ui-dp-year-hover");});bb.html.addEventListener(b[a],"mouseover",function(d){var e=d.target||d.srcElement;bb.html.addClass(e,"ui-dp-year-hover");});}var c=bb.selector.queryAll(this.datePicker2Calendar,".ui-dp-month");for(var a=0;a<c.length;a++){bb.html.addEventListener(c[a],"mouseout",function(d){var e=d.target||d.srcElement;bb.html.removeClass(e,"ui-dp-month-hover");});bb.html.addEventListener(c[a],"mouseover",function(d){var e=d.target||d.srcElement;bb.html.addClass(e,"ui-dp-month-hover");});}};phe.datePicker2.hideDP=function(){this.datePicker2Root.style.left="";this.datePicker2Root.style.top="";if(bb.browser.ie&&bb.browser.version<=6){var a=bb.selector.query(this.datePicker2Root.parentNode,".ui-dp-ie6-mask");a.style.display="none";}if(absa.touch.enabled&&absa.touch.android){bb.html.removeClass(document.body,"ap-common-noTapHighlight");bb.html.removeClass(this.datePicker2Root,"ap-common-defaultTapHighlight");}};phe.datePicker2.renderDP=function(){var c=[];c.push('<div class="ui-dp-calendar">');c.push('<div class="ui-dp-calendar-grid-col1">');c.push('<div class="years">');for(var d=this.calendar.iYearTo;d>=this.calendar.iYearFrom;d--){c.push('<div class="ui-dp-year year y_'+d+'" year="'+d+'">'+d+"</div>");}c.push("</div>");c.push("</div>");c.push('<div class="ui-dp-calendar-grid-col2">');c.push('<div class="ui-dp-control">');for(var b=12;b<this.calendar.locale.Months.length;b++){c.push('<div class="ui-dp-month m_'+(b-12)+'" month="'+(b-12)+'">',this.calendar.locale.Months[b],"</div>");}c.push("</div>");c.push("</div>");c.push('<div class="ui-dp-calendar-grid-col3">');c.push('<div class="ui-dp-table-wrapper">');c.push(this.createDPTableHTML());c.push("</div>");c.push("</div>");c.push("</div>");return c.join("");};phe.datePicker2.createDPTableHTML=function(){var e=[];e.push('<table cellspacing="0" cellpadding="0" border="0" class="ui-dp-table">');e.push("<tbody>");var g=this.getDaysInMonth(this.calendar.iDisplayMonth,this.calendar.iDisplayYear);var c=this.getDaysInfo(this.calendar);var f=c.length/7;for(var b=0;b<f;b++){e.push("<tr>");for(var a=0;a<7;a++){var d=b*7+a;if(c[d].iDay>g){e.push('<td class="ui-dp-day ',c[d].sClass,'">&nbsp;</td>');}else{if(c[d].bSelected){e.push('<td class="ui-dp-day ',c[d].sClass,'"><div>',c[d].iDay,"</div></td>");}else{e.push('<td class="ui-dp-day ',c[d].sClass,'">',c[d].iDay,"</td>");}}}e.push("</tr>");}e.push("</tbody></table>");return e.join("");};phe.datePicker2.getDaysInfo=function(t){var z=this.getDaysInMonth(t.iDisplayMonth,t.iDisplayYear);var g=0;var r=t.locale.Days[new Date(t.iDisplayYear,t.iDisplayMonth,1).getDay()];var u=null;for(var w=0;w<7;w++){u=w+t.locale.StartDay;if(u>6){u-=7;}if(t.locale.Days[u]==r){g=w;}}var q=1;var p=new Date();var n=p.getFullYear();var s=p.getMonth();var f=p.getDate();var b=[];var h="";var k=0;var x=t.oSelectedDate.getFullYear(),e=t.oSelectedDate.getMonth(),d=t.oSelectedDate.getDate();var y=5;if((g==0)&&(z==28)){y=4;}else{var o=7-(z-28);if(g>o){y=5;}}for(var w=0;w<y;w++){for(var u=0;u<7;u++){var v=false,a=false,m;var l=(u+t.locale.StartDay)%7;var c="ui-dp-currentMonth";var h=t.iDisplayYear+"-"+(t.iDisplayMonth+1)+"-"+q;if(t.iDisplayYear==n&&t.iDisplayMonth==s&&q==f){c+=" ui-dp-today";a=true;}if(t.iDisplayYear==x&&t.iDisplayMonth==e&&q==d){v=true;c+=" ui-dp-selected-day";}m={iDay:q,iYear:t.iDisplayYear,iMonth:t.iDisplayMonth+1,iDow:l,sClass:c,bSelected:v,bToday:a};q++;m.bRestricted=this.isRestricted(t,new Date(m.iYear,m.iMonth-1,m.iDay),l);if(m.bRestricted){m.sClass+=" ui-dp-restricted";}b.push(m);}}return b;};phe.datePicker2.getInt=function(f,d,c,a){for(var b=a;b>=c;b--){var e=f.substring(d,d+b);if(this.rIntegerPattern.test(e)){return e;}}return null;};phe.datePicker2.isRestricted=function(b,a,c){if(arguments.length<3){c=a.getDay();}return(a<b.calendarFrom)||(a>b.calendarTo)||b.oDisabledDates[a.valueOf()]||b.oDisabledDates.days[c]||b.bIsSaturdayDisabled&&this.isSaturday(a)||b.bIsSundayDisabled&&this.isSunday(a)?true:false;};phe.datePicker2.isSaturday=function(a){return a.toString().indexOf("Sat")>-1;};phe.datePicker2.isSunday=function(a){return a.toString().indexOf("Sun")>-1;};phe.datePicker2.isRestrictedMonth=function(b,a){return(a<this.calendar.iYearFrom)||((a==this.calendar.iYearFrom)&&(b<this.calendar.calendarFrom.getMonth()))||(a>this.calendar.iYearTo)||((a==this.calendar.iYearTo)&&(b>this.calendar.calendarTo.getMonth()));};phe.datePicker2.getDaysInMonth=function(b,a){if(b==1&&(a%4==0&&(a%100!=0||a%400==0))){return 29;}return this.aMonthLengths[b];};phe.datePicker2.repaint=function(){var b=bb.selector.query(this.datePicker2Calendar,".y_"+this.calendar.iDisplayYear);if(b){this.elmYearDisplay=b;bb.html.addClass(b,"ui-dp-selected-year");}var a=bb.selector.query(this.datePicker2Calendar,".m_"+this.calendar.iDisplayMonth);if(a){this.elmMonthDisplay=a;bb.html.addClass(a,"ui-dp-selected-month");}var d=bb.selector.query(this.datePicker2Calendar,".ui-dp-table-wrapper");d.innerHTML=this.createDPTableHTML();var c=bb.selector.query(this.datePicker2Calendar,".ui-dp-table td.ui-dp-selected-day");if(c){this.elmDayDisplay=c;}this.addTDMouseOverEventHandler();};phe.datePicker2.setYear=function(a){this.calendar.iDisplayYear=a;this.repaint();};phe.datePicker2.setMonth=function(b){var c=b;var a=this.calendar.iDisplayYear;if(b<0){c=11;a--;}else{if(b>11){c=0;a++;}}if(this.isRestrictedMonth(c,a)){return;}this.calendar.iDisplayMonth=c;this.calendar.iDisplayYear=a;this.repaint();};phe.datePicker2.gotoPMonth=function(){this.setMonth(this.calendar.iDisplayMonth-1);};phe.datePicker2.gotoNMonth=function(){this.setMonth(this.calendar.iDisplayMonth+1);};phe.datePicker2.clickTD=function(c){var e=this.datePicker2Input;var a=this.elmDayDisplay;if(bb.html.hasClass(c,"ui-dp-restricted")){return;}var b=parseInt(c.innerText||c.textContent,10);var f=this.calendar.iDisplayMonth;var d=this.calendar.iDisplayYear;if(bb.html.hasClass(c,"ui-dp-previousMonth")){--f;if(f<0){f=11;--d;}}else{if(bb.html.hasClass(c,"ui-dp-nextMonth")){++f;if(f>11){f=0;++d;}}}if(a){bb.html.removeClass(a,"ui-dp-selected-day");}bb.html.addClass(c,"ui-dp-selected-day");this.elmDayDisplay=c;this.selectDate(new Date(d,f,b));this.hideDP();};phe.datePicker2.clickDIV=function(a){var g=this.datePicker2Input;var c=this.elmYearDisplay;var d=this.elmMonthDisplay;var h=this.elmDayDisplay;if(bb.html.hasClass(a,"ui-dp-restricted")){return;}if(bb.html.hasClass(a,"ui-dp-month")){var b=parseInt(h.innerText||h.textContent,10);if(!b){b=1;}var f=parseInt(a.getAttribute("month"));if(!f){f=0;}var i=parseInt(c.getAttribute("year"));phe.datePicker2.setMonth(f);if(d){bb.html.removeClass(d,"ui-dp-selected-month");}bb.html.addClass(a,"ui-dp-selected-month");this.elmMonthDisplay=a;var e=phe.datePicker2.getDaysInMonth(f,i);if(e<b){b=e;}this.selectDate(new Date(i,f,b));}else{if(bb.html.hasClass(a,"ui-dp-year")){var b=parseInt(h.innerText||h.textContent,10);if(!b){b=1;}var f=parseInt(d.getAttribute("month"));if(!f){f=0;}var i=parseInt(a.getAttribute("year"));phe.datePicker2.setYear(i);if(c){bb.html.removeClass(c,"ui-dp-selected-year");}bb.html.addClass(a,"ui-dp-selected-year");this.elmYearDisplay=a;this.selectDate(new Date(i,f,b));}}};phe.datePicker2.selectDate=function(d){var c=!d||!(d instanceof Date)?new Date():d;this.setDate(this.calendar,c);var b=this.getFormattedValue(c,this.calendar.locale.Format,this.calendar.language);var a=this.datePicker2Input.value;if(d){this.datePicker2Input.value=b;phe.datePicker2.setAttribute(this.datePicker2Input.parentNode,"value",b);}if(a!=b){bb.html.fireEvent(this.datePicker2Input,"change");}this.repaint();if(absa.touch.enabled){this.datePicker2Input.blur();}};phe.datePicker2.fireOnChangeEvent=function(c){var b=bb.selector.queryAncestor(c,".ui-datePicker2");phe.datePicker2.setValue(b,c.value);var a=absa.util.attributeToFunction(b,"xonchange");if(a){a.call(b);}};phe.datePicker2.setDate=function(b,c){if(!c instanceof Date){return a;}var a=!b.oSelectedDate||!c||b.oSelectedDate.valueOf()!=c.valueOf();b.oSelectedDate=c;b.iDisplayYear=c.getFullYear();b.iDisplayMonth=c.getMonth();return a;};phe.datePicker2.getFormattedValue=function(i,c,g){var h,e,d;if(i instanceof Date){h=i.getFullYear();e=i.getMonth();d=i.getDate();}else{h=arguments[0];e=arguments[1];d=arguments[2];c=arguments[3];g=arguments[4];i=new Date(h,e,d);}var b=new Date();if(h==null){h=b.getFullYear();}if(e==null){e=b.getMonth();}if(d==null){d=b.getDate();}var a=this.localeTable[g?g:"en"];if(c==null){c=a.Format;}var f=c.replace(/(yyyy|yy|MMMM|MMM|MM|M|dddd|ddd|dd|d)/g,function(j){switch(j){case"yyyy":return h;case"yy":return(""+h).substr(2,4);case"MMMM":return a.Months[e];case"MMM":return a.Months[e+12];case"MM":return(e<9)?"0"+(e+1):e+1;case"M":return e+1;case"dddd":return a.Days[i.getDay()];case"ddd":return a.Days[i.getDay()+7];case"dd":return(d<10)?"0"+d:d;case"d":return d;}});return f;};phe.datePicker2.getDateFromFormat=function(l,e,m){if(!l||l==""){return new Date();}var b=this.localeTable[m?m:"en"];var j=0;var o=0;var k;var d;var n=new Date();var a=n.getFullYear()+"";var h=n.getMonth()+1+"";var g=n.getDate()+"";while(o<e.length){k=e.charAt(o);d="";while(e.charAt(o)==k&&o<e.length){d+=e.charAt(o++);}if(d=="yyyy"||d=="yy"){a=this.getInt(l,j,d.length,d.length);if(a==null){a=n.getFullYear()+"";}j+=a.length;if(a.length==2){iYear=parseInt(a,10);a=(iYear>n.getYear()-90)?1900+iYear:2000+iYear;}}else{if(d=="MMMM"){for(var f=11;f>=0;f--){var c=b.Months[f].toLowerCase();if(l.substring(j,j+c.length).toLowerCase()==c){h=f+1;j+=c.length;break;}}}else{if(d=="MMM"){for(var f=23;f>=12;f--){var c=b.Months[f].toLowerCase();if(l.substring(j,j+c.length).toLowerCase()==c){h=f-11;j+=c.length;break;}}}else{if(d=="ddd"||d=="dddd"){for(var f=0;f<b.Days.length;f++){if(l.substring(j,j+b.Days[f].length).toLowerCase()==b.Days[f].toLowerCase()){j+=b.Days[f].length;break;}}}else{if(d=="MM"||d=="M"){h=this.getInt(l,j,d.length,2);if(h===null){h=n.getMonth()+1+"";}j+=h.length;}else{if(d=="dd"||d=="d"){g=this.getInt(l,j,d.length,2);if(g==null){g=n.getDate()+"";}j+=g.length;}else{if(l.substring(j,j+d.length)!=d){}else{j+=d.length;}}}}}}}}return new Date(a,parseInt(h,10)-1,parseInt(g,10));};phe.datePicker2.setValue=function(b,c){phe.datePicker2.setAttribute(b,"value",c);var a=bb.selector.query(b,".ui-datePicker2--input");a.value=c;};phe.datePicker2.getValue=function(b){var a=bb.selector.query(b,".ui-datePicker2--input");return a.value;};phe.datePicker2.setAttribute=function(d,c,e){var a=bb.selector.query(d,".ui-datePicker2--input")||bb.selector.query(d,".ui-datePicker2--input_disabled");var b=bb.selector.query(d,".ui-datePicker2-clickableImgContainer_disabled")||bb.selector.query(d,".ui-datePicker2-clickableImgContainer");if(c=="disabled"){if(e=="false"){bb.html.replaceClass(b,"ui-datePicker2-clickableImgContainer_disabled","ui-datePicker2-clickableImgContainer");bb.html.replaceClass(a,"ui-datePicker2--input_disabled","ui-datePicker2--input");a.removeAttribute("disabled");}else{bb.html.replaceClass(a,"ui-datePicker2--input","ui-datePicker2--input_disabled");bb.html.replaceClass(b,"ui-datePicker2-clickableImgContainer","ui-datePicker2-clickableImgContainer_disabled");phe.Element.prototype.setAttribute.call(this,a,"disabled",e);}}else{switch(c){case"dataType":phe.Element.prototype.setAttribute.call(this,a,"bbf_type",e);break;case"required":phe.Element.prototype.setAttribute.call(this,a,"bbf_required",e);break;case"requiredText":case"schemaTypeText":case"customValidation":case"customValidationText":case"showMeHow":case"name":case"id":phe.Element.prototype.setAttribute.call(this,a,c,e);break;case"onchange":phe.Element.prototype.setAttribute.call(this,d,"xonchange",e);break;default:phe.Element.prototype.setAttribute.call(this,d,c,e);}}};phe.datePicker2.getAttribute=function(c,b){var a=bb.selector.query(c,".ui-datePicker2--input")||bb.selector.query(c,".ui-datePicker2--input_disabled");switch(b){case"dataType":return phe.Element.prototype.getAttribute.call(this,a,"bbf_type");break;case"required":return phe.Element.prototype.getAttribute.call(this,a,"bbf_required");break;case"requiredText":case"schemaTypeText":case"customValidation":case"customValidationText":case"showMeHow":case"name":case"id":return phe.Element.prototype.getAttribute.call(this,a,b);break;case"onchange":return phe.Element.prototype.getAttribute.call(this,c,"xonchange");break;default:return phe.Element.prototype.getAttribute.call(this,c,b);}};phe.datePicker2.validateDate=function(j){var n=new Date();if(j.value!=""){j.value=bb.string.trim(j.value);var h=/(19|20)\d\d[- /.](0[1-9]|1[012])[- /.](0[1-9]|[12][0-9]|3[01])/;var p=h.test(j.value);if(!p){return false;}var i=j.value.split(/\/|\-/);n=new Date(parseInt(i[0],10),parseInt(i[1],10)-1,parseInt(i[2],10));}else{return true;}var e=j.parentNode;var o=!bb.html.hasClass(e,"ui-datePicker2-futureOnly");var k=!bb.html.hasClass(e,"ui-datePicker2-pastOnly");var a=new Date();var g=e.getAttribute("fromdate");if(!g&&o){g="1900-01-01";}else{if(!g){g=a.getFullYear()+"-"+(a.getMonth()+1)+"-"+a.getDate();}}var b=e.getAttribute("todate");if(!b&&k){b="2099-12-31";}else{if(!b){b=a.getFullYear()+"-"+(a.getMonth()+1)+"-"+a.getDate();}}var d=true;var f=g.split(/\/|\-/);var l=new Date(parseInt(f[0],10),parseInt(f[1],10)-1,parseInt(f[2],10));var m=b.split(/\/|\-/);var c=new Date(parseInt(m[0],10),parseInt(m[1],10)-1,parseInt(m[2],10));if(n<l){d=false;}if(d&&(n>c)){d=false;}return d;};</script><script type="text/javascript">var phe=window.phe||{};phe.dialogBox=new phe.Element;phe.dialogBox.getAttribute=function(a,b){return a.getAttribute(b);};phe.dialogBox.setAttribute=function(c,d,a){var b=d.toLowerCase();if(b=="id"|b=="class"){c.setAttribute(d,a);return true;}else{return false;}};phe.dialogBox.show=function(a){phe.modal.showModal(0.5,a,document.body,true);};phe.dialogBox.hide=function(a){phe.modal.showModal(a.parentNode());};</script><script type="text/javascript">phe.form=new phe.Element;phe.form.reset=function(a){a.reset();};phe.form.displayErrorMessage=function(b,a){if(a){bb.html.addClass(b,"ui-form-incorrect-values");}else{bb.html.removeClass(b,"ui-form-incorrect-values");}};phe.form.displayIOErrorMessage=function(k,h,n,j){if(h){bb.html.addClass(k,"ui-form-ioError");var a=bb.selector.query(k,".ui-formFoot");if(a!=null){var c=bb.selector.query(a,".ap-button-reset");var f=bb.selector.query(a,".ap-button-back");var o=bb.selector.query(a,".ap-button-cancel");var g=bb.selector.query(a,".ap-button-next");if(c!=null){phe.common.hide(c);}if(f!=null){phe.common.hide(f);}if(g!=null){phe.common.hide(g);}if(o!=null){var i=bb.selector.query(o,".ui-button-center");var d=bb.selector.query(document,"body");if(d.lang=="af"){i.innerHTML="Sluit";}else{i.innerHTML="Close";}}else{var e=absa.createButton("ap-button-cancel","absa.wizard.finishButton(this)",absa.locale["Common/General/Label/Close"],absa.locale["Common/General/Label/Close"]);var m=bb.selector.query(a,".ui-buttonFooter");var b=bb.selector.query(m,".ui-exception-container");b.appendChild(e);}if(n!=null&&n!=200){var l=bb.selector.query(a,".statusCode");if(l){if(j!=null&&j.length>0){l.innerHTML="  (status = "+n+" : "+j[0]+")";}else{l.innerHTML="  (status = "+n+")";}}}}}else{bb.html.removeClass(k,"ui-form-ioError");}};phe.form.displayValidationMessage=function(d,b){var a=bb.selector.query(d,".validation-place-holder");var c=bb.selector.query(a,".ui-message");if(c){if(b){phe.message.show(c);}else{phe.message.hide(c);}}};</script><script type="text/javascript">Raphael=function(){function az(){if(az.is(arguments[0],aR)){for(var o=arguments[0],l=a5[a3](az,o.splice(0,3+az.is(o[0],aX))),v=l.set(),u=0,p=o[ax];u<p;u++){var s=o[u]||{};bC.test(s.type)&&v[bc](l[s.type]().attr(s));}return v;}return a5[a3](az,arguments);}az.version="1.4.7";var aQ=/[, ]+/,bC=/^(circle|rect|path|ellipse|text|image)$/,av="prototype",an="hasOwnProperty",bj=document,bs=window,am={was:Object[av][an].call(bs,"Raphael"),is:bs.Raphael};function a7(){}var ap="appendChild",a3="apply",a1="concat",aC="createTouch" in bj,bk="",a0=" ",bg=String,a8="split",w="click dblclick mousedown mousemove mouseout mouseover mouseup touchstart touchmove touchend orientationchange touchcancel gesturestart gesturechange gestureend"[a8](a0),af={mousedown:"touchstart",mousemove:"touchmove",mouseup:"touchend"},aU="join",ax="length",bM=String[av].toLowerCase,ar=Math,aN=ar.max,aY=ar.min,aX="number",bv="string",aR="array",aZ="toString",ay="fill",bl=Object[av][aZ],bf=ar.pow,bc="push",ae=/^(?=[\da-f]$)/,c=/^url\(['"]?([^\)]+?)['"]?\)$/i,aH=/^\s*((#[a-f\d]{6})|(#[a-f\d]{3})|rgba?\(\s*([\d\.]+\s*,\s*[\d\.]+\s*,\s*[\d\.]+(?:\s*,\s*[\d\.]+)?)\s*\)|rgba?\(\s*([\d\.]+%\s*,\s*[\d\.]+%\s*,\s*[\d\.]+%(?:\s*,\s*[\d\.]+%)?)\s*\)|hsb\(\s*([\d\.]+(?:deg|\xb0)?\s*,\s*[\d\.]+\s*,\s*[\d\.]+)\s*\)|hsb\(\s*([\d\.]+(?:deg|\xb0|%)\s*,\s*[\d\.]+%\s*,\s*[\d\.]+%)\s*\)|hsl\(\s*([\d\.]+(?:deg|\xb0)?\s*,\s*[\d\.]+\s*,\s*[\d\.]+)\s*\)|hsl\(\s*([\d\.]+(?:deg|\xb0|%)\s*,\s*[\d\.]+%\s*,\s*[\d\.]+%)\s*\))\s*$/i,aV=ar.round,aP="setAttribute",ao=parseFloat,a4=parseInt,j=" progid:DXImageTransform.Microsoft",bE=String[av].toUpperCase,bn={blur:0,"clip-rect":"0 0 1e9 1e9",cursor:"default",cx:0,cy:0,fill:"#fff","fill-opacity":1,font:'10px "Arial"',"font-family":'"Arial"',"font-size":"10","font-style":"normal","font-weight":400,gradient:0,height:0,href:"http://raphaeljs.com/",opacity:1,path:"M0,0",r:0,rotation:0,rx:0,ry:0,scale:"1 1",src:"",stroke:"#000","stroke-dasharray":"","stroke-linecap":"butt","stroke-linejoin":"butt","stroke-miterlimit":0,"stroke-opacity":1,"stroke-width":1,target:"_blank","text-anchor":"left",title:"Raphael",translation:"0 0",width:0,x:0,y:0},bR={along:"along",blur:aX,"clip-rect":"csv",cx:aX,cy:aX,fill:"colour","fill-opacity":aX,"font-size":aX,height:aX,opacity:aX,path:"path",r:aX,rotation:"csv",rx:aX,ry:aX,scale:"csv",stroke:"colour","stroke-opacity":aX,"stroke-width":aX,translation:"csv",width:aX,x:aX,y:aX},a6="replace";az.type=bs.SVGAngle||bj.implementation.hasFeature("http://www.w3.org/TR/SVG11/feature#BasicStructure","1.1")?"SVG":"VML";if(az.type=="VML"){var L=bj.createElement("div");L.innerHTML='<v:shape adj="1"/>';L=L.firstChild;L.style.behavior="url(#default#VML)";if(!(L&&typeof L.adj=="object")){return az.type=null;}L=null;}az.svg=!(az.vml=az.type=="VML");a7[av]=az[av];az._id=0;az._oid=0;az.fn={};az.is=function(o,l){l=bM.call(l);return l=="object"&&o===Object(o)||l=="undefined"&&typeof o==l||l=="null"&&o==null||l=="array"&&Array.isArray&&Array.isArray(o)||bM.call(bl.call(o).slice(8,-1))==l;};az.setWindow=function(l){bs=l;bj=bs.document;};function aJ(o){if(az.vml){var l=/^\s+|\s+$/g;aJ=aL(function(z){var x;z=bg(z)[a6](l,bk);try{var y=new bs.ActiveXObject("htmlfile");y.write("<body>");y.close();x=y.body;}catch(v){x=bs.createPopup().document.body;}y=x.createTextRange();try{x.style.color=z;var u=y.queryCommandValue("ForeColor");u=(u&255)<<16|u&65280|(u&16711680)>>>16;return"#"+("000000"+u[aZ](16)).slice(-6);}catch(s){return"none";}});}else{var p=bj.createElement("i");p.title="Rapha\u00ebl Colour Picker";p.style.display="none";bj.body[ap](p);aJ=aL(function(s){p.style.color=s;return bj.defaultView.getComputedStyle(p,bk).getPropertyValue("color");});}return aJ(o);}function bI(){return"hsb("+[this.h,this.s,this.b]+")";}function ak(){return"hsl("+[this.h,this.s,this.l]+")";}function r(){return this.hex;}az.hsb2rgb=function(o,l,p){if(az.is(o,"object")&&"h" in o&&"s" in o&&"b" in o){p=o.b;l=o.s;o=o.h;}return az.hsl2rgb(o,l,p/2);};az.hsl2rgb=function(o,l,y){if(az.is(o,"object")&&"h" in o&&"s" in o&&"l" in o){y=o.l;l=o.s;o=o.h;}if(o>1||l>1||y>1){o/=255;l/=255;y/=255;}var x={},u=["r","g","b"],v;if(l){l=y<0.5?y*(1+l):y+l-y*l;y=2*y-l;for(var s=0,p=u.length;s<p;s++){v=o+1/3*-(s-1);v<0&&v++;v>1&&v--;x[u[s]]=v*6<1?y+(l-y)*6*v:v*2<1?l:v*3<2?y+(l-y)*(2/3-v)*6:y;}}else{x={r:y,g:y,b:y};}x.r*=255;x.g*=255;x.b*=255;o=(~~x.r)[aZ](16);u=(~~x.g)[aZ](16);l=(~~x.b)[aZ](16);o=o[a6](ae,"0");u=u[a6](ae,"0");l=l[a6](ae,"0");x.hex="#"+o+u+l;x.toString=r;return x;};az.rgb2hsb=function(o,l,x){if(l==null&&az.is(o,"object")&&"r" in o&&"g" in o&&"b" in o){x=o.b;l=o.g;o=o.r;}if(l==null&&az.is(o,bv)){var v=az.getRGB(o);o=v.r;l=v.g;x=v.b;}if(o>1||l>1||x>1){o/=255;l/=255;x/=255;}var s=aN(o,l,x),u=aY(o,l,x);v=s;if(u==s){return{h:0,s:0,b:s,toString:bI};}else{var p=s-u;u=p/s;o=o==s?(l-x)/p:l==s?2+(x-o)/p:4+(o-l)/p;o/=6;o<0&&o++;o>1&&o--;}return{h:o,s:u,b:v,toString:bI};};az.rgb2hsl=function(o,l,x){if(l==null&&az.is(o,"object")&&"r" in o&&"g" in o&&"b" in o){x=o.b;l=o.g;o=o.r;}if(l==null&&az.is(o,bv)){var v=az.getRGB(o);o=v.r;l=v.g;x=v.b;}if(o>1||l>1||x>1){o/=255;l/=255;x/=255;}var s=aN(o,l,x),u=aY(o,l,x);v=(s+u)/2;if(u==s){o={h:0,s:0,l:v};}else{var p=s-u;u=v<0.5?p/(s+u):p/(2-s-u);o=o==s?(l-x)/p:l==s?2+(x-o)/p:4+(o-l)/p;o/=6;o<0&&o++;o>1&&o--;o={h:o,s:u,l:v};}o.toString=ak;return o;};var a=/,?([achlmqrstvxz]),?/gi,i=/\s*,\s*/,bG={hs:1,rg:1};az._path2string=function(){return this.join(",")[a6](a,"$1");};function aL(o,l,s){function p(){var x=Array[av].slice.call(arguments,0),y=x[aU]("\u25ba"),v=p.cache=p.cache||{},u=p.count=p.count||[];if(v[an](y)){return s?s(v[y]):v[y];}u[ax]>=1000&&delete v[u.shift()];u[bc](y);v[y]=o[a3](l,x);return s?s(v[y]):v[y];}return p;}az.getRGB=aL(function(o){if(!o||(o=bg(o)).indexOf("-")+1){return{r:-1,g:-1,b:-1,hex:"none",error:1};}if(o=="none"){return{r:-1,g:-1,b:-1,hex:"none"};}!(bG[an](o.substring(0,2))||o.charAt()=="#")&&(o=aJ(o));var l,v,u,p,s;if(o=o.match(aH)){if(o[2]){u=a4(o[2].substring(5),16);v=a4(o[2].substring(3,5),16);l=a4(o[2].substring(1,3),16);}if(o[3]){u=a4((s=o[3].charAt(3))+s,16);v=a4((s=o[3].charAt(2))+s,16);l=a4((s=o[3].charAt(1))+s,16);}if(o[4]){o=o[4][a8](i);l=ao(o[0]);v=ao(o[1]);u=ao(o[2]);p=ao(o[3]);}if(o[5]){o=o[5][a8](i);l=ao(o[0])*2.55;v=ao(o[1])*2.55;u=ao(o[2])*2.55;p=ao(o[3]);}if(o[6]){o=o[6][a8](i);l=ao(o[0]);v=ao(o[1]);u=ao(o[2]);(o[0].slice(-3)=="deg"||o[0].slice(-1)=="\u00b0")&&(l/=360);return az.hsb2rgb(l,v,u);}if(o[7]){o=o[7][a8](i);l=ao(o[0])*2.55;v=ao(o[1])*2.55;u=ao(o[2])*2.55;(o[0].slice(-3)=="deg"||o[0].slice(-1)=="\u00b0")&&(l/=360*2.55);return az.hsb2rgb(l,v,u);}if(o[8]){o=o[8][a8](i);l=ao(o[0]);v=ao(o[1]);u=ao(o[2]);(o[0].slice(-3)=="deg"||o[0].slice(-1)=="\u00b0")&&(l/=360);return az.hsl2rgb(l,v,u);}if(o[9]){o=o[9][a8](i);l=ao(o[0])*2.55;v=ao(o[1])*2.55;u=ao(o[2])*2.55;(o[0].slice(-3)=="deg"||o[0].slice(-1)=="\u00b0")&&(l/=360*2.55);return az.hsl2rgb(l,v,u);}o={r:l,g:v,b:u};l=(~~l)[aZ](16);v=(~~v)[aZ](16);u=(~~u)[aZ](16);l=l[a6](ae,"0");v=v[a6](ae,"0");u=u[a6](ae,"0");o.hex="#"+l+v+u;isFinite(ao(p))&&(o.o=p);return o;}return{r:-1,g:-1,b:-1,hex:"none",error:1};},az);az.getColor=function(o){o=this.getColor.start=this.getColor.start||{h:0,s:1,b:o||0.75};var l=this.hsb2rgb(o.h,o.s,o.b);o.h+=0.075;if(o.h>1){o.h=0;o.s-=0.2;o.s<=0&&(this.getColor.start={h:0,s:1,b:o.b});}return l.hex;};az.getColor.reset=function(){delete this.start;};var bp=/([achlmqstvz])[\s,]*((-?\d*\.?\d*(?:e[-+]?\d+)?\s*,?\s*)+)/ig,bL=/(-?\d*\.?\d*(?:e[-+]?\d+)?)\s*,?\s*/ig;az.parsePathString=aL(function(o){if(!o){return null;}var l={a:7,c:6,h:1,l:2,m:2,q:4,s:4,t:2,v:1,z:0},p=[];if(az.is(o,aR)&&az.is(o[0],aR)){p=al(o);}p[ax]||bg(o)[a6](bp,function(x,u,v){var s=[];x=bM.call(u);v[a6](bL,function(z,y){y&&s[bc](+y);});if(x=="m"&&s[ax]>2){p[bc]([u][a1](s.splice(0,2)));x="l";u=u=="m"?"l":"L";}for(;s[ax]>=l[x];){p[bc]([u][a1](s.splice(0,l[x])));if(!l[x]){break;}}});p[aZ]=az._path2string;return p;});az.findDotsAtSegment=function(G,F,E,D,A,C,z,y,x){var v=1-x,s=bf(v,3)*G+bf(v,2)*3*x*E+v*3*x*x*A+bf(x,3)*z;v=bf(v,3)*F+bf(v,2)*3*x*D+v*3*x*x*C+bf(x,3)*y;var p=G+2*x*(E-G)+x*x*(A-2*E+G),l=F+2*x*(D-F)+x*x*(C-2*D+F),o=E+2*x*(A-E)+x*x*(z-2*A+E),u=D+2*x*(C-D)+x*x*(y-2*C+D);G=(1-x)*G+x*E;F=(1-x)*F+x*D;A=(1-x)*A+x*z;C=(1-x)*C+x*y;y=90-ar.atan((p-o)/(l-u))*180/ar.PI;(p>o||l<u)&&(y+=180);return{x:s,y:v,m:{x:p,y:l},n:{x:o,y:u},start:{x:G,y:F},end:{x:A,y:C},alpha:y};};var b=aL(function(o){if(!o){return{x:0,y:0,width:0,height:0};}o=t(o);for(var l=0,y=0,x=[],u=[],v,s=0,p=o[ax];s<p;s++){v=o[s];if(v[0]=="M"){l=v[1];y=v[2];x[bc](l);u[bc](y);}else{l=bu(l,y,v[1],v[2],v[3],v[4],v[5],v[6]);x=x[a1](l.min.x,l.max.x);u=u[a1](l.min.y,l.max.y);l=v[5];y=v[6];}}o=aY[a3](0,x);v=aY[a3](0,u);return{x:o,y:v,width:aN[a3](0,x)-o,height:aN[a3](0,u)-v};});function al(o){var l=[];if(!az.is(o,aR)||!az.is(o&&o[0],aR)){o=az.parsePathString(o);}for(var v=0,u=o[ax];v<u;v++){l[v]=[];for(var p=0,s=o[v][ax];p<s;p++){l[v][p]=o[v][p];}}l[aZ]=az._path2string;return l;}var bA=aL(function(D){if(!az.is(D,aR)||!az.is(D&&D[0],aR)){D=az.parsePathString(D);}var C=[],A=0,z=0,x=0,y=0,v=0;if(D[0][0]=="M"){A=D[0][1];z=D[0][2];x=A;y=z;v++;C[bc](["M",A,z]);}v=v;for(var u=D[ax];v<u;v++){var s=C[v]=[],p=D[v];if(p[0]!=bM.call(p[0])){s[0]=bM.call(p[0]);switch(s[0]){case"a":s[1]=p[1];s[2]=p[2];s[3]=p[3];s[4]=p[4];s[5]=p[5];s[6]=+(p[6]-A).toFixed(3);s[7]=+(p[7]-z).toFixed(3);break;case"v":s[1]=+(p[1]-z).toFixed(3);break;case"m":x=p[1];y=p[2];default:for(var o=1,l=p[ax];o<l;o++){s[o]=+(p[o]-(o%2?A:z)).toFixed(3);}}}else{C[v]=[];if(p[0]=="m"){x=p[1]+A;y=p[2]+z;}s=0;for(o=p[ax];s<o;s++){C[v][s]=p[s];}}p=C[v][ax];switch(C[v][0]){case"z":A=x;z=y;break;case"h":A+=+C[v][p-1];break;case"v":z+=+C[v][p-1];break;default:A+=+C[v][p-2];z+=+C[v][p-1];}}C[aZ]=az._path2string;return C;},0,al),aF=aL(function(D){if(!az.is(D,aR)||!az.is(D&&D[0],aR)){D=az.parsePathString(D);}var C=[],A=0,z=0,x=0,y=0,v=0;if(D[0][0]=="M"){A=+D[0][1];z=+D[0][2];x=A;y=z;v++;C[0]=["M",A,z];}v=v;for(var u=D[ax];v<u;v++){var s=C[v]=[],p=D[v];if(p[0]!=bE.call(p[0])){s[0]=bE.call(p[0]);switch(s[0]){case"A":s[1]=p[1];s[2]=p[2];s[3]=p[3];s[4]=p[4];s[5]=p[5];s[6]=+(p[6]+A);s[7]=+(p[7]+z);break;case"V":s[1]=+p[1]+z;break;case"H":s[1]=+p[1]+A;break;case"M":x=+p[1]+A;y=+p[2]+z;default:for(var o=1,l=p[ax];o<l;o++){s[o]=+p[o]+(o%2?A:z);}}}else{o=0;for(l=p[ax];o<l;o++){C[v][o]=p[o];}}switch(s[0]){case"Z":A=x;z=y;break;case"H":A=s[1];break;case"V":z=s[1];break;case"M":x=C[v][C[v][ax]-2];y=C[v][C[v][ax]-1];default:A=C[v][C[v][ax]-2];z=C[v][C[v][ax]-1];}}C[aZ]=az._path2string;return C;},null,al);function bH(o,l,s,p){return[o,l,s,p,s,p];}function bq(o,l,y,x,u,v){var s=1/3,p=2/3;return[s*o+p*y,s*l+p*x,s*u+p*y,s*v+p*x,u,v];}function aM(M,K,I,H,F,G,E,D,C,A){var y=ar.PI,x=y*120/180,s=y/180*(+F||0),v=[],z,p=aL(function(P,O,Q){var N=P*ar.cos(Q)-O*ar.sin(Q);P=P*ar.sin(Q)+O*ar.cos(Q);return{x:N,y:P};});if(A){o=A[0];z=A[1];G=A[2];u=A[3];}else{z=p(M,K,-s);M=z.x;K=z.y;z=p(D,C,-s);D=z.x;C=z.y;ar.cos(y/180*F);ar.sin(y/180*F);z=(M-D)/2;o=(K-C)/2;u=z*z/(I*I)+o*o/(H*H);if(u>1){u=ar.sqrt(u);I=u*I;H=u*H;}u=I*I;var l=H*H;u=(G==E?-1:1)*ar.sqrt(ar.abs((u*l-u*o*o-l*z*z)/(u*o*o+l*z*z)));G=u*I*o/H+(M+D)/2;var u=u*-H*z/I+(K+C)/2,o=ar.asin(((K-u)/H).toFixed(7));z=ar.asin(((C-u)/H).toFixed(7));o=M<G?y-o:o;z=D<G?y-z:z;o<0&&(o=y*2+o);z<0&&(z=y*2+z);if(E&&o>z){o-=y*2;}if(!E&&z>o){z-=y*2;}}y=z-o;if(ar.abs(y)>x){v=z;y=D;l=C;z=o+x*(E&&z>o?1:-1);D=G+I*ar.cos(z);C=u+H*ar.sin(z);v=aM(D,C,I,H,F,0,E,y,l,[z,v,G,u]);}y=z-o;F=ar.cos(o);G=ar.sin(o);E=ar.cos(z);z=ar.sin(z);y=ar.tan(y/4);I=4/3*I*y;y=4/3*H*y;H=[M,K];M=[M+I*G,K-y*F];K=[D+I*z,C-y*E];D=[D,C];M[0]=2*H[0]-M[0];M[1]=2*H[1]-M[1];if(A){return[M,K,D][a1](v);}else{v=[M,K,D][a1](v)[aU]()[a8](",");A=[];D=0;for(C=v[ax];D<C;D++){A[D]=D%2?p(v[D-1],v[D],s).y:p(v[D],v[D+1],s).x;}return A;}}function bQ(A,z,y,x,u,v,s,p,o){var l=1-o;return{x:bf(l,3)*A+bf(l,2)*3*o*y+l*3*o*o*u+bf(o,3)*s,y:bf(l,3)*z+bf(l,2)*3*o*x+l*3*o*o*v+bf(o,3)*p};}var bu=aL(function(F,E,D,C,z,A,y,x){var v=z-2*D+F-(y-2*z+D),u=2*(D-F)-2*(z-D),s=F-D,p=(-u+ar.sqrt(u*u-4*v*s))/2/v;v=(-u-ar.sqrt(u*u-4*v*s))/2/v;var l=[E,x],o=[F,y];ar.abs(p)>1000000000000&&(p=0.5);ar.abs(v)>1000000000000&&(v=0.5);if(p>0&&p<1){p=bQ(F,E,D,C,z,A,y,x,p);o[bc](p.x);l[bc](p.y);}if(v>0&&v<1){p=bQ(F,E,D,C,z,A,y,x,v);o[bc](p.x);l[bc](p.y);}v=A-2*C+E-(x-2*A+C);u=2*(C-E)-2*(A-C);s=E-C;p=(-u+ar.sqrt(u*u-4*v*s))/2/v;v=(-u-ar.sqrt(u*u-4*v*s))/2/v;ar.abs(p)>1000000000000&&(p=0.5);ar.abs(v)>1000000000000&&(v=0.5);if(p>0&&p<1){p=bQ(F,E,D,C,z,A,y,x,p);o[bc](p.x);l[bc](p.y);}if(v>0&&v<1){p=bQ(F,E,D,C,z,A,y,x,v);o[bc](p.x);l[bc](p.y);}return{min:{x:aY[a3](0,o),y:aY[a3](0,l)},max:{x:aN[a3](0,o),y:aN[a3](0,l)}};}),t=aL(function(E,D){var C=aF(E),A=D&&aF(D);E={x:0,y:0,bx:0,by:0,X:0,Y:0,qx:null,qy:null};D={x:0,y:0,bx:0,by:0,X:0,Y:0,qx:null,qy:null};function y(H,F){var G;if(!H){return["C",F.x,F.y,F.x,F.y,F.x,F.y];}!(H[0] in {T:1,Q:1})&&(F.qx=F.qy=null);switch(H[0]){case"M":F.X=H[1];F.Y=H[2];break;case"A":H=["C"][a1](aM[a3](0,[F.x,F.y][a1](H.slice(1))));break;case"S":G=F.x+(F.x-(F.bx||F.x));F=F.y+(F.y-(F.by||F.y));H=["C",G,F][a1](H.slice(1));break;case"T":F.qx=F.x+(F.x-(F.qx||F.x));F.qy=F.y+(F.y-(F.qy||F.y));H=["C"][a1](bq(F.x,F.y,F.qx,F.qy,H[1],H[2]));break;case"Q":F.qx=H[1];F.qy=H[2];H=["C"][a1](bq(F.x,F.y,H[1],H[2],H[3],H[4]));break;case"L":H=["C"][a1](bH(F.x,F.y,H[1],H[2]));break;case"H":H=["C"][a1](bH(F.x,F.y,H[1],F.y));break;case"V":H=["C"][a1](bH(F.x,F.y,F.x,H[1]));break;case"Z":H=["C"][a1](bH(F.x,F.y,F.X,F.Y));break;}return H;}function z(H,F){if(H[F][ax]>7){H[F].shift();for(var G=H[F];G[ax];){H.splice(F++,0,["C"][a1](G.splice(0,6)));}H.splice(F,1);u=aN(C[ax],A&&A[ax]||0);}}function x(I,G,H,F,K){if(I&&G&&I[K][0]=="M"&&G[K][0]!="M"){G.splice(K,0,["M",F.x,F.y]);H.bx=0;H.by=0;H.x=I[K][1];H.y=I[K][2];u=aN(C[ax],A&&A[ax]||0);}}for(var v=0,u=aN(C[ax],A&&A[ax]||0);v<u;v++){C[v]=y(C[v],E);z(C,v);A&&(A[v]=y(A[v],D));A&&z(A,v);x(C,A,E,D,v);x(A,C,D,E,v);var s=C[v],p=A&&A[v],o=s[ax],l=A&&p[ax];E.x=s[o-2];E.y=s[o-1];E.bx=ao(s[o-4])||E.x;E.by=ao(s[o-3])||E.y;D.bx=A&&(ao(p[l-4])||D.x);D.by=A&&(ao(p[l-3])||D.y);D.x=A&&p[l-2];D.y=A&&p[l-1];}return A?[C,A]:C;},null,al),aq=aL(function(o){for(var l=[],v=0,u=o[ax];v<u;v++){var p={},s=o[v].match(/^([^:]*):?([\d\.]*)/);p.color=az.getRGB(s[1]);if(p.color.error){return null;}p.color=p.color.hex;s[2]&&(p.offset=s[2]+"%");l[bc](p);}v=1;for(u=l[ax]-1;v<u;v++){if(!l[v].offset){o=ao(l[v-1].offset||0);s=0;for(p=v+1;p<u;p++){if(l[p].offset){s=l[p].offset;break;}}if(!s){s=100;p=u;}s=ao(s);for(s=(s-o)/(p-v+1);v<p;v++){o+=s;l[v].offset=o+"%";}}}return l;});function B(o,l,s,p){if(az.is(o,bv)||az.is(o,"object")){o=az.is(o,bv)?bj.getElementById(o):o;if(o.tagName){return l==null?{container:o,width:o.style.pixelWidth||o.offsetWidth,height:o.style.pixelHeight||o.offsetHeight}:{container:o,width:l,height:s};}}else{return{container:1,x:o,y:l,width:s,height:p};}}function bh(o,l){var s=this;for(var p in l){if(l[an](p)&&!(p in o)){switch(typeof l[p]){case"function":(function(u){o[p]=o===s?u:function(){return u[a3](s,arguments);};})(l[p]);break;case"object":o[p]=o[p]||{};bh.call(this,o[p],l[p]);break;default:o[p]=l[p];break;}}}}function bz(o,l){o==l.top&&(l.top=o.prev);o==l.bottom&&(l.bottom=o.next);o.next&&(o.next.prev=o.prev);o.prev&&(o.prev.next=o.next);}function d(o,l){if(l.top!==o){bz(o,l);o.next=null;o.prev=l.top;l.top.next=o;l.top=o;}}function bJ(o,l){if(l.bottom!==o){bz(o,l);o.next=l.bottom;o.prev=null;l.bottom.prev=o;l.bottom=o;}}function bi(o,l,p){bz(o,p);l==p.top&&(p.top=o);l.next&&(l.next.prev=o);o.next=l.next;o.prev=l;l.next=o;}function br(o,l,p){bz(o,p);l==p.bottom&&(p.bottom=o);l.prev&&(l.prev.next=o);o.prev=l.prev;l.prev=o;o.next=l;}function aW(l){return function(){throw new Error("Rapha\u00ebl: you are calling to method \u201c"+l+"\u201d of removed object");};}var aw=/^r(?:\(([^,]+?)\s*,\s*([^\)]+?)\))?/;az.pathToRelative=bA;if(az.svg){a7[av].svgns="http://www.w3.org/2000/svg";a7[av].xlink="http://www.w3.org/1999/xlink";aV=function(l){return +l+(~~l===l)*0.5;};var at=function(o,l){if(l){for(var p in l){l[an](p)&&o[aP](p,bg(l[p]));}}else{o=bj.createElementNS(a7[av].svgns,o);o.style.webkitTapHighlightColor="rgba(0,0,0,0)";return o;}};az[aZ]=function(){return"Your browser supports SVG.\nYou are running Rapha\u00ebl "+this.version;};var J=function(o,l){var p=at("path");l.canvas&&l.canvas[ap](p);l=new au(p,l);l.type="path";f(l,{fill:"none",stroke:"#000",path:o});return l;},ai=function(A,z,y){var x="linear",u=0.5,v=0.5,s=A.style;z=bg(z)[a6](aw,function(C,E,D){x="radial";if(E&&D){u=ao(E);v=ao(D);C=(v>0.5)*2-1;bf(u-0.5,2)+bf(v-0.5,2)>0.25&&(v=ar.sqrt(0.25-bf(u-0.5,2))*C+0.5)&&v!=0.5&&(v=v.toFixed(5)-0.00001*C);}return bk;});z=z[a8](/\s*\-\s*/);if(x=="linear"){var p=z.shift();p=-ao(p);if(isNaN(p)){return null;}p=[0,0,ar.cos(p*ar.PI/180),ar.sin(p*ar.PI/180)];var o=1/(aN(ar.abs(p[2]),ar.abs(p[3]))||1);p[2]*=o;p[3]*=o;if(p[2]<0){p[0]=-p[2];p[2]=0;}if(p[3]<0){p[1]=-p[3];p[3]=0;}}z=aq(z);if(!z){return null;}o=A.getAttribute(ay);(o=o.match(/^url\(#(.*)\)$/))&&y.defs.removeChild(bj.getElementById(o[1]));o=at(x+"Gradient");o.id="r"+(az._id++)[aZ](36);at(o,x=="radial"?{fx:u,fy:v}:{x1:p[0],y1:p[1],x2:p[2],y2:p[3]});y.defs[ap](o);y=0;for(p=z[ax];y<p;y++){var l=at("stop");at(l,{offset:z[y].offset?z[y].offset:!y?"0%":"100%","stop-color":z[y].color||"#fff"});o[ap](l);}at(A,{fill:"url(#"+o.id+")",opacity:1,"fill-opacity":1});s.fill=bk;s.opacity=1;return s.fillOpacity=1;},aG=function(o){var l=o.getBBox();at(o.pattern,{patternTransform:az.format("translate({0},{1})",l.x,l.y)});},f=function(F,E){var D={"":[0],none:[0],"-":[3,1],".":[1,1],"-.":[3,1,1,1],"-..":[3,1,1,1,1,1],". ":[1,3],"- ":[4,3],"--":[8,3],"- .":[4,3,1,3],"--.":[8,3,1,3],"--..":[8,3,1,3,1,3]},C=F.node,z=F.attrs,A=F.rotate();function y(I,K){if(K=D[bM.call(K)]){var G=I.attrs["stroke-width"]||"1";I={round:G,square:G,butt:0}[I.attrs["stroke-linecap"]||E["stroke-linecap"]]||0;for(var M=[],H=K[ax];H--;){M[H]=K[H]*G+(H%2?1:-1)*I;}at(C,{"stroke-dasharray":M[aU](",")});}}E[an]("rotation")&&(A=E.rotation);var x=bg(A)[a8](aQ);if(x.length-1){x[1]=+x[1];x[2]=+x[2];}else{x=null;}ao(A)&&F.rotate(0,true);for(var v in E){if(E[an](v)){if(bn[an](v)){var u=E[v];z[v]=u;switch(v){case"blur":F.blur(u);break;case"rotation":F.rotate(u,true);break;case"href":case"title":case"target":var s=C.parentNode;if(bM.call(s.tagName)!="a"){var p=at("a");s.insertBefore(p,C);p[ap](C);s=p;}s.setAttributeNS(F.paper.xlink,v,u);break;case"cursor":C.style.cursor=u;break;case"clip-rect":s=bg(u)[a8](aQ);if(s[ax]==4){F.clip&&F.clip.parentNode.parentNode.removeChild(F.clip.parentNode);var l=at("clipPath");p=at("rect");l.id="r"+(az._id++)[aZ](36);at(p,{x:s[0],y:s[1],width:s[2],height:s[3]});l[ap](p);F.paper.defs[ap](l);at(C,{"clip-path":"url(#"+l.id+")"});F.clip=p;}if(!u){(u=bj.getElementById(C.getAttribute("clip-path")[a6](/(^url\(#|\)$)/g,bk)))&&u.parentNode.removeChild(u);at(C,{"clip-path":bk});delete F.clip;}break;case"path":if(F.type=="path"){at(C,{d:u?(z.path=aF(u)):"M0,0"});}break;case"width":C[aP](v,u);if(z.fx){v="x";u=z.x;}else{break;}case"x":if(z.fx){u=-z.x-(z.width||0);}case"rx":if(v=="rx"&&F.type=="rect"){break;}case"cx":x&&(v=="x"||v=="cx")&&(x[1]+=u-z[v]);C[aP](v,u);F.pattern&&aG(F);break;case"height":C[aP](v,u);if(z.fy){v="y";u=z.y;}else{break;}case"y":if(z.fy){u=-z.y-(z.height||0);}case"ry":if(v=="ry"&&F.type=="rect"){break;}case"cy":x&&(v=="y"||v=="cy")&&(x[2]+=u-z[v]);C[aP](v,u);F.pattern&&aG(F);break;case"r":F.type=="rect"?at(C,{rx:u,ry:u}):C[aP](v,u);break;case"src":F.type=="image"&&C.setAttributeNS(F.paper.xlink,"href",u);break;case"stroke-width":C.style.strokeWidth=u;C[aP](v,u);z["stroke-dasharray"]&&y(F,z["stroke-dasharray"]);break;case"stroke-dasharray":y(F,u);break;case"translation":u=bg(u)[a8](aQ);u[0]=+u[0]||0;u[1]=+u[1]||0;if(x){x[1]+=u[0];x[2]+=u[1];}bN.call(F,u[0],u[1]);break;case"scale":u=bg(u)[a8](aQ);F.scale(+u[0]||1,+u[1]||+u[0]||1,isNaN(ao(u[2]))?null:+u[2],isNaN(ao(u[3]))?null:+u[3]);break;case ay:if(s=bg(u).match(c)){l=at("pattern");var o=at("image");l.id="r"+(az._id++)[aZ](36);at(l,{x:0,y:0,patternUnits:"userSpaceOnUse",height:1,width:1});at(o,{x:0,y:0});o.setAttributeNS(F.paper.xlink,"href",s[1]);l[ap](o);u=bj.createElement("img");u.style.cssText="position:absolute;left:-9999em;top-9999em";u.onload=function(){at(l,{width:this.offsetWidth,height:this.offsetHeight});at(o,{width:this.offsetWidth,height:this.offsetHeight});bj.body.removeChild(this);F.paper.safari();};bj.body[ap](u);u.src=s[1];F.paper.defs[ap](l);C.style.fill="url(#"+l.id+")";at(C,{fill:"url(#"+l.id+")"});F.pattern=l;F.pattern&&aG(F);break;}s=az.getRGB(u);if(s.error){if(({circle:1,ellipse:1}[an](F.type)||bg(u).charAt()!="r")&&ai(C,u,F.paper)){z.gradient=u;z.fill="none";break;}}else{delete E.gradient;delete z.gradient;!az.is(z.opacity,"undefined")&&az.is(E.opacity,"undefined")&&at(C,{opacity:z.opacity});!az.is(z["fill-opacity"],"undefined")&&az.is(E["fill-opacity"],"undefined")&&at(C,{"fill-opacity":z["fill-opacity"]});}s[an]("o")&&at(C,{"fill-opacity":s.o>1?s.o/100:s.o});case"stroke":s=az.getRGB(u);C[aP](v,s.hex);v=="stroke"&&s[an]("o")&&at(C,{"stroke-opacity":s.o>1?s.o/100:s.o});break;case"gradient":(({circle:1,ellipse:1})[an](F.type)||bg(u).charAt()!="r")&&ai(C,u,F.paper);break;case"opacity":case"fill-opacity":if(z.gradient){if(s=bj.getElementById(C.getAttribute(ay)[a6](/^url\(#|\)$/g,bk))){s=s.getElementsByTagName("stop");s[s[ax]-1][aP]("stop-opacity",u);}break;}default:v=="font-size"&&(u=a4(u,10)+"px");s=v[a6](/(\-.)/g,function(G){return bE.call(G.substring(1));});C.style[s]=u;C[aP](v,u);break;}}}}aB(F,E);if(x){F.rotate(x.join(a0));}else{ao(A)&&F.rotate(A,true);}},e=1.2,aB=function(o,l){if(!(o.type!="text"||!(l[an]("text")||l[an]("font")||l[an]("font-size")||l[an]("x")||l[an]("y")))){var y=o.attrs,x=o.node,u=x.firstChild?a4(bj.defaultView.getComputedStyle(x.firstChild,bk).getPropertyValue("font-size"),10):10;if(l[an]("text")){for(y.text=l.text;x.firstChild;){x.removeChild(x.firstChild);}l=bg(l.text)[a8]("\n");for(var v=0,s=l[ax];v<s;v++){if(l[v]){var p=at("tspan");v&&at(p,{dy:u*e,x:y.x});p[ap](bj.createTextNode(l[v]));x[ap](p);}}}else{l=x.getElementsByTagName("tspan");v=0;for(s=l[ax];v<s;v++){v&&at(l[v],{dy:u*e,x:y.x});}}at(x,{y:y.y});o=o.getBBox();(o=y.y-(o.y+o.height/2))&&isFinite(o)&&at(x,{y:y.y+o});}},au=function(o,l){this[0]=o;this.id=az._oid++;this.node=o;o.raphael=this;this.paper=l;this.attrs=this.attrs||{};this.transformations=[];this._={tx:0,ty:0,rt:{deg:0,cx:0,cy:0},sx:1,sy:1};!l.bottom&&(l.bottom=this);(this.prev=l.top)&&(l.top.next=this);l.top=this;this.next=null;};au[av].rotate=function(o,l,s){if(this.removed){return this;}if(o==null){if(this._.rt.cx){return[this._.rt.deg,this._.rt.cx,this._.rt.cy][aU](a0);}return this._.rt.deg;}var p=this.getBBox();o=bg(o)[a8](aQ);if(o[ax]-1){l=ao(o[1]);s=ao(o[2]);}o=ao(o[0]);if(l!=null){this._.rt.deg=o;}else{this._.rt.deg+=o;}s==null&&(l=null);this._.rt.cx=l;this._.rt.cy=s;l=l==null?p.x+p.width/2:l;s=s==null?p.y+p.height/2:s;if(this._.rt.deg){this.transformations[0]=az.format("rotate({0} {1} {2})",this._.rt.deg,l,s);this.clip&&at(this.clip,{transform:az.format("rotate({0} {1} {2})",-this._.rt.deg,l,s)});}else{this.transformations[0]=bk;this.clip&&at(this.clip,{transform:bk});}at(this.node,{transform:this.transformations[aU](a0)});return this;};au[av].hide=function(){!this.removed&&(this.node.style.display="none");return this;};au[av].show=function(){!this.removed&&(this.node.style.display="");return this;};au[av].remove=function(){if(!this.removed){bz(this,this.paper);this.node.parentNode.removeChild(this.node);for(var l in this){delete this[l];}this.removed=true;}};au[av].getBBox=function(){if(this.removed){return this;}if(this.type=="path"){return b(this.attrs.path);}if(this.node.style.display=="none"){this.show();var o=true;}var l={};try{l=this.node.getBBox();}catch(v){}finally{l=l||{};}if(this.type=="text"){l={x:l.x,y:Infinity,width:0,height:0};for(var u=0,p=this.node.getNumberOfChars();u<p;u++){var s=this.node.getExtentOfChar(u);s.y<l.y&&(l.y=s.y);s.y+s.height-l.y>l.height&&(l.height=s.y+s.height-l.y);s.x+s.width-l.x>l.width&&(l.width=s.x+s.width-l.x);}}o&&this.hide();return l;};au[av].attr=function(o,l){if(this.removed){return this;}if(o==null){o={};for(var s in this.attrs){if(this.attrs[an](s)){o[s]=this.attrs[s];}}this._.rt.deg&&(o.rotation=this.rotate());(this._.sx!=1||this._.sy!=1)&&(o.scale=this.scale());o.gradient&&o.fill=="none"&&(o.fill=o.gradient)&&delete o.gradient;return o;}if(l==null&&az.is(o,bv)){if(o=="translation"){return bN.call(this);}if(o=="rotation"){return this.rotate();}if(o=="scale"){return this.scale();}if(o==ay&&this.attrs.fill=="none"&&this.attrs.gradient){return this.attrs.gradient;}return this.attrs[o];}if(l==null&&az.is(o,aR)){l={};s=0;for(var p=o.length;s<p;s++){l[o[s]]=this.attr(o[s]);}return l;}if(l!=null){s={};s[o]=l;f(this,s);}else{o!=null&&az.is(o,"object")&&f(this,o);}return this;};au[av].toFront=function(){if(this.removed){return this;}this.node.parentNode[ap](this.node);var l=this.paper;l.top!=this&&d(this,l);return this;};au[av].toBack=function(){if(this.removed){return this;}if(this.node.parentNode.firstChild!=this.node){this.node.parentNode.insertBefore(this.node,this.node.parentNode.firstChild);bJ(this,this.paper);}return this;};au[av].insertAfter=function(o){if(this.removed){return this;}var l=o.node||o[o.length].node;l.nextSibling?l.parentNode.insertBefore(this.node,l.nextSibling):l.parentNode[ap](this.node);bi(this,o,this.paper);return this;};au[av].insertBefore=function(o){if(this.removed){return this;}var l=o.node||o[0].node;l.parentNode.insertBefore(this.node,l);br(this,o,this.paper);return this;};au[av].blur=function(o){var l=this;if(+o!==0){var s=at("filter"),p=at("feGaussianBlur");l.attrs.blur=o;s.id="r"+(az._id++)[aZ](36);at(p,{stdDeviation:+o||1.5});s.appendChild(p);l.paper.defs.appendChild(s);l._blur=s;at(l.node,{filter:"url(#"+s.id+")"});}else{if(l._blur){l._blur.parentNode.removeChild(l._blur);delete l._blur;delete l.attrs.blur;}l.node.removeAttribute("filter");}};var bK=function(o,l,u,s){var p=at("circle");o.canvas&&o.canvas[ap](p);o=new au(p,o);o.attrs={cx:l,cy:u,r:s,fill:"none",stroke:"#000"};o.type="circle";at(p,o.attrs);return o;},bt=function(o,l,x,v,s,u){var p=at("rect");o.canvas&&o.canvas[ap](p);o=new au(p,o);o.attrs={x:l,y:x,width:v,height:s,r:u||0,rx:u||0,ry:u||0,fill:"none",stroke:"#000"};o.type="rect";at(p,o.attrs);return o;},a2=function(o,l,v,u,p){var s=at("ellipse");o.canvas&&o.canvas[ap](s);o=new au(s,o);o.attrs={cx:l,cy:v,rx:u,ry:p,fill:"none",stroke:"#000"};o.type="ellipse";at(s,o.attrs);return o;},aA=function(o,l,x,v,s,u){var p=at("image");at(p,{x:x,y:v,width:s,height:u,preserveAspectRatio:"none"});p.setAttributeNS(o.xlink,"href",l);o.canvas&&o.canvas[ap](p);o=new au(p,o);o.attrs={x:x,y:v,width:s,height:u,src:l};o.type="image";return o;},ac=function(o,l,u,s){var p=at("text");at(p,{x:l,y:u,"text-anchor":"left"});o.canvas&&o.canvas[ap](p);o=new au(p,o);o.attrs={x:l,y:u,"text-anchor":"left",text:s,font:bn.font,stroke:"none",fill:"#000"};o.type="text";f(o,o.attrs);return o;},g=function(o,l){this.width=o||this.width;this.height=l||this.height;this.canvas[aP]("width",this.width);this.canvas[aP]("height",this.height);return this;},a5=function(){var o=B[a3](0,arguments),l=o&&o.container,v=o.x,u=o.y,p=o.width;o=o.height;if(!l){throw new Error("SVG container not found.");}var s=at("svg");v=v||0;u=u||0;p=p||512;o=o||342;at(s,{xmlns:"http://www.w3.org/2000/svg",version:1.1,width:p,height:o});if(l==1){s.style.cssText="position:absolute;left:"+v+"px;top:"+u+"px";bj.body[ap](s);}else{l.firstChild?l.insertBefore(s,l.firstChild):l[ap](s);}l=new a7;l.width=p;l.height=o;l.canvas=s;bh.call(l,l,az.fn);l.clear();return l;};a7[av].clear=function(){for(var l=this.canvas;l.firstChild;){l.removeChild(l.firstChild);}this.bottom=this.top=null;(this.desc=at("desc"))[ap](bj.createTextNode("Created with Rapha\u00ebl"));l[ap](this.desc);l[ap](this.defs=at("defs"));};a7[av].remove=function(){this.canvas.parentNode&&this.canvas.parentNode.removeChild(this.canvas);for(var l in this){this[l]=aW(l);}};}if(az.vml){var bO={M:"m",L:"l",C:"c",Z:"x",m:"t",l:"r",c:"v",z:"x"},ad=/([clmz]),?([^clmz]*)/gi,h=/-?[^,\s-]+/g,n=1000+a0+1000,be=10,bU={path:1,rect:1},bP=function(o){var l=/[ahqstv]/ig,y=aF;bg(o).match(l)&&(y=t);l=/[clmz]/g;if(y==aF&&!bg(o).match(l)){return o=bg(o)[a6](ad,function(C,A,z){var F=[],D=bM.call(A)=="m",E=bO[A];z[a6](h,function(G){if(D&&F[ax]==2){E+=F+bO[A=="m"?"l":"L"];F=[];}F[bc](aV(G*be));});return E+F;});}l=y(o);var x;o=[];for(var u=0,v=l[ax];u<v;u++){y=l[u];x=bM.call(l[u][0]);x=="z"&&(x="x");for(var s=1,p=y[ax];s<p;s++){x+=aV(y[s]*be)+(s!=p-1?",":bk);}o[bc](x);}return o[aU](a0);};az[aZ]=function(){return"Your browser doesn\u2019t support SVG. Falling down to VML.\nYou are running Rapha\u00ebl "+this.version;};J=function(o,l){var u=aT("group");u.style.cssText="position:absolute;left:0;top:0;width:"+l.width+"px;height:"+l.height+"px";u.coordsize=l.coordsize;u.coordorigin=l.coordorigin;var s=aT("shape"),p=s.style;p.width=l.width+"px";p.height=l.height+"px";s.coordsize=n;s.coordorigin=l.coordorigin;u[ap](s);s=new au(s,u,l);p={fill:"none",stroke:"#000"};o&&(p.path=o);s.isAbsolute=true;s.type="path";s.path=[];s.Path=bk;f(s,p);l.canvas[ap](u);return s;};f=function(A,z){A.attrs=A.attrs||{};var y=A.node,x=A.attrs,u=y.style,v;v=(z.x!=x.x||z.y!=x.y||z.width!=x.width||z.height!=x.height||z.r!=x.r)&&A.type=="rect";var s=A;for(var p in z){if(z[an](p)){x[p]=z[p];}}if(v){x.path=bx(x.x,x.y,x.width,x.height,x.r);A.X=x.x;A.Y=x.y;A.W=x.width;A.H=x.height;}z.href&&(y.href=z.href);z.title&&(y.title=z.title);z.target&&(y.target=z.target);z.cursor&&(u.cursor=z.cursor);"blur" in z&&A.blur(z.blur);if(z.path&&A.type=="path"||v){y.path=bP(x.path);}z.rotation!=null&&A.rotate(z.rotation,true);if(z.translation){v=bg(z.translation)[a8](aQ);bN.call(A,v[0],v[1]);if(A._.rt.cx!=null){A._.rt.cx+=+v[0];A._.rt.cy+=+v[1];A.setBox(A.attrs,v[0],v[1]);}}if(z.scale){v=bg(z.scale)[a8](aQ);A.scale(+v[0]||1,+v[1]||+v[0]||1,+v[2]||null,+v[3]||null);}if("clip-rect" in z){v=bg(z["clip-rect"])[a8](aQ);if(v[ax]==4){v[2]=+v[2]+ +v[0];v[3]=+v[3]+ +v[1];p=y.clipRect||bj.createElement("div");var o=p.style,l=y.parentNode;o.clip=az.format("rect({1}px {2}px {3}px {0}px)",v);if(!y.clipRect){o.position="absolute";o.top=0;o.left=0;o.width=A.paper.width+"px";o.height=A.paper.height+"px";l.parentNode.insertBefore(p,l);p[ap](l);y.clipRect=p;}}if(!z["clip-rect"]){y.clipRect&&(y.clipRect.style.clip=bk);}}if(A.type=="image"&&z.src){y.src=z.src;}if(A.type=="image"&&z.opacity){y.filterOpacity=j+".Alpha(opacity="+z.opacity*100+")";u.filter=(y.filterMatrix||bk)+(y.filterOpacity||bk);}z.font&&(u.font=z.font);z["font-family"]&&(u.fontFamily='"'+z["font-family"][a8](",")[0][a6](/^['"]+|['"]+$/g,bk)+'"');z["font-size"]&&(u.fontSize=z["font-size"]);z["font-weight"]&&(u.fontWeight=z["font-weight"]);z["font-style"]&&(u.fontStyle=z["font-style"]);if(z.opacity!=null||z["stroke-width"]!=null||z.fill!=null||z.stroke!=null||z["stroke-width"]!=null||z["stroke-opacity"]!=null||z["fill-opacity"]!=null||z["stroke-dasharray"]!=null||z["stroke-miterlimit"]!=null||z["stroke-linejoin"]!=null||z["stroke-linecap"]!=null){y=A.shape||y;u=y.getElementsByTagName(ay)&&y.getElementsByTagName(ay)[0];v=false;!u&&(v=u=aT(ay));if("fill-opacity" in z||"opacity" in z){A=((+x["fill-opacity"]+1||2)-1)*((+x.opacity+1||2)-1)*((+az.getRGB(z.fill).o+1||2)-1);A<0&&(A=0);A>1&&(A=1);u.opacity=A;}z.fill&&(u.on=true);if(u.on==null||z.fill=="none"){u.on=false;}if(u.on&&z.fill){if(A=z.fill.match(c)){u.src=A[1];u.type="tile";}else{u.color=az.getRGB(z.fill).hex;u.src=bk;u.type="solid";if(az.getRGB(z.fill).error&&(s.type in {circle:1,ellipse:1}||bg(z.fill).charAt()!="r")&&ai(s,z.fill)){x.fill="none";x.gradient=z.fill;}}}v&&y[ap](u);u=y.getElementsByTagName("stroke")&&y.getElementsByTagName("stroke")[0];v=false;!u&&(v=u=aT("stroke"));if(z.stroke&&z.stroke!="none"||z["stroke-width"]||z["stroke-opacity"]!=null||z["stroke-dasharray"]||z["stroke-miterlimit"]||z["stroke-linejoin"]||z["stroke-linecap"]){u.on=true;}(z.stroke=="none"||u.on==null||z.stroke==0||z["stroke-width"]==0)&&(u.on=false);A=az.getRGB(z.stroke);u.on&&z.stroke&&(u.color=A.hex);A=((+x["stroke-opacity"]+1||2)-1)*((+x.opacity+1||2)-1)*((+A.o+1||2)-1);p=(ao(z["stroke-width"])||1)*0.75;A<0&&(A=0);A>1&&(A=1);z["stroke-width"]==null&&(p=x["stroke-width"]);z["stroke-width"]&&(u.weight=p);p&&p<1&&(A*=p)&&(u.weight=1);u.opacity=A;z["stroke-linejoin"]&&(u.joinstyle=z["stroke-linejoin"]||"miter");u.miterlimit=z["stroke-miterlimit"]||8;z["stroke-linecap"]&&(u.endcap=z["stroke-linecap"]=="butt"?"flat":z["stroke-linecap"]=="square"?"square":"round");if(z["stroke-dasharray"]){A={"-":"shortdash",".":"shortdot","-.":"shortdashdot","-..":"shortdashdotdot",". ":"dot","- ":"dash","--":"longdash","- .":"dashdot","--.":"longdashdot","--..":"longdashdotdot"};u.dashstyle=A[an](z["stroke-dasharray"])?A[z["stroke-dasharray"]]:bk;}v&&y[ap](u);}if(s.type=="text"){u=s.paper.span.style;x.font&&(u.font=x.font);x["font-family"]&&(u.fontFamily=x["font-family"]);x["font-size"]&&(u.fontSize=x["font-size"]);x["font-weight"]&&(u.fontWeight=x["font-weight"]);x["font-style"]&&(u.fontStyle=x["font-style"]);s.node.string&&(s.paper.span.innerHTML=bg(s.node.string)[a6](/</g,"&#60;")[a6](/&/g,"&#38;")[a6](/\n/g,"<br>"));s.W=x.w=s.paper.span.offsetWidth;s.H=x.h=s.paper.span.offsetHeight;s.X=x.x;s.Y=x.y+aV(s.H/2);switch(x["text-anchor"]){case"start":s.node.style["v-text-align"]="left";s.bbx=aV(s.W/2);break;case"end":s.node.style["v-text-align"]="right";s.bbx=-aV(s.W/2);break;default:s.node.style["v-text-align"]="left";break;}}};ai=function(o,l){o.attrs=o.attrs||{};var y="linear",x=".5 .5";o.attrs.gradient=l;l=bg(l)[a6](aw,function(C,A,z){y="radial";if(A&&z){A=ao(A);z=ao(z);bf(A-0.5,2)+bf(z-0.5,2)>0.25&&(z=ar.sqrt(0.25-bf(A-0.5,2))*((z>0.5)*2-1)+0.5);x=A+a0+z;}return bk;});l=l[a8](/\s*\-\s*/);if(y=="linear"){var u=l.shift();u=-ao(u);if(isNaN(u)){return null;}}var v=aq(l);if(!v){return null;}o=o.shape||o.node;l=o.getElementsByTagName(ay)[0]||aT(ay);!l.parentNode&&o.appendChild(l);if(v[ax]){l.on=true;l.method="none";l.color=v[0].color;l.color2=v[v[ax]-1].color;o=[];for(var s=0,p=v[ax];s<p;s++){v[s].offset&&o[bc](v[s].offset+a0+v[s].color);}l.colors&&(l.colors.value=o[ax]?o[aU]():"0% "+l.color);if(y=="radial"){l.type="gradientradial";l.focus="100%";l.focussize=x;l.focusposition=x;}else{l.type="gradient";l.angle=(270-u)%360;}}return 1;};au=function(o,l,p){this[0]=o;this.id=az._oid++;this.node=o;o.raphael=this;this.Y=this.X=0;this.attrs={};this.Group=l;this.paper=p;this._={tx:0,ty:0,rt:{deg:0},sx:1,sy:1};!p.bottom&&(p.bottom=this);(this.prev=p.top)&&(p.top.next=this);p.top=this;this.next=null;};au[av].rotate=function(o,l,p){if(this.removed){return this;}if(o==null){if(this._.rt.cx){return[this._.rt.deg,this._.rt.cx,this._.rt.cy][aU](a0);}return this._.rt.deg;}o=bg(o)[a8](aQ);if(o[ax]-1){l=ao(o[1]);p=ao(o[2]);}o=ao(o[0]);if(l!=null){this._.rt.deg=o;}else{this._.rt.deg+=o;}p==null&&(l=null);this._.rt.cx=l;this._.rt.cy=p;this.setBox(this.attrs,l,p);this.Group.style.rotation=this._.rt.deg;return this;};au[av].setBox=function(z,y,x){if(this.removed){return this;}var v=this.Group.style,s=this.shape&&this.shape.style||this.node.style;z=z||{};for(var u in z){if(z[an](u)){this.attrs[u]=z[u];}}y=y||this._.rt.cx;x=x||this._.rt.cy;var p=this.attrs,o;switch(this.type){case"circle":z=p.cx-p.r;u=p.cy-p.r;o=p=p.r*2;break;case"ellipse":z=p.cx-p.rx;u=p.cy-p.ry;o=p.rx*2;p=p.ry*2;break;case"image":z=+p.x;u=+p.y;o=p.width||0;p=p.height||0;break;case"text":this.textpath.v=["m",aV(p.x),", ",aV(p.y-2),"l",aV(p.x)+1,", ",aV(p.y-2)][aU](bk);z=p.x-aV(this.W/2);u=p.y-this.H/2;o=this.W;p=this.H;break;case"rect":case"path":if(this.attrs.path){p=b(this.attrs.path);z=p.x;u=p.y;o=p.width;p=p.height;}else{u=z=0;o=this.paper.width;p=this.paper.height;}break;default:u=z=0;o=this.paper.width;p=this.paper.height;break;}y=y==null?z+o/2:y;x=x==null?u+p/2:x;y=y-this.paper.width/2;x=x-this.paper.height/2;var l;v.left!=(l=y+"px")&&(v.left=l);v.top!=(l=x+"px")&&(v.top=l);this.X=bU[an](this.type)?-y:z;this.Y=bU[an](this.type)?-x:u;this.W=o;this.H=p;if(bU[an](this.type)){s.left!=(l=-y*be+"px")&&(s.left=l);s.top!=(l=-x*be+"px")&&(s.top=l);}else{if(this.type=="text"){s.left!=(l=-y+"px")&&(s.left=l);s.top!=(l=-x+"px")&&(s.top=l);}else{v.width!=(l=this.paper.width+"px")&&(v.width=l);v.height!=(l=this.paper.height+"px")&&(v.height=l);s.left!=(l=z-y+"px")&&(s.left=l);s.top!=(l=u-x+"px")&&(s.top=l);s.width!=(l=o+"px")&&(s.width=l);s.height!=(l=p+"px")&&(s.height=l);}}};au[av].hide=function(){!this.removed&&(this.Group.style.display="none");return this;};au[av].show=function(){!this.removed&&(this.Group.style.display="block");return this;};au[av].getBBox=function(){if(this.removed){return this;}if(bU[an](this.type)){return b(this.attrs.path);}return{x:this.X+(this.bbx||0),y:this.Y,width:this.W,height:this.H};};au[av].remove=function(){if(!this.removed){bz(this,this.paper);this.node.parentNode.removeChild(this.node);this.Group.parentNode.removeChild(this.Group);this.shape&&this.shape.parentNode.removeChild(this.shape);for(var l in this){delete this[l];}this.removed=true;}};au[av].attr=function(o,l){if(this.removed){return this;}if(o==null){o={};for(var s in this.attrs){if(this.attrs[an](s)){o[s]=this.attrs[s];}}this._.rt.deg&&(o.rotation=this.rotate());(this._.sx!=1||this._.sy!=1)&&(o.scale=this.scale());o.gradient&&o.fill=="none"&&(o.fill=o.gradient)&&delete o.gradient;return o;}if(l==null&&az.is(o,bv)){if(o=="translation"){return bN.call(this);}if(o=="rotation"){return this.rotate();}if(o=="scale"){return this.scale();}if(o==ay&&this.attrs.fill=="none"&&this.attrs.gradient){return this.attrs.gradient;}return this.attrs[o];}if(this.attrs&&l==null&&az.is(o,aR)){var p={};s=0;for(l=o[ax];s<l;s++){p[o[s]]=this.attr(o[s]);}return p;}if(l!=null){p={};p[o]=l;}l==null&&az.is(o,"object")&&(p=o);if(p){if(p.text&&this.type=="text"){this.node.string=p.text;}f(this,p);if(p.gradient&&({circle:1,ellipse:1}[an](this.type)||bg(p.gradient).charAt()!="r")){ai(this,p.gradient);}(!bU[an](this.type)||this._.rt.deg)&&this.setBox(this.attrs);}return this;};au[av].toFront=function(){!this.removed&&this.Group.parentNode[ap](this.Group);this.paper.top!=this&&d(this,this.paper);return this;};au[av].toBack=function(){if(this.removed){return this;}if(this.Group.parentNode.firstChild!=this.Group){this.Group.parentNode.insertBefore(this.Group,this.Group.parentNode.firstChild);bJ(this,this.paper);}return this;};au[av].insertAfter=function(l){if(this.removed){return this;}if(l.constructor==aO){l=l[l.length];}l.Group.nextSibling?l.Group.parentNode.insertBefore(this.Group,l.Group.nextSibling):l.Group.parentNode[ap](this.Group);bi(this,l,this.paper);return this;};au[av].insertBefore=function(l){if(this.removed){return this;}if(l.constructor==aO){l=l[0];}l.Group.parentNode.insertBefore(this.Group,l.Group);br(this,l,this.paper);return this;};var by=/ progid:\S+Blur\([^\)]+\)/g;au[av].blur=function(o){var l=this.node.runtimeStyle,p=l.filter;p=p.replace(by,bk);if(+o!==0){this.attrs.blur=o;l.filter=p+a0+j+".Blur(pixelradius="+(+o||1.5)+")";l.margin=az.format("-{0}px 0 0 -{0}px",aV(+o||1.5));}else{l.filter=p;l.margin=0;delete this.attrs.blur;}};bK=function(o,l,v,u){var p=aT("group"),s=aT("oval");p.style.cssText="position:absolute;left:0;top:0;width:"+o.width+"px;height:"+o.height+"px";p.coordsize=n;p.coordorigin=o.coordorigin;p[ap](s);s=new au(s,p,o);s.type="circle";f(s,{stroke:"#000",fill:"none"});s.attrs.cx=l;s.attrs.cy=v;s.attrs.r=u;s.setBox({x:l-u,y:v-u,width:u*2,height:u*2});o.canvas[ap](p);return s;};function bx(o,l,u,s,p){return p?az.format("M{0},{1}l{2},0a{3},{3},0,0,1,{3},{3}l0,{5}a{3},{3},0,0,1,{4},{3}l{6},0a{3},{3},0,0,1,{4},{4}l0,{7}a{3},{3},0,0,1,{3},{4}z",o+p,l,u-p*2,p,-p,s-p*2,p*2-u,p*2-s):az.format("M{0},{1}l{2},0,0,{3},{4},0z",o,l,u,s,-u);}bt=function(o,l,y,x,u,v){var s=bx(l,y,x,u,v);o=o.path(s);var p=o.attrs;o.X=p.x=l;o.Y=p.y=y;o.W=p.width=x;o.H=p.height=u;p.r=v;p.path=s;o.type="rect";return o;};a2=function(o,l,x,v,s){var u=aT("group"),p=aT("oval");u.style.cssText="position:absolute;left:0;top:0;width:"+o.width+"px;height:"+o.height+"px";u.coordsize=n;u.coordorigin=o.coordorigin;u[ap](p);p=new au(p,u,o);p.type="ellipse";f(p,{stroke:"#000"});p.attrs.cx=l;p.attrs.cy=x;p.attrs.rx=v;p.attrs.ry=s;p.setBox({x:l-v,y:x-s,width:v*2,height:s*2});o.canvas[ap](u);return p;};aA=function(o,l,y,x,u,v){var s=aT("group"),p=aT("image");s.style.cssText="position:absolute;left:0;top:0;width:"+o.width+"px;height:"+o.height+"px";s.coordsize=n;s.coordorigin=o.coordorigin;p.src=l;s[ap](p);p=new au(p,s,o);p.type="image";p.attrs.src=l;p.attrs.x=y;p.attrs.y=x;p.attrs.w=u;p.attrs.h=v;p.setBox({x:y,y:x,width:u,height:v});o.canvas[ap](s);return p;};ac=function(z,y,x,v){var s=aT("group"),u=aT("shape"),p=u.style,o=aT("path"),l=aT("textpath");s.style.cssText="position:absolute;left:0;top:0;width:"+z.width+"px;height:"+z.height+"px";s.coordsize=n;s.coordorigin=z.coordorigin;o.v=az.format("m{0},{1}l{2},{1}",aV(y*10),aV(x*10),aV(y*10)+1);o.textpathok=true;p.width=z.width;p.height=z.height;l.string=bg(v);l.on=true;u[ap](l);u[ap](o);s[ap](u);p=new au(l,s,z);p.shape=u;p.textpath=o;p.type="text";p.attrs.text=v;p.attrs.x=y;p.attrs.y=x;p.attrs.w=1;p.attrs.h=1;f(p,{font:bn.font,stroke:"none",fill:"#000"});p.setBox();z.canvas[ap](s);return p;};g=function(o,l){var p=this.canvas.style;o==+o&&(o+="px");l==+l&&(l+="px");p.width=o;p.height=l;p.clip="rect(0 "+o+" "+l+" 0)";return this;};var aT;bj.createStyleSheet().addRule(".rvml","behavior:url(#default#VML)");try{!bj.namespaces.rvml&&bj.namespaces.add("rvml","urn:schemas-microsoft-com:vml");aT=function(l){return bj.createElement("<rvml:"+l+' class="rvml">');};}catch(aI){aT=function(l){return bj.createElement("<"+l+' xmlns="urn:schemas-microsoft.com:vml" class="rvml">');};}a5=function(){var o=B[a3](0,arguments),l=o.container,y=o.height,x=o.width,u=o.x;o=o.y;if(!l){throw new Error("VML container not found.");}var v=new a7,s=v.canvas=bj.createElement("div"),p=s.style;u=u||0;o=o||0;x=x||512;y=y||342;x==+x&&(x+="px");y==+y&&(y+="px");v.width=1000;v.height=1000;v.coordsize=be*1000+a0+be*1000;v.coordorigin="0 0";v.span=bj.createElement("span");v.span.style.cssText="position:absolute;left:-9999em;top:-9999em;padding:0;margin:0;line-height:1;display:inline;";s[ap](v.span);p.cssText=az.format("width:{0};height:{1};display:inline-block;position:relative;clip:rect(0 {0} {1} 0);overflow:hidden",x,y);if(l==1){bj.body[ap](s);p.left=u+"px";p.top=o+"px";p.position="absolute";}else{l.firstChild?l.insertBefore(s,l.firstChild):l[ap](s);}bh.call(v,v,az.fn);return v;};a7[av].clear=function(){this.canvas.innerHTML=bk;this.span=bj.createElement("span");this.span.style.cssText="position:absolute;left:-9999em;top:-9999em;padding:0;margin:0;line-height:1;display:inline;";this.canvas[ap](this.span);this.bottom=this.top=null;};a7[av].remove=function(){this.canvas.parentNode.removeChild(this.canvas);for(var l in this){this[l]=aW(l);}return true;};}a7[av].safari=navigator.vendor=="Apple Computer, Inc."&&(navigator.userAgent.match(/Version\/(.*?)\s/)[1]<4||bs.navigator.platform.slice(0,2)=="iP")?function(){var l=this.rect(-99,-99,this.width+99,this.height+99).attr({stroke:"none"});bs.setTimeout(function(){l.remove();});}:function(){};function bd(){this.returnValue=false;}function aE(){return this.originalEvent.preventDefault();}function ah(){this.cancelBubble=true;}function m(){return this.originalEvent.stopPropagation();}var bT=function(){if(bj.addEventListener){return function(o,l,v,u){var p=aC&&af[l]?af[l]:l;function s(z){if(aC&&af[an](l)){for(var y=0,x=z.targetTouches&&z.targetTouches.length;y<x;y++){if(z.targetTouches[y].target==o){x=z;z=z.targetTouches[y];z.originalEvent=x;z.preventDefault=aE;z.stopPropagation=m;break;}}}return v.call(u,z);}o.addEventListener(p,s,false);return function(){o.removeEventListener(p,s,false);return true;};};}else{if(bj.attachEvent){return function(o,l,v,u){function p(x){x=x||bs.event;x.preventDefault=x.preventDefault||bd;x.stopPropagation=x.stopPropagation||ah;return v.call(u,x);}o.attachEvent("on"+l,p);function s(){o.detachEvent("on"+l,p);return true;}return s;};}}}(),bB=[];function aj(o){for(var l=o.clientX,x=o.clientY,v,s=bB.length;s--;){v=bB[s];if(aC){for(var u=o.touches.length,p;u--;){p=o.touches[u];if(p.identifier==v.el._drag.id){l=p.clientX;x=p.clientY;(o.originalEvent?o.originalEvent:o).preventDefault();break;}}}else{o.preventDefault();}v.move&&v.move.call(v.el,l-v.el._drag.x,x-v.el._drag.y,l,x);}}function q(){az.unmousemove(aj).unmouseup(q);for(var o=bB.length,l;o--;){l=bB[o];l.el._drag={};l.end&&l.end.call(l.el);}bB=[];}for(L=w[ax];L--;){(function(l){az[l]=au[av][l]=function(o){if(az.is(o,"function")){this.events=this.events||[];this.events.push({name:l,f:o,unbind:bT(this.shape||this.node||bj,l,o,this)});}return this;};az["un"+l]=au[av]["un"+l]=function(o){for(var s=this.events,p=s[ax];p--;){if(s[p].name==l&&s[p].f==o){s[p].unbind();s.splice(p,1);!s.length&&delete this.events;return this;}}return this;};})(w[L]);}au[av].hover=function(o,l){return this.mouseover(o).mouseout(l);};au[av].unhover=function(o,l){return this.unmouseover(o).unmouseout(l);};au[av].drag=function(o,l,p){this._drag={};this.mousedown(function(s){(s.originalEvent||s).preventDefault();this._drag.x=s.clientX;this._drag.y=s.clientY;this._drag.id=s.identifier;l&&l.call(this,s.clientX,s.clientY);!bB.length&&az.mousemove(aj).mouseup(q);bB.push({el:this,move:o,end:p});});return this;};au[av].undrag=function(o,l,p){for(l=bB.length;l--;){bB[l].el==this&&bB[l].move==o&&bB[l].end==p&&bB.splice(l,1);!bB.length&&az.unmousemove(aj).unmouseup(q);}};a7[av].circle=function(o,l,p){return bK(this,o||0,l||0,p||0);};a7[av].rect=function(o,l,u,s,p){return bt(this,o||0,l||0,u||0,s||0,p||0);};a7[av].ellipse=function(o,l,s,p){return a2(this,o||0,l||0,s||0,p||0);};a7[av].path=function(l){l&&!az.is(l,bv)&&!az.is(l[0],aR)&&(l+=bk);return J(az.format[a3](az,arguments),this);};a7[av].image=function(o,l,u,s,p){return aA(this,o||"about:blank",l||0,u||0,s||0,p||0);};a7[av].text=function(o,l,p){return ac(this,o||0,l||0,p||bk);};a7[av].set=function(l){arguments[ax]>1&&(l=Array[av].splice.call(arguments,0,arguments[ax]));return new aO(l);};a7[av].setSize=g;a7[av].top=a7[av].bottom=null;a7[av].raphael=az;function a9(){return this.x+a0+this.y;}au[av].resetScale=function(){if(this.removed){return this;}this._.sx=1;this._.sy=1;this.attrs.scale="1 1";};au[av].scale=function(O,N,M,K){if(this.removed){return this;}if(O==null&&N==null){return{x:this._.sx,y:this._.sy,toString:a9};}N=N||O;!+N&&(N=O);var H,I,G=this.attrs;if(O!=0){var F=this.getBBox(),E=F.x+F.width/2,D=F.y+F.height/2;H=O/this._.sx;I=N/this._.sy;M=+M||M==0?M:E;K=+K||K==0?K:D;F=~~(O/ar.abs(O));var A=~~(N/ar.abs(N)),y=this.node.style,u=M+(E-M)*H;D=K+(D-K)*I;switch(this.type){case"rect":case"image":var x=G.width*F*H,C=G.height*A*I;this.attr({height:C,r:G.r*aY(F*H,A*I),width:x,x:u-x/2,y:D-C/2});break;case"circle":case"ellipse":this.attr({rx:G.rx*F*H,ry:G.ry*A*I,r:G.r*aY(F*H,A*I),cx:u,cy:D});break;case"text":this.attr({x:u,y:D});break;case"path":E=bA(G.path);for(var s=true,l=0,v=E[ax];l<v;l++){var p=E[l],o=bE.call(p[0]);if(!(o=="M"&&s)){s=false;if(o=="A"){p[E[l][ax]-2]*=H;p[E[l][ax]-1]*=I;p[1]*=F*H;p[2]*=A*I;p[5]=+!(F+A?!+p[5]:+p[5]);}else{if(o=="H"){o=1;for(var z=p[ax];o<z;o++){p[o]*=H;}}else{if(o=="V"){o=1;for(z=p[ax];o<z;o++){p[o]*=I;}}else{o=1;for(z=p[ax];o<z;o++){p[o]*=o%2?H:I;}}}}}}I=b(E);H=u-I.x-I.width/2;I=D-I.y-I.height/2;E[0][1]+=H;E[0][2]+=I;this.attr({path:E});break;}if(this.type in {text:1,image:1}&&(F!=1||A!=1)){if(this.transformations){this.transformations[2]="scale("[a1](F,",",A,")");this.node[aP]("transform",this.transformations[aU](a0));H=F==-1?-G.x-(x||0):G.x;I=A==-1?-G.y-(C||0):G.y;this.attr({x:H,y:I});G.fx=F-1;G.fy=A-1;}else{this.node.filterMatrix=j+".Matrix(M11="[a1](F,", M12=0, M21=0, M22=",A,", Dx=0, Dy=0, sizingmethod='auto expand', filtertype='bilinear')");y.filter=(this.node.filterMatrix||bk)+(this.node.filterOpacity||bk);}}else{if(this.transformations){this.transformations[2]=bk;this.node[aP]("transform",this.transformations[aU](a0));G.fx=0;G.fy=0;}else{this.node.filterMatrix=bk;y.filter=(this.node.filterMatrix||bk)+(this.node.filterOpacity||bk);}}G.scale=[O,N,M,K][aU](a0);this._.sx=O;this._.sy=N;}return this;};au[av].clone=function(){if(this.removed){return null;}var l=this.attr();delete l.scale;delete l.translation;return this.paper[this.type]().attr(l);};var aD=aL(function(E,D,C,A,y,z,x,v,u){for(var s=0,p,o=0;o<1.01;o+=0.01){var l=bQ(E,D,C,A,y,z,x,v,o);o&&(s+=bf(bf(p.x-l.x,2)+bf(p.y-l.y,2),0.5));if(s>=u){return l;}p=l;}});function bV(o,l){return function(F,E,C){F=t(F);for(var D,A,z,y,x="",v={},u=0,p=0,s=F.length;p<s;p++){z=F[p];if(z[0]=="M"){D=+z[1];A=+z[2];}else{y=bD(D,A,z[1],z[2],z[3],z[4],z[5],z[6]);if(u+y>E){if(l&&!v.start){D=aD(D,A,z[1],z[2],z[3],z[4],z[5],z[6],E-u);x+=["C",D.start.x,D.start.y,D.m.x,D.m.y,D.x,D.y];if(C){return x;}v.start=x;x=["M",D.x,D.y+"C",D.n.x,D.n.y,D.end.x,D.end.y,z[5],z[6]][aU]();u+=y;D=+z[5];A=+z[6];continue;}if(!o&&!l){D=aD(D,A,z[1],z[2],z[3],z[4],z[5],z[6],E-u);return{x:D.x,y:D.y,alpha:D.alpha};}}u+=y;D=+z[5];A=+z[6];}x+=z;}v.end=x;D=o?u:l?v:az.findDotsAtSegment(D,A,z[1],z[2],z[3],z[4],z[5],z[6],1);D.alpha&&(D={x:D.x,y:D.y,alpha:D.alpha});return D;};}var bD=aL(function(D,C,A,z,x,y,v,u){for(var s={x:0,y:0},p=0,o=0;o<1.01;o+=0.01){var l=bQ(D,C,A,z,x,y,v,u,o);o&&(p+=bf(bf(s.x-l.x,2)+bf(s.y-l.y,2),0.5));s=l;}return p;}),ag=bV(1),bw=bV(),bF=bV(0,1);au[av].getTotalLength=function(){if(this.type=="path"){if(this.node.getTotalLength){return this.node.getTotalLength();}return ag(this.attrs.path);}};au[av].getPointAtLength=function(l){if(this.type=="path"){if(this.node.getPointAtLength){return this.node.getPointAtLength(l);}return bw(this.attrs.path,l);}};au[av].getSubpath=function(o,l){if(this.type=="path"){if(ar.abs(this.getTotalLength()-l)<0.000001){return bF(this.attrs.path,o).end;}l=bF(this.attrs.path,l,1);return o?bF(l,o).end:l;}};az.easing_formulas={linear:function(l){return l;},"<":function(l){return bf(l,3);},">":function(l){return bf(l-1,3)+1;},"<>":function(l){l*=2;if(l<1){return bf(l,3)/2;}l-=2;return(bf(l,3)+2)/2;},backIn:function(o){var l=1.70158;return o*o*((l+1)*o-l);},backOut:function(o){o-=1;var l=1.70158;return o*o*((l+1)*o+l)+1;},elastic:function(o){if(o==0||o==1){return o;}var l=0.3,p=l/4;return bf(2,-10*o)*ar.sin((o-p)*2*ar.PI/l)+1;},bounce:function(o){var l=7.5625,p=2.75;if(o<1/p){o=l*o*o;}else{if(o<2/p){o-=1.5/p;o=l*o*o+0.75;}else{if(o<2.5/p){o-=2.25/p;o=l*o*o+0.9375;}else{o-=2.625/p;o=l*o*o+0.984375;}}}return o;}};var aS={length:0};function k(){var M=+new Date;for(var K in aS){if(K!="length"&&aS[an](K)){var I=aS[K];if(I.stop||I.el.removed){delete aS[K];aS[ax]--;}else{var H=M-I.start,F=I.ms,G=I.easing,E=I.from,D=I.diff,C=I.to,A=I.t,y=I.prev||0,x=I.el,s=I.callback,v={},z;if(H<F){s=az.easing_formulas[G]?az.easing_formulas[G](H/F):H/F;for(var p in E){if(E[an](p)){switch(bR[p]){case"along":z=s*F*D[p];C.back&&(z=C.len-z);G=bw(C[p],z);x.translate(D.sx-D.x||0,D.sy-D.y||0);D.x=G.x;D.y=G.y;x.translate(G.x-D.sx,G.y-D.sy);C.rot&&x.rotate(D.r+G.alpha,G.x,G.y);break;case aX:z=+E[p]+s*F*D[p];break;case"colour":z="rgb("+[bo(aV(E[p].r+s*F*D[p].r)),bo(aV(E[p].g+s*F*D[p].g)),bo(aV(E[p].b+s*F*D[p].b))][aU](",")+")";break;case"path":z=[];G=0;for(var l=E[p][ax];G<l;G++){z[G]=[E[p][G][0]];for(var u=1,o=E[p][G][ax];u<o;u++){z[G][u]=+E[p][G][u]+s*F*D[p][G][u];}z[G]=z[G][aU](a0);}z=z[aU](a0);break;case"csv":switch(p){case"translation":z=D[p][0]*(H-y);G=D[p][1]*(H-y);A.x+=z;A.y+=G;z=z+a0+G;break;case"rotation":z=+E[p][0]+s*F*D[p][0];E[p][1]&&(z+=","+E[p][1]+","+E[p][2]);break;case"scale":z=[+E[p][0]+s*F*D[p][0],+E[p][1]+s*F*D[p][1],2 in C[p]?C[p][2]:bk,3 in C[p]?C[p][3]:bk][aU](a0);break;case"clip-rect":z=[];for(G=4;G--;){z[G]=+E[p][G]+s*F*D[p][G];}break;}break;}v[p]=z;}}x.attr(v);x._run&&x._run.call(x);}else{if(C.along){G=bw(C.along,C.len*!C.back);x.translate(D.sx-(D.x||0)+G.x-D.sx,D.sy-(D.y||0)+G.y-D.sy);C.rot&&x.rotate(D.r+G.alpha,G.x,G.y);}(A.x||A.y)&&x.translate(-A.x,-A.y);C.scale&&(C.scale+=bk);x.attr(C);delete aS[K];aS[ax]--;x.in_animation=null;az.is(s,"function")&&s.call(x);}I.prev=H;}}}az.svg&&x&&x.paper&&x.paper.safari();aS[ax]&&bs.setTimeout(k);}function bo(l){return aN(aY(l,255),0);}function bN(o,l){if(o==null){return{x:this._.tx,y:this._.ty,toString:a9};}this._.tx+=+o;this._.ty+=+l;switch(this.type){case"circle":case"ellipse":this.attr({cx:+o+this.attrs.cx,cy:+l+this.attrs.cy});break;case"rect":case"image":case"text":this.attr({x:+o+this.attrs.x,y:+l+this.attrs.y});break;case"path":var p=bA(this.attrs.path);p[0][1]+=+o;p[0][2]+=+l;this.attr({path:p});break;}return this;}au[av].animateWith=function(o,l,u,s,p){aS[o.id]&&(l.start=aS[o.id].start);return this.animate(l,u,s,p);};au[av].animateAlong=bS();au[av].animateAlongBack=bS(1);function bS(l){return function(o,v,u,p){var s={back:l};az.is(u,"function")?(p=u):(s.rot=u);o&&o.constructor==au&&(o=o.attrs.path);o&&(s.along=o);return this.animate(s,v,p);};}au[av].onAnimation=function(l){this._run=l||0;return this;};au[av].animate=function(E,D,C,A){if(az.is(C,"function")||!C){A=C||null;}var y={},z={},x={};for(var v in E){if(E[an](v)){if(bR[an](v)){y[v]=this.attr(v);y[v]==null&&(y[v]=bn[v]);z[v]=E[v];switch(bR[v]){case"along":var u=ag(E[v]),s=bw(E[v],u*!!E.back),p=this.getBBox();x[v]=u/D;x.tx=p.x;x.ty=p.y;x.sx=s.x;x.sy=s.y;z.rot=E.rot;z.back=E.back;z.len=u;E.rot&&(x.r=ao(this.rotate())||0);break;case aX:x[v]=(z[v]-y[v])/D;break;case"colour":y[v]=az.getRGB(y[v]);u=az.getRGB(z[v]);x[v]={r:(u.r-y[v].r)/D,g:(u.g-y[v].g)/D,b:(u.b-y[v].b)/D};break;case"path":u=t(y[v],z[v]);y[v]=u[0];s=u[1];x[v]=[];u=0;for(p=y[v][ax];u<p;u++){x[v][u]=[0];for(var o=1,l=y[v][u][ax];o<l;o++){x[v][u][o]=(s[u][o]-y[v][u][o])/D;}}break;case"csv":s=bg(E[v])[a8](aQ);u=bg(y[v])[a8](aQ);switch(v){case"translation":y[v]=[0,0];x[v]=[s[0]/D,s[1]/D];break;case"rotation":y[v]=u[1]==s[1]&&u[2]==s[2]?u:[0,s[1],s[2]];x[v]=[(s[0]-y[v][0])/D,0,0];break;case"scale":E[v]=s;y[v]=bg(y[v])[a8](aQ);x[v]=[(s[0]-y[v][0])/D,(s[1]-y[v][1])/D,0,0];break;case"clip-rect":y[v]=bg(y[v])[a8](aQ);x[v]=[];for(u=4;u--;){x[v][u]=(s[u]-y[v][u])/D;}break;}z[v]=s;}}}}this.stop();this.in_animation=1;aS[this.id]={start:E.start||+new Date,ms:D,easing:C,from:y,diff:x,to:z,el:this,callback:A,t:{x:0,y:0}};++aS[ax]==1&&k();return this;};au[av].stop=function(){aS[this.id]&&aS[ax]--;delete aS[this.id];return this;};au[av].translate=function(o,l){return this.attr({translation:o+" "+l});};au[av][aZ]=function(){return"Rapha\u00ebl\u2019s object";};az.ae=aS;function aO(o){this.items=[];this[ax]=0;this.type="set";if(o){for(var l=0,p=o[ax];l<p;l++){if(o[l]&&(o[l].constructor==au||o[l].constructor==aO)){this[this.items[ax]]=this.items[this.items[ax]]=o[l];this[ax]++;}}}}aO[av][bc]=function(){for(var o,l,s=0,p=arguments[ax];s<p;s++){if((o=arguments[s])&&(o.constructor==au||o.constructor==aO)){l=this.items[ax];this[l]=this.items[l]=o;this[ax]++;}}return this;};aO[av].pop=function(){delete this[this[ax]--];return this.items.pop();};for(var aK in au[av]){if(au[av][an](aK)){aO[av][aK]=function(l){return function(){for(var o=0,p=this.items[ax];o<p;o++){this.items[o][l][a3](this.items[o],arguments);}return this;};}(aK);}}aO[av].attr=function(o,l){if(o&&az.is(o,aR)&&az.is(o[0],"object")){l=0;for(var s=o[ax];l<s;l++){this.items[l].attr(o[l]);}}else{s=0;for(var p=this.items[ax];s<p;s++){this.items[s].attr(o,l);}}return this;};aO[av].animate=function(z,y,x,v){(az.is(x,"function")||!x)&&(v=x||null);var s=this.items[ax],u=s,p,o=this,l;v&&(l=function(){!--s&&v.call(o);});x=az.is(x,bv)?x:l;for(p=this.items[--u].animate(z,y,x,l);u--;){this.items[u].animateWith(p,z,y,x,l);}return this;};aO[av].insertAfter=function(o){for(var l=this.items[ax];l--;){this.items[l].insertAfter(o);}return this;};aO[av].getBBox=function(){for(var o=[],l=[],v=[],u=[],p=this.items[ax];p--;){var s=this.items[p].getBBox();o[bc](s.x);l[bc](s.y);v[bc](s.x+s.width);u[bc](s.y+s.height);}o=aY[a3](0,o);l=aY[a3](0,l);return{x:o,y:l,width:aN[a3](0,v)-o,height:aN[a3](0,u)-l};};aO[av].clone=function(o){o=new aO;for(var l=0,p=this.items[ax];l<p;l++){o[bc](this.items[l].clone());}return o;};az.registerFont=function(o){if(!o.face){return o;}this.fonts=this.fonts||{};var l={w:o.w,face:{},glyphs:{}},v=o.face["font-family"];for(var u in o.face){if(o.face[an](u)){l.face[u]=o.face[u];}}if(this.fonts[v]){this.fonts[v][bc](l);}else{this.fonts[v]=[l];}if(!o.svg){l.face["units-per-em"]=a4(o.face["units-per-em"],10);for(var p in o.glyphs){if(o.glyphs[an](p)){v=o.glyphs[p];l.glyphs[p]={w:v.w,k:{},d:v.d&&"M"+v.d[a6](/[mlcxtrv]/g,function(x){return{l:"L",c:"C",x:"z",t:"m",r:"l",v:"c"}[x]||"M";})+"z"};if(v.k){for(var s in v.k){if(v[an](s)){l.glyphs[p].k[s]=v.k[s];}}}}}}return o;};a7[av].getFont=function(o,l,x,v){v=v||"normal";x=x||"normal";l=+l||{normal:400,bold:700,lighter:300,bolder:800}[l]||400;if(az.fonts){var s=az.fonts[o];if(!s){o=new RegExp("(^|\\s)"+o[a6](/[^\w\d\s+!~.:_-]/g,bk)+"(\\s|$)","i");for(var u in az.fonts){if(az.fonts[an](u)){if(o.test(u)){s=az.fonts[u];break;}}}}var p;if(s){u=0;for(o=s[ax];u<o;u++){p=s[u];if(p.face["font-weight"]==l&&(p.face["font-style"]==x||!p.face["font-style"])&&p.face["font-stretch"]==v){break;}}}return p;}};a7[av].print=function(E,D,C,A,y,z){z=z||"middle";var x=this.set(),v=bg(C)[a8](bk),u=0;az.is(A,C)&&(A=this.getFont(A));if(A){C=(y||16)/A.face["units-per-em"];var s=A.face.bbox.split(aQ);y=+s[0];z=+s[1]+(z=="baseline"?s[3]-s[1]+ +A.face.descent:(s[3]-s[1])/2);s=0;for(var p=v[ax];s<p;s++){var o=s&&A.glyphs[v[s-1]]||{},l=A.glyphs[v[s]];u+=s?(o.w||A.w)+(o.k&&o.k[v[s]]||0):0;l&&l.d&&x[bc](this.path(l.d).attr({fill:"#000",stroke:"none",translation:[u,0]}));}x.scale(C,C,y,z).translate(E-y,D-z);}return x;};var bm=/\{(\d+)\}/g;az.format=function(o,l){var p=az.is(l,aR)?[0][a1](l):arguments;o&&az.is(o,bv)&&p[ax]-1&&(o=o[a6](bm,function(u,s){return p[++s]==null?bk:p[s];}));return o||bk;};az.ninja=function(){am.was?(Raphael=am.is):delete Raphael;return az;};az.el=au[av];return az;}();</script><script type="text/javascript">(function(){var g=Math.max,i=Math.min;Raphael.fn.g=Raphael.fn.g||{};Raphael.fn.g.markers={disc:"disc",o:"disc",flower:"flower",f:"flower",diamond:"diamond",d:"diamond",square:"square",s:"square",triangle:"triangle",t:"triangle",star:"star","*":"star",cross:"cross",x:"cross",plus:"plus","+":"plus",arrow:"arrow","->":"arrow"};Raphael.fn.g.shim={stroke:"none",fill:"#000","fill-opacity":0};Raphael.fn.g.txtattr={font:"12px Arial, sans-serif"};Raphael.fn.g.txtaxisattr={font:"9px Tahoma,Geneva,Helvetica Neue,Helvetica,Arial,sans-serif",fill:"#646464",};Raphael.fn.g.colors=[];var h=[0.6,0.2,0.05,0.1333,0.75,0];for(var f=0;f<10;f++){if(f<h.length){Raphael.fn.g.colors.push("hsb("+h[f]+", .75, .75)");}else{Raphael.fn.g.colors.push("hsb("+h[f-h.length]+", 1, .5)");}}Raphael.fn.g.text=function(c,a,b){return this.text(c,a,b).attr(this.g.txtattr);};Raphael.fn.g.labelise=function(c,a,b){if(c){return(c+"").replace(/(##+(?:\.#+)?)|(%%+(?:\.%+)?)/g,function(m,e,l){if(e){return(+a).toFixed(e.replace(/^#+\.?/g,"").length);}if(l){return(a*100/b).toFixed(l.replace(/^%+\.?/g,"").length)+"%";}});}else{return(+a).toFixed(0);}};Raphael.fn.g.finger=function(e,p,u,c,t,s,q){if((t&&!c)||(!t&&!u)){return q?"":this.path();}s={square:"square",sharp:"sharp",soft:"soft"}[s]||"round";var a;c=Math.round(c);u=Math.round(u);e=Math.round(e);p=Math.round(p);switch(s){case"round":if(!t){var v=~~(c/2);if(u<v){v=u;a=["M",e+0.5,p+0.5-~~(c/2),"l",0,0,"a",v,~~(c/2),0,0,1,0,c,"l",0,0,"z"];}else{a=["M",e+0.5,p+0.5-v,"l",u-v,0,"a",v,v,0,1,1,0,c,"l",v-u,0,"z"];}}else{v=~~(u/2);if(c<v){v=c;a=["M",e-~~(u/2),p,"l",0,0,"a",~~(u/2),v,0,0,1,u,0,"l",0,0,"z"];}else{a=["M",e-v,p,"l",0,v-c,"a",v,v,0,1,1,u,0,"l",0,c-v,"z"];}}break;case"sharp":if(!t){var b=~~(c/2);a=["M",e,p+b,"l",0,-c,g(u-b,0),0,i(b,u),b,-i(b,u),b+(b*2<c),"z"];}else{b=~~(u/2);a=["M",e+b,p,"l",-u,0,0,-g(c-b,0),b,-i(b,c),b,i(b,c),b,"z"];}break;case"square":if(!t){a=["M",e,p+~~(c/2),"l",0,-c,u,0,0,c,"z"];}else{a=["M",e+~~(u/2),p,"l",1-u,0,0,-c,u-1,0,"z"];}break;case"soft":if(!t){v=i(u,Math.round(c/5));a=["M",e+0.5,p+0.5-~~(c/2),"l",u-v,0,"a",v,v,0,0,1,v,v,"l",0,c-v*2,"a",v,v,0,0,1,-v,v,"l",v-u,0,"z"];}else{v=i(Math.round(u/5),c);a=["M",e-~~(u/2),p,"l",0,v-c,"a",v,v,0,0,1,v,-v,"l",u-2*v,0,"a",v,v,0,0,1,v,v,"l",0,c-v,"z"];}}if(q){return a.join(",");}else{return this.path(a);}};Raphael.fn.g.disc=function(c,a,b){return this.circle(c,a,b);};Raphael.fn.g.line=function(c,a,b){return this.rect(c-b,a-b/5,2*b,2*b/5);};Raphael.fn.g.square=function(c,a,b){b=b*0.7;return this.rect(c-b,a-b,2*b,2*b);};Raphael.fn.g.triangle=function(c,a,b){b*=1.75;return this.path("M".concat(c,",",a,"m0-",b*0.58,"l",b*0.5,",",b*0.87,"-",b,",0z"));};Raphael.fn.g.diamond=function(c,a,b){return this.path(["M",c,a-b,"l",b,b,-b,b,-b,-b,b,-b,"z"]);};Raphael.fn.g.flower=function(q,s,u,t){u=u*1.25;var b=u,c=b*0.5;t=+t<3||!t?5:t;var a=["M",q,s+c,"Q"],e;for(var n=1;n<t*2+1;n++){e=n%2?b:c;a=a.concat([+(q+e*Math.sin(n*Math.PI/t)).toFixed(3),+(s+e*Math.cos(n*Math.PI/t)).toFixed(3)]);}a.push("z");return this.path(a.join(","));};Raphael.fn.g.star=function(q,s,a,o,p){o=o||a*0.382;p=p||5;var b=["M",q,s+o,"L"],c;for(var e=1;e<p*2;e++){c=e%2?a:o;b=b.concat([(q+c*Math.sin(e*Math.PI/p)),(s+c*Math.cos(e*Math.PI/p))]);}b.push("z");return this.path(b.join(","));};Raphael.fn.g.cross=function(c,a,b){b=b/2.5;return this.path("M".concat(c-b,",",a,"l",[-b,-b,b,-b,b,b,b,-b,b,b,-b,b,b,b,-b,b,-b,-b,-b,b,-b,-b,"z"]));};Raphael.fn.g.plus=function(c,a,b){b=b/2;return this.path("M".concat(c-b/2,",",a-b/2,"l",[0,-b,b,0,0,b,b,0,0,b,-b,0,0,b,-b,0,0,-b,-b,0,0,-b,"z"]));};Raphael.fn.g.arrow=function(c,a,b){return this.path("M".concat(c-b*0.7,",",a-b*0.4,"l",[b*0.6,0,0,-b*0.4,b,b*0.8,-b,b*0.8,0,-b*0.4,-b*0.6,0],"z"));};Raphael.fn.g.tag=function(q,a,b,c,n){c=c||0;n=n==null?5:n;b=b==null?"$9.99":b;var o=0.5522*n,p=this.set(),e=3;p.push(this.path().attr({fill:"#000",stroke:"#000"}));p.push(this.text(q,a,b).attr(this.g.txtattr).attr({fill:"#fff","font-family":"Helvetica, Arial"}));p.update=function(){this.rotate(0,q,a);var j=this[1].getBBox();if(j.height>=n*2){this[0].attr({path:["M",q,a+n,"a",n,n,0,1,1,0,-n*2,n,n,0,1,1,0,n*2,"m",0,-n*2-e,"a",n+e,n+e,0,1,0,0,(n+e)*2,"L",q+n+e,a+j.height/2+e,"l",j.width+2*e,0,0,-j.height-2*e,-j.width-2*e,0,"L",q,a-n-e].join(",")});}else{var k=Math.sqrt(Math.pow(n+e,2)-Math.pow(j.height/2+e,2));this[0].attr({path:["M",q,a+n,"c",-o,0,-n,o-n,-n,-n,0,-o,n-o,-n,n,-n,o,0,n,n-o,n,n,0,o,o-n,n,-n,n,"M",q+k,a-j.height/2-e,"a",n+e,n+e,0,1,0,0,j.height+2*e,"l",n+e-k+j.width+2*e,0,0,-j.height-2*e,"L",q+k,a-j.height/2-e].join(",")});}this[1].attr({x:q+n+e+j.width/2,y:a});c=(360-c)%360;this.rotate(c,q,a);c>90&&c<270&&this[1].attr({x:q-n-e-j.width/2,y:a,rotation:[180+c,q,a]});return this;};p.update();return p;};Raphael.fn.g.popupit=function(p,u,e,x,z){x=x==null?2:x;z=z||5;p=Math.round(p);u=Math.round(u);var v=e.getBBox(),c=Math.round(v.width/2),w=Math.round(v.height/2),A=[0,c+z*2,0,-c-z*2],b=[-w*2-z*3,-w-z,0,-w-z],y=["M",p-A[x],u-b[x],"l",-z,(x==2)*-z,-g(c-z,0),0,"a",z,z,0,0,1,-z,-z,"l",0,-g(w-z,0),(x==3)*-z,-z,(x==3)*z,-z,0,-g(w-z,0),"a",z,z,0,0,1,z,-z,"l",g(c-z,0),0,z,!x*-z,z,!x*z,g(c-z,0),0,"a",z,z,0,0,1,z,z,"l",0,g(w-z,0),(x==1)*z,z,(x==1)*-z,z,0,g(w-z,0),"a",z,z,0,0,1,-z,z,"l",-g(c-z,0),0,"z"].join(","),a=[{x:p,y:u+z*2+w},{x:p-z*2-c,y:u},{x:p,y:u-z*2-w},{x:p+z*2+c,y:u}][x];e.translate(a.x-c-v.x,a.y-w-v.y);return this.path(y).attr({fill:"#000",stroke:"none"}).insertBefore(e.node?e:e[0]);};Raphael.fn.g.popup=function(o,a,b,n,e){n=n==null?2:n>3?3:n;e=e||5;b=b||"$9.99";var m=this.set(),c=3;m.push(this.path().attr({fill:"#000",stroke:"#000"}));m.push(this.text(o,a,b).attr(this.g.txtattr).attr({fill:"#fff","font-family":"Helvetica, Arial"}));m.update=function(k,l,j){k=k||o;l=l||a;var C=this[1].getBBox(),B=C.width/2,D=C.height/2,w=[0,B+e*2,0,-B-e*2],A=[-D*2-e*3,-D-e,0,-D-e],p=["M",k-w[n],l-A[n],"l",-e,(n==2)*-e,-g(B-e,0),0,"a",e,e,0,0,1,-e,-e,"l",0,-g(D-e,0),(n==3)*-e,-e,(n==3)*e,-e,0,-g(D-e,0),"a",e,e,0,0,1,e,-e,"l",g(B-e,0),0,e,!n*-e,e,!n*e,g(B-e,0),0,"a",e,e,0,0,1,e,e,"l",0,g(D-e,0),(n==1)*e,e,(n==1)*-e,e,0,g(D-e,0),"a",e,e,0,0,1,-e,e,"l",-g(B-e,0),0,"z"].join(","),z=[{x:k,y:l+e*2+D},{x:k-e*2-B,y:l},{x:k,y:l-e*2-D},{x:k+e*2+B,y:l}][n];z.path=p;if(j){this.animate(z,500,">");}else{this.attr(z);}return this;};return m.update(o,a);};Raphael.fn.g.flag=function(m,a,b,c){c=c||0;b=b||"$9.99";var l=this.set(),e=3;l.push(this.path().attr({fill:"#000",stroke:"#000"}));l.push(this.text(m,a,b).attr(this.g.txtattr).attr({fill:"#fff","font-family":"Helvetica, Arial"}));l.update=function(k,p){this.rotate(0,k,p);var q=this[1].getBBox(),j=q.height/2;this[0].attr({path:["M",k,p,"l",j+e,-j-e,q.width+2*e,0,0,q.height+2*e,-q.width-2*e,0,"z"].join(",")});this[1].attr({x:k+j+e+q.width/2,y:p});c=360-c;this.rotate(c,k,p);c>90&&c<270&&this[1].attr({x:k-r-e-q.width/2,y:p,rotation:[180+c,k,p]});return this;};return l.update(m,a);};Raphael.fn.g.label=function(e,a,b){var c=this.set();c.push(this.rect(e,a,10,10).attr({stroke:"none",fill:"#000"}));c.push(this.text(e,a,b).attr(this.g.txtattr).attr({fill:"#fff"}));c.update=function(){var l=this[1].getBBox(),m=i(l.width+10,l.height+10)/2;this[0].attr({x:l.x-m/2,y:l.y-m/2,width:l.width+m,height:l.height+m,r:m});};c.update();return c;};Raphael.fn.g.labelit=function(a){var b=a.getBBox(),c=i(20,b.width+10,b.height+10)/2;return this.rect(b.x-c/2,b.y-c/2,b.width+c,b.height+c,c).attr({stroke:"none",fill:"#000"}).insertBefore(a.node?a:a[0]);};Raphael.fn.g.drop=function(m,a,b,e,c){e=e||30;c=c||0;var l=this.set();l.push(this.path(["M",m,a,"l",e,0,"A",e*0.4,e*0.4,0,1,0,m+e*0.7,a-e*0.7,"z"]).attr({fill:"#000",stroke:"none",rotation:[22.5-c,m,a]}));c=(c+90)*Math.PI/180;l.push(this.text(m+e*Math.sin(c),a+e*Math.cos(c),b).attr(this.g.txtattr).attr({"font-size":e*12/30,fill:"#fff"}));l.drop=l[0];l.text=l[1];return l;};Raphael.fn.g.blob=function(p,a,b,c,n){c=(+c+1?c:45)+90;n=n||12;var q=Math.PI/180,e=n*12/12;var o=this.set();o.push(this.path().attr({fill:"#000",stroke:"none"}));o.push(this.text(p+n*Math.sin((c)*q),a+n*Math.cos((c)*q)-e/2,b).attr(this.g.txtattr).attr({"font-size":e,fill:"#fff"}));o.update=function(P,R,K){P=P||p;R=R||a;var H=this[1].getBBox(),j=g(H.width+e,n*25/12),J=g(H.height+e,n*25/12),G=P+n*Math.sin((c-22.5)*q),w=R+n*Math.cos((c-22.5)*q),l=P+n*Math.sin((c+22.5)*q),k=R+n*Math.cos((c+22.5)*q),O=(l-G)/2,Q=(k-w)/2,m=j/2,I=J/2,L=-Math.sqrt(Math.abs(m*m*I*I-m*m*Q*Q-I*I*O*O)/(m*m*Q*Q+I*I*O*O)),M=L*m*Q/I+(l+G)/2,N=L*-I*O/m+(k+w)/2;if(K){this.animate({x:M,y:N,path:["M",p,a,"L",l,k,"A",m,I,0,1,1,G,w,"z"].join(",")},500,">");}else{this.attr({x:M,y:N,path:["M",p,a,"L",l,k,"A",m,I,0,1,1,G,w,"z"].join(",")});}return this;};o.update(p,a);return o;};Raphael.fn.g.colorValue=function(a,b,c,e){return"hsb("+[i((1-a/b)*0.4,1),c||0.75,e||0.75]+")";};Raphael.fn.g.snapEnds=function(e,c,s){var u=e,b=c;if(u==b){return{from:u,to:b,power:0};}function a(j){return Math.abs(j-0.5)<0.25?~~(j)+0.5:Math.round(j);}var t=(b-u)/s,x=~~(t),v=x,w=0;if(x){while(v){w--;v=~~(t*Math.pow(10,w))/Math.pow(10,w);}w++;}else{while(!x){w=w||1;x=~~(t*Math.pow(10,w))/Math.pow(10,w);w++;}w&&w--;}b=a(c*Math.pow(10,w))/Math.pow(10,w);if(b<c){b=a((c+0.5)*Math.pow(10,w))/Math.pow(10,w);}u=a((e-(w>0?0:0.5))*Math.pow(10,w))/Math.pow(10,w);return{from:u,to:b,power:w};};Raphael.fn.g.axis=function(O,Q,Z,N,ac,j,ab,b,aa,af){af=af==null?2:af;aa=aa||"t";j=j||10;var P=aa=="|"||aa==" "?["M",O+0.5,Q,"l",0,0.001]:ab==1||ab==3?["M",O+0.5,Q,"l",0,-Z]:["M",O,Q+0.5,"l",Z,0],e=this.g.snapEnds(N,ac,j),c=e.from,W=e.to,t=e.power,y=0,U=this.set();d=(W-c)/j;var T=c,V=t>0?t:0;x=Z/j;if(+ab==1||+ab==3){var ae=Q,Y=(ab-1?1:-1)*(af+3+!!(ab-1));while(ae>=Q-Z){aa!="-"&&aa!=" "&&(P=P.concat(["M",O-(aa=="+"||aa=="|"?af:!(ab-1)*af*2),ae+0.5,"l",af*2+1,0]));U.push(this.text(O+Y,ae,(b&&b[y++])||(Math.round(T)==T?T:+T.toFixed(V))).attr(this.g.txtaxisattr).attr({"text-anchor":ab-1?"start":"end"}));T+=d;ae-=x;}if(Math.round(ae+x-(Q-Z))){aa!="-"&&aa!=" "&&(P=P.concat(["M",O-(aa=="+"||aa=="|"?af:!(ab-1)*af*2),Q-Z+0.5,"l",af*2+1,0]));U.push(this.text(O+Y,Q-Z,(b&&b[y])||(Math.round(T)==T?T:+T.toFixed(V))).attr(this.g.txtaxisattr).attr({"text-anchor":ab-1?"start":"end"}));}}else{T=c;V=(t>0)*t;Y=(ab?-1:1)*(af+9+!ab);var ad=O,x=Z/j,S=0,R=0;while(ad<=O+Z){aa!="-"&&aa!=" "&&(P=P.concat(["M",ad+0.5,Q-(aa=="+"?af:!!ab*af*2),"l",0,af*2+1]));U.push(S=this.text(ad,Q+Y,(b&&b[y++])||(Math.round(T)==T?T:+T.toFixed(V))).attr(this.g.txtaxisattr));var X=S.getBBox();if(R>=X.x-5){U.pop(U.length-1).remove();}else{R=X.x+X.width;}T+=d;ad+=x;}if(Math.round(ad-x-O-Z)){aa!="-"&&aa!=" "&&(P=P.concat(["M",O+Z+0.5,Q-(aa=="+"?af:!!ab*af*2),"l",0,af*2+1]));U.push(this.text(O+Z,Q+Y,(b&&b[y])||(Math.round(T)==T?T:+T.toFixed(V))).attr(this.g.txtaxisattr));}}var a=this.path(P);a.text=U;a.all=this.set([a,U]);a.remove=function(){this.text.remove();this.constructor.prototype.remove.call(this);};return a;};Raphael.el.lighter=function(a){a=a||2;var b=[this.attrs.fill,this.attrs.stroke];this.fs=this.fs||[b[0],b[1]];b[0]=Raphael.rgb2hsb(Raphael.getRGB(b[0]).hex);b[1]=Raphael.rgb2hsb(Raphael.getRGB(b[1]).hex);b[0].b=i(b[0].b*a,1);b[0].s=b[0].s/a;b[1].b=i(b[1].b*a,1);b[1].s=b[1].s/a;this.attr({fill:"hsb("+[b[0].h,b[0].s,b[0].b]+")",stroke:"hsb("+[b[1].h,b[1].s,b[1].b]+")"});};Raphael.el.darker=function(a){a=a||2;var b=[this.attrs.fill,this.attrs.stroke];this.fs=this.fs||[b[0],b[1]];b[0]=Raphael.rgb2hsb(Raphael.getRGB(b[0]).hex);b[1]=Raphael.rgb2hsb(Raphael.getRGB(b[1]).hex);b[0].s=i(b[0].s*a,1);b[0].b=b[0].b/a;b[1].s=i(b[1].s*a,1);b[1].b=b[1].b/a;this.attr({fill:"hsb("+[b[0].h,b[0].s,b[0].b]+")",stroke:"hsb("+[b[1].h,b[1].s,b[1].b]+")"});};Raphael.el.original=function(){if(this.fs){this.attr({fill:this.fs[0],stroke:this.fs[1]});delete this.fs;}};})();</script><script type="text/javascript">Raphael.fn.g.piechart=function(S,T,J,V,M){M=M||{};var N=this,L=[],Q=this.set(),K=this.set(),O=this.set(),E=[],C=V.length,B=0,I=0,p=0,U=9,r=false;K.covers=Q;K.coord=[];if(C==1){Q.push(this.ellipse(S,T,J,J).attr(this.g.shim));O.push(this.ellipse(S,T,J,J).attr({fill:M.colors&&M.colors[0]||this.g.colors[0],stroke:M.stroke||"#fff","stroke-width":M.strokewidth==null?1:M.strokewidth}));I=V[0];V[0]={value:V[0],order:0,valueOf:function(){return this.value;}};O[0].middle={x:S,y:T};O[0].mangle=180;O[0].value=V[0];}else{function F(n,o,e,l,a,f){var j=Math.PI/180,d=n+e*Math.cos(-l*j),c=n+e*Math.cos(-a*j),m=n+e/2*Math.cos(-(l+(a-l)/2)*j),g=o+e*Math.sin(-l*j),h=o+e*Math.sin(-a*j),b=o+e/2*Math.sin(-(l+(a-l)/2)*j),k=["M",n,o,"L",d,g,"A",e,e,0,+(Math.abs(a-l)>180),1,c,h,"z"];k.middle={x:m,y:b};K.coord.push(k);return k;}for(var D=0;D<C;D++){I+=V[D];V[D]={value:V[D],order:D,valueOf:function(){return this.value;}};}var i=I*4/360;for(var D=0;D<C;D++){if(V[D].value<=i){I+=i-V[D].value;V[D].valueOf=function(){return i;};}}for(D=0;D<C;D++){if(r&&V[D]*360/I<=1.5){U=D;r=false;}if(D>U){r=false;V[U].value+=V[D];V[U].others=true;p=V[U].value;}}C=Math.min(U+1,V.length);p&&V.splice(C)&&(V[U].others=true);for(D=0;D<C;D++){var R=B-360*V[D]/I/2;if(!D){B=90-R;R=B-360*V[D]/I/2;}if(M.init){var P=F(S,T,1,B,B-360*V[D]/I).join(",");}var G=F(S,T,J,B,B-=360*V[D]/I);var H=this.path(M.init?P:G).attr({fill:M.colors&&M.colors[D]||this.g.colors[D]||"#666",stroke:M.stroke||"#fff","stroke-width":(M.strokewidth==null?1:M.strokewidth),"stroke-linejoin":"round"});H.value=V[D];H.middle=G.middle;H.mangle=R;L.push(H);O.push(H);M.init&&H.animate({path:G.join(",")},(+M.init-1)||1000,">");}for(D=0;D<C;D++){H=N.path(L[D].attr("path")).attr(this.g.shim);H.toBack();M.href&&M.href[D]&&H.attr({href:M.href[D]});H.attr=function(){};Q.push(H);O.push(H);}}K.hover=function(c,a){a=a||function(){};var d=this;for(var b=0;b<C;b++){(function(h,g,e){var f={sector:h,cover:g,cx:S,cy:T,mx:h.middle.x,my:h.middle.y,mangle:h.mangle,r:J,value:V[e],total:I,label:d.labels&&d.labels[e]};g.mouseover(function(){c.call(f);}).mouseout(function(){a.call(f);});})(O[b],Q[b],b);}return this;};K.each=function(c){var a=this;for(var b=0;b<C;b++){(function(g,f,d){var e={sector:g,cover:f,cx:S,cy:T,x:g.middle.x,y:g.middle.y,mangle:g.mangle,r:J,value:V[d],total:I,label:a.labels&&a.labels[d]};c.call(e);})(O[b],Q[b],b);}return this;};K.click=function(c){var a=this;for(var b=0;b<C;b++){(function(g,f,d){var e={sector:g,cover:f,cx:S,cy:T,mx:g.middle.x,my:g.middle.y,mangle:g.mangle,r:J,value:V[d],total:I,label:a.labels&&a.labels[d]};f.click(function(){c.call(e);});})(O[b],Q[b],b);}return this;};K.inject=function(a){a.insertBefore(Q[0]);};var W=function(l,d,b,e){var g=S+J+J/5,h=T,m=h+10;l=l||[];e=(e&&e.toLowerCase&&e.toLowerCase())||"east";b=N.g.markers[b&&b.toLowerCase()]||"square";K.labels=N.set();for(var n=0;n<C;n++){var f=O[n].attr("fill"),c=V[n].order,a;V[n].others&&(l[c]=d||"Others");l[c]=N.g.labelise(l[c],V[n],I);K.labels.push(N.set());K.labels[n].push(N.g[b](g+5,m,5).attr({fill:f,stroke:"none"}));K.labels[n].push(a=N.text(g+20,m,l[c]||V[c]).attr(N.g.txtattr).attr({fill:M.legendcolor||"#000","text-anchor":"start"}));Q[n].label=K.labels[n];m+=a.getBBox().height*1.2;}var k=K.labels.getBBox(),j={east:[0,-k.height/2],west:[-k.width-2*J-20,-k.height/2],north:[-J-k.width/2,-J-k.height-10],south:[-J-k.width/2,J+10]}[e];K.labels.translate.apply(K.labels,j);K.push(K.labels);};if(M.legend){W(M.legend,M.legendothers,M.legendmark,M.legendpos);}K.push(O,Q);K.series=O;K.covers=Q;return K;};</script><script type="text/javascript">Raphael.fn.g.barchart=function(X,Z,au,aq,i,ad){ad=ad||{};var h={round:"round",sharp:"sharp",soft:"soft"}[ad.type]||"square",aj=parseFloat(ad.gutter||"20%"),s=this.set(),ac=this.set(),ap=this.set(),af=this.set(),ab=Math.max.apply(Math,i),j=[],ar=this,Y=0,U=ad.colors||this.g.colors,ag=i.length;if(this.raphael.is(i[0],"array")){ab=[];Y=ag;ag=0;for(var y=i.length;y--;){ac.push(this.set());ab.push(Math.max.apply(Math,i[y]));ag=Math.max(ag,i[y].length);}if(ad.stacked){for(var y=ag;y--;){var al=0;for(var Q=i.length;Q--;){al+=+i[Q][y]||0;}j.push(al);}}for(var y=i.length;y--;){if(i[y].length<ag){for(var Q=ag;Q--;){i[y].push(0);}}}ab=Math.max.apply(Math,ad.stacked?j:ab);}ab=(ad.to)||ab;var W=au/(ag*(100+aj)+aj)*100,at=W*aj/100,an=ad.vgutter==null?20:ad.vgutter,ae=[],am=X+at,ao=(aq-2*an)/ab;if(!ad.stretch){at=Math.round(at);W=Math.floor(W);}!ad.stacked&&(W/=Y||1);for(var y=0;y<ag;y++){ae=[];for(var Q=0;Q<(Y||1);Q++){var x=Math.round((Y?i[Q][y]:i[y])*ao),ak=Z+aq-an-x,S=this.g.finger(Math.round(am+W/2),ak+x,W,x,true,h).attr({stroke:"none",fill:U[Y?Q:y]});if(Y){ac[Q].push(S);}else{ac.push(S);}S.y=ak;S.x=Math.round(am+W/2);S.w=W;S.h=x;S.value=Y?i[Q][y]:i[y];if(!ad.stacked){am+=W;}else{ae.push(S);}}if(ad.stacked){var R;af.push(R=this.rect(ae[0].x-ae[0].w/2,Z,W,aq).attr(this.g.shim));R.bars=this.set();var ai=0;for(var V=ae.length;V--;){ae[V].toFront();}for(var V=0,ah=ae.length;V<ah;V++){var S=ae[V],aa,x=(ai+S.value)*ao,T=this.g.finger(S.x,Z+aq-an-!!ai*0.5,W,x,true,h,1);R.bars.push(S);ai&&S.attr({path:T});S.h=x;S.y=Z+aq-an-!!ai*0.5-x;ap.push(aa=this.rect(S.x-S.w/2,S.y,W,S.value*ao).attr(this.g.shim));aa.bar=S;aa.value=S.value;ai+=S.value;}am+=W;}am+=at;}af.toFront();am=X+at;if(!ad.stacked){for(var y=0;y<ag;y++){for(var Q=0;Q<(Y||1);Q++){var aa;ap.push(aa=this.rect(Math.round(am),Z+an,W,aq-an).attr(this.g.shim));aa.bar=Y?ac[Q][y]:ac[y];aa.value=aa.bar.value;am+=W;}am+=at;}}s.label=function(g,c){g=g||[];this.labels=ar.set();var b,f=-Infinity;if(ad.stacked){for(var k=0;k<ag;k++){var e=0;for(var l=0;l<(Y||1);l++){e+=Y?i[l][k]:i[k];if(l==Y-1){var a=ar.g.labelise(g[k],e,ab);b=ar.g.text(ac[k*(Y||1)+l].x,Z+aq-an/2,a).insertBefore(ap[k*(Y||1)+l]);var d=b.getBBox();if(d.x-7<f){b.remove();}else{this.labels.push(b);f=d.x+d.width;}}}}}else{for(var k=0;k<ag;k++){for(var l=0;l<(Y||1);l++){var a=ar.g.labelise(Y?g[l]&&g[l][k]:g[k],Y?i[l][k]:i[k],ab);b=ar.g.text(ac[k*(Y||1)+l].x,c?Z+aq-an/2:ac[k*(Y||1)+l].y-10,a).insertBefore(ap[k*(Y||1)+l]);var d=b.getBBox();if(d.x-7<f){b.remove();}else{this.labels.push(b);f=d.x+d.width;}}}}return this;};s.hover=function(a,b){af.hide();ap.show();ap.mouseover(a).mouseout(b);return this;};s.hoverColumn=function(a,b){ap.hide();af.show();b=b||function(){};af.mouseover(a).mouseout(b);return this;};s.click=function(a){af.hide();ap.show();ap.click(a);return this;};s.each=function(a){if(!Raphael.is(a,"function")){return this;}for(var b=ap.length;b--;){a.call(ap[b]);}return this;};s.eachColumn=function(a){if(!Raphael.is(a,"function")){return this;}for(var b=af.length;b--;){a.call(af[b]);}return this;};s.clickColumn=function(a){ap.hide();af.show();af.click(a);return this;};s.push(ac,ap,af);s.bars=ac;s.covers=ap;return s;};Raphael.fn.g.hbarchart=function(ae,ag,aa,P,an,Y){Y=Y||{};var al={round:"round",sharp:"sharp",soft:"soft"}[Y.type]||"square",ak=parseFloat(Y.gutter||"20%"),T=this.set(),ac=this.set(),ai=this.set(),V=this.set(),i=Math.max.apply(Math,an),ap=[],ad=this,X=0,af=Y.colors||this.g.colors,O=an.length;if(this.raphael.is(an[0],"array")){i=[];X=O;O=0;for(var R=an.length;R--;){ac.push(this.set());i.push(Math.max.apply(Math,an[R]));O=Math.max(O,an[R].length);}if(Y.stacked){for(var R=O;R--;){var ab=0;for(var S=an.length;S--;){ab+=+an[S][R]||0;}ap.push(ab);}}for(var R=an.length;R--;){if(an[R].length<O){for(var S=O;S--;){an[R].push(0);}}}i=Math.max.apply(Math,Y.stacked?ap:i);}i=(Y.to)||i;var y=Math.floor(P/(O*(100+ak)+ak)*100),ah=Math.floor(y*ak/100),aj=[],ao=ag+ah,am=(aa-1)/i;!Y.stacked&&(y/=X||1);for(var R=0;R<O;R++){aj=[];for(var S=0;S<(X||1);S++){var j=X?an[S][R]:an[R],N=this.g.finger(ae,ao+y/2,Math.round(j*am),y-1,false,al).attr({stroke:"none",fill:af[X?S:R]});if(X){ac[S].push(N);}else{ac.push(N);}N.x=ae+Math.round(j*am);N.y=ao+y/2;N.w=Math.round(j*am);N.h=y;N.value=+j;if(!Y.stacked){ao+=y;}else{aj.push(N);}}if(Y.stacked){var Z=this.rect(ae,aj[0].y-aj[0].h/2,aa,y).attr(this.g.shim);V.push(Z);Z.bars=this.set();var Q=0;for(var U=aj.length;U--;){aj[U].toFront();}for(var U=0,W=aj.length;U<W;U++){var N=aj[U],x,j=Math.round((Q+N.value)*am),s=this.g.finger(ae,N.y,j,y-1,false,al,1);Z.bars.push(N);Q&&N.attr({path:s});N.w=j;N.x=ae+j;ai.push(x=this.rect(ae+Q*am,N.y-N.h/2,N.value*am,y).attr(this.g.shim));x.bar=N;Q+=N.value;}ao+=y;}ao+=ah;}V.toFront();ao=ag+ah;if(!Y.stacked){for(var R=0;R<O;R++){for(var S=0;S<(X||1);S++){var x=this.rect(ae,ao,aa,y).attr(this.g.shim);x.attr({fill:"#EEE","fill-opacity":"1",stroke:"none"});x.toBack();ai.push(x);x.bar=X?ac[S][R]:ac[R];x.value=x.bar.value;ao+=y;}ao+=ah;}}T.label=function(c,e){c=c||[];this.labels=ad.set();for(var f=0;f<O;f++){for(var g=0;g<X;g++){var h=ad.g.labelise(X?c[g]&&c[g][f]:c[f],X?an[g][f]:an[f],i);var d=e?ac[f*(X||1)+g].x-y/2+3:ae+5,a=e?"end":"start",b;this.labels.push(b=ad.g.text(d,ac[f*(X||1)+g].y,h).attr({"text-anchor":a}).insertBefore(ai[0]));if(b.getBBox().x<ae+5){b.attr({x:ae+5,"text-anchor":"start"});}else{ac[f*(X||1)+g].label=b;}}}return this;};T.hover=function(a,b){V.hide();ai.show();b=b||function(){};ai.mouseover(a).mouseout(b);return this;};T.hoverColumn=function(a,b){ai.hide();V.show();b=b||function(){};V.mouseover(a).mouseout(b);return this;};T.each=function(b){if(!Raphael.is(b,"function")){return this;}for(var a=ai.length;a--;){b.call(ai[a]);}return this;};T.eachColumn=function(b){if(!Raphael.is(b,"function")){return this;}for(var a=V.length;a--;){b.call(V[a]);}return this;};T.click=function(a){V.hide();ai.show();ai.click(a);return this;};T.clickColumn=function(a){ai.hide();V.show();V.click(a);return this;};T.push(ac,ai,V);T.bars=ac;T.covers=ai;return T;};</script><script type="text/javascript">Raphael.fn.g.donutchart=function(n,f,e,h,j,c,o){o=o||{};var a=this,q=[],k=n.set(),r=n.set(),m=n.set(),v=[],x=c.length,y=0,B=0,A=0,d=9,z=true;function u(p,i,G,H,N,L,M){var R=Math.PI/180,E=p+H*Math.cos(-N*R),C=p+H*Math.cos(-L*R),Q=p+G*Math.cos(-N*R),P=p+G*Math.cos(-L*R),J=p+H/2*Math.cos(-(N+(L-N)/2)*R),K=i+H*Math.sin(-N*R),I=i+H*Math.sin(-L*R),F=i+G*Math.sin(-N*R),D=i+G*Math.sin(-L*R),O=i+H/2*Math.sin(-(N+(L-N)/2)*R),S=["M",Q,F,"A",G,G,0,+(Math.abs(L-N)>180),1,P,D,"L",C,I,"A",H,H,0,+(Math.abs(L-N)>180),0,E,K,"z"];S.middle={x:J,y:O};return S;}r.covers=k;if(x==1){m.push(n.circle(f,e,j).attr({fill:a.colors[0],stroke:o.stroke||"#fff","stroke-width":o.strokewidth==null?1:o.strokewidth}));k.push(n.circle(f,e,j).attr(a.shim));B=c[0];c[0]={value:c[0],order:0,valueOf:function(){return this.value;}};m[0].middle={x:f,y:e};m[0].mangle=180;}else{for(var w=0;w<x;w++){B+=c[w];c[w]={value:c[w],order:w,valueOf:function(){return this.value;}};}c.sort(function(p,i){return i.value-p.value;});for(w=0;w<x;w++){if(z&&c[w]*360/B<=1.5){d=w;z=false;}if(w>d){z=false;c[d].value+=c[w];c[d].others=true;A=c[d].value;}}x=Math.min(d+1,c.length);A&&c.splice(x)&&(c[d].others=true);for(w=0;w<x;w++){var g=y-360*c[w]/B/2;if(!w){y=90-g;g=y-360*c[w]/B/2;}if(o.init){var l=u(f,e,1,y,y-360*c[w]/B).join(",");}var t=u(f,e,h,j,y,y-=360*c[w]/B);var s=n.path(o.init?l:t).attr({fill:o.colors&&o.colors[w]||a.colors[w]||"#666",opacity:o.opacity[w]||1,stroke:o.stroke||"#fff","stroke-width":(o.strokewidth==null?1:o.strokewidth),"stroke-linejoin":"round"});s.value=c[w];s.middle=t.middle;s.mangle=g;q.push(s);m.push(s);o.init&&s.animate({path:t.join(",")},(+o.init-1)||1000,">");}for(w=0;w<x;w++){s=n.path(q[w].attr("path")).attr({fill:"none",stroke:"#fff"});o.href&&o.href[w]&&s.attr({href:o.href[w]});s.attr=function(){};k.push(s);m.push(s);}}r.hover=function(E,C){C=C||function(){};var D=this;for(var p=0;p<x;p++){(function(F,G,i){var H={sector:F,cover:G,cx:f,cy:e,mx:F.middle.x,my:F.middle.y,mangle:F.mangle,ir:h,or:j,value:c[i],total:B,label:D.labels&&D.labels[i]};G.mouseover(function(){E.call(H);}).mouseout(function(){C.call(H);});})(m[p],k[p],p);}return this;};r.each=function(D){var C=this;for(var p=0;p<x;p++){(function(E,F,i){var G={sector:E,cover:F,cx:f,cy:e,x:E.middle.x,y:E.middle.y,mangle:E.mangle,ir:h,or:j,value:c[i],total:B,label:C.labels&&C.labels[i]};D.call(G);})(m[p],k[p],p);}return this;};r.click=function(D){var C=this;for(var p=0;p<x;p++){(function(E,F,i){var G={sector:E,cover:F,cx:f,cy:e,mx:E.middle.x,my:E.middle.y,mangle:E.mangle,ir:h,or:j,value:c[i],total:B,label:C.labels&&C.labels[i]};F.click(function(){D.call(G);});})(m[p],k[p],p);}return this;};r.inject=function(i){i.insertBefore(k[0]);};var b=function(I,D,C,p){var M=f+j+j/5,L=e,H=L+10;I=I||[];p=(p&&p.toLowerCase&&p.toLowerCase())||"east";C=n[C&&C.toLowerCase()]||"circle";r.labels=n.set();for(var G=0;G<x;G++){var N=m[G].attr("fill"),E=c[G].order,F;c[G].others&&(I[E]=D||"Others");I[E]=a.labelise(I[E],c[G],B);r.labels.push(n.set());r.labels[G].push(n[C](M+5,H,5).attr({fill:N,stroke:"none"}));r.labels[G].push(F=n.text(M+20,H,I[E]||c[E]).attr(a.txtattr).attr({fill:o.legendcolor||"#000","text-anchor":"start"}));k[G].label=r.labels[G];H+=F.getBBox().height*1.2;}var J=r.labels.getBBox(),K={east:[0,-J.height/2],west:[-J.width-2*j-20,-J.height/2],north:[-j-J.width/2,-j-J.height-10],south:[-j-J.width/2,j+10]}[p];r.labels.translate.apply(r.labels,K);r.push(r.labels);};if(o.legend){b(o.legend,o.legendothers,o.legendmark,o.legendpos);}r.push(m,k);r.series=m;r.covers=k;return r;};</script><script type="text/javascript">phe.graph=new phe.Element;phe.graphButtons=new phe.Element;phe.graphData=new phe.Element;phe.graphDataItemLabel=new phe.Element;phe.graphDataItemValue=new phe.Element;phe.graph.defaultColors=["#8B2D2F","#E53B32","#ED742D","#EA5B76","#E73E58","#A53048","#802B3D"],phe.graph.initialize=function(c){var d=bb.selector.queryAll(c,".ui-graph");for(var b=0;b<d.length;b++){var a=d[b];if(!a.paper){if(a.getAttribute("defaultType")=="donut"){a.paper=Raphael(bb.selector.query(a,".ui-donutgraph-paper"));}else{if(a.getAttribute("defaultType")=="vBar"){a.paper=Raphael(bb.selector.query(a,".ui-verticalBarGraph-paper"));}else{a.paper=Raphael(bb.selector.query(a,".ui-graph-paper"));}}this.getGraphData(a);}}};phe.graph.getGraphData=function(a){absa.io.makeRequest(a.getAttribute("datafile"),function(c){if(c.errors.length>0){absa.showIOErrorMessage(a);}else{if(c.text.length>0){var r=bb.html.createElementFromString(c.text);var n=[];var y=[];var f=[];var g=[];var l=0;if(r.rows&&r.rows[0].cells.length>0){for(var u=0;u<r.rows[0].cells.length;u++){var w=r.rows[0].cells[u];g.push(w.getAttribute("legendValue"));n.push(w.innerText||w.textContent);y.push(w.getAttribute("tooltip"));f.push(w.getAttribute("color")||phe.graph.defaultColors[l++]);}var t=[];var k=[];var h=[];var x=0;for(var s=0;s<r.rows[1].cells.length;s++){var w=r.rows[1].cells[s];if((w.innerText||w.textContent)==""){var m=(parseFloat(w.getAttribute("graphValue")));}else{var m=(parseFloat(w.innerText||w.textContent));}if(a.getAttribute("defaultType")=="vBar"){if(!isNaN(parseFloat(w.getAttribute("barTopValue")))){var p=(parseFloat(w.getAttribute("barTopValue")));k.push(p);}}if(m>0){x++;}t.push(m);h.push(w.getAttribute("tooltip"));}if(x>0){if(a.getAttribute("defaultType")=="donut"){var v=bb.selector.query(a,".ui-donutgraph-paper");}else{if(a.getAttribute("defaultType")=="vBar"){var v=bb.selector.query(a,".ui-verticalBarGraph-paper");}else{var v=bb.selector.query(a,".ui-graph-paper");}}if(v){phe.common.show(v.firstChild);}a.graphLegends=n;a.graphLegendValues=g;a.graphHeaderTooltips=y;a.graphColors=f;a.graphValues=t;a.graphTooltips=h;a.graphTopValues=k;var q=a.getAttribute("defaultType");switch(q){case"bar":phe.graph.drawBarChart(a);break;case"vBar":phe.graph.drawVBarChart(a);break;case"donut":phe.graph.drawDonutChart(a);break;case"pie":phe.graph.drawPieChart(a);break;case"3dPie":phe.graph.draw3DPieChart(a);break;default:phe.graph.drawPieChart(a);}var z=bb.selector.query(a,".ui-graph-accessibility");if(!z){z=bb.html.createElementFromString('<div class="ui-graph-accessibility vi-screenreader-line"></div>');a.appendChild(z);}if(z.firstChild){z.replaceChild(r,z.firstChild);}else{z.appendChild(r);}var b=bb.selector.queryAll(z,"th");var e=bb.selector.queryAll(z,"td");for(var u=0;u<e.length;u++){var d=e[u].innerHTML;e[u].innerHTML="";e[u].appendChild(bb.html.createElementFromString('<span class="vi-chart-cell" tabindex="0">'+b[u].innerHTML+" "+d+"</span>"));}}else{var o=bb.selector.query(a,".ui-graph--noGraphDataWarning");if(a.getAttribute("defaultType")=="donut"){var v=bb.selector.query(a,".ui-donutgraph-paper");}else{if(a.getAttribute("defaultType")=="vBar"){var v=bb.selector.query(a,".ui-verticalBarGraph-paper");}else{var v=bb.selector.query(a,".ui-graph-paper");}}phe.common.hide(v.firstChild);phe.message.show(o);}}else{var o=bb.selector.query(a,".ui-graph--noGraphDataWarning");if(a.getAttribute("defaultType")=="donut"){var v=bb.selector.query(a,".ui-donutgraph-paper");}else{if(a.getAttribute("defaultType")=="vBar"){var v=bb.selector.query(a,".ui-verticalBarGraph-paper");}else{var v=bb.selector.query(a,".ui-graph-paper");}}phe.common.hide(v.firstChild);phe.message.show(o);}}}});};phe.graph.getGraphLegendValue=function(a,c){for(var b=0;b<a.graphLegends.length;b++){if(c==a.graphLegends[b]){return a.graphLegendValues[b];}}};phe.graph.drawBarChart=function(n){phe.graph.clearPaper(n);var l=n.graphLegends;var q=n.graphColors;var o=n.graphValues;var d=n.graphTooltips;var m=0;for(var f=0;f<o.length;f++){m+=o[f];}var b=parseInt(n.getAttribute("width")||"140",10);var a=parseInt(n.getAttribute("height")||"120",10);var h=parseInt(n.getAttribute("left")||"140",10);var e=parseInt(n.getAttribute("top")||"20",10);var g=n.paper.g.hbarchart(h,e,b,a,o,{colors:q,gutter:50,to:m});var c=[];for(var f=0;f<o.length;f++){var k=n.paper.text(20,g.bars[f].y,l[f]);k.attr({"text-anchor":"left","font-family":'Tahoma,Geneva,"Helvetica Neue",Helvetica,Arial,sans-serif',fill:"#646464","font-size":"11px"});var j=k.getBBox();var p=n.paper.rect(20,g.bars[f].y-8,j.width,j.height).attr({fill:"white","fill-opacity":"0",stroke:"transparent","stroke-width":"0"});c.push(p);}this.addToolTips(n,g,c);this.addEventsCallbacks(n,g,c);};phe.graph.drawVBarChart=function(E){phe.graph.clearPaper(E);var s=E.graphLegends;var d=E.graphColors;var B=E.graphValues;var l=E.graphTooltips;var e=0;for(var C=0;C<B.length;C++){e+=B[C];}var D=parseInt(E.getAttribute("width")||"140",15);var m=parseInt(D*0.6);var h=85;var u=10;var t=E.paper.g.barchart(h,u,D,m,B,{colors:d,vgutter:20});var b=[];for(var C=0;C<B.length;C++){var f=s[C];var w=f.split(" ");var v=m;var c=22;if(bb.browser.ie){v=m+3;}for(var z=0;z<w.length;z++){var y=w[z];var k=E.paper.text(t.bars[C].x-27,v,y);k.attr({"text-anchor":"start","font-family":'Tahoma,Geneva,"Helvetica Neue",Helvetica,Arial,sans-serif',fill:"#646464","font-weight":"bold","font-size":"11px"});var A=k.getBBox();var g=E.paper.rect(t.bars[C].x-27,30,A.width,128).attr({fill:"white","fill-opacity":"0",stroke:"transparent","stroke-width":"0","word-wrap":"break-word"});v=v+12;c=c+12;}var n=E.graphTopValues;if(n.length!=0){var a=(113-(Math.round((B[C]/Math.max.apply(Math,B))*100)))*1.3;var r;if(n[C]>10){r=E.paper.text(t.bars[C].x-12,a,n[C].toString().concat("%"));}else{r=E.paper.text(t.bars[C].x-12,m-20,n[C].toString().concat("%"));}r.attr({"text-anchor":"start","font-family":'Tahoma,Geneva,"Helvetica Neue",Helvetica,Arial,sans-serif',fill:"#646464","font-weight":"bold","font-size":"11px"});}b.push(g);}B.sort(function(j,i){return i-j;});var p=6;var o=B[0]/p;var q=[];var x=[];for(var C=0;C<=p;C++){q[C]=Math.round(o*C);x[C]="R ".concat(q[C].toFixed(2).replace(/(\d)(?=(\d{3})+\.)/g,"$1,").replace(".00",""));}E.paper.g.axis(92,m-12,m-40,0,105,6,1,x,"|",1,E.paper).attr({stroke:"#A4A4A4"});E.paper.path(["M",94,m-10,"H",D+94]).attr({stroke:"#A4A4A4"}).toBack();E.paper.path(["M",94,28,"V",m-10]).attr({stroke:"#A4A4A4"}).toBack();this.addToolTips(E,t,b);this.addEventsCallbacks(E,t,b);};phe.graph.drawDonutChart=function(E){phe.graph.clearPaper(E);var u=E.getAttribute("legendPos")||"south";if(u==null||u==""){u="south";}var c=E.graphColors;var z=E.graphValues.concat();var m=E.graphLegends;var h=E.graphTooltips;var o=z.length-1,B,D,v,x,d,n,s;for(var A=0;A<z.length;A++){d=false;var C=Math.max.apply(Math,z);var w=parseFloat((C*0.1)/100);if(z[A]<=w){z[A]=w;}for(n=0;n<o;n+=1){s=n+1;if(z[n]<z[s]){B=z[s];z[s]=z[n];z[n]=B;D=m[s];m[s]=m[n];m[n]=D;v=h[s];h[s]=h[n];h[n]=v;x=c[s];c[s]=c[n];c[n]=x;d=true;}}}var b=parseInt(E.getAttribute("width")||"400",10);var r=parseInt(E.getAttribute("height")||"200",10);var f=parseInt(E.getAttribute("left")||"80",10);var q=parseInt(E.getAttribute("top")||"95",10);var l=parseInt(E.getAttribute("radius")||"1",10);var t=l-25;if(l==1){l=parseInt(E.getAttribute("width")||E.getAttribute("height")||"140",10)/2;t=l-25;}var k=E.paper.g.donutchart(E.paper,f,q,t,l,z,{colors:c,opacity:1,stroke:"#fff"});var a;var j=E.getAttribute("showLegend");if(j==null){j="true";}if(j=="true"){var u=E.getAttribute("legendPos");if(u==null||u==""){a=this.drawLegend(E);}else{a=this.drawLegendAtPos(E,u);}}var e=E.getAttribute("targetValue");var p=E.getAttribute("fontSize");var g;if(bb.browser.ie){g=E.paper.text(61,98,e);}else{g=E.paper.text(54,94,e);}if(p==null||p==""){g.attr({"text-anchor":"left","font-family":'Tahoma,Geneva,"Helvetica Neue",Helvetica,Arial,sans-serif',fill:"#ED742D","font-size":"22px","font-weight":"bold"});}else{g.attr({"text-anchor":"left","font-family":'Tahoma,Geneva,"Helvetica Neue",Helvetica,Arial,sans-serif',fill:"#646464","font-size":p,"font-weight":"bold"});}var y=g.getBBox();if(bb.browser.ie){E.paper.rect(60,81,y.width,y.height).attr({fill:"white","fill-opacity":"0",stroke:"transparent","stroke-width":"0"});}else{E.paper.rect(54,81,y.width,y.height).attr({fill:"white","fill-opacity":"0",stroke:"transparent","stroke-width":"0"});}this.addToolTips(E,k,a);this.addEventsCallbacks(E,k,a);};phe.graph.drawPieChart=function(h){phe.graph.clearPaper(h);var j=h.graphColors;var i=h.graphValues.concat();var f=parseInt(h.getAttribute("width")||"400",10);var e=parseInt(h.getAttribute("height")||"200",10);var c=parseInt(h.getAttribute("left")||"220",10);var a=parseInt(h.getAttribute("top")||"75",10);var g=parseInt(h.getAttribute("radius")||"1",10);if(g==1){g=parseInt(h.getAttribute("width")||h.getAttribute("height")||"140",10)/2;}var d=h.paper.g.piechart(c,a,g,i,{colors:j});var b=h.getAttribute("showLegend");if(b==null){b="true";}if(b=="true"){var k=h.getAttribute("legendPos");if(k==null||k==""){aLegendElements=this.drawLegend(h);}else{aLegendElements=this.drawLegendAtPos(h,k);}}this.addToolTips(h,d,aLegendElements);this.addEventsCallbacks(h,d,aLegendElements);};phe.graph.draw3DPieChart=function(m){phe.graph.clearPaper(m);var n=m.graphColors;var o=m.graphValues.concat();var b=m.graphValues.concat();var h=parseInt(m.getAttribute("width")||"400",10);var g=parseInt(m.getAttribute("height")||"200",10);var f=parseInt(m.getAttribute("left")||"220",10);var c=parseInt(m.getAttribute("top")||"75",10);var l=parseInt(m.getAttribute("radius")||"1",10);if(l==1){l=parseInt(m.getAttribute("width")||m.getAttribute("height")||"140",10)/2;}var k=m.paper.g.piechart(f,c,l,o,{colors:n});k.scale(1,0.5,0,50);if(o.length=="1"){var j=m.paper.path(["M",f+l,c,"A",l,l,0,0,1,f-l,c,"L",f-l,2*c,"A",l,l,0,0,0,f+l,2*c,"z"]).scale(1,0.5,0,50).attr({fill:n[0],stroke:"#FFF"});}else{var a=m.paper.g.piechart(f,2*c,l,b,{colors:n}).scale(1,0.5,0,50);for(var d=0;d<k.coord.length;d++){if(k.coord[d][5]<k.coord[d][2]&&k.coord[d][13]>k.coord[d][2]){m.paper.path(["M",k.coord[d][1]+k.coord[d][7],k.coord[d][2],"A",k.coord[d][7],k.coord[d][8],0,0,1,k.coord[d][12],k.coord[d][13],"L",a.coord[d][12],a.coord[d][13],"A",a.coord[d][7],a.coord[d][8],0,0,0,a.coord[d][1]+a.coord[d][7],a.coord[d][2],"z"]).attr({fill:n[d],stroke:"#FFF"}).scale(1,0.5,0,50);}else{if((k.coord[d][5]>k.coord[d][2]&&k.coord[d][13]>k.coord[d][2]&&k.coord[d][10]==0)||(k.coord[d][5]==k.coord[d][2]&&k.coord[d][13]>k.coord[d][2]&&k.coord[d][10]==0)){m.paper.path(["M",k.coord[d][4],k.coord[d][5],"A",k.coord[d][7],k.coord[d][8],0,0,1,k.coord[d][12],k.coord[d][13],"L",a.coord[d][12],a.coord[d][13],"A",a.coord[d][7],a.coord[d][8],0,0,0,a.coord[d][4],a.coord[d][5],"z"]).attr({fill:n[d],stroke:"#FFF"}).scale(1,0.5,0,50);}else{if((k.coord[d][5]>k.coord[d][2]&&k.coord[d][13]<k.coord[d][2])||(k.coord[d][13]==k.coord[d][2]&&k.coord[d][5]>k.coord[d][2])){m.paper.path(["M",k.coord[d][1]-k.coord[d][7],k.coord[d][2],"A",k.coord[d][7],k.coord[d][8],0,0,0,k.coord[d][4],k.coord[d][5],"L",a.coord[d][4],a.coord[d][5],"A",a.coord[d][7],a.coord[d][8],0,0,1,a.coord[d][1]-a.coord[d][7],a.coord[d][2],"z"]).attr({fill:n[d],stroke:"#FFF"}).scale(1,0.5,0,50);}else{if((k.coord[d][5]>k.coord[d][2]&&k.coord[d][13]>k.coord[d][2]&&k.coord[d][10]==1)||(k.coord[d][5]==k.coord[d][2]&&k.coord[d][13]>k.coord[d][2]&&k.coord[d][10]==1)){m.paper.path(["M",k.coord[d][4],k.coord[d][5],"A",k.coord[d][7],k.coord[d][8],0,0,1,k.coord[d][1]-k.coord[d][7],k.coord[d][2],"L",a.coord[d][1]-a.coord[d][7],a.coord[d][2],"A",a.coord[d][7],a.coord[d][8],0,0,0,a.coord[d][4],a.coord[d][5],"z"]).attr({fill:n[d],stroke:"#FFF"}).scale(1,0.5,0,50);m.paper.path(["M",k.coord[d][1]+k.coord[d][7],k.coord[d][2],"A",k.coord[d][7],k.coord[d][8],0,0,1,k.coord[d][12],k.coord[d][13],"L",a.coord[d][12],a.coord[d][13],"A",a.coord[d][7],a.coord[d][8],0,0,0,a.coord[d][1]+a.coord[d][7],a.coord[d][2],"z"]).attr({fill:n[d],stroke:"#FFF"}).scale(1,0.5,0,50);}else{if((k.coord[d][5]<k.coord[d][2]&&k.coord[d][13]<k.coord[d][2]&&k.coord[d][10]==1)||(k.coord[d][5]==k.coord[d][2]&&k.coord[d][13]<k.coord[d][2]&&k.coord[d][10]==1)||(k.coord[d][5]==k.coord[d][2]&&k.coord[d][13]==k.coord[d][2]&&k.coord[d][10]==0)){m.paper.path(["M",k.coord[d][1]+k.coord[d][7],k.coord[d][2],"A",k.coord[d][7],k.coord[d][8],0,0,1,k.coord[d][1]-k.coord[d][7],k.coord[d][2],"L",a.coord[d][1]-a.coord[d][7],a.coord[d][2],"A",a.coord[d][7],a.coord[d][8],0,0,0,a.coord[d][1]+a.coord[d][7],a.coord[d][2],"z"]).attr({fill:n[d],stroke:"#FFF"}).scale(1,0.5,0,50);}}}}}}a.remove();}var e=m.getAttribute("showLegend");if(e==null){e="true";}if(e=="true"){var p=m.getAttribute("legendPos");if(p==null||p==""){aLegendElements=this.drawLegend(m);}else{aLegendElements=this.drawLegendAtPos(m,p);}}this.addToolTips(m,k,aLegendElements);this.addEventsCallbacks(m,k,aLegendElements);};phe.graph.drawLegendAtPos=function(s,p){var c=s.graphColors;var b=parseInt(s.getAttribute("width")||"400",10);var h=parseInt(s.getAttribute("height")||"200",10);var e=parseInt(s.getAttribute("left")||"220",10);var i=parseInt(s.getAttribute("top")||"75",10);var o=parseInt(s.getAttribute("radius")||"1",10);if(o==1){o=parseInt(s.getAttribute("width")||s.getAttribute("height")||"140",10)/2;}var r=0;var q=0;if(p=="north"){r=(b/4);q=18;}else{if(p=="south"){r=(b/4);var m=(i+o+10);if(m>=h){m=h/2;}q=m;}else{if(p=="east"){var n=Number(e+o+10);if(n>=b){n=b/2;}r=n;q=18;}else{r=14;q=18;}}}var g=q;var a=[];for(var k=0;k<s.graphLegends.length;k++){if(k==0){g=g;}else{g=g+20;}s.paper.rect(r,g-8,8,8).attr({fill:c[k],stroke:"#fff"});var f="";if(bb.browser.ie){f=s.paper.text(r+20,g-2.5,s.graphLegends[k]);}else{f=s.paper.text(r+20,g-5,s.graphLegends[k]);}f.attr({"text-anchor":"left","font-family":'Tahoma,Geneva,"Helvetica Neue",Helvetica,Arial,sans-serif',fill:"#646464","font-size":"11px"});var l=f.getBBox();var d=s.paper.rect(r+20,g-10.5,l.width,l.height).attr({fill:"white","fill-opacity":"0",stroke:"transparent","stroke-width":"0"});a.push(d);}return a;};phe.graph.drawLegend=function(e){var h=e.graphColors;var f=[];for(var d=0;d<e.graphLegends.length;d++){if(e.getAttribute("defaultType")=="donut"){var g=(d+1)*18+170;}else{var g=(d+1)*18+20;}e.paper.rect(14,g-8,8,8).attr({fill:h[d],stroke:"#fff"});var b="";if(bb.browser.ie){b=e.paper.text(34,g-2.5,e.graphLegends[d]);}else{b=e.paper.text(34,g-5,e.graphLegends[d]);}b.attr({"text-anchor":"left","font-family":'Tahoma,Geneva,"Helvetica Neue",Helvetica,Arial,sans-serif',fill:"#646464","font-size":"11px"});var a=b.getBBox();var c=e.paper.rect(34,g-10.5,a.width,a.height).attr({fill:"white","fill-opacity":"0",stroke:"transparent","stroke-width":"0"});f.push(c);}return f;};phe.graph.addToolTips=function(d,a,h){var g=d.graphHeaderTooltips;var f=d.graphTooltips;var b=a.series||a.bars;var g=d.graphHeaderTooltips;var f=d.graphTooltips;var b=a.series||a.bars;if(h!=null&&h.length>0){for(var e=0;e<h.length;e++){var c=f[e]||(typeof b[e].value=="object"?b[e].value.value:b[e].value);h[e].node.setAttribute("tooltip",g[e]||c);b[e].node.setAttribute("tooltip",c);}}};phe.graph.addEventsCallbacks=function(d,b,f){var a=absa.util.attributeToFunction(d,"onvalueclick",["sLabel"]);if(a){var c=b.series||b.bars;if(f!=null){for(var e=0;e<f.length;e++){f[e].attr({cursor:"pointer"});c[e].attr({cursor:"pointer"});(function(h,i,g){g.click(function(){a.call(g,phe.graph.getGraphLegendValue(d,i));});h.click(function(){a.call(h,phe.graph.getGraphLegendValue(d,i));});})(c[e],d.graphLegends[e],f[e]);}}}};phe.graph.clearPaper=function(a){a.paper.clear();};</script><script type="text/javascript">var phe=window.phe||{};phe.grid=new phe.Element;phe.rows=new phe.Element;phe.row=new phe.Element;phe.cell=new phe.Element;</script><script type="text/javascript">var phe=window.phe||{};phe.helpText=new phe.Element;phe.helpText.hideHelptext=function(){var a=phe.helpText.helptextContainer;a.target=null;a.style.display="none";};phe.helpText.showHelptext=function(b,e){var f=phe.helpText.helptextContainer;if(f.target!=b){f.target=b;var d=e||b.getAttribute("helptext");phe.helpText.helptextMessage.innerHTML=d;bb.html.setStyle(f,"opacity","0.0");f.style.display="";if(bb.browser.webkit&&bb.browser.version>500){if(f){bb.html.position(f,b,"end-before");f.style.top=absa.util.getOffset(b).top+"px";}}else{bb.html.position(f,b,"end-before");}if(bb.html.hasClass(b,"ap-icon-info")){phe.helpText.helptextContainer.className="ap-helpText-baloon ap-helpText-baloon-icon-info";}else{phe.helpText.helptextContainer.className="ap-helpText-baloon";}var c=bb.html.getBoxObject(f);var a=bb.html.getBoxObject(f.target);if(c.left<a.left){bb.html.addClass(phe.helpText.helptextContainer,"ap-helpText-right");}if(c.top<a.top){bb.html.addClass(phe.helpText.helptextContainer,"ap-helpText-bottom");}if(bb.browser.ie&&bb.browser.version<=6){bb.html.position(phe.helpText.mask,phe.helpText.borderFrame,"overlap");phe.helpText.mask.style.width=phe.helpText.borderFrame.offsetWidth+"px";phe.helpText.mask.style.height=phe.helpText.borderFrame.offsetHeight+"px";}bb.smil.animate(f,{attributeName:"opacity",from:"0.0",to:"1.0",dur:"300ms",fill:"freeze"});}};phe.helpText.helptextContainer=document.createElement("div");phe.helpText.helptextContainer.style.display="none";phe.helpText.helptextContainer.className="ap-helpText-baloon";document.body.appendChild(phe.helpText.helptextContainer);if(bb.browser.ie&&bb.browser.version<=6){var mask=document.createElement("iframe");mask.style.position="absolute";mask.frameBorder="0";mask.scrolling="no";bb.html.addClass(mask,"ap-helpText-ie6-mask");phe.helpText.helptextContainer.appendChild(mask);phe.helpText.mask=mask;}var borderFrame=document.createElement("div");borderFrame.className="ap-helpText-frame";phe.helpText.helptextContainer.appendChild(borderFrame);phe.helpText.borderFrame=borderFrame;phe.helpText.helptextCloseButton=document.createElement("div");phe.helpText.helptextCloseButton.className="ap-helpText-close-button";borderFrame.appendChild(phe.helpText.helptextCloseButton);phe.helpText.helptextMessage=document.createElement("div");borderFrame.appendChild(phe.helpText.helptextMessage);phe.helpText.baloonPin=document.createElement("div");phe.helpText.helptextContainer.appendChild(phe.helpText.baloonPin);phe.helpText.baloonPin.className="ap-helpText-pin";bb.html.addEventListener(phe.helpText.helptextCloseButton,"mouseup",function(){phe.helpText.hideHelptext();});</script><script type="text/javascript">phe.keyboard=new phe.Element;phe.keyBoardInputs=new phe.Element;phe.keyBoardContainer=new phe.Element;phe.keyboard.handlers={};phe.keyboard.handlers.blur=function(){};phe.keyboard.handlers.focus=function(){};phe.keyboard.focuskeyboard=false;phe.keyboard.initialize=function(c){var d=bb.selector.queryAll(c,".ui-keyboard");for(var a=0;a<d.length;a++){var e=bb.selector.queryAll(d[a],".ui-keyboard-inputs input");if(!bb.selector.query(d[a],".ui-keyboard-input-selected")){bb.html.addClass(e[0],"ui-keyboard-input-selected");}bb.html.disableUserSelect(bb.selector.query(d[a],".ui-keyboard-keyboardContainer"));for(var b=0;b<e.length;b++){bb.html.addEventListener(e[b],"focus",function(){if(!bb.html.hasClass(this,"ui-keyboard-input-selected")){phe.keyboard.focuskeyboard=true;var f=bb.selector.query(bb.selector.queryAncestor(this,".ui-keyboard-inputs",true),".ui-keyboard-input-selected");if(f){bb.html.removeClass(f,"ui-keyboard-input-selected");}bb.html.addClass(this,"ui-keyboard-input-selected");}});bb.html.addEventListener(e[b],"blur",function(f){if(bb.html.hasClass(this,"ui-keyboard-input-selected")){phe.keyboard.focuskeyboard=false;}});bb.html.addEventListener(e[b],"mouseout",function(f){if(bb.html.hasClass(this,"ui-keyboard-input-selected")){phe.helpText.hideHelptext();}});}}};</script><script type="text/javascript">phe.keypad=new phe.Element;phe.keyPadInputs=new phe.Element;phe.keyPadContainer=new phe.Element;phe.keypad.handlers={};phe.keypad.handlers.blur=function(){};phe.keypad.handlers.focus=function(){};phe.keypad.focusKeypad=false;phe.keypad.initialize=function(c){var d=bb.selector.queryAll(c,".ui-keypad");for(var a=0;a<d.length;a++){var e=bb.selector.queryAll(d[a],".ui-keypad-inputs input");if(!bb.selector.query(d[a],".ui-keypad-input-selected")){bb.html.addClass(e[0],"ui-keypad-input-selected");}bb.html.disableUserSelect(bb.selector.query(d[a],".ui-keypad-padContainer"));for(var b=0;b<e.length;b++){bb.html.addEventListener(e[b],"focus",function(f){if(!bb.html.hasClass(this,"ui-keypad-input-selected")){phe.keypad.focusKeypad=true;var g=bb.selector.query(bb.selector.queryAncestor(this,".ui-keypad-inputs",true),".ui-keypad-input-selected");if(g){bb.html.removeClass(g,"ui-keypad-input-selected");}bb.html.addClass(this,"ui-keypad-input-selected");}});bb.html.addEventListener(e[b],"blur",function(f){if(bb.html.hasClass(this,"ui-keypad-input-selected")){phe.keypad.focusKeypad=false;}});bb.html.addEventListener(e[b],"mouseout",function(f){if(bb.html.hasClass(this,"ui-keypad-input-selected")){phe.helpText.hideHelptext();}});}}};</script><script type="text/javascript">var phe=window.phe||{};phe.label=new phe.Element;</script><script type="text/javascript">var phe=window.phe||{};phe.media=new phe.Element;phe.media.STATUS=-999;phe.media.initialize=function(c){var d=bb.selector.queryAll(c,".ui-media");if(d!=null){for(var a=0;a<d.length;a++){var b=d[a];if(bb.html.hasClass(b,"ui--image-hover")){phe.media.setAttribute(b,"onmouseover","phe.media._showHideHoverImage(this,true)");phe.media.setAttribute(b,"onmouseout","phe.media._showHideHoverImage(this,false)");}}}};phe.media.setAttribute=function(a,b,c){if(a!=null){phe.Element.prototype.setAttribute.call(this,a,b,c);}};phe.media.getAttribute=function(b,c){if(b!=null){var a=phe.Element.prototype.getAttribute.call(this,b,c);if(a==null){a=phe.Element.prototype.getAttribute.call(this,b,"data-"+c);}return a;}else{return null;}};phe.media._showHideHoverImage=function(d,b){var c=phe.media.getAttribute(d,"src");var a=phe.media.getAttribute(d,"srcHover");if(c&&a){phe.media.setAttribute(d,"srcHover",c);phe.media.setAttribute(d,"src",a);}if(b){bb.html.addClass(d,"ui--image-hover-showing");}else{bb.html.removeClass(d,"ui--image-hover-showing");}};</script><script type="text/javascript">var phe=window.phe||{};phe.link=new phe.Element;</script><script type="text/javascript">var phe=window.phe||{};phe.message=new phe.Element;phe.message.setMessage=function(b,a){var c=bb.selector.query(b,".ui-message-body");c.innerHTML=a;};phe.message.setTitle=function(c,a){var b=bb.selector.query(c,".ui-message-title");b.innerHTML=a;};phe.message.setTimeStamp=function(b,c){if(!arguments.length){c=phe.message.createTimeStamp();}var a=bb.selector.query(b,".ui-message-timeStamp");a.innerHTML=phe.message.createTimeStamp();};phe.message.createTimeStamp=function(){var b=function(c){return new Array(3-String(c).length).join("0")+c;},a=new Date;return a.getFullYear()+"-"+b(a.getMonth()+1)+"-"+b(a.getDate())+" "+b(a.getHours())+":"+b(a.getMinutes())+":"+b(a.getSeconds());};phe.message.createElement=function(b){var a=document.createElement("div");a.innerHTML='<div class="ui-message ui-message-'+(b||"error")+'" tabindex="0">												<div class="ui-message-timeStamp">'+phe.message.createTimeStamp()+'</div>												<div class="ui-message--icon"></div>													<div class="ui-message-content">														<div class="ui-message-title"></div>														<div class="ui-message-body"></div>													</div>												</div>												<div class="clear-both"></div>											</div>';return a.firstChild;};</script><script type="text/javascript">var phe=window.phe||{};phe.modal=new phe.Element;phe.modalBody=new phe.Element;phe.modalFooter=new phe.Element;phe.modal.showModal=function(c,f,b,e,a,h,g){if(this.modalCover){this.hideModal();}if(!f){return;}phe.modal.elementTriggeringModal=document.activeElement?document.activeElement:null;this.modalParentNode=b||document.body;this.bFullScreen=false;if(this.modalParentNode==document.body){this.bFullScreen=true;}if(bb.browser.ie&&bb.browser.version<=6){this.modalCover=bb.html.createElementFromString('<div class="ui-modalWindow"><iframe class="ui-modal-iframe" /></div>');}else{this.modalCover=bb.html.createElementFromString('<div class="ui-modalWindow"></div>');}if(this.bFullScreen){this.modalCover.style.position="fixed";}this.modalParentNode.appendChild(this.modalCover);bb.html.setStyle(this.modalCover,"opacity",c?c:0);if(e){var d=f.cloneNode(false);d.innerHTML=f.innerHTML;}else{var d=f;}d.style.display="";this.modalContent=bb.html.createElementFromString('<div class="ui-modal-content" clone="true"></div>');if(this.bFullScreen){this.modalContent.style.position="fixed";}this.modalContent.appendChild(d);this.modalParentNode.appendChild(this.modalContent);if(g){bb.html.addClass(this.modalContent,g);}this.updatePosition(a,h);this.modalContent.setAttribute("tabIndex","0");this.modalContent.setAttribute("role","alertdialog");this.modalContent.setAttribute("aria-labelledby","modal-header-title");this.modalContent.focus();if(e){absa.initializeNewContent(this.modalContent);}if(absa.touch.enabled&&absa.touch.android){bb.html.addClass(this.modalContent,"ap-common-defaultTapHighlight");bb.html.addClass(document.body,"ap-common-noTapHighlight");}window.focus();};phe.modal.updatePosition=function(a,e){var b=bb.html.getBoxObject(this.modalContent,"border");if(a&&parseFloat(a)>0){if(this.modalContent.style!=null){this.modalContent.style.left=parseFloat(a)+"px";}}else{if(this.modalContent.style!=null){this.modalContent.style.marginLeft="-"+b.width/2+"px";}}if(this.modalContent!=null){if(e&&parseFloat(e)>0){if(this.modalContent.style!=null){this.modalContent.style.top=parseFloat(e)+"px";}}else{if(this.modalContent.style!=null){this.modalContent.style.marginTop="-"+b.height/2+"px";}}}if((absa.touch.enabled&&absa.touch.android)||(bb.browser.ie&&bb.browser.version<=6)){if(this.bFullScreen){this.modalCover_IE6_center=function(){var h=phe.modal.modalCover;if(h&&h.parentNode.nodeType==1){if(h.style!=null){h.style.position="absolute";var f=document.documentElement;var g=bb.html.getBoxObject(h,"border");h.style.height=f.clientHeight+"px";h.style.width=f.clientWidth+"px";h.style.top=f.scrollTop+"px";}}else{phe.modal.modalCover=null;}};this.modalCover_IE6_center();bb.document.addEventListener("resize",this.modalCover_IE6_center,false);bb.document.addEventListener("scroll",this.modalCover_IE6_center,false);if(phe.modal.modalContent.style!=null){phe.modal.modalContent.style.marginTop="";phe.modal.modalContent.style.marginLeft="";}this.modalContent_IE6_center=function(){var h=phe.modal.modalContent;if(h&&h.parentNode.nodeType==1){if(h.style!=null){h.style.position="absolute";var f=document.documentElement;var g=bb.html.getBoxObject(h,"border");if(a&&parseFloat(a)>0){h.style.left=(f.scrollLeft+parseFloat(a))+"px";}else{h.style.left=(f.scrollLeft+(f.clientWidth/2)-(g.width/2))+"px";}if(e&&parseFloat(e)>0){h.style.top=(f.scrollTop+parseFloat(e))+"px";}else{h.style.top=(f.scrollTop+(f.clientHeight/2)-(g.height/2))+"px";}}}else{phe.modal.modalContent=null;}};this.modalContent_IE6_center();bb.document.addEventListener("resize",this.modalContent_IE6_center,false);bb.document.addEventListener("scroll",this.modalContent_IE6_center,false);}else{var d=phe.modal.modalCover;var c=bb.html.getBoxObject(d.parentNode,"border");if(this.modalCover.style!=null){this.modalCover.style.height=c.height+"px";this.modalCover.style.width=c.width+"px";}}}if(window.addEventListener){window.addEventListener("keydown",phe.modal.keepFocus,false);}else{if(window.attachEvent){document.attachEvent("onkeydown",phe.modal.keepFocus);}else{window.onkeydown=phe.modal.keepFocus;}}};phe.modal.keepFocus=function(c){var c=c||window.event;var e=c.target||c.srcElement;if(e!=null){var a=bb.selector.queryAncestor(e,".ui-modal-content");if(a==null){var b=".ui-modal-content";var d=bb.selector.query(document.body,b);if(d!=null){d.focus();bb.html.handlePreventDefault(c);}}}};phe.modal.hideModal=function(a){if(this.modalParentNode){if(this.modalContent){this.modalParentNode.removeChild(this.modalContent);}}if(this.modalParentNode){if(this.modalCover){this.modalParentNode.removeChild(this.modalCover);}}this.modalCover=null;this.modalContent=null;if((absa.touch.enabled&&absa.touch.android)||(this.bFullScreen&&bb.browser.ie&&bb.browser.version==6)){bb.document.removeEventListener("resize",this.modalCover_IE6_center,false);bb.document.removeEventListener("scroll",this.modalCover_IE6_center,false);bb.document.removeEventListener("resize",this.modalContent_IE6_center,false);bb.document.removeEventListener("scroll",this.modalContent_IE6_center,false);}if(window.removeEventListener){window.removeEventListener("keydown",phe.modal.keepFocus,false);}else{if(window.detachEvent){document.detachEvent("onkeydown",phe.modal.keepFocus);}else{window.onkeydown={};}}if(this.basicElement){bb.destruct(this.basicElement);this.basicElement=null;}if(phe.modal.elementTriggeringModal&&phe.modal.elementTriggeringModal.offsetHeight>0){phe.modal.elementTriggeringModal.focus();}if(absa.touch.enabled&&absa.touch.android){bb.html.removeClass(document.body,"ap-common-noTapHighlight");}if(a){a.apply();}};phe.modal.setAttribute=function(a,c,d){if(c=="title"){var b=bb.selector.query(a,".ui-modalHeader-title");b.innerText=b.textContent=d||"";}else{phe.Element.setAttribute.call(this,a,c,d);}};phe.modal.getAttribute=function(a,c){if(c=="title"){var b=bb.selector.query(a,".ui-modalHeader-title");return b.textContent||b.innerText;}else{return phe.Element.getAttribute.call(this,a,c);}};phe.modal.onCloseModalButtonClick=function(b){var a=bb.selector.queryAncestor(b,".ui-modal");var c=bb.selector.query(a,".ui-modalBody");if(!c._hasIOError){a._onClose=a._onClose||new Function(a.getAttribute("onclose"));if(!bb.html.hasClass(c.firstChild,"ap-loading-message")){if(typeof a._onClose=="function"){a._onClose.call(this,a);}}}phe.modal.hideModal();};</script><script type="text/javascript">var phe=window.phe||{};phe.radioGroup=new phe.Element;phe.radioItem=new phe.Element;phe.radioGroup.getAttribute=function(a,b){if(b=="onchange"){return phe.Element.prototype.getAttribute.call(this,a,"onselect");}else{return phe.Element.prototype.getAttribute.call(this,a,b);}};phe.radioGroup.setAttribute=function(a,b,c){if(b=="onchange"){phe.Element.prototype.setAttribute.call(this,a,"onselect",c);}else{phe.Element.prototype.setAttribute.call(this,a,b,c);}};phe.radioGroup.getValue=function(a){return phe.radioGroup.getAttribute(a,"value");};phe.radioGroup.setValue=function(c,e){var a=bb.selector.queryAll(c,".ui-radioItem--input");for(var b=0;b<a.length;b++){a[b].checked=false;var d=a[b].getAttribute("value");if(d==e){a[b].checked=true;phe.radioGroup.setAttribute(c,"value",e);break;}}};phe.radioGroup.getRadioItems=function(b){var a=bb.selector.queryAll(b,".ui-radioItem--input");return a;};phe.radioGroup.isAnyRadioItemsChecked=function(c){var a=bb.selector.queryAll(c,".ui-radioItem--input");var d=false;for(var b=0;b<a.length;b++){if(a[b].checked|a[b].defaultChecked){d=true;}}return d;};phe.radioItem.getAttribute=function(a,b){return phe.Element.prototype.getAttribute.call(this,a,b);};phe.radioItem.setAttribute=function(a,b,c){if(b=="disabled"){if(c=="true"){phe.Element.prototype.setAttribute.call(this,a,"disabled",c);}else{a.removeAttribute("disabled");}}else{if(b=="checked"){if(c=="true"){phe.Element.prototype.setAttribute.call(this,a,"checked",c);}else{a.removeAttribute("checked");}}else{phe.Element.prototype.setAttribute.call(this,a,b,c);}}};</script><script type="text/javascript">var phe=window.phe||{};phe.searchBox=new phe.Element;phe.searchBox.getValue=function(a){return phe.Element.prototype.getAttribute.call(this,a,"value");};phe.searchBox.setValue=function(a,c){var b=bb.selector.query(a,".ui-searchBox--input");b.value=c;phe.Element.prototype.setAttribute.call(this,a,"value",c);};phe.searchBox.enableDisable=function(b){var a=b.getAttribute("disabled");var c=bb.selector.query(b,".ui-searchBox--button");var d=bb.selector.query(b,".ui-searchBox--input");if(a){b.removeAttribute("disabled");bb.html.removeClass(c,"ui-searchBox--button_disabled");c.removeAttribute("disabled");d.removeAttribute("disabled");}else{b.setAttribute("disabled","true");bb.html.addClass(c,"ui-searchBox--button_disabled");c.setAttribute("disabled","true");d.setAttribute("disabled","true");}};phe.searchBox.clearField=function(a){if(a.tagName.toLowerCase()=="div"){a.getElementsByTagName("input").value="";}else{if(a.tagName.toLowerCase()=="input"){a.value="";}else{if(a.tagName.toLowerCase()=="button"){a.previousSibling.value="";}}}};phe.searchBox.doClickInField=function(c){if(c.value==c.parentNode.getAttribute("defaultMsg")){phe.searchBox.clearField(c);c.focus();}else{var a=bb.selector.query(c.parentNode,".ui-searchBox--button_reset");var b=bb.selector.query(c.parentNode,".ui-searchBox--button_tick");if(a){bb.html.removeClass(a,"ui-searchBox--button_reset");}else{if(b){bb.html.removeClass(b,"ui-searchBox--button_tick");}}}};phe.searchBox.doSearchFunctionCall=function(k){var g=bb.selector.query(k,".ui-searchBox--input");var e=bb.selector.query(k,".ui-searchBox--button");var f=k.getAttribute("forceSearch");if(bb.html.hasClass(e,"ui-searchBox--button_reset")){phe.searchBox.resetContainer(k);}else{var j;var a;if(k.getAttribute("disabled")=="true"){}else{phe.helpText.hideHelptext();j=g.value;a=k.getAttribute("defaultMsg");if(j!=a||f=="true"){bb.html.addClass(e,"ui-searchBox--button_reset");k.setAttribute("value",j);var d=k.getAttribute("onsearch");if(d!=null){if(bb.html.hasClass(g,"ui-incorrect-value")&&!(f=="true")){}else{var c=absa.util.attributeToFunction(k,"onsearch");var b=bb.selector.queryAncestor(k,".p-gadget");if(!b){var i=bb.selector.queryAncestor(k,".ui-form");var h=bb.selector.query(i,"."+k.getAttribute("target"));}else{var h=bb.selector.query(b,"."+k.getAttribute("target"));}if(h){h._search=true;}c.call(k);}}if(j==""){phe.searchBox.resetContainer(k);}}else{phe.searchBox.resetContainer(k);}}}g.focus();g.select();};phe.searchBox.resetContainer=function(j){var g=bb.selector.query(j,".ui-searchBox--input");var f=bb.selector.query(j,".ui-searchBox--button");var i=g.value;var b=j.getAttribute("defaultMsg");if(absa.touch.enabled){g.value="";}else{g.value=b;}bb.html.removeClass(f,"ui-searchBox--button_reset");var a=j.getAttribute("dataFile");if(a){var c=j.getAttribute("target");var d=bb.selector.queryAncestor(j,".ui-tabBody-selected");if(!d){d=bb.selector.queryAncestor(j,".ui-form");}var h=bb.selector.query(d,"."+c);if(h!=null){h.setAttribute("dataFile",a);h._search=true;phe.table.reload(h);}var e=absa.util.attributeToFunction(j,"onreset");if(e){e.call(j);}}};phe.searchBox.resetSearchBox=function(c){var d=bb.selector.query(c,".ui-searchBox--input");var a=bb.selector.query(c,".ui-searchBox--button");var e=d.value;var b=c.getAttribute("defaultMsg");if(e!=b){d.value=b;bb.html.removeClass(a,"ui-searchBox--button_reset");}};phe.searchBox.onblur=function(b){var a=bb.selector.queryAncestor(b,".ui-searchBox");if(b.value==""){phe.searchBox.resetSearchBox(a);}};phe.searchBox.selectOrClear=function(oInput,sAction){if(sAction=="clear"){oInput.value="";}else{if(sAction=="select"){oInput.select();}}var oSearchContainer=bb.selector.queryAncestor(oInput,".ap-searchBox-container");var oButton=bb.selector.query(oSearchContainer,"button");var sProxyUrl=oButton.getAttribute("proxyUrl");var sTableClass=oButton.getAttribute("tableClass");var bDisableReload=oButton.getAttribute("disableReload")||false;var defaultOnClick=oButton.getAttribute("defaultOnClick");if(bb.html.hasClass(oButton,"ap-searchBox-button-reset")){oButton.setAttribute("tooltip","Click to search");oButton.onclick=function(){phe.searchBox(oButton,sProxyUrl,sTableClass,bDisableReload);eval(defaultOnClick);};bb.html.replaceClass(oButton,"ap-searchBox-button-reset","ap-icon ap-searchBox-button");}};</script><script type="text/javascript">var phe=window.phe||{};phe.slider=new phe.Element;var oGlobalSlider;phe.slider.getValue=function(a){if(phe.Element.prototype.getAttribute.call(this,a,"value")!=null){return phe.Element.prototype.getAttribute.call(this,a,"value");}else{return phe.Element.prototype.getAttribute.call(this,a,"min");}};phe.slider.setAttribute=function(a,c,e){if(c=="disabled"){var d=bb.selector.query(a,".ui-slider--input")||bb.selector.query(a,".ui-slider--input_disabled");var b=bb.selector.query(a,".ui-slider-grippy")||bb.selector.query(a,".ui-slider-grippy_disabled");if(e=="true"){bb.html.replaceClass(d,"ui-slider--input","ui-slider--input_disabled");bb.html.replaceClass(b,"ui-slider-grippy","ui-slider-grippy_disabled");d.disabled=true;}else{bb.html.replaceClass(d,"ui-slider--input_disabled","ui-slider--input");bb.html.replaceClass(b,"ui-slider-grippy_disabled","ui-slider-grippy");d.disabled=false;}}else{if(c=="max"){phe.Element.prototype.setAttribute.call(this,a,c,e);a._max=parseFloat(e);a._valueDelta=a._max-a._min;a._valueRatio=a._valueDelta/(a._rail.offsetWidth||parseInt(bb.html.getStyle(a._rail,"width"))||200);}else{phe.Element.prototype.setAttribute.call(this,a,c,e);}}};phe.slider.setValue=function(b,e){var d=bb.selector.query(b,".ui-slider--input");d.value=e;phe.Element.prototype.setAttribute.call(this,b,"value",e);var c=bb.selector.query(b,".ui-slider-grippy");if(b.getAttribute("type")!="text"){var a=phe.slider.valueToPosition(b,e);phe.slider.slide(b,a,true);}};phe.slider.getMouseX=function(a){return a.pageX||(a.clientX+document.documentElement.scrollLeft);};phe.slider.valueToPosition=function(b,c){c=(c>b._max)?b._max:c;c=(c<b._min)?b._min:c;var a=(c-b._valueOffset)/b._valueRatio;return parseInt(a);};phe.slider.positionToValue=function(b,a){var c=a*b._valueRatio+b._valueOffset;return Math.ceil(c);};phe.slider.outputValue=function(b,d){var c=d._input.value=phe.slider.positionToValue(b,d._position);d._input.value=c;d.setAttribute("aria-valuenow",c);var a=bb.selector.queryAncestor(b,".ui-slider");a.setAttribute("value",c);bb.html.fireEvent(d._input,"change");};phe.slider.focus=function(a,b){this._activeSlider=a;this._activeGrippy=b;bb.html.addClass(b,"pressed");};phe.slider.unfocus=function(){if(phe.slider._activeGrippy){if(phe.slider._activeGrippy=="both"){var a=phe.slider._activeSlider;a._minRange=a._originalMinRange;bb.html.removeClass(a._grippies[0],"pressed");bb.html.removeClass(a._grippies[1],"pressed");}else{bb.html.removeClass(phe.slider._activeGrippy,"pressed");}phe.slider._activeGrippy=null;phe.slider._activeSlider=null;}};phe.slider.slide=function(l,i,a){if(isNaN(i)){return;}var e=i;var c=l;var h=bb.selector.query(c,".ui-slider-grippy");var p=c._rail.offsetWidth;var o=phe.slider.positionToValue(c,e);if(typeof(o)=="undefined"){return;}else{if(isNaN(o)){return;}}e=phe.slider.valueToPosition(c,parseFloat(o));var q=0;var g=p;var f=c._grippies;var k=f.length;var m=phe.slider.valueToPosition(c,c._minRange);if(k>1){if(h==f[0]){g=f[1]._position-m;g=(g<0)?0:g;}else{q=f[0]._position+m;q=(q>p)?p:q;}}e=(e<q)?q:e;e=(e>g)?g:e;h.style.left=e-5+"px";h._position=e;var d=h.offsetWidth-(e-h.offsetLeft);var j=e-h.offsetLeft;var n=(k>1)?(f[0]._position+d):0;var b=((f[k-1]._position-n-j));b=(b<0)?0:b;if(!a){phe.slider.outputValue(c,h);}};phe.slider.initializeBehavior=function(b){b._inputs=bb.selector.queryAll(b,".ui-slider--input");var k=b._inputs.length;if(k==0){return;}b._rail=bb.selector.query(b,".ui-slider-rail");b._min=parseFloat(b.getAttribute("min")||0);b._max=parseFloat(b.getAttribute("max")||b._rail.offsetWidth);b._minRange=parseFloat(b.getAttribute("minRange")||0);b._precision=parseInt(b.getAttribute("precision")||0);b._step=parseFloat(b.getAttribute("keyStep")||1);b._valueOffset=b._min-0;b._valueDelta=b._max-b._min;b._valueRatio=b._valueDelta/(b._rail.offsetWidth||parseInt(bb.html.getStyle(b._rail,"width"))||200);b._grippies=bb.selector.queryAll(b,".ui-slider-grippy");var f=b._grippies.length;if(f!=k){return;}for(var e=0;e<f;e++){var a=function(n){n=n||window.event;var l=n.srcElement||n.target;var p=l._grippy;var i=parseInt(p._slider.getAttribute("max"),10);var m=parseInt(p._slider.getAttribute("min"),10);var o=parseInt(l.value,10);if(o>i){l.value=i;}else{if(o<m){l.value=m;}}};var d=b._grippies[e];var h=b._inputs[e];bb.html.addEventListener(h,"blur",a);d._input=h;d._slider=b;h._grippy=d;d._position=phe.slider.valueToPosition(b,parseFloat(h.value)||0);}phe.slider._activeSlider=b;b._grippyCenter=0;for(var e=0;e<f;e++){phe.slider._activeGrippy=b._grippies[e];phe.slider.slide(b,phe.slider._activeGrippy._position,true);var g=bb.selector.query(b,".ui-slider--input");g.onchange=phe.slider.fireOnChangeEvent;g.onkeyup=phe.slider.fireOnChangeEvent;}b._grippyCenter=b._grippies[0]._position-b._grippies[0].offsetLeft;phe.slider._activeGrippy=null;phe.slider._activeSlider=null;var j=bb.selector.queryAncestor(b,"form",document.body);if(j){var c=function(){allInputs=bb.selector.queryAll(j,".ui-slider--input");for(var m=0;m<allInputs.length;m++){var l=allInputs[m];phe.slider._activeGrippy=l._grippy;phe.slider._activeSlider=phe.slider._activeGrippy._slider;phe.slider._activeGrippy._position=phe.slider.valueToPosition(phe.slider._activeSlider,parseFloat(l.defaultValue));phe.slider.slide(b,phe.slider._activeGrippy._position);phe.slider._activeGrippy=null;phe.slider._activeSlider=null;}};bb.html.addEventListener(j,"reset",c);}if(absa.touch.enabled){absa.touch.register(h._grippy);}};phe.slider.initialize=function(c){var e=bb.selector.queryAll(c,".ui-slider");for(var b=0;b<e.length;b++){phe.slider.initializeBehavior(e[b]);}if(absa.touch.enabled){var d=bb.selector.queryAll(c,".ui-slider--input[bbf_x_type_number]");for(var a=0;a<d.length;a++){if(absa.touch.iPad){d[a].setAttribute("pattern","[0-9]*");}else{if(absa.touch.android){d[a].setAttribute("type","number");}}}}};phe.slider.fireOnChangeEvent=function(){var c=this;var b=bb.selector.queryAncestor(c,".ui-slider");var a=absa.util.attributeToFunction(b,"xonchange");if(parseFloat(c.value)>parseFloat(b.getAttribute("max"))){c.value=b.getAttribute("max");phe.slider.setAttribute(b,"value",c.value);}if(c.value!=""){phe.slider.setAttribute(b,"value",c.value);}else{phe.slider.setAttribute(b,"value",b.getAttribute("min"));}if(a){a.call(b);}};bb.html.addEventListener(document,"mousemove",function(c){c=c||window.event;if(phe.slider._activeGrippy){var b=phe.slider.getMouseX(c);var a=b-phe.slider._activeGrippy._offsetX;phe.slider.slide(phe.slider._activeSlider,a);bb.html.handlePreventDefault(c);}});phe.slider.fireOnBlur=function(a){var b=absa.util.attributeToFunction(a,"xonblur");if(b){b.call(a);}};bb.html.addEventListener(document,"mouseup",function(){phe.slider.unfocus();if(oGlobalSlider){phe.slider.fireOnBlur(oGlobalSlider);oGlobalSlider=null;}});</script><script type="text/javascript">var phe=window.phe||{};phe.suggestBox=new phe.FormElement;phe.suggestBox.getAttribute=function(a,b){switch(b){case"onchange":return phe.FormElement.prototype.getAttribute.call(this,a,"onsetvalue");break;case"multipleRequest":return phe.FormElement.prototype.getAttribute.call(this,a,"dataFileSuggestMultiRequest");break;default:return phe.FormElement.prototype.getAttribute.call(this,a,b);break;}};phe.suggestBox.setAttribute=function(a,b,c){switch(b){case"onchange":phe.FormElement.prototype.setAttribute.call(this,a,"onsetvalue",c);break;case"multipleRequest":phe.FormElement.prototype.setAttribute.call(this,a,"dataFileSuggestMultiRequest",c);break;case"readOnly":if(c==""){a.removeAttribute("readonly");}else{phe.FormElement.prototype.setAttribute.call(this,a,"readOnly",c);}break;default:phe.FormElement.prototype.setAttribute.call(this,a,b,c);break;}};phe.suggestBox.getValue=function(a){return phe.FormElement.prototype.getAttribute.call(this,a,"value");};phe.suggestBox.setValue=function(a,b){phe.FormElement.prototype.setAttribute.call(this,a,"value",b);};</script><script type="text/javascript">var phe=window.phe||{};phe.tabBox=new phe.Element;phe.tabBodies=new phe.Element;phe.tabBody=new phe.Element;phe.tabHeads=new phe.Element;phe.tabBox.initialize=function(o){var k=bb.selector.queryAll(o,".ui-tabBox");for(var h=0,f=k.length;h<k.length;h++){var a=k[h];var c=bb.selector.query(a,".ui-tabHeads").children;var n=a.getAttribute("disableFirstTabLoad")?true:false;var l=a.getAttribute("selectedIndex")*1;if(!n){phe.tabBox.selectTab(c[isNaN(l)?0:l],true);}for(var g=0,m=c.length;g<m;g++){if(bb.browser.ie){bb.html.disableUserSelect(c[g]);}bb.html.addEventListener(c[g],"keydown",function(j){var r=bb.selector.queryAncestor(this,".ui-tabBox");var i=bb.selector.query(r,".ui-tabHeads").children;var q=phe.tabBox.getFocusTabIndex(i);phe.tabBox.validateKeyPressArrow(j,function(s){if(s=="up"||s=="left"){var t=q;if(t-1>=0){while(bb.html.getStyle(i[t-1],"display")=="none"&&t-1>=0){t-=1;}i[t-1].focus();}}else{if(s=="down"||s=="right"){var t=q;if(t<i.length-1){while(bb.html.getStyle(i[t+1],"display")=="none"&&t+1<i.length-1){t+=1;}i[t+1].focus();}}}});absa.util.validateKeyPressShiftTab(j,function(){var s=phe.tabBox.getFocusableElementBeforeTabBox(r);if(s){s.focus();}});absa.util.validateKeyPressTab(j,function(){var s=phe.tabBox.getFocusableElementAfterTabBox(r);if(s){s.focus();}});});}var p=bb.selector.query(a,".ui-tabHeads-start");if(p){bb.html.addEventListener(p,"focus",function(q){var r=bb.selector.queryAncestor(this,".ui-tabBox");var i=phe.tabBox.getCurrentTabIndex(r);var j=bb.selector.queryAll(r,".ui-tabHead");if(i>-1){j[i].focus();}bb.html.handlePreventDefault(q);});}var e=bb.selector.query(a,".ui-tabHeads-end");if(e){bb.html.addEventListener(e,"focus",function(q){var r=bb.selector.queryAncestor(this,".ui-tabBox");var i=phe.tabBox.getCurrentTabIndex(r);var j=bb.selector.queryAll(r,".ui-tabHead");if(i>-1){j[i].focus();}bb.html.handlePreventDefault(q);});}var d=bb.selector.query(a,".ui-tabBox-tab-finish");if(d){bb.html.addEventListener(d,"focus",function(j){var i=phe.tabBox.getFocusableElementAfterTabBox(a);if(i){i.focus();}bb.html.handlePreventDefault(j);});}var b=bb.selector.query(a,".ui-tabBox-body-end");if(b){bb.html.addEventListener(b,"focus",function(q){var r=bb.selector.queryAncestor(this,".ui-tabBox");var i=phe.tabBox.getCurrentTabIndex(r);var j=bb.selector.queryAll(r,".ui-tabHead");if(i>-1){j[i].focus();}bb.html.handlePreventDefault(q);});}}};phe.tabBox.selectTab=function(a,d,b){if(a!=null){if(bb.html.hasClass(a,"ui-tab-disabled")){return false;}var e=a.parentNode;var g=bb.selector.query(e,".ui-tab-selected");var j=bb.selector.queryAncestor(e,".p-gadget-content");if(j){bb.html.removeClass(j,"ui-showMeHow");}if(g&&g===a&&d){return;}var c=bb.selector.queryAncestor(e,".ui-tabBox");var f=bb.selector.query(c,".ui-tabBodies");var i=phe.tabBox.getCurrentTabBody(f);var h=function(){if(g){bb.html.removeClass(g,"ui-tab-selected");}if(i){bb.html.removeClass(i,"ui-tabBody-selected");i.setAttribute("aria-hidden","true");}var k=phe.tabBox.getTabBodyBelongingToTabHead(e,a,c,f);bb.html.addClass(a,"ui-tab-selected");if(k){bb.html.addClass(k,"ui-tabBody-selected");if(!d){if(k.offsetWidth>0){k.focus();}k.setAttribute("aria-hidden","false");absa.lazyLoadNode(k,true,function(){if(b){b(k);}phe.tabBox.contentLoaded();});}}return k;};if(absa.unconfirmedChanges&&i){return absa.unconfirmedChanges.cancelNavigation(i,h);}else{return h();}}};phe.tabBox.selectTabByIndex=function(a,c){var b=bb.selector.query(a,".ui-tabHeads");return phe.tabBox.selectTab(b.childNodes[c]);};phe.tabBox.getCurrentTabBody=function(c){var d=bb.selector.query(c,".ui-tabBodies");var e=d.childNodes;for(var b=0,a=e.length;b<a;b++){if(bb.html.hasClass(e[b],"ui-tabBody-selected")){return e[b];}}};phe.tabBox.getCurrentTabIndex=function(c){var a=bb.selector.queryAll(c,".ui-tabHead");for(var b=0;b<a.length;b++){if(bb.html.hasClass(a[b],"ui-tab-selected")){return b;}}return -1;};phe.tabBox.getFocusTabIndex=function(a){var c=document.activeElement;for(var b=0;b<a.length;b++){if(a[b]==c){return b;}}return -1;};phe.tabBox.reloadTab=function(a){var b=bb.selector.queryAncestor(a,".ui-tabBody-selected");absa.lazyLoadNode(b,true);};phe.tabBox.contentLoaded=function(){gadgets.pubsub.publish("tabBox","tabContentLazyLoaded");};phe.tabBox.validateKeyPressArrow=function(c,a){if(c){var b;if(c.keyIdentifier){b=c.keyIdentifier.toLowerCase();}else{if(window.event){b=c.keyCode;}else{if(c.which){b=c.which;}}}if(c.shiftKey==false){if(c.keyCode=="37"||b=="37"||b=="u+0037"){a("left");bb.html.handlePreventDefault(c);}else{if(c.keyCode=="38"||b=="38"||b=="u+0038"){a("up");bb.html.handlePreventDefault(c);}else{if(c.keyCode=="39"||b=="39"||b=="u+0039"){a("right");bb.html.handlePreventDefault(c);}else{if(c.keyCode=="40"||b=="40"||b=="u+0040"){a("down");bb.html.handlePreventDefault(c);}}}}}}};phe.tabBox.getTabBodyBelongingToTabHead=function(a,f,c,d){var e=phe.getElementPosition(a,f);var b;if(e==-1){b=null;}else{b=phe.getNthElement(d,e);}return b;};phe.tabBox.getFocusableElementBeforeTabBox=function(a){var d=bb.selector.queryAll(document.body,"[tabindex='0']");var c=bb.selector.query(a,"[tabindex='0']");for(var b=0;b<d.length;b++){if(d[b]==c){break;}}while(b>0){if(!phe.tabBox.isElementVisible(d[b-1])){b--;}else{break;}}return d[b-1];};phe.tabBox.getFocusableElementAfterTabBox=function(a){var c=bb.selector.queryAll(document.body,"[tabindex='0']");var d=bb.selector.queryAll(a,"[tabindex='0']");for(var b=0;b<c.length;b++){if(c[b]==d[d.length-1]){break;}}while(b<c.length-1){if(!phe.tabBox.isElementVisible(c[b+1])){b++;}else{break;}}return c[b+1];};phe.tabBox.isElementVisible=function(a){var b=true;while(a!=document.body){if(bb.html.getStyle(a,"display")=="none"||bb.html.hasClass(a,"vi-screenreader-line")){b=false;break;}a=a.parentNode;}return b;};phe.tabBody.reload=function(a){absa.lazyLoadNode(a,true);};</script><script type="text/javascript">var phe=window.phe||{};phe.tabBoxVertical=new phe.Element;phe.tabBoxVerticalHeads=new phe.Element;phe.tabBoxVerticalHead=new phe.Element;phe.tabBoxVerticalBodies=new phe.Element;phe.tabBoxVerticalBody=new phe.Element;phe.tabBoxVertical.init=function(u){var p=bb.selector.queryAll(u,".ui-tabBoxVertical");for(var h=0;h<p.length;h++){var s=p[h];var c=bb.selector.queryAll(s,".ui-tabBoxVerticalHeads .ui-tabBoxVerticalHead");var b=bb.selector.queryAll(s,".ui-tabBoxVerticalBody");var t=0;for(var m=0,d=c.length;m<d;m++){var a=c[m];bb.html.addEventListener(c[m],"keydown",function(k){var i=bb.selector.queryAncestor(this,".ui-tabBoxVerticalHead");if(bb.html.hasClass(i,"ui-tabBoxVerticalHead_active")){var j=this;absa.util.validateKeyPressTab(k,function(){var v=bb.selector.queryAncestor(j,".ui-tabBoxVertical");var l=phe.tabBoxVertical.getCurrentTabBody(v);l.focus();});}});}var n=bb.selector.query(s,".ui-tabBoxVertical-body-end");bb.html.addEventListener(n,"focus",function(v){var w=bb.selector.queryAncestor(this,".ui-tabBoxVertical");var j=phe.tabBoxVertical.getCurrentTabIndex(w);var k=bb.selector.queryAll(w,".ui-tabBoxVerticalHead .ui-tabBoxVerticalHead-text");var l=3;if(k.length<=5){l=k.length-1;}if(j<l){var i=k[j+1];i.focus();bb.html.handlePreventDefault(v);}else{if(j==l&&k.length>5){bb.selector.query(w,".ui-tabBoxVertical-menu-pagelnk").focus();}}});var o=phe.tabBoxVertical.getCurrentTabIndex(s);var r=bb.selector.queryAll(s,".ui-tabBoxVerticalHead .ui-tabBoxVerticalHead-text");var g;var q;if(r.length<=5){q=r.length-1;g=r[q];}else{g=bb.selector.query(s,".ui-tabBoxVertical-menu-next");if(g.visible=="false"){g=bb.selector.query(s,".ui-tabBoxVertical-menu-prev");}}bb.html.addEventListener(g,"keydown",function(j){var i=this;absa.util.validateKeyPressTab(j,function(){var l=bb.selector.queryAncestor(i,".ui-tabBoxVertical");var k=bb.selector.query(l,".ui-tabBoxVertical-tab-end");k.focus();});});for(var f=0;f<c.length;f++){if(c[f].getAttribute("selected")=="true"){if(c.length>5){phe.tabBoxVertical.showHideGroupPages(c[f],Math.ceil((f+1)/4));}}}var e=phe.tabBoxVertical.getCurrentTabBody(s);if(e.getAttribute("proxyurl")!=""){absa.lazyLoadNode(e,true);}}};phe.tabBoxVertical.showGroupPrev=function(a){var c=a.parentNode.getAttribute("currentGroup");var b=(Number(c)-1);a.parentNode.setAttribute("currentGroup",b);phe.tabBoxVertical.showHideGroupPages(a,b);};phe.tabBoxVertical.showGroupNext=function(a){var c=a.parentNode.getAttribute("currentGroup");var b=(Number(c)+1);a.parentNode.setAttribute("currentGroup",b);phe.tabBoxVertical.showHideGroupPages(a,b);};phe.tabBoxVertical.showGroup=function(a){var b=a.getAttribute("group");var c=a.parentNode.parentNode.getAttribute("currentGroup");a.parentNode.parentNode.setAttribute("currentGroup",b);phe.tabBoxVertical.showHideGroupPages(a,b);};phe.tabBoxVertical.showHideGroupPages=function(a,d){var e=bb.selector.queryAncestor(a,".ui-tabBoxVertical");var b=bb.selector.queryAll(e,".ui-tabBoxVerticalHead");for(var c=0;c<b.length;c++){if(b[c].getAttribute("group")==d){b[c].style.display="";}else{b[c].style.display="none";}}if(d==1){bb.selector.query(a.parentNode.parentNode,".ui-tabBoxVertical-menu-prev").style.display="none";bb.selector.query(a.parentNode.parentNode,".ui-tabBoxVertical-menu-next").style.display="";}else{if(d>=Math.ceil(b.length/4)){bb.selector.query(a.parentNode.parentNode,".ui-tabBoxVertical-menu-prev").style.display="";bb.selector.query(a.parentNode.parentNode,".ui-tabBoxVertical-menu-next").style.display="none";}else{bb.selector.query(a.parentNode.parentNode,".ui-tabBoxVertical-menu-prev").style.display="";bb.selector.query(a.parentNode.parentNode,".ui-tabBoxVertical-menu-next").style.display="";}}};phe.tabBoxVertical.selectTabByIndex=function(a,c){var b=bb.selector.queryAll(a,".ui-tabBoxVerticalHead");return phe.tabBoxVertical.switchView(b[c]);};phe.tabBoxVertical.setTabHeadTitle=function(a,d,e){var b=bb.selector.queryAll(a,".ui-tabBoxVerticalHead");var c=bb.selector.query(b[d],".ui-tabBoxVertical-text-content");c.innerHTML=e;};phe.tabBoxVertical.getTabHeadTitle=function(a,d){var b=bb.selector.queryAll(a,".ui-tabBoxVerticalHead");var c=bb.selector.query(b[d],".ui-tabBoxVertical-text-content");return c.innerHTML;};phe.tabBoxVertical.getCurrentTabIndex=function(a){var b=bb.selector.queryAll(a,".ui-tabBoxVerticalHead");for(var c=0;c<b.length;c++){if(bb.html.hasClass(b[c],"ui-tabBoxVerticalHead_active")){return c;}}return -1;};phe.tabBoxVertical.getCurrentTabBody=function(a){return bb.selector.query(a,".ui-tabBoxVerticalBody_active");};phe.tabBoxVertical.reloadTab=function(a){var b=bb.selector.query(a,".ui-tabBoxVerticalBody_active");absa.lazyLoadNode(b,true);};phe.tabBoxVertical.switchView=function(d){if(!d){return;}var a=bb.selector.queryAncestor(d,".ui-tabBoxVertical");var b=phe.tabBoxVertical.getCurrentTabBody(a);var c=function(){if(bb.html.hasClass(d,"ui-tabBoxVerticalHead")){var k=bb.selector.query(a,".ui-tabBoxVerticalHead_active");if(k){var l=bb.selector.query(k,".ui-tabBoxVerticalHead_expanded");l.innerHTML=l.textContent=" ";var h=bb.selector.query(k,".ui-tabBoxVerticalHead_collapsed");h.innerHTML=h.textContent=absa.locale["Common/General/Label/Expand"]+". ";bb.html.removeClass(k,"ui-tabBoxVerticalHead_active");k.setAttribute("aria-selected","");}var j=bb.selector.query(d,".ui-tabBoxVerticalHead_collapsed");j.innerHTML=j.textContent=" ";var i=bb.selector.query(d,".ui-tabBoxVerticalHead_expanded");i.innerHTML=i.textContent=". "+absa.locale["Common/General/Label/Selected"];bb.html.addClass(d,"ui-tabBoxVerticalHead_active");d.setAttribute("aria-selected",true);var f=phe.tabBoxVertical.getCurrentTabBody(a);if(f){bb.html.removeClass(f,"ui-tabBoxVerticalBody_active");}var e=bb.selector.queryAll(a,".ui-tabBoxVerticalBodies .ui-tabBoxVerticalBody-container");var g=e[phe.tabBoxVertical.getCurrentTabIndex(a)];bb.html.addClass(g,"ui-tabBoxVerticalBody_active");if(g.getAttribute("proxyurl")!=""){absa.lazyLoadNode(g,true);}g.focus();}};if(absa.unconfirmedChanges&&b){return absa.unconfirmedChanges.cancelNavigation(b,c);}else{return c();}};</script><script type="text/javascript">var phe=window.phe||{};phe.deck=new phe.FormElement;phe.deck.initialize=function(d){var e=bb.selector.queryAll(d,".ui-deck");for(var c=0,b=e.length;c<e.length;c++){var a=bb.selector.queryAll(e[c],".ui-deckItem");if(phe.deck.getAttribute(a[0],"proxyurl")){absa.lazyLoadNode(a[0],true);}}};phe.deck.getAttribute=function(a,b){return phe.Element.prototype.getAttribute.call(this,a,b);};phe.deck.setAttribute=function(a,b,c){phe.FormElement.prototype.setAttribute.call(this,a,b,c);};phe.deck.getCurrentDeckItemIndex=function(c){var a=bb.selector.queryAll(c,".ui-deckItem");for(var b=0;b<a.length;b++){if(bb.html.hasClass(a[b],"ui-deckItem-selected")){return b;}}return -1;};phe.deck.onLeftButtonClick=function(d){var f=bb.selector.queryAncestor(d,".ui-deck");var c=bb.selector.queryAll(f,".ui-deckItem");var g=phe.deck.getCurrentDeckItemIndex(f);var e=c[g];var b=parseInt(g)-1;if(b<0){var a=c.length-1;b=a;bb.html.addClass(c[a],"ui-deckItem-selected");}else{bb.html.addClass(c[b],"ui-deckItem-selected");}if(phe.deck.getAttribute(c[b],"proxyurl")){absa.lazyLoadNode(c[b],true);}bb.html.removeClass(c[g],"ui-deckItem-selected");};phe.deck.onRightButtonClick=function(d){var f=bb.selector.queryAncestor(d,".ui-deck");var c=bb.selector.queryAll(f,".ui-deckItem");var g=phe.deck.getCurrentDeckItemIndex(f);var e=c[g];var a=parseInt(g)+1;var b=c.length;if(a==b){a=0;bb.html.addClass(c[a],"ui-deckItem-selected");}else{bb.html.addClass(c[a],"ui-deckItem-selected");}if(phe.deck.getAttribute(c[a],"proxyurl")){absa.lazyLoadNode(c[a],true);}bb.html.removeClass(c[g],"ui-deckItem-selected");};</script><script type="text/javascript">var phe=window.phe||{};phe.textBox=new phe.FormElement;phe.textBox.initialize=function(b){if(absa.touch.enabled){var c=bb.selector.queryAll(b,".ui-textBox[bbf_x_type_number]");for(var a=0;a<c.length;a++){if(absa.touch.iPad){c[a].setAttribute("pattern","[0-9]*");}else{if(absa.touch.android){c[a].setAttribute("type","number");}}}}};phe.textBox.setAttribute=function(b,a,c){if(b){if(a=="readOnly"){if(c==""){b.removeAttribute("readOnly");}else{phe.FormElement.prototype.setAttribute.call(this,b,"readOnly",c);}}else{phe.FormElement.prototype.setAttribute.call(this,b,a,c);}}};phe.textBox.getValue=function(a){if(a){return phe.FormElement.prototype.getAttribute.call(this,a,"value");}else{return null;}};phe.textBox.setValue=function(a,b){if(a){phe.FormElement.prototype.setAttribute.call(this,a,"value",b);}};</script><script type="text/javascript">var phe=window.phe||{};phe.tooltip=new phe.Element;phe.tooltip.tooltipCaller=null;phe.tooltip.timeoutShow=null;phe.tooltip.timeoutHide=null;phe.tooltip.onmousedown=null;phe.tooltip.oModal=null;phe.tooltip.scrollTop=null;phe.tooltip.element=document.createElement("div");phe.tooltip.element.style.display="none";phe.tooltip.element.className="ap-tooltipElement";phe.tooltip.hideTooltip=function(){phe.tooltip.element.style.display="none";phe.tooltip.clearTimeouts();if(phe.tooltip.onmousedown){bb.html.removeEventListener(document,"mousedown",phe.tooltip.onmousedown);phe.tooltip.onmousedown=null;}};phe.tooltip.showTooltip=function(){phe.tooltip.clearTimeouts();var c=phe.tooltip.tooltipCaller;var b=c.getAttribute("tooltipTimeout")||200;if(!c.getAttribute("anchorPoint")){}if(!c.getAttribute("offsetX")){c.setAttribute("offsetX",0);}if(!c.getAttribute("offsetY")){c.setAttribute("offsetY",10);}var a=phe.tooltip.element;a.innerHTML=c.getAttribute("tooltip");a.target=c;a.style.display="block";a.style.visibility="hidden";a.style.width="";a.style.left="";a.style.top="";phe.tooltip.onmousedown=function(){phe.tooltip.hideTooltip();};bb.html.addEventListener(document,"mousedown",phe.tooltip.onmousedown);phe.tooltip.timeoutShow=setTimeout(function(){var g=bb.html.getBoxObject(a);if(g.w>300){a.style.width="300px";}var f=bb.html.getBoxObject(c);switch(c.getAttribute("anchorPoint")){case"topleft":a.style.left=(f.x+parseInt(c.getAttribute("offsetX")))+"px";if(bb.browser.webkit&&bb.browser.version>500){a.style.top=absa.util.getOffset(c).top+"px";}else{a.style.top=(f.y+parseInt(c.getAttribute("offsetY")))+"px";}a.setAttribute("startfromleft",""+(f.x+parseInt(c.getAttribute("offsetX"))));a.setAttribute("startfromtop",""+(f.y+parseInt(c.getAttribute("offsetY"))));break;case"bottomright":a.style.left=(((f.x+f.w)-g.w)+parseInt(c.getAttribute("offsetX")))+"px";if(bb.browser.webkit&&bb.browser.version>500){a.style.top=absa.util.getOffset(c).top+"px";}else{a.style.top=(((f.y+f.h)-g.h)+parseInt(c.getAttribute("offsetY")))+"px";}a.setAttribute("startfromleft",""+(((f.x+f.w)-g.w)+parseInt(c.getAttribute("offsetX"))));a.setAttribute("startfromtop",""+(((f.y+f.h)-g.h)+parseInt(c.getAttribute("offsetY"))));break;default:a.style.position="absolute";a.style.left=(f.x+f.width)+"px";if(bb.browser.webkit&&bb.browser.version>500){a.style.top=absa.util.getOffset(a.target).top+"px";}else{a.style.top=(f.y)+"px";}a.setAttribute("startfromleft",""+(f.x+f.width));a.setAttribute("startfromtop",""+(f.y));break;}var e=bb.html.getBoxObject(a);var d=bb.html.getBoxObject(document.body);if(d.width<(f.x+f.width+e.width)){a.style.left=(f.x-e.w)+"px";}a.style.visibility="visible";bb.html.setStyle(a,"opacity","0.0");bb.smil.animate(a,{attributeName:"opacity",from:"0.0",to:"1.0",dur:"300ms",fill:"freeze"});},b);phe.tooltip.timeoutHide=setTimeout(function(){phe.tooltip.hideTooltip();},1000*10);};phe.tooltip.clearTimeouts=function(){if(phe.tooltip.timeoutShow){phe.tooltip.timeoutShow=clearTimeout(phe.tooltip.timeoutShow);}if(phe.tooltip.timeoutHide){phe.tooltip.timeoutHide=clearTimeout(phe.tooltip.timeoutHide);}};document.body.appendChild(phe.tooltip.element);</script><script type="text/javascript">var phe=window.phe||{};phe.wizard=new phe.Element;phe.wizardHead=new phe.Element;phe.wizardBody=new phe.Element;phe.wizard.getCurrentStepIndex=function(c){var b=0;var a=bb.selector.query(c,".ui-wizard-head");while(a){if(a.nodeType===1){if(bb.html.hasClass(a,"ui-wizard-selected")){return b;}b++;}a=a.nextSibling;}return false;};phe.wizard.getNextStepBody=function(b){var c=bb.selector.queryAll(b,".ui-wizard-body");var d=bb.selector.queryAll(b,".ui-wizard-head");var a=phe.wizard.getCurrentStepIndex(b);var e=a+1;return c[e]||c[a]||null;};phe.wizard.getStepsCount=function(a){var b=bb.selector.queryAll(a,".ui-wizard-head");return b.length;};phe.wizard.getCurrentStepBody=function(a){return bb.selector.query(a,".ui-wizard-body-selected");};phe.wizard.selectStep=function(c){var f=bb.html.hasClass(c,"ui-wizard-head");var d=bb.selector.queryAncestor(c,".ui-wizard");var g=bb.selector.query(d,".ui-wizard-head-wrapper");var e=bb.selector.query(d,".ui-wizard-body-wrapper");var k=bb.selector.queryAll(g,".ui-wizard-head");var i=bb.selector.queryAll(e,".ui-wizard-body");var m=f?k:i;var b=m.length;for(var h=0;h<b;h++){if(m[h]===c){break;}}var a=bb.selector.query(g,".ui-wizard-selected");var l=bb.selector.query(e,".ui-wizard-body-selected");bb.html.removeClass(a,"ui-wizard-selected");bb.html.removeClass(l,"ui-wizard-body-selected");bb.html.addClass(k[h],"ui-wizard-selected");bb.html.addClass(i[h],"ui-wizard-body-selected");phe.wizard.setShowMeHow(i[h]);phe.wizard.setCallMeButton(i[h]);phe.wizard.setAdvisorButton(i[h]);phe.wizard.setContactUsButton(i[h]);var j=bb.selector.queryAncestor(d,".ui-modal");if(j){phe.modal.updatePosition();}i[h].focus();};phe.wizard.setShowMeHow=function(f){var b=bb.selector.queryAncestor(f,".ui-wizard");var d=f.getAttribute("disableShowMeHow");var c=bb.selector.query(b,".ui-wizard--showMeHow");if(d&&d=="true"){bb.html.addClass(b,"ui-wizard--showMeHow_disabled");bb.html.replaceClass(c,"ap-icon-help","ap-icon-help-inactive");var e=phe.button.getAttribute(c,"data-showMeHowInActive");if(e){phe.button.setAttribute(c,"tooltip",absa.locale["Common/General/Label/ShowMeHowNotAvailable"]);c.disable=true;}}else{bb.html.removeClass(b,"ui-wizard--showMeHow_disabled");bb.html.replaceClass(c,"ap-icon-help-inactive","ap-icon-help");var a=phe.button.getAttribute(c,"data-showMeHowActive");if(a){phe.button.setAttribute(c,"tooltip",a);c.disable=false;}}};phe.wizard.setCallMeButton=function(d){var b=bb.selector.queryAncestor(d,".ui-wizard");var a=d.getAttribute("showCallMe");var c=bb.selector.query(b,".ui-wizard--callMeButton");if(a==null){if(c!=null){bb.html.removeClass(c,"ap-common-show");bb.html.addClass(c,"ap-common-hide");}}else{if(c!=null){bb.html.replaceClass(c,"ap-common-hide","ap-common-show");}bb.html.removeClass(c,"ap-common-hide");}};phe.wizard.setAdvisorButton=function(d){if(d){var c=d.getAttribute("showAdvisor");var a=bb.selector.queryAncestor(d,".ui-wizard");if(a){var b=bb.selector.query(a,".ui-wizard--advisorButton");if(b){if(c==null){bb.html.removeClass(b,"ap-common-show");bb.html.addClass(b,"ap-common-hide");}else{bb.html.removeClass(b,"ap-common-hide");}}}}};phe.wizard.setContactUsButton=function(d){var a=bb.selector.queryAncestor(d,".ui-wizard");var c=d.getAttribute("showContactUs");var b=bb.selector.query(a,".ui-wizard--contactUsButton");if(c==null){bb.html.removeClass(b,"ap-common-show");bb.html.addClass(b,"ap-common-hide");}else{bb.html.removeClass(b,"ap-common-hide");}};phe.wizard.setContactUsButton=function(d){var a=bb.selector.queryAncestor(d,".ui-wizard");var c=d.getAttribute("showContactUs");var b=bb.selector.query(a,".ui-wizard--contactUsButton");if(c==null){bb.html.removeClass(b,"ap-common-show");bb.html.addClass(b,"ap-common-hide");}else{bb.html.removeClass(b,"ap-common-hide");}};phe.wizard.selectStepRelative=function(e,c){var b=bb.selector.queryAncestor(e,".ui-wizard");var a=bb.selector.queryAll(b,".ui-wizard-head");var d=phe.wizard.getCurrentStepIndex(b);if(typeof d==="number"&&typeof c==="number"){var f=d+c;if(a[f]){phe.wizard.selectStep(a[f]);}}};phe.wizard.selectStepAbsolute=function(c,d){if(c!=null&&d!=null){if(typeof d==="number"){var b=bb.selector.queryAncestor(c,".ui-wizard");if(b){var a=bb.selector.queryAll(b,".ui-wizard-head");if(a!=null&&a[d]){phe.wizard.selectStep(a[d]);}}}}};phe.wizardBody.onCallMeClick=function(d,b){var a=bb.selector.queryAncestor(d,".ui-wizard");var c=phe.wizard.getCurrentStepBody(a);var e=phe.wizardBody.getAttribute(c,"oncallmeactivate");if(e){new Function("event",e).call(c,b);}};phe.wizardBody.onAdvisorClick=function(e,b){var a=bb.selector.queryAncestor(e,".ui-wizard");var c=phe.wizard.getCurrentStepBody(a);var d=phe.wizardBody.getAttribute(c,"onAdvisorClick");if(d){new Function("event",d).call(c,b);}};phe.wizardBody.onContactUsClick=function(e,b){var a=bb.selector.queryAncestor(e,".ui-wizard");var d=phe.wizard.getCurrentStepBody(a);var c=phe.wizardBody.getAttribute(d,"onContactUsClick");if(c){new Function("event",c).call(d,b);}};</script><script type="text/javascript">var phe=window.phe||{};phe.inputReadOnlyText=new phe.FormElement;phe.inputReadOnlyText.setAttribute=function(a,b,c){if(b=="readOnly"){if(c==""){a.removeAttribute("readOnly");}else{phe.FormElement.prototype.setAttribute.call(this,a,"readOnly",c);}}else{phe.FormElement.prototype.setAttribute.call(this,a,b,c);}};phe.inputReadOnlyText.getValue=function(a){return phe.FormElement.prototype.getAttribute.call(this,a,"value");};phe.inputReadOnlyText.setValue=function(a,b){phe.FormElement.prototype.setAttribute.call(this,a,"value",b);};phe.inputReadOnlyText.initialize=function(a){setTimeout(function(){var c=bb.selector.queryAll(a,".ui-inputReadOnlyText-multiline");for(var b=0;b<c.length;b++){if(c[b].scrollHeight=="28"){c[b].style.height="13px";}else{c[b].style.height=c[b].scrollHeight+"px";}}},0);};</script><script type="text/javascript">var phe=window.phe||{};phe.hiddenField=new phe.Element;phe.hiddenField.getValue=function(a){if(a){return a.value;}else{return null;}};phe.hiddenField.setValue=function(a,b){if(a){a.value=b;}};</script><script type="text/javascript">var phe=window.phe||{};phe.timePicker=new phe.Element;phe.timePicker.getValue=function(a){return a.value;};phe.timePicker.setValue=function(a,b){a.value=b;};phe.timePicker.getSelectedIndex=function(a){return a.selectedIndex;};phe.timePicker.setSelectedIndex=function(b,a){b.selectedIndex=a;};phe.timePicker.getSelectedText=function(a){return a.options[a.selectedIndex].text;};phe.timePicker.setSelectedText=function(a,b){a.options[a.selectedIndex].text=b;};phe.timePicker.setAttribute=function(a,b,c){phe.Element.prototype.setAttribute.call(this,a,b,c);if(b=="min"||b=="max"){phe.timePicker.setTimeRange(a);}};phe.timePicker.setTimeRange=function(g){var a=phe.timePicker.getAttribute(g,"min");var d=phe.timePicker.getAttribute(g,"max");g.innerHTML="";try{if(a.toLowerCase()=="now"){var h=document.createElement("OPTION");h.text=absa.locale["Common/General/Label/Now"];h.value="Now";g.options.add(h);var f=absa.date.parseXPathDateTime(g.getAttribute("serverTime"));if(f!=null){var c=f.getHours();a=parseInt(c)+2;}else{a=parseInt(absa.date.getTimeNowHourOnly())+2;}}}catch(e){a=parseInt(absa.date.getTimeNowHourOnly())+2;}for(var b=parseInt(a);b<=parseInt(d);b++){var h=document.createElement("OPTION");h.text=(b<10?"0":"")+b+":00";h.value=(b<10?"0":"")+b+":00";g.options.add(h);}};</script><script type="text/javascript">var phe=window.phe||{};phe.select=new phe.FormElement;phe.option=new phe.Element;phe.select.getValue=function(a){return phe.FormElement.prototype.getAttribute.call(this,a,"value");};phe.select.getValues=function(d){var c=new Array();for(var b=0;b<d.options.length;b++){if(d.options[b].selected){c.push(d.options[b].value);}}return c;};phe.select.setValue=function(a,b){phe.FormElement.prototype.setAttribute.call(this,a,"value",b);};phe.select.getSelectedOption=function(a){return a.options[a.selectedIndex];};phe.select.getSelectedOptions=function(d){var c=new Array();for(var b=0;b<d.options.length;b++){if(d.options[b].selected){c.push(d.options[b]);}}return c;};phe.select.getSelectedIndex=function(a){return a.selectedIndex;};phe.select.getSelectedIndexes=function(d){var c=new Array();for(var b=0;b<d.options.length;b++){if(d.options[b].selected){c.push(b);}}return c;};phe.select.setSelectedIndex=function(b,a){b.selectedIndex=a;};phe.select.setSelectedIndexes=function(c,d){for(var b=0;b<d.length;b++){c.options[d[b]].selected=true;}};phe.select.getSelectedAttribute=function(b,a){return b.options[b.selectedIndex].getAttribute(a);};phe.select.getSelectedText=function(a){return a.options[a.selectedIndex].text;};phe.select.getSelectedTexts=function(d){var c=new Array();for(var b=0;b<d.options.length;b++){if(d.options[b].selected){c.push(d.options[b].text);}}return c;};phe.select.setSelectedText=function(a,b){a.options[a.selectedIndex].text=b;};phe.select.addOption=function(b,a,c){optn=document.createElement("OPTION");optn.text=a;optn.value=c;b.options.add(optn);};phe.select.removeOption=function(b,a){b.remove(a);};phe.select.getLength=function(a){return a.options.length;};phe.select.getValueByIndex=function(b,a){return b.options[a].value;};phe.select.getTextByIndex=function(b,a){return b.options[a].text;};phe.select.setTooltipDisplayText=function(a){if(phe.select.getSelectedText(a)){phe.select.setAttribute(a,"tooltip",phe.select.getSelectedText(a));}};</script><script type="text/javascript">var phe=window.phe||{};phe.table=new phe.Element;phe.tableHead=new phe.Element;phe.tableHeadCell=new phe.Element;phe.tableBody=new phe.Element;phe.tableBodyRow=new phe.Element;phe.tableBodyCell=new phe.Element;phe.tableBodyRowExpandableExtention=new phe.Element;phe.table.tableFragment=document.createElement("div");phe.table.tableFragment.style.display="none";phe.table.setAttribute=function(a,b,d){if(b=="sort-defaultColumn"){phe.Element.prototype.setAttribute.call(this,a,"sortedcolumn",d);}else{if(b=="sort-defaultOrder"){phe.Element.prototype.setAttribute.call(this,a,"sortorder",d);}else{if(b=="height"){var c=bb.selector.query(a,".ui-table--scrollContainer");a._scrollableHeight=0;c.style.height=d;}else{if(b=="rowPacketSize"){phe.Element.prototype.setAttribute.call(this,a,"rowPacketSize",d);a._rowPacketSize=a.getAttribute("rowPacketSize");}else{phe.Element.prototype.setAttribute.call(this,a,b,d);}}}}};phe.table.getAttribute=function(a,b){if(b=="sort-defaultColumn"){return phe.Element.prototype.getAttribute.call(this,a,"sortedcolumn");}else{if(b=="sort-defaultOrder"){return phe.Element.prototype.getAttribute.call(this,a,"sortorder");}else{return phe.Element.prototype.getAttribute.call(this,a,b);}}};phe.table.getTableHead=function(a){return bb.selector.query(a,".ui-tableHead");};phe.tableHead.getTableHeadCell=function(a,c){var b=bb.selector.query(a,".ui-tableHead tr");return b.cells[c];};phe.table.getTableBody=function(a){return bb.selector.query(a,".ui-tableBody");};phe.tableBody.getRowByIndex=function(a,b){var c=bb.selector.query(a,".ui-tableBody .ui-tableBodyTBody");return c.rows[b];};phe.tableBodyRow.getCellByIndex=function(a,d,b){var c=phe.tableBody.getRowByIndex(a,d);return c.cells[b];};phe.tableHead.getLength=function(a){var b=bb.selector.query(a,".ui-tableHead tr");return b.cells.length;};phe.tableBody.getLength=function(a){var b=bb.selector.query(a,".ui-tableBody .ui-tableBodyTBody");return b.rows.length;};phe.tableBodyRow.getLength=function(a,b){var c=phe.tableBody.getRowByIndex(a,b);return c.cells.length;};phe.tableBody.deleteRow=function(a,b){var c=bb.selector.query(a,".ui-tableBody .ui-tableBodyTBody");c.deleteRow(b);};phe.tableBody.cloneRow=function(a,b){var d=bb.selector.query(a,".ui-tableBody .ui-tableBodyTBody");var c=d.rows[b].cloneNode(true);return c;};phe.tableBody.insertRow=function(b,d,c){var e=bb.selector.query(b,".ui-tableBody .ui-tableBodyTBody");var a=e.insertRow(c);a.parentNode.replaceChild(d,a);};phe.tableBody.getSelectedRowsValues=function(b){var e=bb.selector.queryAll(b,".ui-tableBodyRow-selector");var a=new Array();for(var d=0;d<e.length;d++){var c=e[d];if(c.checked==true){a.push(c.getAttribute("value"));}}return a;};phe.tableBodyRow.toggleAlternativeStyle=function(a,b){var c=phe.tableBody.getRowByIndex(a,b);if(bb.html.hasClass(c,"ui-tableBodyRow--rowAlternate")){bb.command.removeClass(c,"ui-tableBodyRow--rowAlternate");}else{bb.command.addClass(c,"ui-tableBodyRow--rowAlternate");}};phe.tableBodyRow.getTable=function(a){return bb.selector.queryAncestor(a,".ui-table");};phe.tableBodyRow.getIndex=function(a){return a.rowIndex;};phe.tableBodyCell.getIndex=function(a){return a.cellIndex;};phe.table.setTableSorting=function(f){var d=bb.selector.queryAncestor(f,".ui-sortableTable");var b=f.getAttribute("sortOrder");if(b){b=(b=="ASC")?"DESC":"ASC";}else{b=f.getAttribute("defaultOrder")||"ASC";}var c=d.getAttribute("sortOrder");if(c){var a=d.getAttribute("sortedColumn");var e=bb.selector.query(d,'.ui-table--sortHandle[name="'+a+'"]');if(e){e.setAttribute("sortOrder","");bb.html.removeClass(e,"sorted-"+c);}else{}}d.setAttribute("sortedColumn",f.getAttribute("name"));d.setAttribute("sortOrder",b);f.setAttribute("sortOrder",b);bb.html.addClass(f,"sorted-"+b);};phe.table.setRowsAlternateStyle=function(a){if(a&&a.rows){var c=a.rows;for(var b=0;b<c.length;b++){if(b%2==0){bb.html.removeClass(c[b],"ui-tableBodyRow--rowAlternate");}else{bb.html.addClass(c[b],"ui-tableBodyRow--rowAlternate");}}}};phe.table.tableScroll=function(c){var b=bb.selector.queryAncestor(c.currentView,".ui-sortableTable");if(!b._isLoading){if(b._nbRows<b._totalRows){var a=bb.selector.query(b,".ui-table--scrollContainer");var d=a.scrollTop;if(d!=b._lastScrollTop){if(b._scrollableHeight==0){b._scrollableHeight=b.offsetHeight;}if(b._loadingMessageContainer.offsetTop-d<b._scrollableHeight){phe.table.loadData(b,false);}b._lastScrollTop=d;}}}};phe.table.empty=function(d){var c=bb.selector.query(d,".ui-table--scrollContainer");if(c){var g=bb.selector.query(c,".ui-tableBody");if(g){var a=bb.selector.queryAll(g,".ui-tableBodyTBody .ap-table-stickyRow");var h=document.createElement("table");h.className="ui-tableBody";var f=document.createElement("tbody");f.className="ui-tableBodyTBody";h.appendChild(f);try{if(g!=null){c.removeChild(g);}}catch(e){}if(d._loadingMessageContainer&&d._loadingMessageContainer.parentNode==c){c.insertBefore(h,d._loadingMessageContainer);}else{c.appendChild(h);}for(var b=0;b<a.length;b++){f.appendChild(a[b]);}}}};phe.table.removeSorting=function(b){var a=bb.selector.query(b,".sorted-DESC")||bb.selector.query(b,".sorted-ASC");if(a){bb.html.removeClass(a,"sorted-DESC");bb.html.removeClass(a,"sorted-ASC");b.removeAttribute("sortedcolumn");b.removeAttribute("sortorder");}};phe.table.reload=function(a){phe.table.empty(a);a._dataFile=a.getAttribute("dataFile");phe.table.loadData(a,true);};phe.table.loadData=function(h,f,b){if(!h._dataFile){return;}var g=h.getAttribute("sortedColumn");var c=h.getAttribute("sortOrder");var i=bb.selector.queryAll(h,".ui-tableBodyTBody .ap-table-stickyRow");var d=bb.selector.queryAll(h,".ui-tableBodyRow--ioErrorMessage");if(h._search||h._sort){h._iExcludeRows=i.length;h._search=false;h._sort=false;}h._nbRows=bb.selector.queryAll(h,".ui-tableBodyRow").length;var e=[h._dataFile,(h._dataFile.indexOf("?")==-1)?"?":"&","sortedColumn=",g,"&sortOrder=",c,"&startRow=",(h._nbRows-h._iExcludeRows-d.length),"&rowPacketSize=",h._rowPacketSize].join("");var a=function(k){if(f){phe.table.empty(h);}phe.table.tableFragment.innerHTML=k.text;var m=bb.selector.query(phe.table.tableFragment,".ui-tableBody");if(m){var x=bb.selector.query(h,".ui-table--scrollContainer .ui-tableBody");if(x.tBodies[0]!=null){var j=x.tBodies[0];x.parentNode.appendChild(phe.table.tableFragment);absa.initializeNewContent(phe.table.tableFragment);x.parentNode.removeChild(phe.table.tableFragment);h._totalRows=m.getAttribute("totalRows")||0;var z=bb.selector.query(phe.table.tableFragment,".ui-tableBodyTBody").rows;var B=bb.selector.queryAll(h,".ap-table-stickyRow");var p=0;var w=0;for(var v=0,t=z.length,s=0;v<t;v++){if(z[v-s].getAttribute("class")!="ui-table-hoverable"){var n=false;for(var A=0;A<B.length;A++){if(B[A].getAttribute("id")==z[v-s].getAttribute("id")){n=true;}p++;if(p%2==0){bb.command.removeClass(B[A],"ui-tableBodyRow--rowAlternate");}else{bb.command.addClass(B[A],"ui-tableBodyRow--rowAlternate");}}if(n==false){if(B.length!=0){w++;if(w%2==0){bb.command.removeClass(z[v-s],"ui-alternate-row");}else{bb.command.addClass(z[v-s],"ui-alternate-row");}}j.appendChild(z[v-s]);s++;}else{h._iExcludeRows-=1;}}}if(b){var u=bb.selector.queryAll(h,".ui-tableBodyRow")[h._nbRows+2];var r=bb.selector.queryAll(u,".ui-tableBodyCellContent");for(var v=0;v<r.length;v++){if(r[v].hasAttribute("tabindex")&&r[v].getAttribute("tabindex")>=0){r[v].focus();break;}}}h._nbRows=bb.selector.queryAll(h,".ui-tableBodyRow").length;if(h._nbRows>=h._totalRows){var y=bb.selector.query(h,".vi-table-scroller");if(y){y.parentNode.removeChild(y);}}absa.util.copyAttributes(m,x);if(absa.touch.enabled&&(h._nbRows<h._totalRows)){var q="<tr class='ui-tableBodyRow-loadMore'><td colspan='99'><div tabindex='0' class='ui-table-loadMore' onclick='phe.table.loadMoreRows(this)'>Load More Records</div></td></tr>";j.appendChild(bb.html.createElementFromString(q));}}}var o=absa.util.attributeToFunction(h,"oncallback",["aNewRows"]);if(o){o.call(h,z);}};h._isLoading=true;if(h._loadingMessageContainer){h._loadingMessageContainer.style.display="";phe.loadingMessage.showLoadingMessage(h._loadingMessageContainer);}absa.io.makeRequest(e,function(m){h._isLoading=false;if(h._loadingMessageContainer){phe.loadingMessage.hideLoadingMessage(h._loadingMessageContainer);h._loadingMessageContainer.style.display="none";}if(!m.errors.length){var o=bb.selector.query(h,".ui-tableBodyRow--ioErrorMessage");if(o){o.parentNode.removeChild(o);}a(m);}else{var k=bb.selector.query(h,".ui-tableBodyTBody");var o=bb.selector.query(k,".ui-tableBodyRow--ioErrorMessage");if(!o){var j="<tr class='ui-tableBodyRow ui-tableBodyRow--ioErrorMessage'><td colspan='30' class='ui-tableBodyCell'></td></tr>";var l=bb.html.createElementFromString(j);var n=bb.selector.query(l,".ui-tableBodyCell");absa.showIOErrorMessage(n);k.appendChild(l);}}});};phe.table.loadMoreRows=function(c){var a=bb.selector.queryAncestor(c,".ui-table");var d=bb.selector.query(a,".ui-table--scrollContainer .ui-tableBody");var b=bb.selector.query(d,".ui-tableBodyRow-loadMore");if(b){b.parentNode.removeChild(b);}phe.table.loadData(a);};phe.table.initializeBehavior=function(k){var c=bb.selector.query(k,".ui-table--scrollContainer");if(c){k._scrollableHeight=c.offsetHeight;var j=bb.selector.queryAll(k,".ap-table-loadingMessage");k._loadingMessageContainer=j[j.length-1];if(k._loadingMessageContainer){k._loadingMessageContainer.style.height=c.offsetHeight+"px";k._loadingMessageContainer.style.display="none";}}var a=k.getAttribute("sortedColumn");var b=bb.selector.query(k,'span[name="'+a+'"]')||bb.selector.query(k,"span[name]");if(b&&a){phe.table.setTableSorting(b);}k._rowPacketSize=k.getAttribute("rowPacketSize");k._iExcludeRows=0;k._search=false;k._dataFile=k.getAttribute("dataFile")||k.getAttribute("datafile");if(k._dataFile&&k.getAttribute("forceInitialLoadFromDataFile")){phe.table.loadData(k,false);}else{var l=bb.selector.query(k,".ui-table--scrollContainer table");k._nbRows=bb.selector.queryAll(k,".ui-tableBodyRow").length-bb.selector.queryAll(k,".ap-table-stickyRow").length;if(l&&l.getAttribute("totalRows")){k._totalRows=l.getAttribute("totalRows");}else{k._totalRows=0;}var f=absa.util.attributeToFunction(k,"oncallback");if(f){f.call(k);}if(absa.touch.enabled&&(k._nbRows<k._totalRows)){var d="<tr class='ui-tableBodyRow-loadMore'><td colspan='99'><div tabindex='0' class='ui-table-loadMore' onclick='phe.table.loadMoreRows(this)'>Load More Records</div></td></tr>";var i=bb.selector.query(k,".ui-table--scrollContainer .ui-tableBody");var h=bb.selector.query(i,".ui-tableBody");h.appendChild(bb.html.createElementFromString(d));}}if(bb.html.hasClass(k,"ui-scroller-table")){var e=function(m){m=m||window.event;m.currentView=m.srcElement||m.target;phe.table.tableScroll(m);};if(!absa.touch.enabled){bb.html.addEventListener(c,"scroll",e);}var g=bb.selector.query(k,".vi-table-scroller");if(!g){g=document.createElement("a");g.setAttribute("role","button");g.setAttribute("href","javascript:");g.className="vi-table-scroller vi-screenreader-line";g.innerHTML="load more content for table";k.appendChild(g);bb.html.addEventListener(g,"click",function(m){if(!k._isLoading){if(k._nbRows<k._totalRows){phe.table.loadData(k,false,true);}}});}}};phe.table.initialize=function(c){var a=bb.selector.queryAll(c,".ui-sortableTable");for(var b=0;b<a.length;b++){phe.table.initializeBehavior(a[b]);}};</script><script type="text/javascript">var phe=window.phe||{};phe.table=phe.table||{};phe.table.finish=function(b){var a=bb.selector.queryAncestor(b,".ui-sortableTable");phe.table.reload(a);};phe.table.sortClient=function(d,j){var g=bb.selector.queryAncestor(d,"th");var k=d.getAttribute("sortorder")||d.getAttribute("sortOrder");if(k){k=(k=="ASC")?"DESC":"ASC";}else{k=d.getAttribute("defaultOrder")||"ASC";}var e="";var a="";var h=null;var f=d.getAttribute("sorttype")||d.getAttribute("sortType");if(f==null){f="checkbox";}switch(f){case"date":a="string";break;case"alphabetic":e='var sText = this.textContent || this.innerText || ""; return sText.toLowerCase()';break;case"checkbox":e='var sText = bb.selector.query(this,"input[type=checkbox]").checked || false; return sText;';break;case"numeric":e='var sContent = bb.selector.query(this,".vi-tabbable-content") || this; var sText = sContent.textContent || sContent.innerText || ""; return sText;';a="custom";h=function(m,l){var n=/-?[\d\.]*\d/;m=m.match(n);m=(m)?m[0]:0;l=l.match(n);l=(l)?l[0]:0;return Number(m)-Number(l);};break;default:a="Sort";}var i=bb.selector.query(j,".ui-tableBodyTBody");if(i.rows[0]){var c=i.rows[0].cells[g.cellIndex];bb.command.sort(c,k!="DESC",e,a,h);}var b=bb.selector.query(j,"th .sorted-DESC, th .sorted-ASC");if(b){bb.html.removeClass(b,"sorted-"+b.getAttribute("sortOrder"));}d.setAttribute("sortOrder",k);bb.html.addClass(d,"sorted-"+k);absa.vi.tableHeader.changeSortOrderLabel(d);};phe.table.sortServer=function(a,b){phe.table.setTableSorting(a);phe.table.empty(b);phe.table.loadData(b,true);absa.vi.tableHeader.changeSortOrderLabel(a);};</script><script type="text/javascript">var phe=window.phe||{};phe.table=phe.table||{};phe.table.isDisableMultiExpandedRows=function(b){var a=phe.table.getTableBody(b);var c=a.getAttribute("disablemultiexpandedrows");if(c=="true"){return true;}else{return false;}};phe.tableBodyRow.isExpanded=function(a){if(bb.html.hasClass(a,"ui-expanded-row")){return true;}else{return false;}};phe.tableBodyRow.getRowExpandableExtension=function(a){return a.parentNode.rows[a.rowIndex+1];};phe.tableBodyRow.getExtensionContent=function(a){return bb.selector.query(a.parentNode.rows[a.rowIndex+1],".ui-tableBodyRowExpandableExtension--expandedContent");};phe.tableBodyRow.collapseRow=function(a){var c=a.parentNode.rows[a.rowIndex+1];var b=bb.selector.query(a,".ui-expandableTable-icon,.ui-expandableTable-icon-expanded");if(c){if(bb.html.hasClass(a,"ui-expanded-row")){function d(){bb.html.addClass(c,"ui-tableBodyRowExpandableExtension_hidden");bb.html.replaceClass(a,"ui-expanded-row","ui-expandable-row");a.setAttribute("aria-selected","");c.setAttribute("aria-hidden","true");c.setAttribute("aria-expanded","false");var g=absa.util.attributeToFunction(c,"oncollapse");if(g){g.call(c);}if(b){bb.html.replaceClass(b,"ui-expandableTable-icon-expanded","ui-expandableTable-icon");var e=absa.locale["Common/General/Label/Expand"];var f=absa.locale["Common/General/Label/Collapse"];absa.vi.setElementLabel(b,absa.vi.getElementLabel(b).replace(f,e));}}if(absa.unconfirmedChanges&&c){return absa.unconfirmedChanges.cancelNavigation(c,d);}else{return d();}}}};phe.tableBodyRow.scrollInView=function(e){var b=bb.selector.queryAncestor(e,".ui-table--scrollContainer",this.viewNode);var c=e.offsetTop+e.firstChild.offsetHeight;var d=b.offsetHeight+b.scrollTop;if(c>d){b.scrollTop=(b.scrollTop+c-d);}var a=e.parentNode.rows[e.rowIndex-1];if(a.offsetTop<b.scrollTop){b.scrollTop=a.offsetTop;}};phe.tableBodyRow.expandRow=function(m,d,c){if(absa.ENABLETAGGING=="true"){var a=m.getAttribute("tagging");if(a){absa.analytics.trackAccordion(a);}}var o=m.parentNode.rows[m.rowIndex+1];var k=bb.selector.query(m,".ui-expandableTable-icon,.ui-expandableTable-icon-expanded");if(o){var l=phe.tableBodyRow.getTable(m);if(phe.table.isDisableMultiExpandedRows(l)){var j=bb.selector.queryAll(l,".ui-expanded-row");for(var e=0;e<j.length;e++){phe.tableBodyRow.collapseRow(j[e]);}}if(bb.html.hasClass(m,"ui-expandable-row")){bb.html.removeClass(o,"ui-tableBodyRowExpandableExtension_hidden");bb.html.replaceClass(m,"ui-expandable-row","ui-expanded-row");m.setAttribute("aria-selected","true");o.setAttribute("aria-hidden","false");o.setAttribute("aria-expanded","true");if(k){bb.html.replaceClass(k,"ui-expandableTable-icon","ui-expandableTable-icon-expanded");var q=absa.locale["Common/General/Label/Expand"];var p=absa.locale["Common/General/Label/Collapse"];absa.vi.setElementLabel(k,absa.vi.getElementLabel(k).replace(q,p));}}if(d){m._dataFile=d;var b=this;var g=bb.selector.query(o,".ui-tableBodyRowExpandableExtension--expandedContent");g.innerHTML="";function f(r){var s=bb.selector.query(o,".ui-tableBodyRowExpandableExtension--expandedContent");s.innerHTML="";s.appendChild(bb.html.createElementFromString(r.text));phe.tableBodyRow.scrollInView(o);absa.initializeNewContent(s);m._oldDataFile=d;oForm=bb.selector.query(s,'form[trackunconfirmedchanges="true"]');if(oForm){aButtons=bb.selector.queryAll(oForm,".ui-button-cross-red");}if(oForm&&aButtons){for(var t=0;t<aButtons.length;t++){bb.html.addEventListener(aButtons[t],"click",function(){if(oForm._changed){oForm._changed=false;}});}}}var h=document.createElement("div");h.className="ap-loading-message";g.appendChild(h);h.style.display="";phe.loadingMessage.showLoadingMessage(h);absa.io.makeRequest(d,function(s){phe.loadingMessage.hideLoadingMessage(h);if(!s.errors.length){f(s);if(o){var i=absa.util.attributeToFunction(o,"onexpand");if(i){i.call(o);}}if(c){c(g);}}else{var r=phe.message.createElement("error");g.appendChild(r);phe.message.setMessage(r,"Your request could not be processed. Please try again later.");}});o.focus();}else{phe.tableBodyRow.scrollInView(o);var n=absa.util.attributeToFunction(o,"onexpand");if(n){n.call(o);}}}};</script><script type="text/javascript">var phe=window.phe||{};phe.rearrangeTable=phe.rearrangeTable||{};phe.rearrangeTable.tableFragment=document.createElement("div");phe.rearrangeTable.tableFragment.style.display="none";phe.rearrangeTable.initialize=function(b){var c=bb.selector.queryAll(b,".ui-rearrangeTable");for(var a=0;a<c.length;a++){phe.rearrangeTable.initializeBehavior(c[a]);}};phe.rearrangeTable.initializeBehavior=function(b){phe.rearrangeTable.saveInitialPosition(b);var a=bb.selector.query(b,".ui-table--scrollContainer");if(a){b._scrollableHeight=a.offsetHeight;b._loadingMessageContainer=bb.selector.query(b,".ap-table-loadingMessage");if(b._loadingMessageContainer){b._loadingMessageContainer.style.height=a.offsetHeight+"px";b._loadingMessageContainer.style.display="none";}}b._rowPacketSize=b.getAttribute("rowPacketSize");b._dataFile=b.getAttribute("dataFile")||b.getAttribute("datafile");if(!b._dataFile){return;}if(b._dataFile&&b.getAttribute("forceInitialLoadFromDataFile")){phe.rearrangeTable.loadData(b,false);}else{var d=bb.selector.query(b,".ui-table--scrollContainer table");b._nbRows=bb.selector.queryAll(b,".ui-tableBodyRow").length;if(d&&d.getAttribute("totalRows")){b._totalRows=d.getAttribute("totalRows");}else{b._totalRows=0;}}var c=function(f){f=f||window.event;f.currentView=f.srcElement||f.target;phe.rearrangeTable.tableScroll(f);};bb.html.addEventListener(a,"scroll",c);var e=bb.selector.query(b,".vi-table-scroller");if(!e){e=document.createElement("a");e.setAttribute("role","button");e.setAttribute("href","javascript:");e.className="vi-table-scroller vi-screenreader-line";e.innerHTML="load more content for table";b.appendChild(e);}bb.html.addEventListener(e,"click",function(f){if(!b._isLoading){if(b._nbRows<b._totalRows){phe.rearrangeTable.loadData(b,false);}}});};phe.rearrangeTable.tableScroll=function(c){var b=bb.selector.queryAncestor(c.currentView,".ui-rearrangeTable");if(!b._isLoading){if(b._nbRows<b._totalRows){var a=bb.selector.query(b,".ui-table--scrollContainer");var d=a.scrollTop;if(d!=b._lastScrollTop){if(b._scrollableHeight==0){b._scrollableHeight=b.offsetHeight;}if(b._loadingMessageContainer.offsetTop-d<b._scrollableHeight){phe.rearrangeTable.loadData(b,false);}b._lastScrollTop=d;}}}};phe.rearrangeTable.saveInitialPosition=function(c){var a=bb.selector.query(c,".ui-table--scrollContainer tbody");c._originalPosition=[];for(var b=0;b<a.rows.length;b++){c._originalPosition.push(a.rows[b]);}};phe.rearrangeTable.saveIncrementalPosition=function(e){var b=bb.selector.query(e,".ui-table--scrollContainer tbody");var a=e._originalPosition.length,d=b.rows.length;if(a<d){for(var c=a;c<d;c++){e._originalPosition.push(b.rows[c]);}}};phe.rearrangeTable.checkPositionChange=function(e){var c=bb.selector.query(e,".ui-table--scrollContainer tbody");var b="data-benid";if(e&&e._originalPosition){var g=[];for(var d=0;d<e._originalPosition.length;d++){if(c.rows[d]!=e._originalPosition[d]){var f=bb.selector.query(e._originalPosition[d],"*["+b+"]");if(f&&f.getAttribute(b)){var a=f.getAttribute(b);g.push("benId:"+a+",oldPos:"+d+",newPos:"+this.getRowPosition(e._originalPosition[d]));}}}}return g;};phe.rearrangeTable.savePosition=function(c,f){var b=bb.selector.query(c,".ui-table--scrollContainer tbody");var a={};var d=c.getAttribute("dataFileSavePosition");if(d){var a=phe.rearrangeTable.checkPositionChange(c);var e={};e[gadgets.io.RequestParameters.METHOD]=gadgets.io.MethodType.POST;e[gadgets.io.RequestParameters.POST_DATA]=gadgets.io.encodeValues(a);absa.io.makeRequest(d,function(g){if(!g.errors.length){if(f){f(g);}}else{absa.showIOErrorMessage(c);}},e);}};phe.rearrangeTable.removePosition=function(a){if(a._originalPosition){a._originalPosition=[];}};phe.rearrangeTable.resetPosition=function(a){phe.rearrangeTable.removePosition(a);phe.table.empty(a);a._dataFile=a.getAttribute("dataFile");phe.rearrangeTable.loadData(a,true);};phe.rearrangeTable.showArrow=function(a){var c=bb.selector.queryAncestor(a,"tbody");if(c&&c.rows.length>1){var b=bb.selector.query(c,".ui-rearrangeTable_showRow");if(b){bb.html.removeClass(b,["ui-rearrangeTable_showRow","ui-rearrangeTable_showRowFirst","ui-rearrangeTable_showRowLast"]);b.setAttribute("aria-selected","false");this.unsetRadio(b);}bb.html.addClass(a,"ui-rearrangeTable_showRow");a.setAttribute("aria-selected","true");this.setRadio(a);if(c.rows[0]==a){bb.html.addClass(a,"ui-rearrangeTable_showRowFirst");}if(c.rows[c.rows.length-1]==a){bb.html.addClass(a,"ui-rearrangeTable_showRowLast");}if(bb.browser.ie&&bb.browser.version<=7){bb.selector.query(a,".ui-rearrangeTable-icons").style.zoom=1;bb.selector.query(a,".ui-rearrangeTable-icons").style.zoom=0;bb.selector.query(a,".ui-rearrangeTable-hint").style.zoom=1;bb.selector.query(a,".ui-rearrangeTable-hint").style.zoom=0;}}};phe.rearrangeTable.changePosition=function(b,a){var c=bb.selector.queryAncestor(b,"tbody");if(c&&c.rows.length>1){if(a<=(c.rows.length-1)){c.insertBefore(b,c.rows[a]);}else{c.appendChild(b);}}b.focus();this.showArrow(b);};phe.rearrangeTable.moveUp=function(a){phe.rearrangeTable.changePosition(a,phe.rearrangeTable.getRowPosition(a)-1);};phe.rearrangeTable.moveDown=function(a){phe.rearrangeTable.changePosition(a,phe.rearrangeTable.getRowPosition(a)+2);};phe.rearrangeTable.getRowPosition=function(a){var b=bb.selector.queryAncestor(a,"tbody");if(b){for(var c=0;c<b.rows.length;c++){if(b.rows[c]==a){return c;}}}return null;};phe.rearrangeTable.setRadio=function(a){var b=bb.selector.query(a,".ui-tableBodyCellContent input[type=radio]");if(b){b.checked=true;}};phe.rearrangeTable.unsetRadio=function(a){var b=bb.selector.query(a,".ui-tableBodyCellContent input[type=radio]");if(b){b.checked=false;}};phe.rearrangeTable.loadData=function(a,b){a._nbRows=bb.selector.queryAll(a,".ui-tableBodyRow").length;var c=[a._dataFile,(a._dataFile.indexOf("?")==-1)?"?":"&","&startRow=",a._nbRows,"&rowPacketSize=",a._rowPacketSize].join("");var d=function(e){if(b){phe.table.empty(a);}phe.rearrangeTable.tableFragment.innerHTML=e.text;var k=bb.selector.query(phe.rearrangeTable.tableFragment,"table");if(k){var m=bb.selector.query(a,".ui-table--scrollContainer table");var g=m.tBodies[0];m.parentNode.appendChild(phe.rearrangeTable.tableFragment);m.parentNode.removeChild(phe.rearrangeTable.tableFragment);a._totalRows=k.getAttribute("totalRows")||0;var j=bb.selector.queryAll(phe.rearrangeTable.tableFragment,"tr");var f=0;var l=0;for(var h=0;h<j.length;h++){g.appendChild(j[h]);}a._nbRows=bb.selector.queryAll(a,".ui-tableBodyRow").length;absa.util.copyAttributes(k,m);phe.rearrangeTable.saveIncrementalPosition(a);}};a._isLoading=true;if(a._loadingMessageContainer){a._loadingMessageContainer.style.display="";phe.loadingMessage.showLoadingMessage(a._loadingMessageContainer);}absa.io.makeRequest(c,function(h){a._isLoading=false;if(a._loadingMessageContainer){phe.loadingMessage.hideLoadingMessage(a._loadingMessageContainer);if(a._nbRows>=a._totalRows){a._loadingMessageContainer.style.display="none";}}if(!h.errors.length){d(h);}else{var f=bb.selector.query(a,".ui-tableBodyTBody");var j=bb.selector.query(f,".ui-tableBodyRow--ioErrorMessage");if(!j){var e="<tr class='ui-tableBodyRow ui-tableBodyRow--ioErrorMessage'><td colspan='30' class='ui-tableBodyCell'></td></tr>";var g=bb.html.createElementFromString(e);var i=bb.selector.query(g,".ui-tableBodyCell");absa.showIOErrorMessage(i);f.appendChild(g);}}});};</script><script type="text/javascript">var phe=window.phe||{};phe.fileUpload=new phe.FormElement;phe.fileUpload._timer1;phe.fileUpload.getValue=function(b){var a=bb.selector.query(b,".ui-fileUpload--value");return phe.FormElement.prototype.getAttribute.call(this,a,"value");};phe.fileUpload.setValue=function(a,b){throw"FileInput component is read-only!";};phe.fileUpload.getAttribute=function(b,c){var d=bb.selector.query(b,".ui-fileUpload--input"),a=bb.selector.query(b,".ui-fileUpload--value");switch(c){case"requiredText":case"showMeHow":return phe.Element.prototype.getAttribute.call(this,d,c);break;case"name":case"required":return phe.Element.prototype.getAttribute.call(this,a,c);break;default:return phe.Element.prototype.getAttribute.call(this,b,c);}};phe.fileUpload.setAttribute=function(b,c,e){var d=bb.selector.query(b,".ui-fileUpload--input"),a=bb.selector.query(b,".ui-fileUpload--value");switch(c){case"requiredText":case"showMeHow":phe.Element.prototype.setAttribute.call(this,d,c,e);break;case"name":case"required":phe.Element.prototype.setAttribute.call(this,oFileUploadHidden,c,e);break;default:phe.Element.prototype.setAttribute.call(this,b,c,e);}};phe.fileUpload.getFileName=function(a){return a._fileName;};phe.fileUpload.getFileSize=function(a){return a._fileSize;};phe.fileUpload.getFileType=function(a){return a._fileType;};phe.fileUpload.onUploadButtonClick=function(i){var o=bb.selector.query(i,".ui-fileUpload--input");if(o.value!=""){var c=true;var k=phe.fileUpload.getAttribute(i,"limitToFileTypes");if(k!=null){if(typeof k!="undefined"){if(k!=null&&k.length>0){var b=o.value;if(k.indexOf(",")>-1){var g=k.split(",");var j=false;for(x in g){var a=bb.string.trim(g[x].toLowerCase());if(b.toLowerCase().indexOf(a)>-1){j=true;}}if(j){c=true;}else{c=false;phe.helpText.showHelptext(o,o.getAttribute("fileTypeNotSupportedValidationText"));}}else{var a=bb.string.trim(k.toLowerCase());if(b.toLowerCase().indexOf(a)>-1){j=true;}else{c=false;phe.helpText.showHelptext(o,o.getAttribute("fileTypeNotSupportedValidationText"));}}}}}var l=phe.fileUpload.getAttribute(i,"targetFolder");if(l==null){l="";}if(c){var p=bb.selector.query(i,".ui-fileUpload--icon");bb.html.addClass(p,"ui-fileUpload_loading");bb.html.addClass(i,"ui-fileUpload_busy");var h=bb.selector.query(i,".ui-fileUpload--value"),f=bb.selector.query(i,".ui-fileUpload--label");var e="fileUpload-"+Math.round(Math.random()*1000000000000);h.id=e;var d=bb.selector.query(i,".ui-modal");if(d){phe.common.setAttribute(d,"data-id",e);}var n=phe.fileUpload.createStructure(e,k,l);f.name=e+"-label";f.value=o.value.replace(/^.*[\\\/]/,"");bb.html.addClass(h,"ui-fileUpload_working");phe.fileUpload.cloneFileInput(o);var m=bb.selector.query(n,"form");m.appendChild(o);m.submit();if(absa.TIMEOUT_BALANCE==null){absa.TIMEOUT_BALANCE=230000;}f._timeout=setTimeout(function(){phe.fileUpload.onServerTimeOut(i);},absa.TIMEOUT_BALANCE-30000);phe.fileUpload.startSessionKeepAlive();}}else{phe.helpText.showHelptext(o,o.getAttribute("fileNotSelectedValidationText"));}};phe.fileUpload.onCancelButtonClick=function(b){var a=bb.selector.query(b,".ui-fileUpload--icon");bb.html.removeClass(a,"ui-fileUpload_loading");phe.fileUpload.stopWindowIO(b);phe.fileUpload.resetElement(b);};phe.fileUpload.doResetFileUploadFromModal=function(e){var a=bb.selector.queryAncestor(e,".ui-modal");var c=phe.common.getAttribute(a,"data-id");phe.modal.hideModal();var b=document.getElementById(c);var d=bb.selector.queryAncestor(b,".ui-fileUpload");phe.fileUpload.onClearButtonClickB(d);};phe.fileUpload.onClearButtonClick=function(f){var e=phe.fileUpload.getAttribute(f,"showModalConfirmOnFileRemove");if(e=="true"){var c=bb.selector.query(f,".ui-fileUpload--confirmModal");phe.modal.showModal(0.5,c,f,true);}else{bb.html.removeClass(f,"ui-fileUpload_finish");var a=bb.selector.query(f,".ui-fileUpload--icon");a.setAttribute("class","ui-fileUpload--icon");var d=bb.selector.query(f,".ui-fileUpload--label");var b=bb.selector.query(f,".ui-fileUpload--value");b.value="";d.value="";}};phe.fileUpload.onClearButtonClickB=function(d){bb.html.removeClass(d,"ui-fileUpload_finish");var a=bb.selector.query(d,".ui-fileUpload--icon");a.setAttribute("class","ui-fileUpload--icon");var c=bb.selector.query(d,".ui-fileUpload--label");var b=bb.selector.query(d,".ui-fileUpload--value");b.value="";c.value="";};phe.fileUpload.onServerResponse=function(h,g){var a=h+"-container";var c=document.getElementById(a);var d=document.getElementById(h);var f=bb.selector.queryAncestor(d,".ui-fileUpload");var e=bb.selector.query(f,".ui-fileUpload--label");var b=bb.selector.query(f,".ui-fileUpload--icon");bb.html.removeClass(b,"ui-fileUpload_loading");f._fileName=g.fileName;f._fileSize=g.fileSize;f._fileType=g.fileType;e._timeout=clearTimeout(e._timeout);phe.fileUpload.stopSessionKeepAlive();if(g.status=="success"){phe.fileUpload.onUploadSuccess(f,g.fileID);}else{phe.fileUpload.onUploadFailure(f);}};phe.fileUpload.onServerTimeOut=function(c){var a=bb.selector.query(c,".ui-fileUpload--icon");bb.html.removeClass(a,"ui-fileUpload_loading");bb.html.addClass(a,"ui-fileUpload_error");var b=bb.selector.query(c,".ui-fileUpload--value");bb.html.removeClass(b,"ui-fileUpload_working");phe.fileUpload.stopWindowIO(c);phe.fileUpload.removeStructure(c);phe.fileUpload.stopSessionKeepAlive();};phe.fileUpload.onUploadSuccess=function(e,c){var a=bb.selector.query(e,".ui-fileUpload--icon");bb.html.addClass(a,"ui-fileUpload_success");bb.html.replaceClass(e,"ui-fileUpload_busy","ui-fileUpload_finish");var d=bb.selector.query(e,".ui-fileUpload--label");var b=bb.selector.query(e,".ui-fileUpload--value");b.value=c;bb.html.removeClass(b,"ui-fileUpload_working");d.blur();phe.fileUpload.removeStructure(e);phe.fileUpload.stopSessionKeepAlive();};phe.fileUpload.onUploadFailure=function(d){var a=bb.selector.query(d,".ui-fileUpload--icon");bb.html.addClass(a,"ui-fileUpload_error");bb.html.replaceClass(d,"ui-fileUpload_busy","ui-fileUpload_finish");var c=bb.selector.query(d,".ui-fileUpload--label");var b=bb.selector.query(d,".ui-fileUpload--value");bb.html.removeClass(b,"ui-fileUpload_working");c.blur();phe.fileUpload.removeStructure(d);phe.fileUpload.stopSessionKeepAlive();};phe.fileUpload.resetElement=function(c){bb.html.removeClass(c,"ui-fileUpload_busy");var b=bb.selector.query(c,".ui-fileUpload--label");var a=bb.selector.query(c,".ui-fileUpload--value");a.value="";b.value="";bb.html.removeClass(a,"ui-fileUpload_working");phe.fileUpload.removeStructure(c);};phe.fileUpload.stopWindowIO=function(c){var b=bb.selector.query(c,".ui-fileUpload--value");var a=window.frames[b.id+"-frame"].window;try{if(bb.browser.name!="ie"){a.stop();}else{a.document.execCommand("Stop");}}catch(d){}};phe.fileUpload.createStructure=function(c,b,d){var a=document.createElement("div");a.id=c+"-container";if(absa.CONTEXT==null){absa.CONTEXT="/absa-online";}a.innerHTML='<form novalidate method="POST" target="'+c+'-frame" action="'+absa.CONTEXT+'/FileUpload" enctype="multipart/form-data"><input type="text" name="nonce" value="'+absa.NONCE+'" /><input type="text" name="processId" value="'+c+'" /><input type="text" name="limitToFileTypes" value="'+b+'" /><input type="text" name="targetFolder" value="'+d+'" /></form><iframe name="'+c+'-frame" style="display:none"></iframe>';document.body.appendChild(a);return a;};phe.fileUpload.removeStructure=function(d){var c=bb.selector.query(d,".ui-fileUpload--value");var a=c.id+"-container";var b=document.getElementById(a);b.parentNode.removeChild(b);};phe.fileUpload.cloneFileInput=function(b){var a=b.cloneNode(true);bb.html.addEventListener(a,"mouseover",function(c){var d=bb.browser.ie?c.srcElement:c.currentTarget;absa.showMeHow.showHelpText(d);});bb.html.addEventListener(a,"mouseout",function(c){phe.helpText.hideHelptext();});if(b.nextSibling){b.parentNode.insertBefore(a,b.nextSibling);}else{b.parentNode.appendChild(a);}a.value="";};phe.fileUpload.startSessionKeepAlive=function(){clearInterval(phe.fileUpload._timer1);phe.fileUpload._timer1=setInterval(function(){phe.fileUpload.sessionKeepAlive();},10000);};phe.fileUpload.stopSessionKeepAlive=function(){clearInterval(phe.fileUpload._timer1);clearInterval(phe.fileUpload._timer1);};phe.fileUpload.sessionKeepAlive=function(){absa.io.makeRequest("proxy?pipe=genericWebservice&ws=SecurityWebService&action=sessionKeepAlive",function(a){if(a.text.indexOf("false")<0){}else{clearInterval(phe.fileUpload._timer1);absa.index.doLogout();}});};</script><script type="text/javascript">var phe=window.phe||{};phe.captchaCheck=new phe.Element;if(absa.CONTEXT==null){absa.CONTEXT="/absa-online";}phe.captchaCheck.refreshChallenge=function(e){var a=bb.selector.queryAncestor(e,".ui-captchaCheck");var b=bb.selector.query(a,".ui-captchaCheck--iconSound");if(bb.html.hasClass(b,"ui-captchaCheck--iconHide")){var d=bb.selector.query(a,".ui-captchaCheck_iframe");d.src=absa.CONTEXT+"/captchaSnd.wav?uniq="+new Date().getTime();}else{var c=bb.selector.query(a,".ui-captchaCheck_img");c.src=absa.CONTEXT+"/captchaImg?uniq="+new Date().getTime();}};phe.captchaCheck.getSoundChallenge=function(e){var a=bb.selector.queryAncestor(e,".ui-captchaCheck");var c=bb.selector.query(a,".ui-captchaCheck--iconImage");bb.html.addClass(e,"ui-captchaCheck--iconHide");bb.html.removeClass(c,"ui-captchaCheck--iconHide");var b=bb.selector.query(a,".ui-captchaCheck_img");b.src=absa.CONTEXT+"/static/style/resources/jcaptchaSnd.jpg";var d=bb.selector.query(a,".ui-captchaCheck_iframe");d.src=absa.CONTEXT+"/captchaSnd.wav";};phe.captchaCheck.getImageChallenge=function(e){var a=bb.selector.queryAncestor(e,".ui-captchaCheck");var b=bb.selector.query(a,".ui-captchaCheck--iconSound");bb.html.addClass(e,"ui-captchaCheck--iconHide");bb.html.removeClass(b,"ui-captchaCheck--iconHide");var c=bb.selector.query(a,".ui-captchaCheck_img");c.src=absa.CONTEXT+"/captchaImg";var d=bb.selector.query(a,".ui-captchaCheck_iframe");d.src=absa.CONTEXT+"/static/style/resources/dot.gif";};phe.captchaCheck.help=function(a){};phe.captchaCheck.testCaptcha=function(d,f){var a=bb.selector.query(d,".ui-captchaCheck-textBox");if(a==null){a=bb.selector.queryAll(document.body,".ui-captchaCheck-textBox")[0];}var c="";if(a==null){c="";}else{c=phe.textBox.getValue(a);}var b={CaptchaTxt:c};var e={};e[gadgets.io.RequestParameters.METHOD]=gadgets.io.MethodType.POST;e[gadgets.io.RequestParameters.POST_DATA]=gadgets.io.encodeValues(b);absa.io.makeRequest(absa.CONTEXT+"/captchaCheck",f,e);};phe.captchaCheck.testCaptchaTxt=function(c,d){var a={CaptchaTxt:c};var b={};b[gadgets.io.RequestParameters.METHOD]=gadgets.io.MethodType.POST;b[gadgets.io.RequestParameters.POST_DATA]=gadgets.io.encodeValues(a);absa.io.makeRequest(absa.CONTEXT+"/captchaCheck",d,b);};</script><script type="text/javascript">var phe=window.phe||{};phe.iFrame=new phe.Element;phe.iFrame.initialize=function(b){var j=bb.selector.query(b,".ui-iFrame-container");var u=bb.selector.queryAll(b,".ui-iFrame-setup");var g=false;if(u!=null){for(var p=0;p<u.length;p++){var s=new Date().getTime();var x=u[p].getAttribute("xclass");var e=u[p].getAttribute("xstyle");var f=u[p].getAttribute("xname");var l=u[p].getAttribute("xid");var w=u[p].getAttribute("xtarget");var q=u[p].getAttribute("xsrc");var c=u[p].getAttribute("xwidth");var m=u[p].getAttribute("xheight");var v=u[p].getAttribute("xframeborder");var r=u[p].getAttribute("xscrolling");var h=u[p].getAttribute("xonload");if(x!=null){if(x.indexOf("special-case-quote-pdf")>-1){g=true;}}var t=document.createElement("iframe");var n=u[p].attributes;for(var i=0;i<n.length;i++){var d=n[i];if(d.name.indexOf("data-")>-1){t.setAttribute(d.name,d.value);}}if(x!=null){t.setAttribute("class",x+" ui-iFrame-"+s);}if(e!=null){t.style=e;}if(f!=null){t.name=f;}if(l!=null){t.id=l;}if(w!=null){t.target=w;}if(c!=null){t.width=c;}if(m!=null){t.height=m;}if(v!=null){t.frameBorder=v;}if(r!=null){t.scrolling=r;}var o="";if(q!=null){if(q.indexOf("nonce")==-1){if(q.indexOf("?")==-1){q+="?nonce="+absa.NONCE;}else{q+="&nonce="+absa.NONCE;}}if(g){var a="scifrm_"+s;o="<!DOCTYPE html><head><title>-</title><meta http-equiv='X-UA-Compatible' content='IE=10; IE=9; IE=8' /><meta http-equiv='Pragma' content='no-cache' /><meta http-equiv='Cache-Control' content='no-cache, no-store' /><meta http-equiv='Expires' content='Thu, 01 Jan 1970 00:00:00 GMT' /><meta http-equiv='Access-Control-Allow-Headers' content='Content-Type, If-Modified-Since'><meta http-equiv='Access-Control-Allow-Methods' content='GET, POST, HEAD'><meta http-equiv='Access-Control-Allow-Origin' content='*'></head><script> var initialLoadDone = false;  var continuePolling = true;  function doLoadPDFQuote(oIFrame) {  if (initialLoadDone == false) {    var srcPDF = oIFrame.getAttribute('data-src');    oIFrame.setAttribute('src',srcPDF);    initialLoadDone = true;    setTimeout(function(){ pollThisIFrame(); },2000);   }  }  function pollThisIFrame() {    if (continuePolling) {     var oIFrame = document.getElementById('"+a+"');     try {       var contentType = '';       if (oIFrame != null) {         contentType = oIFrame.contentType || oIFrame.mimeType;         if (contentType == null) {           var oIFrameCW = (oIFrame.contentWindow || oIFrame.contentDocument);           if (oIFrameCW != null) {             contentType = (oIFrameCW.document.contentType || oIFrameCW.document.mimeType);           }         }       }       if (contentType != null && contentType.indexOf('pdf') > -1) {        postMessageToParent();        continuePolling = false;       } else {        setTimeout(function(){ pollThisIFrame(); },2000);       }     } catch (ee) {       if ((ee.message.indexOf('No such interface supported') > -1) | (ee.message.indexOf('Permission denied to access property') > -1)) {          if (oIFrame.src.indexOf('.pdf') > -1) {            postMessageToParent();            continuePolling = false;          } else {            setTimeout(function(){ pollThisIFrame(); },2000);          }       }     }    }  }  function postMessageToParent() {    var target = parent.postMessage ? parent : (parent.document.postMessage ? parent.document : undefined);    if(typeof target != 'undefined' && document.body.scrollHeight){       target.postMessage('PDF', '*');    }  } <\/script><body style='padding:0px; margin:0px;'><iframe onload='doLoadPDFQuote(this)' id='"+a+"' ";if(x!=null){o+=" class='"+x+" ui-iFrame-"+s+"' ";}if(e!=null){o+=" style='"+e+"' ";}if(f!=null){o+=" name='"+f+"' ";}if(c!=null){o+=" width='"+c+"' ";}if(m!=null){o+=" height='"+m+"' ";}if(v!=null){o+=" frameborder='"+v+"' ";}if(r!=null){o+=" scrolling='"+r+"' ";}if(q!=null){o+=" src='/absa-online/static/style/resources/empty.html' ";}if(q!=null){o+=" data-src='"+q+"' ";}if(h!=null){o+=" data-onload='"+h+"' ";}o+="><h3>Loading...</h3></iframe></body></html>";}else{if(h!=null){t.onload=function(){setTimeout(function(){phe.iFrame._executeFunctionByName(h,window,[]);},2000);};}o="<!DOCTYPE html><head><title>-</title><meta http-equiv='X-UA-Compatible' content='IE=10; IE=9; IE=8' /><meta http-equiv='Pragma' content='no-cache' /><meta http-equiv='Cache-Control' content='no-cache, no-store' /><meta http-equiv='Expires' content='Thu, 01 Jan 1970 00:00:00 GMT' /><meta http-equiv='X-Frame-Options' content='SAMEORIGIN' /></head><body>"+absa.locale["Common/General/Label/Loading"]+"...<form novalidate name='initIFrame"+s+"' id='initIFrame"+s+"' method='POST' action='"+q+"'></form><script language='javascript'>function doInitIFrame"+s+"(){  var tF = document.getElementById('initIFrame"+s+"');  tF.submit(); } doInitIFrame"+s+"(); <\/script></body></html>";}setTimeout(function(){j.appendChild(t);absa.initializeNewContent(t);var k=(t.contentWindow||t.contentDocument);if(k.document){k=k.document;}if(o!=""){k.open("text/html");k.write(o);k.close();}},2000);}}}};phe.iFrame._executeFunctionByName=function(f,c,g){var a=[].slice.call(g).splice(2);var e=f.split(".");var d=e.pop();d=d.replace("()","");for(var b=0;b<e.length;b++){e[b]=e[b].replace("()","");c=c[e[b]];}return c[d].apply(window,a);};phe.iFrame.goTo=function(b,a){var d=b;if(typeof b=="object"){if(b.nodeName=="DIV"){d=b;b=bb.selector.query(b,".ui-iFrame");}else{d=b.previousSibling;}}if(b!=null&a!=null){if(a.indexOf("nonce")==-1){if(a.indexOf("?")==-1){a+="?nonce="+absa.NONCE;}else{a+="&nonce="+absa.NONCE;}}var f=(b.contentWindow||b.contentDocument);if(f.document){f=f.document;}var c=new Date().getTime();var e="<!DOCTYPE html><head><title>-</title><meta http-equiv='X-UA-Compatible' content='IE=10; IE=9; IE=8' /><meta http-equiv='Pragma' content='no-cache' /><meta http-equiv='Cache-Control' content='no-cache, no-store' /><meta http-equiv='Expires' content='Thu, 01 Jan 1970 00:00:00 GMT' /><meta http-equiv='X-Frame-Options' content='SAMEORIGIN' /></head><body>...<form novalidate name='initIFrame"+c+"' id='initIFrame"+c+"' method='POST' action='"+a+"'></form><script language='javascript'>function doInitIFrame"+c+"(){  var tF = document.getElementById('initIFrame"+c+"');  tF.submit(); } doInitIFrame"+c+"(); <\/script></body></html>";f.open("text/html");f.write(e);f.close();}};phe.iFrame.setAttribute=function(a,e,f){if(a!=null&(e!=null&&e!="")){var d=a;if(typeof a=="object"){if(a.nodeName=="DIV"){d=a;a=bb.selector.query(a,".ui-iFrame");}else{d=a.previousSibling;}}if(a!=null&e!=null){if(f==""){if(d!=null){d.removeAttribute("x"+e);}a.removeAttribute(e);}else{switch(e){case"onload":if(d!=null){phe.Element.prototype.setAttribute.call(this,d,"xonload",f);}phe.Element.prototype.setAttribute.call(this,a,"onload",f);var b=phe.iFrame.getAttribute(a,"onload");if(b!=null){var c=phe.iFrame.getAttribute(a,"onload");if(c!=null&&c!=""){a.onload=function(){if(c!=null){phe.iFrame._executeFunctionByName(c,window,[]);}};}}break;case"src":phe.iFrame.goTo(a,f);default:phe.Element.prototype.setAttribute.call(this,a,e,f);}}}}};phe.iFrame.getAttribute=function(b,d){if(b!=null){var c=b;if(typeof b=="object"){if(b.nodeName=="DIV"){c=b;b=bb.selector.query(c,".ui-iFrame");}else{c=b.previousSibling;}}switch(d){case"onload":var a=phe.Element.prototype.getAttribute.call(this,b,"onload");if(a==null){a=phe.Element.prototype.getAttribute.call(this,c,"xonload");}return a;break;default:var a=phe.Element.prototype.getAttribute.call(this,b,d);if(a==null){a=phe.Element.prototype.getAttribute.call(this,c,"x"+d);}return a;}}};</script><script type="text/javascript">var phe=window.phe||{};phe.clientAgreement=new phe.Element;phe.clientAgreement.STATUS=-999;phe.clientAgreement.initialize=function(b){var a=bb.selector.query(b,".ui-clientAgreement");if(a!=null){if(phe.clientAgreement.STATUS==-999){phe.clientAgreement._hasClientAcceptedAgreement(a);}else{if(phe.clientAgreement.STATUS==1){phe.clientAgreement._showAcceptedView(a);}else{phe.clientAgreement._showNotAcceptedYetView(a);}}}};phe.clientAgreement._hasClientAcceptedAgreement=function(a){absa.io.makeRequest("proxy?pipe=genericWebservice&ws=PersonalInformationWebService&action=getClientAgreementDetails",function(d){var e=bb.html.createElementFromString(d.text);var c=bb.selector.query(e,".ap-getClientAgreementDetails-clntAgrmntAccepted");if(c){var b=phe.hiddenField.getValue(c);if(b=="Y"){phe.clientAgreement.STATUS=1;phe.clientAgreement._showAcceptedView(a);}else{phe.clientAgreement.STATUS=0;phe.clientAgreement._showNotAcceptedYetView(a);}}});};phe.clientAgreement._acceptAgreement=function(a){var b=bb.selector.queryAncestor(a,".ui-form");if(b!=null){phe.loadingMessage.showLoadingMessage(b);}absa.io.makeRequest("proxy?pipe=genericWebservice&ws=PersonalInformationWebService&action=setClientAgreementDetails",function(g){var h=bb.html.createElementFromString(g.text);var d=bb.selector.query(h,".ap-applyButtonCheck-setClientAgreementDetails");if(d!=null){var c=phe.hiddenField.getValue(d);if(c=="true"){phe.clientAgreement.STATUS=1;}if(phe.clientAgreement.STATUS==1){var f=bb.selector.queryAncestor(a,".ui-clientAgreement");if(f){phe.clientAgreement._showAcceptedView(f);}}else{absa.modal.loadModal("proxy?pipe=genericWebservice&ws=PersonalInformationWebService&action=setClientAgreementDetails&view=modal",absa.locale["Common/General/Error/TechnicalError"]);var e=bb.selector.query(a,".ui-clientAgreement-chkBox");if(e!=null){e.checked=false;}}}if(b!=null){phe.loadingMessage.hideLoadingMessage(b);}});};phe.clientAgreement._showAcceptedView=function(d){if(d!=null){var b=bb.selector.query(d,".ui-clientAgreement-NO");var a=bb.selector.query(d,".ui-clientAgreement-YES");if(absa.CLIENTTYPE=="B"){if(a){var c=bb.selector.query(a,".ui-clientAgreement-YES-business");if(c){phe.common.show(c);}}}else{if(a){var e=bb.selector.query(a,".ui-clientAgreement-YES-personal");if(e){phe.common.show(e);}}}if(b){phe.common.hide(b);}if(a){phe.common.show(a);}}};phe.clientAgreement._showNotAcceptedYetView=function(d){if(d!=null){var b=bb.selector.query(d,".ui-clientAgreement-NO");var a=bb.selector.query(d,".ui-clientAgreement-YES");if(absa.CLIENTTYPE=="B"){if(b){var c=bb.selector.query(b,".ui-clientAgreement-NO-business");if(c){phe.common.show(c);}}}else{if(b){var e=bb.selector.query(b,".ui-clientAgreement-NO-personal");if(e){phe.common.show(e);}}}if(a){phe.common.hide(a);}if(b){phe.common.show(b);}}};phe.clientAgreement.loadAgreement=function(){phe.clientAgreement._loadAgreement();};phe.clientAgreement._loadAgreement=function(){absa.openReport("/absa-online/report/clientAgreement/docfusion.pdf?clientAgreementIn="+absa.CLIENTTYPE+"&amp;forceDownload=false");};phe.clientAgreement.setAttribute=function(a,b,c){if(a!=null){phe.Element.prototype.setAttribute.call(this,a,b,c);}};phe.clientAgreement.getAttribute=function(b,c){if(b!=null){var a=phe.Element.prototype.getAttribute.call(this,b,c);if(a==null){a=phe.Element.prototype.getAttribute.call(this,b,"data-"+c);}return a;}else{return null;}};</script><script type="text/javascript">var phe=window.phe||{};phe.qrCode=new phe.Element;phe.qrCode.STATUS=-999;phe.qrCode.initialize=function(b){var c=bb.selector.queryAll(b,".ui-qrCode");if(c!=null){for(var a=0;a<c.length;a++){}}};phe.qrCode.setAttribute=function(a,b,c){if(a!=null){phe.Element.prototype.setAttribute.call(this,a,b,c);}};phe.qrCode.getAttribute=function(b,c){if(b!=null){var a=phe.Element.prototype.getAttribute.call(this,b,c);if(a==null){a=phe.Element.prototype.getAttribute.call(this,b,"data-"+c);}return a;}else{return null;}};phe.qrCode.reload=function(b,d,a){if(b!=null){var f=phe.qrCode.getAttribute(b,"uniqueNumber");if(d!=null&&d!="null"){f=d;}var e=phe.qrCode.getAttribute(b,"size");if(a!=null&&a!="null"){e=a;}phe.qrCode.setAttribute(b,"uniqueNumber",f);phe.qrCode.setAttribute(b,"size",e);var c=bb.selector.query(b,".ui-qrCode-img-src");if(c){c.setAttribute("src","/absa-online/qrCode?theMsg="+f+"&theSize="+e+"&uniq="+new Date().getMilliseconds());}}};</script><script type="text/javascript">phe.layout={};phe.layout.init=function(){var b=bb.document.getElementById("portal");var a=b.getProperty("activeContainer");this.showHide(a.getPreference("title"));b.addEventListener("activateContainer",function(c){phe.layout.showHide(c.target.getPreference("title"));},false);};phe.layout.showHide=function(a){var b=document.getElementById("ap-container-wrapper");bb.html.removeClass(b,"ap-accounts-container");bb.html.removeClass(b,"ap-payments-container");bb.html.removeClass(b,"ap-profile-container");bb.html.removeClass(b,"ap-insurances-container");bb.html.removeClass(b,"ap-apply-container");bb.html.removeClass(b,"ap-save-invest-container");if(a=="saveInvest"){bb.html.addClass(b,"ap-save-invest-container");}else{if(a=="Accounts"){bb.html.addClass(b,"ap-accounts-container");}else{if(a=="Payments"){bb.html.addClass(b,"ap-payments-container");}else{if(a=="Insurance"){bb.html.addClass(b,"ap-insurances-container");}else{if(a=="Profile"){bb.html.addClass(b,"ap-profile-container");}else{if(a=="Apply"){bb.html.addClass(b,"ap-apply-container");}}}}}}};</script><script type="text/javascript" src="./front_2_files/willAll.js.download"></script><style type="text/css">
			.ap-customerSelfUpgrade-applyPadding{
				padding-right:160px;
			}
		</style><style type="text/css">
			.ap-homeLoanSwitch-applyPadding{
				padding-right:160px;
			}
			.ap-offersHomeLoanSwitch-furtherAdvanceFunds{
				height:	20px;
				text-align: center;
				max-width:	109px;
				padding-left: 0px;
				padding-right: 0px;
			}
			.ap-homeLoanSwitch-imagePadding{
				height:	60px;
			}
		</style><style type="text/css">
		.avafSlider .ui-slider-rail {
			width: 880px;
			height: 5px;
			text-align: left;
		}
		
		.avafSlider .ui-slider--inputContainer {
			visibility: hidden;
		}
		
		.ap-avafOffers-amounts {
			border: 1px solid;
			border-radius: 4px;
			/*background: #D01010;*/
			color: #FFFFFF;
			text-align: center;
			font-size: 13pt;
			width: 180px;
			overflow: hidden;
			height: 40px !important; 
			padding-top: 0px !important;
			/* Resonance - NEW */
			background: #870A3C;
		}
		.ap-avafOffers-mnth {
			font-size: 15pt;
			padding-right: 5px;
		}
		
		.ap-avafOffers-mnth-label {
			width: 20px;
			color: GrayText;
		}
		
		.ap-avafOffers-percent {
			font-size: 12pt;
		}
		.ap-avafOffers-balloonAmt {
			border: 1px solid;
			border-radius: 4px;
			/*background: #D01010;*/
			color: #FFFFFF;
			text-align: center;
			font-size: 13pt;
			width: 150px;
			overflow: hidden;
			height:40px !important; 
			padding-top: 0px !important;
			/* Resonance - NEW */
			background: #870A3C;
		}
		
		.ap-avafOffers-cellWidths {
			width: 33%;
		}
		
		.ap-avafOffers-centerText {
			text-align: center;
		}
		
		.ap-avafOffers-12MonthsPadding {
			padding-left:14px ;
		}
		
		.ap-avafOffers-72MonthsPadding {
			padding-right:11px ;
		}
		.ap-avafOffers-0PercentPadding {
			padding-left:15px ;
		}
		.ap-avafOffers-5PercentPadding {
			padding-left:10px ;
		}
		.ap-avafOffers-10PercentPadding {
			padding-left:4px ;
		}
		.ap-avafOffers-30PercentPadding {
			padding-right:10px ;
		}
		.ap-avafOffers-balloonPadding{
			padding-right: 24px ;
		}
		
		.ap-avafOffers-balloonPaymentTxt{
			width:24px ; 
			height:15px ;
		}
		.ap-avafOffers-termAllowedTxt{
			width:14px ; 
			height:15px ;
		}
		
		.ap-avafOffers-callCenterNo{
			/*color:#D01010;*/
			padding-left:5px;
			/* Resonance - NEW */
			color: #870A3C;
		}
		.ap-avafOffers-buttonPadding{
			padding-right:15px !important;
			
		}
		.ap-avafOffers-TnC{
			margin:0px 10px;
		}
		</style><style type="text/css">
		</style><style type="text/css">
		.insuranceslider .ui-slider-rail {
			width: 600px;
			height: 5px;
		}
		
		.insuranceslider .ui-slider--inputContainer {
			visibility: hidden;
		}
		
		.insuranceslider .ui-slider-grippy {
			height:20px;
		}
		
		.ap-myAbsaOffers-insPremium {
			border: 1px solid;
			border-radius: 4px;
			/*background: #D01010;*/
			color: #FFFFFF;
			text-align: center;
			font-size: 20pt;
			width: 150px;
			overflow: hidden;
			/* Resonance - NEW */
			background: #870A3C;
		}
		</style><style type="text/css">
			.ap-customerSelfUpgrade-applyPadding{
				padding-right:160px;
			}
		</style><style type="text/css">
		.ap-overdraft-tabletrow {
			
		}
		.ap-overdraft-redbox {
			border: 1px solid;
			border-radius: 4px;
			/*background: #D01010;*/
			color: #FFFFFF;
			text-align: center;
			font-size: 20pt;
			width:200px; 
			padding-top: 10px;
			/* Resonance - NEW */
			background: #870A3C;
		}
		
		.ap-overdraft-tabletcell {
			 height:50px;
			 margin:0px 0px 0px 0px; 
			 padding:0px 0px 0px 0px;
			 font-size: 20px;
			 text-align: center;
		}
		
		.ap-overdraft-tabletred {
			/*background-color: #D01010;*/
			text-align:center;
			margin:0px 0px 0px 0px; 
			padding:0px 0px 0px 0px; 
			border-right: 0px;
			height: 40px;
			color: white;
			border-radius:4px 0px 0px 4px;
			vertical-align: middle;
			/* Resonance - NEW */
			background-color: #870A3C;
		}
		
		.ap-overdraft-tabletgreen {
			background-color: green;
			text-align:center;
			margin:0px 0px 0px 0px; 
			padding:0px 0px 0px 0px;  
			border-left: 0px;
			height: 40px;
			color: white;
			border-radius:0px 4px 4px 0px;
			vertical-align: middle;
		}
		
		.ap-overdraft-tabletredText {
			height:40px; 
			padding:0px 0px 0px 0px; 
			text-align: center; 
			vertical-align: middle;
		}
		
		.ap-overdraft-tabletgreenText {
		 	height:40px; 		 	
		 	text-align: center; 
		 	vertical-align: middle;			
		}
		.ap-bbEXOD-pieBorder .ui-graph-paper {
			border-top:0px !important;
		}
		.ap-bbOverdraft-modalWidth{
			width:450px;
		}
		.ap-bbOverdraft-list {
			margin-bottom:10px;
		}
		.ap-bbOverdraft-list li{
			list-style-type:disc;
			list-style-position:inside;
		}
		</style><style type="text/css">
			.ap-stHomeOwner-cellWidth30{
				width:30%;
			}
			.ap-stHomeOwner-cellWidth70{
				width:70%;
			}
			.ap-stHomeOwner-selectBoxWidth{
				width:215px;
			}
			.shortTermslider .ui-slider-rail {
			width: 700px;
			height: 5px;
			}	
			.shortTermslider .ui-slider--inputContainer {
				visibility: hidden;
			}

 			.ap-shortTermslider-aligncovervalue5 {
			 padding-left: 10px;
    		 padding-right: 2px;
    		 text-align: center;
    		 height:0px;
    		 width:60px;
			}
			
			.ap-shortTermslider-aligncovervaluehs1 {
    		 padding-right: 5px;
    		 text-align: center;
    		 height:0px;
    		 width:60px;	
			}
			
			.ap-shortTermslider-slidercell{
				padding-left : 0px;
			  	padding-right: 0px;
			  	height:0px;
			  	width:65px;
			}
			.ap-stHomeContent-slidercell{
				padding-left : 5px;
			  	padding-right: 0px;
			  	height:0px;
			  	width:65px;
			}
			.ap-stHomeContent-lastSliderCell{
				padding-left : 1px;
			  	height:0px;
			  	width:65px;
			}
			.ap-shortTermSliderMsg-rightpadding {
			   padding-right: 0px;
			}
			
			.ap-shortTermSliderLast-rightpadding {
			   padding-right: 10px;
			}
			.ap-shortTermslider-aligncovervalue10 {
				  padding-right: 0px;
				  width:65px;
				  }
			.ap-shortTerm-premiumAmountBox{
				border: 1px solid;
				border-radius: 4px;
				/*background: #D01010;*/
				color: #FFFFFF;
				text-align: left;
				font-size: 11pt;
				width: 90px;
				height: 25px;
				/* Resonance - NEW */
				background: #870A3C;
			}
			.ap-shortTerm-leftRightPadding{
				padding-left: 	10px;
				padding-right: 	10px;
			}
			.ap-shortTerm-premiumAmountBoxMO{
				border: 1px solid;
				border-radius: 4px;
				/*background: #D01010;*/
				color: #FFFFFF;
				text-align: left;
				font-size: 11pt;
				width: 90px;
				height: 25px;
				/* Resonance - NEW */
				background: #870A3C;
			}
		</style><style type="text/css">
			.ap-homeLoanFurtherAdvance-applyPadding{
				padding-right:160px;
			}
			.ap-offersHomeLoanFurtherAdvance-furtherAdvanceFunds{
				height:	20px;
				text-align: center;
				max-width:	109px;
				padding-left: 0px;
				padding-right: 0px;
			}
		</style><style type="text/css">
.ap-composeSecureMessages-buttonFooter {
	border-left: 1px solid #C8C8C8;
	margin-left: 0;
	margin-right: 8px;
	width: 100%;
	border-right: 1px solid #C8C8C8;
}

.ap-composeMessage-formFoot{
	border-top: 0px;
	margin-left: 5px;
	margin-right: 5px;
}

.ap-composeSecureMessages-messageTextLabelContainer {
	margin-left: -5px;
	
}

.ap-composeSecureMessages-messageTextAPBLabelContainer {
	
	float: right;
	text-align : right;
	width: 300px
}

.ap-composeSecureMessages-textBox {
	width: 147px;
}

.ap-composeSecureMessages-select {
	width: 155px;
}

.ap-secureMessages-inboxMessageTextScrollContainer{
	border-width: 0;
	overflow-x: hidden;
	overflow-y: auto;
	position: relative;
	height: 165px;
}
.ap-secureMessages-buttonsContainer{
	padding-right:4px;
}

.ap-secureMessages-tableHeadButton .ui-tableHeadCell--content{
	padding: 0px;
	height: 28px;
}


.ap-secureMessages-noPadding {
	padding-left: 0px;
	padding-right: 0px;
}

.ap-composeSecureMessages-messageText {
	height: 78px;
	margin-left: -5px;
	margin-top: 5px;
	width: 102.1%;
}

.ap-composeSecureMessages-datePickerCell {
	padding-right: 18px;
}

.ap-composeSecureMessages-detailsContainer {
	vertical-align: top;
}

.ap-viewArchivedSecureMessageContent-borderBottom {
	border-bottom: 1px solid #c8c8c8;
}

.ap-secureMessages-boldFontWeight {
	font-weight: bold;
}

.ap-secureMessages-topVerticalAlign {
	vertical-align: top;
}

.ap-secureMessageViewArchivedStatements-sendTypeSelect {
	width: 106px;
}

.ap-secureMessages-modalMessageTextCell {
	padding: 10px;
}

.ap-secureMessages-borderTop {
	border-top: 1px solid #c8c8c8;
}

.ap-viewSentSecureMessageContent-cell20percent{
	width:20%;
}

.ap-viewSentSecureMessageContent-headerButtonsSpan {
	text-align: right;
}

.ap-viewSentSecureMessageContent-headerButtonCellTrnsactionEnquiry {
	padding-right: 0px;
}

.ap-secureMessages-borderBottom {
	border-bottom: 1px solid #c8c8c8;
}

.ap-viewReceivedSecureMessageContent-messageText {
	height: 78px;
	margin-left: 4px;
	margin-top: 4px;
	width: 863px;
}

.ap-viewSentSecureMessageContent-messageText {
	height: 78px;
	width: 855px;
	padding: 5px;
}

.ap-secureMessages-inboxMessageTextScrollContainer li{
	list-style: disc outside none;
	margin-left: 13px;
}

.ap-viewSecureMessages-messageSubjectContainer{
	cursor: pointer;
}

.ap-viewUnitTrustPriceWatch-Text {
	text-align: right;
}

.ap-viewUnitTrustPriceWatch-dailymoveup {
	color: #009712;
}

.ap-viewUnitTrustPriceWatch-dailymovedown {
	color: #D81E00;
}

.ap-viewUnitTrustPriceWatch-factsheet {
	vertical-align: center;
}

.ap-viewUnitTrustPriceWatch-error {
	padding-top: 3px;
}

.ap-viewUnitTrustPriceWatch-header {
	padding-left: 10px;
	line-height: 30px;
}

.ap-viewUnitTrustPriceWatch-source {
	text-align: right;
}

.ap-viewUnitTrustPriceWatch-prices {
	border-bottom: 1px solid #C9C9C9;
}

.ap-viewUnitTrustPriceWatch-errorMessage {
	width: 680px;
}

.ap-viewCalculator-link {
	color:				gray;
	text-decoration:	none;
}
.ap-viewCalculator-resultRow{
	background-color:	#f4f4f4;
}
.ap-viewCalculator-link:hover {
	/*color: red;*/
	text-decoration:	underline;
	/* Resonance - NEW */
	color: #AF154B;
}

.ap-viewCalculator-noRightPadding {
	padding-right:	0px;
}

.ap-viewCalculator-noMarginLeft {
	float:	right;
	width:	18px;
}

.ap-viewCalculator-width100 {
	width:			100px;
	text-align:		right;
}

.ap-viewCalculator-width130 {
	width:		130px;
	text-align:	right;
}

.ap-viewCalculator-width20 {
	width:	20%;
}

.ap-viewCalculator-width40 {
	width:	40%;
}

.ap-viewCalculator-width25 {
	width:	25%;
}

.ap-viewCalculator-width15 {
	width:	15%;
}

.ap-viewCalculator-width5 {
	width:	5%;
}

.ap-viewCalculator-width95 {
	width:	95%;
}

.ap-viewCalculator-modalBody {
	height:		300px;
	width:		600px;
	overflow-x:	hidden;
	overflow-y:	auto;
	position:	relative;
}

.ap-viewExchangeRate-error {
	height: 178px;
}

.ap-viewExchangeRate-lastUpdated {
	width: 70%;
}

.ap-viewExchangeRate-alternateRow {
	background-color: #f4f4f4;
}

.ap-viewSensNews-newsHeadLine {
	height: 19px;
	line-height: 19px;
}

.ap-viewSensNews-modalBody {
	height: 300px;
	width: 750px;
}

.ap-viewSensNews-scroll {
	height: 150px;
	overflow-y: auto;
}

.ap-viewSensNews-articleDate {
	width: 30%;
	vertical-align: top;
}

.ap-viewSensNews-articleRoot {
	overflow-y: auto;
	overflow-x: hidden;
	height: 268px;
}

.ap-viewSensNews-error {
	height: 178px;
}

.ap-viewSensNews-cellLink {
	text-decoration: none;
	color: #646464;
}

.ap-viewSensNews-cellLink:hover {
	text-decoration: underline;
}

.ap-viewSensNews-lastUpdated {
	width: 70%;
}

.ap-viewSensNews-alternateRow {
	background-color: #f4f4f4;
}

.ap-changeAccountGraph-head {
	border-bottom:	1px solid #c0c0c0;
}

.ap-changeAccountGraph-tabBodies {
	position: relative;
}

.ap-changeAccountGraph-gridrow-alt {
	background-color:	#f4f4f4;
}

.ap-changeAccountGraph-gridlist {
	border-top:	1px solid #c0c0c0;
}

.ap-changeAccountGraph-tabBody {
	height:	182px;
}

.ap-changeAccountGraph-link {
	color:				gray;
	text-decoration:	none;
	font-weight:		bold;
}

.ap-changeAccountGraph-link:hover {
	/*color: red;*/
	text-decoration:	underline;
	/* Resonance - NEW */
	color: #AF154B;
}

.ap-changeSaveAndInvestGraph-gridrow-alt {
	background-color:	#f4f4f4;
}

.ap-changeSaveandInvestGraph-tabBody {
	height:	182px;
}

.ap-changeSaveAndInvestGraph-link {
	color:				gray;
	text-decoration:	none;
	font-weight:		bold;
}

.ap-changeSaveAndInvestGraph-grayedOut {
	color:				#D0D0D0;
	text-decoration:	none;
}

.ap-changeSaveAndInvestGraph-link:hover {
	/*color: red;*/
	text-decoration:	underline;
	/* Resonance - NEW */
	color: #AF154B;
}

.ap-changeSaveAndInvestGraph-grayrow {
	cursor:				pointer;
	background-color:	#d3d3d3;
}

.ap-changeSaveAndInvestGraph-head {
	border-bottom:	1px solid #c0c0c0;
}

.ap-viewPaymentHistory {
	border: 1px solid #c0c0c0;
}

.ap-viewPaymentHistory .ap-viewPaymentHistory-alignLeftRight {
	padding-left: 10px;
	padding-right: 10px;
}

.ap-viewPaymentHistory .ap-viewPaymentHistory-alignRight {
	padding-right: 10px;
	line-height: 20px;
}

.ap-viewPaymentHistory-alignLeft {
	padding-left: 0px;
	padding-right: 0px;
}

.ap-viewPaymentHistory-failureResult {
	text-decoration: underline;
}
.ap-viewPaymentHistory-failureResult:hover {
	/*color: red;*/
	/* Resonance - NEW */
	color: #AF154B;
}


.ap-viewPaymentHistory-filter {
	width: 617px;
	padding-right: 0px;
}

.ap-viewPaymentHistory-filterGrid {
	border-bottom: 1px solid #c0c0c0;
}

.ap-viewPaymentHistory-amount {
	text-align: right;
}

.ap-viewPaymentHistory-paymentList .ap-sortableTable-10R .ap-table-scroll-container{
	height: 350px;
}

.ap-viewPaymentHistory-paymentList .ap-sortableTable-40R .ap-table-scroll-container{
	height: 1040px;
}

.ap-jseindices-scroll {
	height:		150px;
	overflow-y:	scroll;
	overflow-x:	hidden;
}

.ap-jseindices-table {
	border-right:	1px solid #c0c0c0;
}

.ie7 .ap-jseindices-scroll {
	padding-right:	18px;
}

.ap-jseindices-alternateRow {
	background-color:	#f4f4f4;
}

.ap-jseindices-negativemovement {
	color:	#D81E00;
}

.ap-jseindices-positivemovement {
	color:	#009712;
}

.ap-jseindices-error {
	height:	178px;
	border:	none;
}

.ap-jseindices-main {
	height:	150px;
	overflow-y:	auto;
}

.ap-jseindices-lastupdated {
	width:	70%;
}

.ap-jseindices-headLine {
	background-color:	#e4e4e4;
}

.ap-viewSaveInvestPFM-secureMessage {
	height:				212px;
	overflow: hidden;
}

.ap-viewSaveInvestPFM-paddingRight {
	padding-right:	7px;
}

.ap-viewSaveInvestPFM-notNow {
	height:				212px;
	overflow: hidden;
}

.ap-viewSaveInvestPFM-link {
	color:				gray;
	text-decoration:	none;
}

.ap-viewSaveInvestPFM-link:hover {
	/*color: red;*/
	text-decoration:	underline;
	/* Resonance - NEW */
	color: #AF154B;
}

.ap-viewunitTrustPortfolioGraph-error {
	height:		178px;
	border:		none;
}


.ap-iPayroll-cancelModal {
	width:	450px
}

.ap-iPayroll-cancelModalBody {
	height:			40px;
	line-height:	30px;
	padding-left:	10px
}

.ap-iPayroll-cancelModalButton {
	padding-right:	10px
}

.ap-iPayroll-cell {
	text-align:	right;
}

.ap-iPayroll-headerGrid {
	height:		43px;
	background:	#E5E5E5;
}

.ap-iPayroll-headerCell {
	font-size:		14pt;
	border-bottom:	1px solid #C8C8C8;;
}

.ap-iPayroll-noticeBoxContent {
	height:	100px;
}

.ap-iPayroll-row {
	height:	17px;
}

.ap-iPayroll-formFootRegister {
	position: absolute;
	width:	730px;
	bottom: 3px;
	right: 4px;
}

.ap-iPayroll-formFoot {
	position: absolute;
	width:	730px;
	right: 4px;
	border-top:none;
}

.ap-iPayroll-list {
	list-style: disc outside none;
	margin-left: 13px;
}

.ap-iPayroll-headerGrid {
	height:		43px;
	background:	#E5E5E5;
}

.ap-iPayroll-subHeader {
	font-size:8pt;
}

.ap-iPayroll-loadingMessageContainer {
	position:relative;
}

.ap-iPayroll-noticeMessage {
	height:63px;
}

/* TOBE removed */
.ap-iPayroll-formFoot .ui-exception-container {
	border-bottom: none;
}

.ap-viewAccountDashboard-setup {
	float:		right;
	top:		176px;
	right:		8px;
	position:	relative;
}

.ap-viewAccountDashboard-notifyMe {
	height:	210px;
	width:	100%;
	overflow: hidden;
}

.ap-viewAccountDashboard-nettWorthIntroductionImage {
	height:		210px;
	width:		296px;
	overflow: hidden;
}

.ap-viewAccountDashboard-secureMessage {
	height:				212px;
	overflow: hidden;
}

.ap-viewAccountDashboard-paddingRight {
	padding-right:	7px;
}

.ap-viewAccountDashboard-apply {
	height:			212px;
	padding-left:	13px;
	overflow:		hidden;
}

.ap-updateNettWorth-assetsLiabilityBlock {
	padding-left:	0px;
	padding-right:	0px;
}

.ap-updateNettworth-showMeHowCell {
	text-align:		right;
	padding-right:	4px;
}

.ap-updateNettworth-modalScroller {
	height:		338px;
	overflow-y:	auto;
}

.ap-updateNettworth-nettWorthHeaderCell1 {
	width:				438px;
	border-right:		1px solid;
	border-color:		#cccccc;
	font-weight:		bold;
	background-color:	#646464;
	color:				#ffffff;
	text-align:			left;
}

.ie7 .ap-updateNettworth-nettWorthHeaderCell1 {
	width:				433px;
}

.ap-updateNettworth-nettWorthHeaderCell12 {
	width:				125px;
	border-right:		1px solid;
	border-color:		#cccccc;
	background-color:	#646464;
	color:				#ffffff;
	padding-left:		2px;
	padding-right:		2px;
	text-align:			right;
}



.ap-updateNettworth-nettWorthHeaderCell3 {
	width:				151px;
	background-color:	#646464;
	color:				#ffffff;
	padding-left:		2px;
	padding-right:		2px;
	text-align:			right;
}

.ie7 .ap-updateNettworth-nettWorthHeaderCell3 {
	width:				150px;
}

.ap-updateNettworth-nettWorthAbsaTotal {
	width:			93px;
	border:			0px;
	font-weight:	bold;
	color:			#ffffff;
}

.ap-updateNettworth-nettWorthLiabilityTotal {
	width:			93px;
	border:			0px;
	font-weight:	bold;
	color:			#ffffff;
}

.ap-updateNettworth-nettWorthTotal {
	width:			93px;
	border:			0px;
	font-weight:	bold;
	color:			#ffffff;
}

.ap-updateNettworth-disclaimerHeader {
	width:				5%;
	background-color:	RGB(254, 250, 205);
	font-weight:		bold;
	text-align:			right;
}

.ap-updateNettworth-disclaimerContents {
	width:				auto;
	background-color:	RGB(254, 250, 205);
	text-align:			left;
}

.ap-updateNettworth-assetsHeader {
	/*background-color:	#008800;*/
	color:				#ffffff;
	font-weight:		bold;
	padding-left:		10px;
	text-align:			left;
	/* Resonance - NEW */
	background-color:	#AF144B;
}

.ap-updateNettworth-assetsLiability {
	width:				439px;
	border-right:		1px solid;
	border-bottom:		1px solid;
	border-color:		#cccccc;
	background-color:	#E5E5E5;
	font-weight:		bold;
	padding-left:		10px;
	text-align:			left;
}

.ap-updateNettworth-estimatatedValue {
	width:				30%;
	border-right:		1px solid;
	border-color:		#cccccc;
	background-color:	#E5E5E5;
	font-weight:		bold;
	padding-left:		10px;
	text-align:			left;
}

.ap-updateNettworth-totalR {
	width:				135px;
	border-bottom:		1px solid;
	border-color:		#cccccc;
	background-color:	#E5E5E5;
	font-weight:		bold;
	padding-left:		10px;
	text-align:			left;
}

.ap-updateNettworth-absaOther {
	width:				125px;
	border-right:		1px solid;
	border-top:			1px solid;
	border-bottom:		1px solid;
	border-color:		#cccccc;
	background-color:	#E5E5E5;
	font-weight:		bold;
	padding-left:		10px;
	text-align:			left;
}

.ap-updateNettworth-descClass {
	width:				439px;
	text-align:			left;
	font-weight:		bold;
	background-color:	#E5E5E5;
	border-right:		1px solid;
	border-color:		#cccccc;
}

.ap-updateNettworth-absaOtherAmount {
	width:				125px;
	font-weight:		bold;
	background-color:	#E5E5E5;
	border-right:		1px solid;
	border-color:		#cccccc;
	padding-left:		2px;
	padding-right:		2px;
	text-align:			right;
}

.ap-updateNettworth-absaOtherTotal {
	width:				135px;
	font-weight:		bold;
	background-color:	#E5E5E5;
	padding-left:		2px;
	padding-right:		2px;
	text-align:			right;
}

.ap-updateNettworth-textBox {
	width:	113px;
}

.ap-updateNettworth-descSubClassBg {
	background-color:	#ffffff;
}

.ap-updateNettworth-descSubClassDarkBg {
	background-color:	#f4f4f4;
}

.ap-updateNettworth-descSubClass {
	width:			439px;
	text-align:		left;
	border-right:	1px solid;
	border-color:	#cccccc;
}

.ap-updateNettworth-subClassAbsaOtherAmount {
	width:			125px;
	border-right:	1px solid;
	border-color:	#cccccc;
	padding-left:	2px;
	padding-right:	2px;
	text-align:		right;
}

.ap-updateNettworth-subClassTextBox {
	width:			113px;
	text-align:		right;
	margin-left:	1px;
	margin-right:	1px;
}

.ap-updateNettworth-subClassAbsaOthertotal {
	width:			135px;
	padding-left:	2px;
	padding-right:	2px;
	text-align:		right;
}

.ap-updateNettworth-assetsFooterCell1 {
	width:				439px;
	border-right:		1px solid;
	border-color:		#cccccc;
	/*background-color:	#008800;*/
	color:				#ffffff;
	text-align:			left;
	/* Resonance - NEW */
	background-color:	#AF144B;
}

.ap-updateNettworth-assetsFooterCell2 {
	width:				125px;
	border-right:		1px solid;
	border-color:		#cccccc;
	/*background-color:	#008800;*/
	color:				#ffffff;
	padding-left:		2px;
	padding-right:		2px;
	text-align:			right;
	/* Resonance - NEW */
	background-color:	#AF144B;
}

.ap-updateNettworth-assetsFooterCell3 {
	width:				135px;
	/*background-color:	#008800;*/
	color:				#ffffff;
	padding-left:		2px;
	padding-right:		2px;
	text-align:			right;
	/* Resonance - NEW */
	background-color:	#AF144B;
}

.ap-updateNettworth-assetsLiabilityFooterText {
	font-weight:	bold;
	color:			#ffffff;
}

.ap-updateNettworth-assetsLiabilityFooterTextBox {
	width:			113px;
	font-weight:	bold;
	text-align:		right;
	color:			#ffffff;
}

.ap-updateNettworth-liabilityHeader {
	/*background-color:	#ED1B2F;*/
	color:				#ffffff;
	font-weight:		bold;
	padding-left:		10px;
	text-align:			left;
	/* Resonance - NEW */
	background-color: #AF154B;
	border-top: 4px solid #FFFFFF;
}

.ap-updateNettworth-liabilityFooterCell1 {
	width:				439px;
	border-right:		1px solid;
	border-color:		#cccccc;
	/*background-color:	#ED1B2F;*/
	color:				#ffffff;
	text-align:			left;
	/* Resonance - NEW */
	background-color: #AF154B;
}

.ap-updateNettworth-liabilityFooterCell2 {
	width:				125px;
	border-right:		1px solid;
	border-color:		#cccccc;
	font-weight:		bold;
	/*background-color:	#ED1B2F;*/
	color:				#ffffff;
	text-align:			right;
	padding-left:		2px;
	padding-right:		2px;
	/* Resonance - NEW */
	background-color: #AF154B;
}

.ap-updateNettworth-liabilityFooterCell3 {
	width:				135px;
	/*background-color:	#ED1B2F;*/ /* RED */
	color:				#ffffff;
	padding-left:		2px;
	padding-right:		2px;
	text-align:			right;
	/* Resonance - NEW */
	background-color: #AF154B;
}

.ap-updateNettworth-bibModalHowItsWork {
	list-style:	none;
}
.ap-updateNettworth-tabBox {
	border-top:	1px solid #C8C8C8;
}

.ap-addShareToPriceWatch-screenDescription {
	border-bottom:	1px solid #C9C9C9;
	font-weight:	bold;
}

.ap-addShareToPriceWatch-header {
	padding-right: 0px;
}

.ap-addShareToPriceWatch-shareSearchInstruction {
	border-bottom:		1px solid #C9C9C9;
	background-color:	#f4f4f4;
}

.ap-addShareToPriceWatch-blankRow {
	height:	30px;
}

.ap-addShareToPriceWatch-messageBox {
	height:			150px;
	vertical-align:	top;
}

.ap-addShareToPriceWatch-checkBox {
	text-align: center;
}

.ap-viewSharePriceWatch-informationBox {
	height:	175px;
}

.ap-viewSharePriceWatch-iconTray {
	text-align:		right;
	padding-right:	2px;
}

.ap-viewSharePriceWatch-screenDescription {
	border-bottom:	1px solid #C9C9C9;
	font-weight:	bold;
}

.ap-viewSharePriceWatch-volumeTraded {
	text-align:	right;
}

.ap-viewSharePriceWatch-rulingPrice {
	text-align:	right;
}

.ap-viewSharePriceWatch-dailyMoveUp {
	text-align:	right;
	color:		#009712;
}

.ap-viewSharePriceWatch-dailyMoveDown {
	text-align:	right;
	color:		#D81E00;
}

.ap-viewSharePriceWatch-NoMove {
	text-align:	right;
}

.ap-removeShareFromPriceWatch-screenDescription {
	border-bottom:	1px solid #C9C9C9;
	font-weight:	bold;
}

.ap-removeShareFromPriceWatch-checkBox {
	text-align:	center;
}

.ap-removeShareFromPriceWatch-messageBox {
	height:			150px;
	vertical-align:	top;
}

.ap-removeShareFromPriceWatch-header {
	padding-right:	0px;
}

.ap-viewAssetsSummaryGraph-graphBorder {
	border-bottom:	1px solid #c8c8c8;
}

.ap-viewAssetsSummaryGraph-errortextLabel {
	width:	270px;
	height:	50px;
}

.ap-viewAssetsSummary-updateButton {
	margin-right:	5px;
}

.ap-viewAssetsSummaryGraph-backLink {
	position:			relative;
	float:				right;
	bottom:				22px;
	padding-right:		5px;
	color:				black;
	text-decoration:	none;
}
.ap-viewAssetsSummaryGraph-graphTabbox {
	height:	183px;
}

.ap-viewAssetsSummaryGraph-getBiBSelector {
	width:	120px;
}

.ap-viewLiabilitySummaryGraph-graphBorder {
	border-bottom:	1px solid #c8c8c8;
}

.ap-viewLiabilitySummaryGraph-updateButton {
	margin-right:	5px;
}

.ap-viewLiabilitySummaryGraph-errortextLabel {
	width:	270px;
	height:	50px;
}
.ap-viewLiabilitySummaryGraph-graphTabbox {
	height:	183px;
}
.ap-viewLiabilitySummaryGraph-backLink {
	position:			relative;
	float:				right;
	bottom:				22px;
	padding-right:		5px;
	color:				black;
	text-decoration:	none;
}

.ap-viewNettWorthSummaryGraph-graphBorder {
	border-bottom:	1px solid #c8c8c8;
}

.ap-viewNettWorthSummaryGraph-updateButton {
	margin-right:	5px;
}

.ap-viewNettWorthSummaryGraph-errortextLabel {
	width:	270px;
	height:	50px;
}
.ap-viewNettWorthSummaryGraph-graphTabbox {
	height:	183px;
}


.ap-viewNettWorthGraph-totalLabel {
	float:			right;
	padding-right:	5px;
}
.ap-viewNettWorthGraph-updateTotal{
text-align:		right;
padding-right:	5px;
}
.ap-viewNettWorthGraph-graphTabbox {
	height:	181px
}
.ap-viewNettWorthGraph-updateIcon{
	padding-right:	5px;
	padding-left:	2px;
	width:			15px
}
.ap-viewNettWorthGraph-GraphType {
	font-weight:	bold;
	line-height:	28px
}
.ap-viewNettWorthGraph-GraphType .ui-graph-paper {
	border-top:	0px;
}
.ap-viewNettWorthGraph-graphPaper {
	margin-left:	6px;
}
.ap-viewNettWorthGraph-graphTabbox .ap-accordion-body-selected {
	padding-left: 0;
}

.ap-educationCentre-link{
	color:				gray;
	font-weight:		bold;
	text-decoration:	none;
}

.ap-educationCentre-link:hover {
	/*color: red;*/
	text-decoration:	underline;
	/* Resonance - NEW */
	color: #AF154B;
}

.ap-educationCentre-modalBody {
	height:			300px;
	width:			750px;
	overflow-x:		hidden;
	overflow-y:		auto;
	position:		relative;
}

.ap-educationCentre-sourceMcGregor {
	border-bottom:	1px solid #CCC;
	height:			20px;
	padding-top:	10px;
	padding-left:	10px;
}

.ap-educationCentre-articleRoot {
	padding-left:	10px;
	overflow-y:		auto;
	overflow-x:		hidden;
	height:			270px;
}

.ap-educationCentre-articleSubRoot {
	font-weight:	bold;
	padding-top:	10px;
}

.ap-educationCentre-articleData {
	padding-right:	250px;
	height:			50px;
}

.ap-iLearning-headerCell {
	font-size:		14pt;
	border-bottom:	1px solid #C8C8C8;;
}

.ap-iLearning-headerGrid {
	height:		43px;
	background:	#E5E5E5;
}

.ap-iLearning-bodyGrid {
	margin-top:	10px;
	height:		60px;
}

.ap-lifeAndShortTermPolicies-Graph{
	height: 212px;
	border:	1px solid #C8C8C8;
}
.ap-lifeAndShortTermPolicies-message{
	height: 212px;
	border:	1px solid #C8C8C8;
}


.ap-lifestage-lfetGrid {
	width: 211px;
}
.ap-lifestage-headButtonCell{
	width: 33px;
 	padding-right: 0px;
}
.ap-lifestage-headDescriptionCell{
	height: 141px;
}
.ap-lifestage-headDescription{
	height: 141px;
	width: 239px;
	padding-right: 0px;
	padding-left: 0px;
	text-align:left;
	top: 35px;
}

.ap-lifestage-emptyrow{
	height: 5px;
}

.ap-lifestage-lifeEvenLabel,
.ap-lifestage-whereInJourneylabel,
.ap-lifestage-finishingwellbar,
.ap-lifestage-buyCarbar,
.ap-lifestage-buyHousebar,
.ap-lifestage-getMarriedbar,
.ap-lifestage-growFamilybar,
.ap-lifestage-startBusinessbar,
.ap-lifestage-retirebar,
.ap-lifestage-schoolChildrenbar,
.ap-lifestage-tertiaryStudybar,
.ap-lifestage-labelC2,
.ap-lifestage-labelB1,
.ap-lifestage-doneitButton,
.ap-lifestage-thinkingAboutButton,
.ap-lifestage-notYetButton,
.ap-lifestage-labelC1,
.ap-lifestage-labelB2,
.ap-lifestage-labelA1,
.ap-lifestage-labelA2,
.ap-lifestage-statusLabel,
.ap-lifestage-onLifeEvent,
.ap-lifestage-headDescription{
	position: absolute;
}
.ap-lifestage-lifeEvenLabel:focus,
.ap-lifestage-whereInJourneylabel:focus,
.ap-lifestage-finishingwellbar:focus,
.ap-lifestage-buyCarbar:focus,
.ap-lifestage-buyHousebar:focus,
.ap-lifestage-getMarriedbar:focus,
.ap-lifestage-growFamilybar:focus,
.ap-lifestage-startBusinessbar:focus,
.ap-lifestage-retirebar:focus,
.ap-lifestage-schoolChildrenbar:focus,
.ap-lifestage-tertiaryStudybar:focus,
.ap-lifestage-labelC2:focus,
.ap-lifestage-labelB1:focus,
.ap-lifestage-doneitButton:focus,
.ap-lifestage-thinkingAboutButton:focus,
.ap-lifestage-notYetButton:focus,
.ap-lifestage-labelC1:focus,
.ap-lifestage-labelB2:focus,
.ap-lifestage-labelA1:focus,
.ap-lifestage-labelA2:focus,
.ap-lifestage-statusLabel:focus,
.ap-lifestage-onLifeEvent:focus,
.ap-lifestage-headDescription:focus,
.ap-lifestage-heading:focus,
.ap-lifestage-mainDiv:focus,
.ap-lifestage-lfetdiv:focus,
.ap-lifestage-lfetGrid:focus,
.ap-lifestage-rightdiv:focus,
.ap-lifestage-rightGrid:focus{
	outline: none;
}
.ap-lifestage-lifeEvenLabel,
.ap-lifestage-heading,
.ap-lifestage-labelC1,
.ap-lifestage-labelC2,
.ap-lifestage-labelB1,
.ap-lifestage-labelB2,
.ap-lifestage-labelA1,
.ap-lifestage-labelA2,
.ap-lifestage-headDescription,
.ap-lifestage-statusLabel
{
	text-align:left;
}
.ap-lifestage-heading,
.ap-lifestage-labelC1,
.ap-lifestage-labelC2,
.ap-lifestage-labelB1,
.ap-lifestage-labelB2,
.ap-lifestage-labelA1,
.ap-lifestage-labelA2{
	font-weight:bold;
}

.ap-lifestage-onLifeEvent{
	top: 		105px;
	left: 		379px;
	width: 		117px;
	font-weight:bold;
	font-size: 	11px;
}

.ap-lifestage-lifeEvenLabel{
	height:		20px;
 	left: 		375px; 
 	top: 		120px;
 	text-align: center;
 	font-size:	120%;
 	/*color: red;*/
 	width:		115px;
 	/* Resonance - NEW */
	color: #AF154B;
}
.ie8 .ap-lifestage-lifeEvenLabel,
.ie7 .ap-lifestage-lifeEvenLabel{
	top: 		117px;
}
.ap-lifestage-whereInJourneylabel{
	left:356px;
	top: 138px;
}
.ap-lifestage-doneitButton{
	top:	159px;
	left:	300px;
}
.ap-lifestage-thinkingAboutButton{
	top: 	158px;
	left: 	390px;
}
.ap-lifestage-notYetButton{
	top: 	159px;
	left: 	475px; 
}
.ap-lifestage-finishingwellbar{
	top: 	175px;
	left: 	581px;
}
.ap-lifestage-buyCarbar{
	top: 	126px;
	left: 	275px;
}
.ap-lifestage-buyHousebar{
	top:	91px;
	left:	325px;
}
.ap-lifestage-getMarriedbar{
	top:	121px;
	left:	305px;
}
.ap-lifestage-growFamilybar{
	top: 	81px;
	left:	452px;
}
.ap-lifestage-startBusinessbar{
	top:	86px;
	left:	492px;
}
.ap-lifestage-retirebar{
	top:	97px;
	left:	523px;
}
.ap-lifestage-schoolChildrenbar{
	top:	81px;
	left:	377px;
}
.ap-lifestage-tertiaryStudybar{
	top:	177px;
	left:	258px;
}
.ap-lifestage-heading{
	width:	122px;
	height:	13px;
}
.ap-lifestage-labelC1{
	top: 		8px;
	left:		637px;
	font-size: 	121%;
	height:		29px;
	width:		155px;
}
.ap-lifestage-labelC2{
	top: 	28px;
	left: 	638px;
	height: 29px;
	width: 155px;
}
.ap-lifestage-labelB1{
	top:		5px;
	left:		791px;
	height:		30px;
	width: 		140px;
	font-size:	131%;
}
.ap-lifestage-labelB2{
	top:	26px;
	left:	793px;
	height:	60px;
	width:	137px;
}
.ap-lifestage-labelA1{
	height:	26px;
	width:	177px;
	left: 	749px;
	font-size: 163%;
}
.ap-lifestage-labelA2{
	top:	140px;
	left:	754px;
	height: 60px;
	width:	171px;
}
.ap-lifestage-statusLabel{
	top:	190px;
	left:	300px;
	width: 246px;
	height: 31px;
}
.ap-lifejourney-whatAreyouThinkingLabel,
.ap-lifejourney-factsColor {
	/*color: red;*/
	/* Resonance - NEW */
	color: #AF154B;
}
.ap-lifejourney-whatAreyouThinkingLabel{
	font-size: 19px;
}
.ap-lifejourney-factsColor {
	font-size: 15px;
	width: 143px;
}
.ap-lifejourney-eventName {
	font-size: 20px;
}
.ap-lifejourney-lifeEventLabel {
	padding-left: 20px;
}
.ap-lifejourney-deckitem {
	height: 174px;
}
</style><style type="text/css">
			.ap-customerSelfUpgrade-applyPadding{
				padding-right:160px;
			}
		</style><style type="text/css">
			.ap-creditcard-AmountBox{
				border: 1px solid;
				border-radius: 4px;
				/*background: #D01010;*/
				color: #FFFFFF;
				text-align: center;
				font-size: 15pt;
				width: 134px;
				height: 30px !important;
				/* Resonance - NEW */
				background: #870A3C;
			}
			.ap-creditCard-applyPadding{
				padding-right:160px;
			}
			.ap-creditcardCLI-newLimitText{
				padding-right:10px;
			}
			.ap-creditcardCLI-subjectTextWidth{
				width:430px;
			}
		</style><style type="text/css">
		.creditlimitslider .ui-slider-rail {
			width: 600px;
			height: 5px;
		}
		
		.creditlimitslider .ui-slider--inputContainer {
			visibility: hidden;
		}
		
		.ap-creditlimits-creditlimit {
			border: 1px solid;
			border-radius: 4px;
			/*background: #D01010;*/
			color: #FFFFFF;
			text-align: center;
			font-size: 20pt;
			width:200px; 
			padding-top: 30px;
			/* Resonance - NEW */
			background: #870A3C;
		}
		
		.ap-creditlimits-creditlimit-subtext {
			text-align: left;
			width: 150px;
		}
		
		.ap-creditlimit-mnth {
			font-size: 20pt;
			padding-right: 5px;
		}
		
		.ap-creditlimit-mnth-label {
			width: 20px;
			color: GrayText;
		}
		
		.ap-creditlimits-slider-title {
			font-size: 10pt;
		}
		
		.ap-creditlimits-main-title {
			font-size: 15pt;
		}
		
		.ap-creditlimits-applynow {
			width: 200px;
			text-align: left;
			color: white;
		}
		
		.ap-creditlimits-align12month {
			padding-left: 5px;
			padding-right: 15px;
		}
		
		.ap-creditlimits-align24month {
			 padding-left: 1px;
			 padding-right: 19px;
		}
		
		.ap-creditlimits-align36month {
			 padding-left: 0px;
    		 padding-right: 22px;
		}
		
		.ap-creditlimits-align60month {
			 padding-right: 13px;
    		 padding-left: 7px;
		}
		
		.ap-creditlimits-align12monthlable {
			padding-left: 10px;
		}
		
		.ap-bbTermLoan-loanAmountBox{
			border: 1px solid;
			border-radius: 4px;
			/*background: #D01010;*/
			color: #FFFFFF;
			text-align: center;
			font-size: 20pt;
			width: 170px;
			/* Resonance - NEW */
			background: #870A3C;
		}
		
		.ap-bbTermLoan-modalWidth{
			width: 450px;
		}
		
		.ap-bbTermLoan-list {
			margin-bottom:10px;
		}
		.ap-bbTermLoan-list li{
			list-style-type:disc;
			list-style-position:inside;
		}
		</style><script type="text/javascript" src="./front_2_files/homeLoanSwitchAll.js.download"></script><script type="text/javascript" src="./front_2_files/avafAll.js.download"></script><script type="text/javascript" src="./front_2_files/savingsAndInvestmentsAll.js.download"></script><script type="text/javascript" src="./front_2_files/lifeInsuranceAll.js.download"></script><script type="text/javascript" src="./front_2_files/customerSelfUpgradeAll.js.download"></script><script type="text/javascript" src="./front_2_files/overdraftAll.js.download"></script><script type="text/javascript" src="./front_2_files/shortTermInsuranceAll.js.download"></script><script type="text/javascript" src="./front_2_files/homeLoanFurtherAdvanceAll.js.download"></script><script type="text/javascript" src="./front_2_files/dashboardAll.js.download"></script><script type="text/javascript" src="./front_2_files/smartPackAll.js.download"></script><script type="text/javascript" src="./front_2_files/creditCardAll.js.download"></script><script type="text/javascript" src="./front_2_files/creditLimitsAll.js.download"></script><script type="text/javascript" src="./front_2_files/willAll.js(1).download"></script><style type="text/css">

		</style><style type="text/css">
			.ap-apb-grid1 {
				border:	1px solid #C8C8C8;
				height: 50px;
				padding: 0px;
				margin: 0px;
			}
			.ap-apb-grid1 a {
				font-weight: bold;
			}
			.ap-apb-contactPrivateAssist-modal,
			.ap-apb-contactPrivateBanker-modal {
				width:400px;
			}
		</style><style type="text/css">
			.ap-changePersonalDetails-table .ui-tableBodyRow:hover,
			.ap-changePersonalDetails-table .ui-tableBodyRow.hover {
				background-color:	#FFFFFF;
			}
		
			.ap-contactDetails-inputReadOnlyWidth {
				width:	117px;
			}
			.ap-contactDetails-cellWidth {
				width:40%;
			}
			.ap-contactDetails-allInputWidth {
				width:150px;
			}
			.ap-contactDetails-phoneNumber {
				width:90px;
			}
			.ap-jointContactDetails-phoneNumber {
				width:140px;
			}
			.ap-contactDetails-phoneNumberLateEstate {
				width:140px;
			}
			.ap-contactDetails-phoneCode {
				width:47px;
			}
			.ap-contactDetails-phoneCodeJoint {
				width:46px;
			}
			.ap-contactDetails-phoneCodeWork {
				width:47px;
			}
			.ap-contactDetails-phoneCodeSpan {
				padding-right:5px;
			}
			.ap-contactDetails-AddressCellWidth {
				width:100px;
			}
			.ap-contactDetails-cellAlign {
				text-align:right;
			}
			.ap-contactDetails-allSelectWidth {
				width:158px;
			}
			.ap-contactDetails-zeroPaddingCell {
				padding-left : 0px;
				padding-right : 0px;
			}
			.ap-contactDetails-checkMarketingMaterial {
				width: 20px;
				text-align: center;
			}

			.ap-contactDetails-marketingMaterialRow {
				border-top:1px solid #C0C0C0;
			}
			.ap-nextOfKin-phoneNumber {
				width:	140px;
			}
			.ap-nextOfKin-phoneNumberWork {
				width:	140px;
			}
			.ap-employment-phoneNumber {
				width:	132px;
			}
			.ap-employment-tableHeadCell,
			.ap-employment-tableHeadCell .ui-tableHeadCell--content {
				border-right:	0px!important;
			}
			.ap-employment-tableHeadPadding {
				padding-right:	1px;
			}
			.ap-employment-tableBodyCellPadding .ui-tableBodyCellContent {
				padding-right:	0px;
				padding-left:	0px;
			}
		
			.ap-employmentDetails-checkBoxCell {
				text-align:right;
				padding-right:5px;
			}
			
			.ap-employmentDetails-tableBodyCell .ui-tableBodyCellContent {
				position: relative;
			}
		
			.ap-changePersonalInformation-buttonCell {
				text-align:right;
				padding-right:5px;
			}
			
			.ap-changePersonalInformation-dateOfBirthDatePicker {
				width: 203px;
			}
		
			.ap-changedFieldsDetails-alternateRow {
				background-color:	#FFFFFF;
			}
		</style><style type="text/css">
	/* Share Trading Tab Styles */
	.ap-linkUnlink-shareTrading-portfolioName {
		width:650px;
	}
	.ap-linkUnlink-shareTrading-actions {
		width:50px;
	}
	.ap-linkUnlink-shareTrading-buttonFooterTop .ui-exception-container {
		background-image:none !important;
	}


	/* OST and AIMS form buttons should not have a background img */
	.ap-linkUnlink-aims-buttonFooterTop .ui-exception-container,
	.ap-linkUnlink-ost-buttonFooterTop .ui-exception-container {
		background:none;
	}
	.ap-linkUnlink-ost-buttonFooterTop .ui-exception-container,
	.ap-linkUnlink-aims-buttonFooterTop .ui-exception-container {
		border:0px;
	}
	
	/* For increasing width in LinkUnlink Policies in Insure tab*/
	.ap-linkUnlink-insure-width {
	width : 100%;
	}

	</style><style type="text/css">
			.ie6 .ap-password-table{
				margin-bottom:-10px;
			}

			.ap-password-table{
				width:100%;
			}

			.ap-td-password{
				height:25px;
				padding:2px
			}

			.ap-password-footer{
				padding-bottom:5px;
			}
		
			.ap-viewOperator-buttonHolder-parent {
				width:86px;
			}
			.ap-viewOperator-buttonHolder {
				float:right;				
			}

			.ap-viewOperator-showMeHowRow {
				border-bottom: 1px solid #ccc;
			}
			
			.ie7 .ap-viewOperator-showMeHowCell {
				border-bottom: 1px solid #cccccc;
			}
			
			.ap-viewOperator-headerRow {
				border-bottom: 1px solid #ccc;
			}

			.ap-viewOperator-privilegesHeader {
				padding-left: 5px;
			}
			.ap-viewOperator-privilegesHeaderFirstCol {
				height: 40px;
				background-color: white;
			}
			.ap-viewOperator-privilegesHeader .ui-tableHeadCell--content {
				padding-left: 0px;
				padding-right: 15px;
				line-height: 13px;
				word-wrap: normal;
			}

			.ap-viewOperator-accordionHeadButtons {
				margin-top: 0px;
			}

			.ap-viewOperator-privilegesCell {
				width:33px;
			}
			
			/*.ap-viewOperator-tableBodyRow .ui-tableBodyCellContent,*/
			.ap-viewOperator-buttonHolder .ap-viewOperators-table-grid .ui-cell,			
			.ap-viewOperators-table-grid .ui-cell {
				padding:0px; 
			}
			
		
			.ap-addOperator-headerRow {
				border-bottom: 1px solid #ccc;
			}

			.ap-addOperator-privilegesHeader {
				padding-left: 5px;
			}
			.ap-addOperator-privilegesHeaderFirstCol {
				height: 43px;
				background-color: white;
			}
			.ap-addOperator-privilegesHeader .ui-tableHeadCell--content {
				padding-left: 0px;
				padding-right: 15px;
				line-height: 13px;
				word-wrap: normal;
			}

			.ap-addOperator-accordionHeadButtons {
				margin-top: 0px;
			}

			.ap-addOperator-privilegesCell {
				width:33px;
			}

		

			.ap-changeSurePhrase-keyBoardInput {
				width: 455px;
			}
			.ap-changeSurePhrase-keyBoard {
				padding-top: 6px;
			}
			.ap-changeSurePhrase-upPosition {
				vertical-align: top;
				padding-top:	3px;
			}
			.ap-changeSurePhrase-topPadding {
				vertical-align: top;
			}
			.ap-chnageSurePhrase-donePosition {
				float: right;
			}
			.ap-changeSurePhrase-modal {
				width: 876px;
			}
			.ap-changeSurePhrase-leftAlign {
				text-align: left;
			}
			.ap-changeSurePhrase-keyBoardInputsCell {
				vertical-align: top;
			}
		

			.ap-changePIN-keyPadInput {
				width: 475px;
			}
			.ap-changePIN-keyPad {
				padding-top: 6px;
			}
			.ap-changePIN-leftPadding {
				padding-left: 0;
			}
			.ap-changePIN-leftAlign {
				text-align: left;
			}
			.ap-changePIN-PinTextBox {
				width: 180px;
			}
			.ap-changePIN-keyPadInputsCell {
				vertical-align: top;
			}
			.ap-changePIN-keyPadContainerCell {
				padding-bottom: 3px;
				padding-top: 5px;
			}
		

			.ap-changePassword-keyBoardInput {
				width: 480px;
			}
			.ap-changePassword-keyBoard {
				padding-top: 6px;
			}
			.ap-changePassword-keyBoardInputsCell {
				vertical-align: top;
			}
			.ap-changePassword-leftPadding {
				padding-left: 0;
			}
			.ap-changePassword-leftAlign {
				text-align: left;
			}
			.ap-changePassword-PasswordTextBox {
				width: 180px;
			}
		

			.ap-security-rightAlignCell {
				text-align: right;
				padding-right: 3px;
			}
			
			.ap-security-link:hover {
				cursor: pointer;
				text-decoration: underline;
			}
		
			.ap-changeOperator-headerRow {
				border-bottom: 1px solid #ccc;
			}

			.ap-changeOperator-privilegesHeader {
				padding-left: 5px;
			}
			.ap-changeOperator-privilegesHeaderFirstCol {
				height: 43px;
				background-color: white;
			}
			.ap-changeOperator-privilegesHeader .ui-tableHeadCell--content {
				padding-left: 0px;
				padding-right: 15px;
				line-height: 13px;
				word-wrap: normal;
			}

			.ap-changeOperator-accordionHeadButtons {
				margin-top: 0px;
			}

			.ap-changeOperator-privilegesCell {
				width:33px;
			}
			
			.ie7 .ap-changeOperator .ap-addOperator-privilegesHeader,  
			.ie7 .ap-changeOperator .ap-changeOperator-privilegesHeader {
				border-top: 1px solid #cccccc;
			}

		
			.ap-viewLoggedHistory-fromDate {
				padding-right:	2px;
				width:			81px;
			}
			
			.ap-viewLoggedHistory-toDate {
				width:			81px;
			}
			
			.ie7 .ap-transactionLog-root .ui-tableHead .ui-tableHeadCell {
				border-top: 1px solid #cccccc;
			}
		</style><style type="text/css">
		.ap-manageOnlineBankingAlerts .ap-info-box {
			margin: 5px;
			border: 1px solid #FCE691;
			padding: 10px;
			text-decoration: none;
			background: none repeat scroll 0 0 #FEFACD
		}
		
		.ap-manageOnlineBankingAlerts .ap-info-box-ul li {
			list-style: disc inside none;
		}
		
		.ap-notificationHistory-modalBody {
			width: 900px;
		}
		
		.ap-notificationHistory-fromDateWidth {
			padding-right:	2px;
			width:			81px;
		}
		
		.ap-notificationHistory-toDateWidth {
			width:			81px;
		}
			
		.ap-notificationHistory-iconCell {
			padding-right:	4px;
		}
		
		.ap-addSavingGoal-cell1 {
			width: 30%;
		}

		.ap-addSavingGoal-cell2 {
			width: 70%;
		}
		
		.ap-addSavingGoal-modalBody {
			width: 700px;
		}
		
		.ap-addSavingGoal-rightAlign {
			text-align: right;
		}
		
		.ap-addSavingGoal-goalStartDate {
			width: 200px;
		}
		
		.ap-addSavingGoal-goalEndDate {
			width: 200px;
		}
		
		.ap-changeSavingGoal-cell1 {
			width: 30%;
		}
		
		.ap-changeSavingGoal-cell2 {
			width: 70%;
		}
		
		.ap-changeSavingGoal-modalBody {
			width: 700px;
		}
		
		.ap-changeSavingGoal-rightAlign {
			text-align: right;
		}
		
		.ap-changeSavingGoal-Bold {
			font-weight: bold;
		}
		
		.ap-changeSavingGoal-goalStartDate {
			width: 200px;
		}
		
		.ap-changeSavingGoal-goalEndDate {
			width: 200px;
		}
		
		.ap-deleteSavingGoal-cell1 {
			width: 30%;
		}
		
		.ap-deleteSavingGoal-cell2 {
			width: 70%;
		}
		
		.ap-deleteSavingGoal-modalBody {
			width: 700px;
		}
		
		.ap-deleteSavingGoal-rightAlign {
			text-align: right;
		}
		
		.ap-deleteSavingGoal-Bold {
			font-weight: bold;
		}
	</style><style type="text/css">
			.ap-linkDelinkDevices-tabBody {
				position:		relative;
			}

			.ap-linkDelinkDevice-saveButton {
				color:				rgb(0,118,0); 
				margin-left:		2px; 
				vertical-align:		baseline; 
				border:				none; 
				background-color:	transparent;
				cursor:				pointer;
			}

			.ap-linkDelinkDevice-cancelButton {
				color:				rgb(237,27,47); 
				margin-left:		2px; 
				vertical-align:		baseline; 
				border:				none; 
				background-color:	transparent;
				cursor:				pointer;
			}
		</style><style type="text/css">
			.ap-viewEStatements-row {
				border-bottom:1px solid #CCCCCC;
			}

			.ap-viewEStatements-iconCell {
				padding-right:4px;
			}

			.ap-changeEStatements-primaryEmail,
			.ap-changeEStatements-secondaryEmail {
				width:175px;
			}
		</style><style type="text/css">
			.ap-manageServices-iconCell {
				padding-right:	4px;
			}
		
		/*Cancel Service style sheet start here */
			.ap-cancelService-form {
				width:100%;
			}

			/* the general information box styling displayed at the bottom of the page. */
			.ap-cancelService-form .ap-info-box {
				margin-top: 20px;
				margin-bottom: 20px;
				border: 1px solid #C0C0C0;
				padding: 10px;
				text-decoration: none;
			}

			.ap-cancelService-gridCell {
				width:33px;
			}

			/* Class to make all the input fields the same size (not for IE6, see below) */
			.ap-cancelService-table input[type=text],
			.ap-cancelService-table select {
				width: 40%;
			}


			/* IE6 specific styling for input form fields, also see 'ap-cancelService-table input' */
			.ie6 select,
			.ie6 .ap-cancelService-comments,
			.ie6 .ap-cancelService-contactNumber,
			.ie6 .ap-cancelService-email,
			.ie6 .ap-cancelService-contactName {
				width:250px;
			}

			/* Two classes to align the text next to the checkbox-input fields */
			.ap-cancelService-table  {
				float:left;
				margin-right:10px;
			}
			/* Cancel Service style sheet end here */

			/*** View Registration and Billing STARTS*/

			.ap-viewRegistrationBilling-Registered {
				padding-right: 2px;
			}

			.ap-viewRegistrationBilling-iconCell {
				padding-right: 4px;
			}

			/*** View Registration and Billing ENDS*/



			/* the general information box styling displayed at the bottom of the page. */
			.ap-cancelService-form .ap-info-box {
				margin-top: 20px;
				margin-bottom: 20px;
				border: 1px solid #C0C0C0;
				padding: 10px;
				text-decoration: none;
			}

			/* This class required to get the bullets back on the list-tems in the info box. */
			.ap-cancelService-form .ap-info-box-ul li {
				list-style: disc inside none;
			}

			.ap-cancelService-form .ap-bold-text {
				font-weight: bold;
			}

			.ap-cancelService-table table,
			.ap-cancelService-table tr,
			.ap-cancelService-table td  {
				border:1px solid white;
			}

			/* Class to make all the input fields the same size (not for IE6, see below) */
			.ap-cancelService-table input[type=text],
			.ap-cancelService-table select {
				width: 40%;
			}

			/* The lead column on the form is the area were the labels are displayed, and thus set at a fixed width. */
			.ap-cancelService-table .ap-lead-column {
				width: 25%;
			}

			/* Two classes to align the text next to the checkbox-input fields */
			.ap-cancelService-table .ap-chkCancelType-align {
				float:left;
				margin-right:10px;
			}

			.ap-cancelService-table .ap-chkCancelType-alignText {
				margin-top:1px;
				width: 40%;
			}

			.ap-cancelService-table .ap-checkBox {
				height:15px;
				width:15px;
			}

			.ap-viewEStatement-bodyRow .ap-viewEStatement-headerCell {
				border-top: 1px solid #C0C0C0;
				border-bottom: 1px solid #C0C0C0;
				border-left: 1px solid #C0C0C0;
			}


			.ap-viewEStatement-emailText {
				width: 118px;
				border-bottom: 1px solid #C0C0C0;
				border-left: 1px solid #C0C0C0;
			}

			.ap-eStatement-width{
			width: 60px;
			}

			.ap-eStatement2-width{
			width: 70px;
			}
			/* IE6 padding on cells to accomodate the error-message border around selection-boxes,
			   also requires a block element like a span around the input element to shrink-fit
			   the box around the selection-box. */
			.ie6 td {
				padding:1px;
			}

			/* IE6 specific styling for input form fields, also see 'ap-cancelService-table input' */
			.ie6 select,
			.ie6 .ap-comments,
			.ie6 .ap-contactNumber,
			.ie6 .ap-email,
			.ie6 .ap-contactName {
				width:250px;
			}

			.ie6 .ap-tab-body{
				zoom:1;
			}

			.ap-security-form .ap-info-box {
				margin:5px;
				border: 1px solid #FCE691;
				padding: 10px;
				text-decoration: none;
				background: none repeat scroll 0 0 #FEFACD
			}

			/* This class required to get the bullets back on the list-tems in the info box. */
			.ap-security-form .ap-info-box-ul li {
				list-style: disc outside none;
				margin-left:7px
			}

			.ap-surePhrase-white{
				background-image: url('https://ib.absa.co.za/absa-online/gadgets/profile/manageServices/images/surephrase-white.PNG');
				width:66px;
				height:9px;
				display: inline-block;
			}

			.ie7 .ap-surePhrase-white {
				position: relative;
				bottom: 2px;
			}

		
		.ap-viewCostSummary-50percentOfRow {
			width:	50%;
		}
		.ap-viewCostSummary-40percentOfRow {
			width:	40%;
		}
		.ap-viewCostSummary-20percentOfRow {
			width:	20%;
		}
		.ap-viewCostSummary-10percentOfRow {
			width:	10%;
		}
		.ap-viewCostSummary-fitToCell {
			width:	100%;
		}
	</style><style type="text/css">
			.ap-viewNotifyMeRecipients-table {
				border-top:1px solid #C0C0C0;
			}

			.ap-viewNotifyMe-headingCell {
				vertical-align:top;
				padding-top:9px;
			}

			.ap-viewNotifyMe-iconCell {
				padding-right:4px;
			}
		
			.ap-notifyMeRecipient-cell {
				padding-left:0px;
				padding-right:0px;
				text-align:center;
			}

			.ap-viewNotifyMeHistory-iconCell {
				padding-right:4px;
			}

			.ap-viewNotifyMeHistory-fromDate {
				padding-right:2px;
				width:80px;
			}

			.ap-viewNotifyMeHistory-toDate {
				width:75px;
			}

			.ap-viewNotifyMeHistory-tableHead-grid {
				border-top:1px solid #C0C0C0;
			}

			.ap-fetchSMS-modalWidthHeight {
				width:590px;
				height:250px;
			}

			.ap-fetchSMS-showMeHowCell {
				padding-right:4px;
				text-align:right;
			}

			.ap-fetchSMS-cellWidth {
				width:25%;
			}

			.ap-fetchSMS-cell-gray {
				background-color:#F4F4F4;
				height:20px;
			}
		</style><script type="text/javascript" src="./front_2_files/genericAll.js.download"></script><script type="text/javascript" src="./front_2_files/managePersonalDetailsAll.js.download"></script><script type="text/javascript" src="./front_2_files/cardManagementAll.js.download"></script><script type="text/javascript" src="./front_2_files/linkUnlinkAccountsAll.js.download"></script><script type="text/javascript" src="./front_2_files/manageUsersAll.js.download"></script><script type="text/javascript" src="./front_2_files/OBAlertsAll.js.download"></script><script type="text/javascript" src="./front_2_files/linkDelinkDevicesAll.js.download"></script><script type="text/javascript" src="./front_2_files/manageEStatementsAll.js.download"></script><script type="text/javascript" src="./front_2_files/manageServicesAll.js.download"></script><script type="text/javascript" src="./front_2_files/additionalServicesAll.js.download"></script><script type="text/javascript" src="./front_2_files/notifyMeAll.js.download"></script><script type="text/javascript">
        currentLanguage = 'enUs';
        /*
         * Date Format 1.2.3
         * (c) 2007-2009 Steven Levithan <stevenlevithan.com>
         * MIT license
         *
         * Includes enhancements by Scott Trenda <scott.trenda.net>
         * and Kris Kowal <cixar.com/~kris.kowal/>
         *
         * Accepts a date, a mask, or a date and a mask.
         * Returns a formatted version of the given date.
         * The date defaults to the current date/time.
         * The mask defaults to dateFormat.masks.default.
         */
        var dateFormat = function() {
            var token = /d{1,4}|m{1,4}|yy(?:yy)?|([HhMsTt])\1?|[LloSZ]|"[^"]*"|'[^']*'/g,
                timezone = /\b(?:[PMCEA][SDP]T|(?:Pacific|Mountain|Central|Eastern|Atlantic) (?:Standard|Daylight|Prevailing) Time|(?:GMT|UTC)(?:[-+]\d{4})?)\b/g,
                timezoneClip = /[^-+\dA-Z]/g,
                pad = function(val, len) {
                    val = String(val);
                    len = len || 2;
                    while (val.length < len) val = "0" + val;
                    return val;
                };
            // Regexes and supporting functions are cached through closure
            return function(date, mask, utc) {
                var dF = dateFormat;
                // You can't provide utc if you skip other args (use the "UTC:" mask prefix)
                if (arguments.length == 1 && Object.prototype.toString.call(date) == "[object String]" && !/\d/.test(date)) {
                    mask = date;
                    date = undefined;
                }
                // Passing date through Date applies Date.parse, if necessary
                date = date ? new Date(date) : new Date;
                if (isNaN(date)) throw SyntaxError("invalid date");
                mask = String(dF.masks[mask] || mask || dF.masks["default"]);
                // Allow setting the utc argument via the mask
                if (mask.slice(0, 4) == "UTC:") {
                    mask = mask.slice(4);
                    utc = true;
                }
                var _ = utc ? "getUTC" : "get",
                    d = date[_ + "Date"](),
                    D = date[_ + "Day"](),
                    m = date[_ + "Month"](),
                    y = date[_ + "FullYear"](),
                    H = date[_ + "Hours"](),
                    M = date[_ + "Minutes"](),
                    s = date[_ + "Seconds"](),
                    L = date[_ + "Milliseconds"](),
                    o = utc ? 0 : date.getTimezoneOffset(),
                    flags = {
                        d: d,
                        dd: pad(d),
                        ddd: dF.i18n.dayNames[D],
                        dddd: dF.i18n.dayNames[D + 7],
                        m: m + 1,
                        mm: pad(m + 1),
                        mmm: dF.i18n.monthNames[m],
                        mmmm: dF.i18n.monthNames[m + 12],
                        yy: String(y).slice(2),
                        yyyy: y,
                        h: H % 12 || 12,
                        hh: pad(H % 12 || 12),
                        H: H,
                        HH: pad(H),
                        M: M,
                        MM: pad(M),
                        s: s,
                        ss: pad(s),
                        l: pad(L, 3),
                        L: pad(L > 99 ? Math.round(L / 10) : L),
                        t: H < 12 ? "a" : "p",
                        tt: H < 12 ? "am" : "pm",
                        T: H < 12 ? "A" : "P",
                        TT: H < 12 ? "AM" : "PM",
                        Z: utc ? "UTC" : (String(date).match(timezone) || [""]).pop().replace(timezoneClip, ""),
                        o: (o > 0 ? "-" : "+") + pad(Math.floor(Math.abs(o) / 60) * 100 + Math.abs(o) % 60, 4),
                        S: ["th", "st", "nd", "rd"][d % 10 > 3 ? 0 : (d % 100 - d % 10 != 10) * d % 10]
                    };
                return mask.replace(token, function($0) {
                    return $0 in flags ? flags[$0] : $0.slice(1, $0.length - 1);
                });
            };
        }();
        // Some common format strings
        dateFormat.masks = {
            "default": "ddd mmm dd yyyy HH:MM:ss",
            shortDate: "m/d/yy",
            mediumDate: "mmm d, yyyy",
            longDate: "mmmm d, yyyy",
            fullDate: "dddd, mmmm d, yyyy",
            shortTime: "h:MM TT",
            mediumTime: "h:MM:ss TT",
            longTime: "h:MM:ss TT Z",
            isoDate: "yyyy-mm-dd",
            isoTime: "HH:MM:ss",
            isoDateTime: "yyyy-mm-dd'T'HH:MM:ss",
            isoUtcDateTime: "UTC:yyyy-mm-dd'T'HH:MM:ss'Z'"
        };
        // Internationalization strings
        dateFormat.i18n = {
            dayNames: [
                "Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat",
                "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"
            ],
            monthNames: [
                "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec",
                "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"
            ]
        };
        // For convenience...
        Date.prototype.format = function(mask, utc) {
            return dateFormat(this, mask, utc);
        };
    </script></head>
	
		<body class="ap-jsp-body postlogin ap-clientType-individual" lang="en" accessaccount="9087952354" sbu="F" sid="2da5fcd73c80f77d2e36" jid="jMf0p2QVq8mv1RJl-hjMAMF" id="ap-page-body" role="application">
	
		
		<script language="JavaScript" type="text/javascript"><!--
			/* You may give each page an identifying name, server, and channel on the next lines. */
			s.pageName = "isf:home";
			s.server = "";
			s.channel = "";
			s.pageType = "";
			s.prop1 = "";
			s.prop2 = "";
			s.prop3 = "";
			s.prop4 = "";
			s.prop5 = "";
			/* Conversion Variables */
			s.campaign = "";
			s.state = "";
			s.zip = "";
			s.events = "";
			s.products = "";
			s.purchaseID = "";
			s.eVar1 = "";
			s.eVar2 = "";
			s.eVar3 = "";
			s.eVar4 = "";
			s.eVar5 = "";
			var s_code = s.t();
			if (s_code) document.write(s_code);//-->
		</script>
		
		<!-- Please wait splash -->
		
		
		
		<div style="position:fixed; top:0px; left:0px; z-index:106; width:100%; height:54px; background:#FFFFFF; padding:10px 0px 0px 10px; box-shadow: 0 4px 8px 0 rgba(0,0,0,.16);">
			<img src="./front_2_files/logo-red.png" width="44" height="44">
		</div>
		
		
			<div role="banner" class="ap-page-header" style="z-index:106;">
		
			
				
					<!-- <img role="presentation" src="static/style/resources/absa-logo-2018.png" width="141" height="97" style="position:absolute; top:12px;" /> -->
				
			
			<div class="ap-navigation-message">
			
				
			
			
			
			
				<div class="ap-navigation-links">
					<!-- PS: Private banking code changes will remain dormant till some code finalization -->
					
					
						<a class="ui-link" style="margin-right:5px" href="http://www.absa.co.za/Absacoza/Contact-Us" target="blank" onclick="var x=&quot;.tl(&quot;;s_objectID=&quot;http://www.absa.co.za/Absacoza/Contact-Us_1&quot;;return this.s_oc?this.s_oc(e):true">
							Contact us
						</a> |
					
					<a class="ui-link" style="margin-right:5px;margin-left:5px" href="http://www.absa.co.za/Absacoza/Individual/Ways-to-Bank/Anytime%2C-Anywhere/Absa-Online" target="blank" onclick="var x=&quot;.tl(&quot;;s_objectID=&quot;http://www.absa.co.za/Absacoza/Individual/Ways-to-Bank/Anytime%2C-Anywhere/Absa-Online_1&quot;;return this.s_oc?this.s_oc(e):true">
						Help
					</a> |
					<a class="ui-link" onclick="absa.print.printFullPageGeneric(this)" style="margin-right:5px;margin-left:5px">
						Print
					</a> |
					<a onclick="absa.index.doLogout(1)" class="ui-link" style="margin-left:5px">
						Logoff
					</a>
				</div>
			
			</div>
			
			
				<div class="ap-navigation-main" id="viMainNavigation" style="z-index:107;">
					<div class="ap-tabStrip-rounded-left"></div>
<ul role="navigation" class="ap-tabStrip-tabs">
						
								<li class="ap-tab-button " id="SSR-tab-00">
									<a name="tabNo0" for="mTabNo0" style="position:absolute;"></a>
									<a role="link" accesskey="" id="mTabNo0" href="#" style="text-decoration:none" onclick="var x=&quot;.tl(&quot;;s_objectID=&quot;https://ib.absa.co.za/absa-online/index.jsp?axob=2&amp;lang=E&amp;rid=1174802268&amp;goto=https://ib.absa.co._1&quot;;return this.s_oc?this.s_oc(e):true">
										<div class="ap-tab-title">Express</div>
										<div class="ap-tab-title-hidden">Express</div>
									</a>
								</li>
						 
						
							
						
							
						
							
						
							
						
							
						
							
						
					<li class="ap-tab-button" id="SSR-tab-l16" style="user-select: none;">
								<a name="tabNo1" for="mTabNo1" style="position:absolute;"></a>
								<a role="link" accesskey="1" id="mTabNo1" href="#" style="text-decoration:none" onclick="var x=&quot;.tl(&quot;;s_objectID=&quot;https://ib.absa.co.za/absa-online/index.jsp?axob=2&amp;lang=E&amp;rid=1174802268&amp;goto=https://ib.absa.co._2&quot;;return this.s_oc?this.s_oc(e):true">
									<div class="ap-tab-title">Accounts</div>
									<div class="ap-tab-title-hidden">Accounts</div>
								</a>
							</li><li class="ap-tab-button" id="SSR-tab-l74" style="user-select: none;">
								<a name="tabNo2" for="mTabNo2" style="position:absolute;"></a>
								<a role="link" accesskey="2" id="mTabNo2" href="#" style="text-decoration:none" onclick="var x=&quot;.tl(&quot;;s_objectID=&quot;https://ib.absa.co.za/absa-online/index.jsp?axob=2&amp;lang=E&amp;rid=1174802268&amp;goto=https://ib.absa.co._3&quot;;return this.s_oc?this.s_oc(e):true">
									<div class="ap-tab-title">Payments</div>
									<div class="ap-tab-title-hidden">Payments</div>
								</a>
							</li><li class="ap-tab-button" id="SSR-tab-l3" style="user-select: none;">
								<a name="tabNo3" for="mTabNo3" style="position:absolute;"></a>
								<a role="link" accesskey="3" id="mTabNo3" href="#" style="text-decoration:none" onclick="var x=&quot;.tl(&quot;;s_objectID=&quot;https://ib.absa.co.za/absa-online/index.jsp?axob=2&amp;lang=E&amp;rid=1174802268&amp;goto=https://ib.absa.co._4&quot;;return this.s_oc?this.s_oc(e):true">
									<div class="ap-tab-title">Save and Invest</div>
									<div class="ap-tab-title-hidden">Save and Invest</div>
								</a>
							</li><li class="ap-tab-button" id="SSR-tab-l49" style="user-select: none;">
								<a name="tabNo4" for="mTabNo4" style="position:absolute;"></a>
								<a role="link" accesskey="4" id="mTabNo4" href="#" style="text-decoration:none" onclick="var x=&quot;.tl(&quot;;s_objectID=&quot;https://ib.absa.co.za/absa-online/index.jsp?axob=2&amp;lang=E&amp;rid=1174802268&amp;goto=https://ib.absa.co._5&quot;;return this.s_oc?this.s_oc(e):true">
									<div class="ap-tab-title">Apply</div>
									<div class="ap-tab-title-hidden">Apply</div>
								</a>
							</li><li class="ap-tab-button" id="SSR-tab-l32" style="user-select: none;">
								<a name="tabNo5" for="mTabNo5" style="position:absolute;"></a>
								<a role="link" accesskey="5" id="mTabNo5" href="#" style="text-decoration:none" onclick="var x=&quot;.tl(&quot;;s_objectID=&quot;https://ib.absa.co.za/absa-online/index.jsp?axob=2&amp;lang=E&amp;rid=1174802268&amp;goto=https://ib.absa.co._6&quot;;return this.s_oc?this.s_oc(e):true">
									<div class="ap-tab-title">Insure</div>
									<div class="ap-tab-title-hidden">Insure</div>
								</a>
							</li><li class="ap-tab-button ap-tab-active" id="SSR-tab-l35" style="user-select: none;">
								<a name="tabNo6" for="mTabNo6" style="position:absolute;"></a>
								<a role="link" accesskey="6" id="mTabNo6" href="#" style="text-decoration:none" onclick="var x=&quot;.tl(&quot;;s_objectID=&quot;https://ib.absa.co.za/absa-online/index.jsp?axob=2&amp;lang=E&amp;rid=1174802268&amp;goto=https://ib.absa.co._7&quot;;return this.s_oc?this.s_oc(e):true">
									<div class="ap-tab-title">Profile</div>
									<div class="ap-tab-title-hidden">Profile</div>
								</a>
				  </li></ul>
					<div class="ap-tabStrip-rounded-right"></div>
					<div style="clear: both;"></div>
					
					
						<!-- <img src="static/style/resources/ao-logo2.png" width="189" height="60" style="position:absolute;top:0;right:4px" /> -->
					
					
					<div class="ap-navigation-sub ap-tabStrip-subnav">
						
							<ul class="ap-tabStrip-subnav-l16">
								
									<li class="ap-tab-button" href="">
										<div tabindex="0">Make your selection below by clicking on the applicable account, function or Quicklink icon.</div>
									</li>
								
							</ul>
						
							<ul class="ap-tabStrip-subnav-l74 ">
								
									<li class="ap-tab-button" href="">
										<div tabindex="0">Make your selection below by clicking on the applicable function or Quicklink icon.</div>
									</li>
								
							</ul>
						
							<ul class="ap-tabStrip-subnav-l3 ">
								
									<li class="ap-tab-button" href="">
										<div tabindex="0">Make your selection below by clicking on the applicable function or Quicklink icon.</div>
									</li>
								
							</ul>
						
							<ul class="ap-tabStrip-subnav-l49 ">
								
									<li class="ap-tab-button" href="">
										<div tabindex="0">Make your selection below by clicking on the applicable account, function or service.</div>
									</li>
								
							</ul>
						
							<ul class="ap-tabStrip-subnav-l32 ">
								
									<li class="ap-tab-button" href="">
										<div tabindex="0">Make your selection below by clicking on the appropriate quick links</div>
									</li>
								
							</ul>
						
							<ul class="ap-tabStrip-subnav-l35  ap-subnav-active">
								
									<li class="ap-tab-button" href="">
										<div tabindex="0">Make your selection below by clicking on the applicable function.</div>
									</li>
								
							</ul>
						
						<div class="ap-switchTo-container" tabindex="0">
							<!-- PS: where Feature Store buttons used to be -->
						</div>
					</div>
				</div>
			
		</div>
		
		
		<div class="ap-page-container" id="ap-page-container-div">
			
			<div></div>
			<div class="ap-global-message" id="ap-global-message">
				<div id="ap-nocookies-msg" style="display: none;">
					Warning: you do not have Cookies enabled. This applications needs Cookies to function
					properly. Please turn it on and reload the page. If you need assistance
					in turning on your Cookies <a>click here</a> to get instructions.
				</div>
				<noscript>
					<div>
						Warning: you do not have Javascript enabled. This
						applications needs Javascript to function properly. Please turn it on
						and reload the page. If you need assistance in turning on your
						Javascript <a>click here</a> to get instructions.
					</div>
				</noscript>
			</div>
			
			
			<script type="text/javascript">
				bb.cookie.set("bbCookiesChk",new Date().getTime());
				if (!bb.cookie.get("bbCookiesChk")) {
					document.getElementById('ap-nocookies-msg').style.display = "";
				} else {
					bb.cookie.set("bbCookiesChk","", -1);
				}
			</script>
			
			
			
			
				<div class="ap-main-content-wrapper">
			
			
				<div class="ap-main-content-wrapper-top">
					<div class="ap-corners-rounded-top-left"></div>
					<div class="ap-corners-rounded-top"></div>
					<div class="ap-corners-rounded-top-right"></div>
				</div>
				<!-- dashboard -->
				<div class="ap-page-content ap-container">
					<!--
					
					-->
					
					<div id="gadget-placeholder-l2-g3010113" class="ap-page-content-dashboard" style="display:none;"></div>
					<div id="gadget-placeholder-l3-g3010113" class="ap-page-content-dashboard" style="display:none;"></div>
					
					
					<div id="gadget-placeholder-l2-g300031" class="ap-page-content-dashboard" style=""><div class="p-gadget ap-accountbar ap-dashboard-dummy" style="position: static; display: none;"><div class="ap-container"><div class="ap-titlebar p-gadget-top-left p-gadget-header" style="user-select: none; cursor: default;"><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-restore ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line ">Show section Dashboard</span></div><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-minimize ap-bar-section ap-icon-bar-status" style="display: none;"><span class="vi-screenreader-line ">Hide section Dashboard</span></div><div class="p-gadget-title-container"><div tabindex="0" class="p-gadget-title ap-bar-section ap-bar-title">Dashboard</div><div class="p-gadget-subTitle"></div></div><div class="p-gadget-draggable-section"><button class="p-gadget-draggable-button"></button></div></div><div tabindex="-1" role="application" class="p-gadget-content" id="g30"><div xmlns="http://www.w3.org/1999/xhtml" class="ap-gadget-lazyContent" proxyurl="proxy?pipe=dashboard&amp;tabSectionName=Account&amp;tabItems=NettWorthGraphs,messages&amp;tabUrlItems=Dashboards/Accounts/account-dashboard,Dashboards/messages"><div xmlns="http://www.w3.org/1999/xhtml" class="p-gadget ap-highlevel-gadget ui-tabBox ap-dashBoard-tabBox p-gadget-minimized" disablefirsttabload="true"><div class="p-gadget-top-left p-gadget-header ap-titlebar"><div class="p-gadget-button p-gadget-button-restore ap-bar-section ap-icon-bar-status" role="button" tabindex="0"></div><div class="p-gadget-button p-gadget-button-minimize ap-bar-section ap-icon-bar-status" role="button" tabindex="0"></div><div class="vi-screenreader-line"><div class="ui-tabHeads-start" tabindex="0"></div></div><ul class="ui-tabHeads ui-tabHeads-titlebar"><li tabindex="0" role="button" class="ui-tabHead ap-tabHead-nettWorthGraphs   ui-tab-first-tab">My financial management tools<span class="vi-screenreader-line "> 1 of 2 Tab. </span><div style="width:100%"><div class="ui-tabBox--type2--image"></div></div></li><li tabindex="0" role="button" class="ui-tabHead ap-viewSecureMessage ap-tabHead-viewSecureMessage ">Messages <span xmlns:ui="http://www.absa.co.za/2009/ui" class="ap-dashBoard-messageNumber"></span><span class="vi-screenreader-line "> 2 of 2 Tab. </span><div style="width:100%"><div class="ui-tabBox--type2--image"></div></div></li></ul><div class="vi-screenreader-line"><div class="ui-tabHeads-end" tabindex="0"></div></div><button class="ui-button ap-icon-print" type="button" tabindex="0" tooltip="Print this content" onclick="absa.print.printGadgetDashboardGeneric(this)" aria-label="Print this content. "><div class="ui-button-left"><div class="ui-button-right"><div class="ui-button-center"><span class="vi-screenreader-line ">Print this content. </span></div></div></div></button></div><div class="p-gadget-content"><div class="ap-dashboard-content"><div class="ui-tabBodies ui-tabBodies-noborder"><div class="ui-tabBody ap-accountDashboard-nettWorth" role="tabpanel" tabindex="0" aria-busy="false" aria-hidden="false" proxyurl="proxy?pipe=genericEmptyResponse&amp;xslFile=Dashboards/Accounts/account-dashboard" onlazyloadnode="absa.gadgets.dashboard.refreshPrefrences(this)"></div><div class="ui-tabBody " role="tabpanel" tabindex="0" aria-busy="true" aria-hidden="true" proxyurl="proxy?pipe=genericEmptyResponse&amp;xslFile=Dashboards/messages" onlazyloadnode="absa.apps.viewSecureMessages.onlazyLoadTabBody(this, true);"></div><div class="vi-screenreader-line"><div class="ui-tabBox-tab-finish" tabindex="0"></div><div class="ui-tabBox-body-end" tabindex="0"></div></div></div></div></div></div></div>
		<div></div></div></div></div></div>
					<div id="gadget-placeholder-l3-g300032" class="ap-page-content-dashboard" style="display: none;"><div class="p-gadget p-gadget-loading" style="position: static;"><div class="ap-container"><div class="ap-titlebar p-gadget-top-left p-gadget-header" style="user-select: none;"><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-restore ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line "></span></div><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-minimize ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line "></span></div><div class="p-gadget-title-container"><div tabindex="0" class="p-gadget-title ap-bar-section ap-bar-title"></div><div class="p-gadget-subTitle"></div></div><div class="p-gadget-draggable-section"><button class="p-gadget-draggable-button"></button></div></div><div tabindex="-1" role="application" class="p-gadget-content"></div></div></div></div>
					<div id="gadget-placeholder-l4-g300033" class="ap-page-content-dashboard" style="display: none;"><div class="p-gadget p-gadget-loading" style="position: static;"><div class="ap-container"><div class="ap-titlebar p-gadget-top-left p-gadget-header" style="user-select: none;"><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-restore ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line "></span></div><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-minimize ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line "></span></div><div class="p-gadget-title-container"><div tabindex="0" class="p-gadget-title ap-bar-section ap-bar-title"></div><div class="p-gadget-subTitle"></div></div><div class="p-gadget-draggable-section"><button class="p-gadget-draggable-button"></button></div></div><div tabindex="-1" role="application" class="p-gadget-content"></div></div></div></div>
					<div id="gadget-placeholder-l5-g300034" class="ap-page-content-dashboard" style="display: none;"><div class="p-gadget p-gadget-loading" style="position: static;"><div class="ap-container"><div class="ap-titlebar p-gadget-top-left p-gadget-header" style="user-select: none;"><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-restore ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line "></span></div><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-minimize ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line "></span></div><div class="p-gadget-title-container"><div tabindex="0" class="p-gadget-title ap-bar-section ap-bar-title"></div><div class="p-gadget-subTitle"></div></div><div class="p-gadget-draggable-section"><button class="p-gadget-draggable-button"></button></div></div><div tabindex="-1" role="application" class="p-gadget-content"></div></div></div></div>
					<div id="gadget-placeholder-l7-g300036" class="ap-page-content-dashboard" style=""><div class="p-gadget ap-accountbar ap-dashboard-dummy" style="position: static;"><div class="ap-container"><div class="ap-titlebar p-gadget-top-left p-gadget-header" style="user-select: none; cursor: default;"><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-restore ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line ">Show section Dashboard</span></div><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-minimize ap-bar-section ap-icon-bar-status" style="display: none;"><span class="vi-screenreader-line ">Hide section Dashboard</span></div><div class="p-gadget-title-container"><div tabindex="0" class="p-gadget-title ap-bar-section ap-bar-title">Dashboard</div><div class="p-gadget-subTitle"></div></div><div class="p-gadget-draggable-section"><button class="p-gadget-draggable-button"></button></div></div><div tabindex="-1" role="application" class="p-gadget-content" id="g39"><div xmlns="http://www.w3.org/1999/xhtml" class="ap-gadget-lazyContent" proxyurl="proxy?pipe=dashboard&amp;tabSectionName=Profile&amp;tabItems=iLearning,messages&amp;tabUrlItems=iLearning/iLearning,Dashboards/messages"><div xmlns="http://www.w3.org/1999/xhtml" class="p-gadget ap-highlevel-gadget ui-tabBox ap-dashBoard-tabBox p-gadget-minimized" disablefirsttabload="true"><div class="p-gadget-top-left p-gadget-header ap-titlebar"><div class="p-gadget-button p-gadget-button-restore ap-bar-section ap-icon-bar-status" role="button" tabindex="0"></div><div class="p-gadget-button p-gadget-button-minimize ap-bar-section ap-icon-bar-status" role="button" tabindex="0"></div><div class="vi-screenreader-line"><div class="ui-tabHeads-start" tabindex="0"></div></div><ul class="ui-tabHeads ui-tabHeads-titlebar"><li tabindex="0" role="button" class="ui-tabHead ap-viewSecureMessage ap-tabHead-viewSecureMessage  ui-tab-first-tab">Messages <span xmlns:ui="http://www.absa.co.za/2009/ui" class="ap-dashBoard-messageNumber"></span><span class="vi-screenreader-line "> 1 of 1 Tab. </span><div style="width:100%"><div class="ui-tabBox--type2--image"></div></div></li></ul><div class="vi-screenreader-line"><div class="ui-tabHeads-end" tabindex="0"></div></div><button class="ui-button ap-icon-print" type="button" tabindex="0" tooltip="Print this content" onclick="absa.print.printGadgetDashboardGeneric(this)" aria-label="Print this content. "><div class="ui-button-left"><div class="ui-button-right"><div class="ui-button-center"><span class="vi-screenreader-line ">Print this content. </span></div></div></div></button></div><div class="p-gadget-content"><div class="ap-dashboard-content"><div class="ui-tabBodies ui-tabBodies-noborder"><div class="ui-tabBody " role="tabpanel" tabindex="0" aria-busy="false" aria-hidden="false" proxyurl="proxy?pipe=genericEmptyResponse&amp;xslFile=Dashboards/messages" onlazyloadnode="absa.apps.viewSecureMessages.onlazyLoadTabBody(this, true);"></div><div class="vi-screenreader-line"><div class="ui-tabBox-tab-finish" tabindex="0"></div><div class="ui-tabBox-body-end" tabindex="0"></div></div></div></div></div></div></div>
		<div></div></div></div></div></div>
					<div id="gadget-placeholder-l2-g3010004" class="ap-page-content-dashboard" style="display: none;"></div>
					<div id="gadget-placeholder-l3010079-g3010082" class="ap-page-content-dashboard ap-dashboard-insurance" style="display: none;"><div class="p-gadget p-gadget-loading" style="position: static;"><div class="ap-container"><div class="ap-titlebar p-gadget-top-left p-gadget-header" style="user-select: none;"><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-restore ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line "></span></div><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-minimize ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line "></span></div><div class="p-gadget-title-container"><div tabindex="0" class="p-gadget-title ap-bar-section ap-bar-title"></div><div class="p-gadget-subTitle"></div></div><div class="p-gadget-draggable-section"><button class="p-gadget-draggable-button"></button></div></div><div tabindex="-1" role="application" class="p-gadget-content"></div></div></div></div>
					
					
					
					<div id="content" tabindex="0" role="main" aria-label="ABSA online main conent area" class="ap-container-highlevel">
						
							<div class="ap-titlebar ap-heading-titlebar">
								
									<div class="ap-heading-titlebar-item ap-container-top-l2" id="ap-container-top-l2">
										<h2 tabindex="0" class="ap-bar-section ap-bar-title" style="width:170px" id="ap-bar-section-Accounts">
											
												
												
												
													Accounts
												
											
										</h2>
										
										
											<div class="ap-bar-section ap-bar-section-right ap-bar-align-right" style="width: 272px; padding-right: 16px; float:right" id="ap-bar-section-accounts-options">Quicklinks</div>
										
										
										
										
									</div>
								
									<div class="ap-heading-titlebar-item ap-container-top-l3 " id="ap-container-top-l3">
										<h2 tabindex="0" class="ap-bar-section ap-bar-title" style="width:170px" id="ap-bar-section-Payments">
											
												
												
												
													Payment types
												
											
										</h2>
										
										
										
											<div class="ap-bar-section ap-bar-section-right ap-bar-align-right ap-bar-divider" style="width: 272px; padding-right: 16px; float:right" id="ap-bar-section-accounts-options">Quicklinks</div>
										
										
										
									</div>
								
									<div class="ap-heading-titlebar-item ap-container-top-l4 " id="ap-container-top-l4">
										<h2 tabindex="0" class="ap-bar-section ap-bar-title" style="width:170px" id="ap-bar-section-saveInvest">
											
												
													Total Investment Portfolio
												
												
												
											
										</h2>
										
										
										
										
											<div class="ap-bar-section ap-bar-section-right ap-bar-align-right ap-bar-divider" style="width: 272px; padding-right: 25px; float:right" id="ap-bar-section-accounts-options">Quicklinks</div>
										
										
									</div>
								
									<div class="ap-heading-titlebar-item ap-container-top-l5 " id="ap-container-top-l5">
										<h2 tabindex="0" class="ap-bar-section ap-bar-title" style="width:170px" id="ap-bar-section-Apply">
											
												
												
												
													Apply
												
											
										</h2>
										
										
										
										
										
									</div>
								
									<div class="ap-heading-titlebar-item ap-container-top-l3010079 " id="ap-container-top-l3010079">
										<h2 tabindex="0" class="ap-bar-section ap-bar-title" style="width:170px" id="ap-bar-section-Insurance">
											
												
												
													Policies
												
												
											
										</h2>
										
										
										
										
										
											<div class="ap-bar-section ap-bar-section-right ap-bar-align-right ap-bar-divider" style="width: 272px; padding-right: 25px; float:right" id="ap-bar-section-insurance-options">Quick links</div>
										
									</div>
								
									<div class="ap-heading-titlebar-item ap-container-top-l7  ap-container-top-show" id="ap-container-top-l7">
										<h2 tabindex="0" class="ap-bar-section ap-bar-title" style="width:170px" id="ap-bar-section-Profile">
											
												
												
												
													Profile
												
											
										</h2>
										
										
										
										
										
									</div>
								
							</div>
						
						
						
						<div class="ap-container-content ap-profile-container" id="ap-container-wrapper">
							
								<!-- Payments Bar -->
								<table class="ui-grid ap-payments-bar" xmlns="http://www.w3.org/1999/xhtml">
									<tbody class="ui-rows">
										<tr class="ui-row">
											<td style="width:438px;" class="ui-cell"></td>
											<td style="width:160px;" class="ui-cell"></td>
											<td style="width:124px; padding-right:26px" class="ui-cell ap-common-alignRight ap-refreshBalance-quickLinks ">
												<button aria-label="Resend payment notification" onclick="gadgets.pubsub.publish(&#39;goTo:mainBeneficiaries/viewOrManageBeneficiariesOrGroups&#39;)" tooltip="Resend payment notification" tabindex="0" type="button" class="ui-button ap-icon-resend" anchorpoint="mouse" offsetx="0" offsety="10">
													<div class="ui-button-left">
														<div class="ui-button-right">
															<div class="ui-button-center">
																<span class="vi-screenreader-line ">Resend payment notification</span>
															</div>
														</div>
													</div>
												</button>
												<button aria-label="Print this content" onclick="absa.print.printFullPageGeneric(this)" tooltip="Print this content" tabindex="0" class="ui-button ap-icon-print" type="button">
													<div class="ui-button-left">
														<div class="ui-button-right">
															<div class="ui-button-center">
																<span class="vi-screenreader-line ">Print this content</span>
															</div>
														</div>
													</div>
												</button>
												<!-- PaySingle QuickLink -->
												<button aria-label="Click here to pay a beneficiary" onclick="absa.index.paySingle.doPayBen(this);" tooltip="Click here to pay a beneficiary" tabindex="0" type="button" class="ui-button ap-icon-paySingle ap-payBeneficiary-button">
													<div class="ui-button-left">
														<div class="ui-button-right">
															<div class="ui-button-center">
																<span class="vi-screenreader-line ">Click here to pay a beneficiary</span>
															</div>
														</div>
													</div>
												</button>
											</td>
										</tr>
									</tbody>
								</table>
	
								<!-- Save Invest Bar -->
								<table class="ui-grid ap-saveInvest-bar" xmlns="http://www.w3.org/1999/xhtml">
									<tbody class="ui-rows">
										<tr class="ui-row">
											<td style="width:438px;" class="ui-cell ap-refreshBalance-lastRefreshedCell ">
												These values are not real-time and are based on the latest available uploaded closing prices per product.
											</td>
											<td style="width:175px;" class="ui-cell ap-common-alignRight ">Balance (R)</td>
											<td style="width:103px;padding-right:37px" class="ui-cell ap-common-alignRight ap-refreshBalance-quickLinks ">
												<button aria-label="Link or unlink accounts" onclick="gadgets.pubsub.publish(&#39;goTo:profile/linkUnlinkAccounts/linkUnlinkRetail&#39;);" style="margin-right:0px;" tooltip="Link or unlink accounts" tabindex="0" type="button" class="ui-button ap-icon-link">
													<div class="ui-button-left">
														<div class="ui-button-right">
															<div class="ui-button-center">
																<span class="vi-screenreader-line ">Link or unlink accounts</span>
															</div>
														</div>
													</div>
												</button>
												<button aria-label="Print this content" onclick="absa.print.printPopupSaveInvest(this)" tooltip="Print this content" tabindex="0" class="ui-button ap-icon-print" type="button">
													<div class="ui-button-left">
														<div class="ui-button-right">
															<div class="ui-button-center">
																<span class="vi-screenreader-line ">Print this content</span>
															</div>
														</div>
													</div>
												</button>
												<!-- PaySingle QuickLink -->
												<button aria-label="Click here to pay a beneficiary" onclick="absa.index.paySingle.doPayBen(this);" tooltip="Click here to pay a beneficiary" tabindex="0" type="button" class="ui-button ap-icon-paySingle ap-payBeneficiary-button">
													<div class="ui-button-left">
														<div class="ui-button-right">
															<div class="ui-button-center">
																<span class="vi-screenreader-line ">Click here to pay a beneficiary</span>
															</div>
														</div>
													</div>
												</button>
											</td>
										</tr>
									</tbody>
								</table>
	
								<!-- Refresh Balances Bar -->
								<table class="ui-grid ap-refreshBalances-bar" xmlns="http://www.w3.org/1999/xhtml">
									<tbody class="ui-rows">
										<tr class="ui-row">
											<td style="width:278px;" class="ui-cell ap-refreshBalance-lastRefreshedCell ">
												Last refreshed at:
												<span class="ap-refreshBalances-dateTime">2019-09-20 14:33:26</span>
											</td>
											<td style="width:144px" class="ui-cell ap-common-alignRight ">Uncleared (R)</td>
											<td style="width:160px;" class="ui-cell ap-common-alignRight ">Available (R)</td>
											<td style="width:179px;" class="ui-cell ap-common-alignRight ">Balance (R)</td>
											<td style="width:158px; padding:0px 28px 0px 0px;" class="ui-cell ap-common-alignRight ap-refreshBalance-quickLinks ">
												<button aria-label="Click to refresh balances." onclick="absa.util.observer.publish(&#39;load-balances&#39;,&#39;&#39;);" tooltip="Click to refresh balances." tabindex="0" type="button" class="ui-button ap-icon-change ap-refreshBalance-button">
													<div class="ui-button-left">
														<div class="ui-button-right">
															<div class="ui-button-center">
																<span class="vi-screenreader-line ">Click to refresh balances.</span>
															</div>
														</div>
													</div>
												</button>
												
													<button aria-label="Print this content" onclick="absa.print.printFullPageGeneric(this)" tooltip="Print this content" tabindex="0" class="ui-button ap-icon-print" type="button">
														<div class="ui-button-left">
															<div class="ui-button-right">
																<div class="ui-button-center">
																	<span class="vi-screenreader-line ">Print this content</span>
																</div>
															</div>
														</div>
													</button>
												
												<button aria-label="Link or unlink accounts" onclick="gadgets.pubsub.publish(&#39;goTo:profile/linkUnlinkAccounts/linkUnlinkRetail&#39;);" tooltip="Link or unlink accounts" tabindex="0" type="button" class="ui-button ap-icon-link">
													<div class="ui-button-left">
														<div class="ui-button-right">
															<div class="ui-button-center">
																<span class="vi-screenreader-line ">Link or unlink accounts</span>
															</div>
														</div>
													</div>
												</button>
												<button aria-label="Click to rearrange your accounts" onclick="absa.index.rearrangeAccounts.onRearrangeAccountsClick(this)" tooltip="Click to rearrange your accounts" tabindex="0" type="button" class="ui-button ap-icon-sortBeneficiaries">
													<div class="ui-button-left">
														<div class="ui-button-right">
															<div class="ui-button-center">
																<span class="vi-screenreader-line ">Link or unlink accounts</span>
															</div>
														</div>
													</div>
												</button>
												<!-- PaySingle QuickLink -->
												<button aria-label="Click here to pay a beneficiary" onclick="absa.index.paySingle.doPayBen(this);" tooltip="Click here to pay a beneficiary" tabindex="0" type="button" class="ui-button ap-icon-paySingle ap-payBeneficiary-button">
													<div class="ui-button-left">
														<div class="ui-button-right">
															<div class="ui-button-center">
																<span class="vi-screenreader-line ">Click here to pay a beneficiary</span>
															</div>
														</div>
													</div>
												</button>
											</td>
										</tr>
									</tbody>
								</table>
	
								<!-- Insurances Bar -->
								<table class="ui-grid ap-insurances-bar" xmlns="http://www.w3.org/1999/xhtml">
									<tbody class="ui-rows">
										<tr class="ui-row">
											<td style="width:395px;" class="ui-cell ap-insurances-lastRefreshedCell">
												Last refreshed at: <date and="" time="">
												<span class="ap-insurances-dateTime"></span>
											</date></td>
											<td style="width:135px;" class="ui-cell ap-common-alignRight ">Status</td>
											<td style="width:131px;" class="ap-common-alignRight ">
												Cover amount (R)
											</td>
											<td>
												<button class="ap-icon-info-transparent" style="margin-top: 8px;" tooltip="A detailed breakdown of cover amount is available under &#39;Manage policy&#39;- for each individual policy" <="" button="">
											</button></td>
											<td style="width:143px;" class="ui-cell ap-common-alignRight ">Premium amount (R)</td>
											<td style="width:143px;" class="ui-cell ap-common-alignRight ap-insurances-quickLinks ">
												<button aria-label="Refresh" onclick="absa.util.observer.publish(&#39;load-insurance-balances&#39;,&#39;&#39;);" tooltip="Refresh" tabindex="0" type="button" class="ui-button ap-icon-change ap-insurances-button">
													<div class="ui-button-left">
														<div class="ui-button-right">
															<div class="ui-button-center">
																<span class="vi-screenreader-line ">Refresh</span>
															</div>
														</div>
													</div>
												</button>
												<button aria-label="Link/Unlink" onclick="gadgets.pubsub.publish(&#39;goTo:profile/linkUnlinkAccounts/linkUnlinkPolicies&#39;);" tooltip="Link/Unlink" tabindex="0" type="button" class="ui-button ap-icon-link">
													<div class="ui-button-left">
														<div class="ui-button-right">
															<div class="ui-button-center">
																<span class="vi-screenreader-line ">Link/Unlink</span>
															</div>
														</div>
													</div>
												</button>
												<button aria-label="Print" onclick="absa.print.printFullPageGeneric(this)" tooltip="Print this content" tabindex="0" class="ui-button ap-icon-print" type="button">
													<div class="ui-button-left">
														<div class="ui-button-right">
															<div class="ui-button-center">
																<span class="vi-screenreader-line ">Print</span>
															</div>
														</div>
													</div>
												</button>
												<!-- PaySingle QuickLink -->
												<button aria-label="Click here to pay a beneficiary" onclick="absa.index.paySingle.doPayBen(this);" tooltip="Click here to pay a beneficiary" tabindex="0" type="button" class="ui-button ap-icon-paySingle ap-payBeneficiary-button">
													<div class="ui-button-left">
														<div class="ui-button-right">
															<div class="ui-button-center">
																<span class="vi-screenreader-line ">Click here to pay a beneficiary</span>
															</div>
														</div>
													</div>
												</button>
											</td>
										</tr>
									</tbody>
								</table>
	
								<!-- Save n Invest : Absa Savings Portfolio the 1st group on the page -->
								<div class="ap-grouped-layout">
									<!-- Titlebar of the first group -->
									<div class="ap-titlebar ap-heading-save-invest">
										<div class="ap-heading-titlebar-item ap-container-top-show" style="padding-right:105px">
											<div class="ap-bar-section ap-bar-title">Absa Investment portfolio</div>
											<div id="absaInvestment-Networth" class="ap-bar-section ap-bar-title" style="float:right; text-align:right;"></div>
										</div>
									</div>
									<!-- wrapper for the first group gadgets -->
									<div class="ap-grouped-layout-content">
										<!-- PS: add gadget placeholders here, placeholder always starts with gadget-placeholder- container id -->
										<!-- starting with 'l' - gadget id starting with g and id's can be found in the admin -->
										<div id="gadget-placeholder-l4-g3010025" class="gadget-placeholder-l4-A"></div>
									</div>
									<div class="ap-container-bottom-save-invest">
										<div class="ap-corners-rounded-bottom-left"></div>
										<div class="ap-corners-rounded-bottom"></div>
										<div class="ap-corners-rounded-bottom-right"></div>
									</div>
								</div>
							
							
							<!-- Save n Invest : Absa Savings Portfolio the 2nd group on the page -->
							<div class="ap-grouped-layout-portal">
								<!-- Titlebar of the 2nd group -->
								
									<div class="ap-titlebar ap-heading-save-invest">
										<div class="ap-heading-titlebar-item ap-container-top-show" style="padding-right:105px">
											<div class="ap-bar-section ap-bar-title">Absa Savings portfolio</div>
											  <button class="ui-button ap-savingGoalbutton ap-icon-checkerFlag" onclick="absa.index.showHideSavingGadget();" tooltip="Switch view between account balances and savings goal" type="button" anchorpoint="mouse" offsetx="0" offsety="10">
												<div class="ui-button-left">
													<div class="ui-button-right">
														<div class="ui-button-center">
															
														</div>
													</div>
												</div>
											</button>	
											<div id="absaSavings-Networth" class="ap-bar-section ap-bar-title" style="float:right; text-align:right;"></div>
										</div>
									</div>
								
								
								<div class="ap-grouped-layout-content">
									<div class="p-portal" id="portal" style="height: 994px;">
										<div class="p-column-resize-grippy"></div>
										<div class="p-column-resize-line"></div>
										<div class="p-portal-dragPlaceholder"></div>
										
										
													
												
													<div class="p-gadget ap-accountbar  p-gadget-minimized  ap-accountBalances ap-retailAccount current" style="width: 944px; left: 0px; top: 0px; display: none;" accountno="9087952354" balance="false">
														<div class="ap-container">
															<script type="text/javascript"></script>
															<div class="ap-titlebar p-gadget-top-left p-gadget-header" style="user-select: none;">
																<div role="button" tabindex="0" class="p-gadget-button p-gadget-button-restore ap-bar-section ap-icon-bar-status">
																	
																		<span class="vi-screenreader-line ">Show section FLEXI ACC</span>
																	
																</div>
																<div role="button" tabindex="0" class="p-gadget-button p-gadget-button-minimize ap-bar-section ap-icon-bar-status">
																	
																		<span class="vi-screenreader-line ">Hide section FLEXI ACC</span>
																	
																</div>
																<div class="p-gadget-title-container">
																	<div tabindex="0" class="p-gadget-title ap-bar-section ap-bar-title"><div style="line-height:17px" class="ap-bar-section-Accounts" aria-labelledby="ap-bar-section-Accounts"><div class="p-gadget-title-view" style="position:relative;">FLEXI ACC</div></div></div>
																	<div tabindex="0" class="p-gadget-subTitle">9087952354</div>
																</div>
																<div class="p-gadget-draggable-section">
																	<button class="p-gadget-draggable-button"></button>
																</div>
															<div class="ap-gadget-button-container"><button xmlns="http://www.w3.org/1999/xhtml" tabindex="0" type="button" class="ui-button ap-icon-print" tooltip="Print this content"><div class="ui-button-left"><div class="ui-button-right"><div class="ui-button-center"><span class="vi-screenreader-line ">. Print this content</span></div></div></div></button></div><div class="ap-balances"><div style="width: 150px; padding: 10px; margin:0; font-size:12px;" class="ap-bar-section ap-bar-section-right ap-bar-align-right ap-bar-title ap-bar-section-m uncleared-field"><label class="vi-hidden" for="6750303">Uncleared (R):</label><span tabindex="0" class="ap-balances-account-values" id="6750303"> 0.00</span></div><div style="width: 150px; padding: 10px; margin:0; font-size:12px;" class="ap-bar-section ap-bar-section-right ap-bar-align-right ap-bar-title ap-bar-section-m available-field"><label class="vi-hidden" for="6750301">Available (R):</label><span tabindex="0" class="ap-balances-account-values" id="6750301"> 62,008.35</span></div><div style="width: 165px; padding: 10px; margin:0; font-size:12px;" class="ap-bar-section ap-bar-section-right ap-bar-align-right ap-bar-title ap-bar-section-m balance-field"><label class="vi-hidden" for="6750302">Balance (R):</label><span tabindex="0" class="ap-balances-account-values" id="6750302">- 34,124.04</span></div><div class="ap-bar-section ap-bar-section-right ap-bar-align-left ap-bar-section-icons ap-bar-section-icons-options" aria-labelledby="ap-bar-section-accounts-options"><button type="button" tooltip="Click to configure eStatements" class="ui-button ap-icon-statement"><div class="ui-button-left"><div class="ui-button-right"><div class="ui-button-center"><span class="vi-screenreader-line ">Click to configure eStatements. </span></div></div></div></button><button type="button" tooltip="undefined" class="ui-button ap-icon-mobile-inactivated"><div class="ui-button-left"><div class="ui-button-right"><div class="ui-button-center"><span class="vi-screenreader-line ">undefined. </span></div></div></div></button><button type="button" tooltip="Click to change account name" class="ui-button ap-icon-configure"><div class="ui-button-left"><div class="ui-button-right"><div class="ui-button-center"><span class="vi-screenreader-line ">Click to change account name. </span></div></div></div></button></div></div></div>
															
																<div class="p-gadget-content " style="" id="g93" tabindex="-1" role="application" aria-label="">
																	
<div xmlns="http://www.w3.org/1999/xhtml" class="ap-gadget-lazyContent"></div>
<div></div>
																</div>
															
														</div>
													</div>
												
													<div class="p-gadget ap-accountbar  p-gadget-minimized  ap-accountBalances ap-absaReward" style="width: 944px; left: 0px; top: 68px; display: none;" accountno="151027001431" balance="false">
														<div class="ap-container">
															<script type="text/javascript"></script>
															<div class="ap-titlebar p-gadget-top-left p-gadget-header" style="user-select: none;">
																<div role="button" tabindex="0" class="p-gadget-button p-gadget-button-restore ap-bar-section ap-icon-bar-status">
																	
																		<span class="vi-screenreader-line ">Show section Absa Rewards</span>
																	
																</div>
																<div role="button" tabindex="0" class="p-gadget-button p-gadget-button-minimize ap-bar-section ap-icon-bar-status">
																	
																		<span class="vi-screenreader-line ">Hide section Absa Rewards</span>
																	
																</div>
																<div class="p-gadget-title-container">
																	<div tabindex="0" class="p-gadget-title ap-bar-section ap-bar-title"><div style="line-height:17px" class="ap-bar-section-Accounts" aria-labelledby="ap-bar-section-Accounts"><div class="p-gadget-title-view" style="position:relative;">Absa Rewards</div></div></div>
																	<div tabindex="0" class="p-gadget-subTitle">151027001431</div>
																</div>
																<div class="p-gadget-draggable-section">
																	<button class="p-gadget-draggable-button"></button>
																</div>
															<div class="ap-gadget-button-container"><button xmlns="http://www.w3.org/1999/xhtml" tabindex="0" type="button" class="ui-button ap-icon-print" tooltip="Print this content"><div class="ui-button-left"><div class="ui-button-right"><div class="ui-button-center"><span class="vi-screenreader-line ">. Print this content</span></div></div></div></button></div><div class="ap-balances"><div style="width: 150px; padding: 10px; margin:0; font-size:12px;" class="ap-bar-section ap-bar-section-right ap-bar-align-right ap-bar-title ap-bar-section-m uncleared-field"></div><div style="width: 150px; padding: 10px; margin:0; font-size:12px;" class="ap-bar-section ap-bar-section-right ap-bar-align-right ap-bar-title ap-bar-section-m available-field"></div><div style="width: 165px; padding: 10px; margin:0; font-size:12px;" class="ap-bar-section ap-bar-section-right ap-bar-align-right ap-bar-title ap-bar-section-m balance-field"><label class="vi-hidden" for="6891512">Balance (R):</label><span tabindex="0" class="ap-balances-account-values" id="6891512"> 275.00</span></div><div class="ap-bar-section ap-bar-section-right ap-bar-align-left ap-bar-section-icons ap-bar-section-icons-options" aria-labelledby="ap-bar-section-accounts-options"></div></div></div>
															
																<div class="p-gadget-content " style="" id="g94" tabindex="-1" role="application" aria-label="">
																	
<div xmlns="http://www.w3.org/1999/xhtml" class="ap-gadget-lazyContent"></div>
<div></div>
																</div>
															
														</div>
													</div>
												
													<div class="p-gadget ap-accountbar  p-gadget-minimized  ap-accountBalances ap-retailAccount creditCard" style="width: 944px; left: 0px; top: 136px; display: none;" accountno="4787698012625010" balance="false">
														<div class="ap-container">
															<script type="text/javascript"></script>
															<div class="ap-titlebar p-gadget-top-left p-gadget-header" style="user-select: none;">
																<div role="button" tabindex="0" class="p-gadget-button p-gadget-button-restore ap-bar-section ap-icon-bar-status">
																	
																		<span class="vi-screenreader-line ">Show section Credit card account</span>
																	
																</div>
																<div role="button" tabindex="0" class="p-gadget-button p-gadget-button-minimize ap-bar-section ap-icon-bar-status">
																	
																		<span class="vi-screenreader-line ">Hide section Credit card account</span>
																	
																</div>
																<div class="p-gadget-title-container">
																	<div tabindex="0" class="p-gadget-title ap-bar-section ap-bar-title"><div style="line-height:17px" class="ap-bar-section-Accounts" aria-labelledby="ap-bar-section-Accounts"><div class="p-gadget-title-view" style="position:relative;">Credit card account</div></div></div>
																	<div tabindex="0" class="p-gadget-subTitle">4787698012625010</div>
																</div>
																<div class="p-gadget-draggable-section">
																	<button class="p-gadget-draggable-button"></button>
																</div>
															<div class="ap-gadget-button-container"><button xmlns="http://www.w3.org/1999/xhtml" tabindex="0" type="button" class="ui-button ap-icon-print" tooltip="Print this content"><div class="ui-button-left"><div class="ui-button-right"><div class="ui-button-center"><span class="vi-screenreader-line ">. Print this content</span></div></div></div></button></div><div class="ap-balances"><div style="width: 150px; padding: 10px; margin:0; font-size:12px;" class="ap-bar-section ap-bar-section-right ap-bar-align-right ap-bar-title ap-bar-section-m uncleared-field"><label class="vi-hidden" for="8724013">Uncleared (R):</label><span tabindex="0" class="ap-balances-account-values" id="8724013"> 10,000.00</span></div><div style="width: 150px; padding: 10px; margin:0; font-size:12px;" class="ap-bar-section ap-bar-section-right ap-bar-align-right ap-bar-title ap-bar-section-m available-field"><label class="vi-hidden" for="8724011">Available (R):</label><span tabindex="0" class="ap-balances-account-values" id="8724011"> 8,275.21</span></div><div style="width: 165px; padding: 10px; margin:0; font-size:12px;" class="ap-bar-section ap-bar-section-right ap-bar-align-right ap-bar-title ap-bar-section-m balance-field"><label class="vi-hidden" for="8724012">Balance (R):</label><span tabindex="0" class="ap-balances-account-values" id="8724012">- 277,325.79</span></div><div class="ap-bar-section ap-bar-section-right ap-bar-align-left ap-bar-section-icons ap-bar-section-icons-options" aria-labelledby="ap-bar-section-accounts-options"><button type="button" tooltip="Click to configure eStatements" class="ui-button ap-icon-statement"><div class="ui-button-left"><div class="ui-button-right"><div class="ui-button-center"><span class="vi-screenreader-line ">Click to configure eStatements. </span></div></div></div></button><button type="button" tooltip="undefined" class="ui-button ap-icon-mobile-inactivated"><div class="ui-button-left"><div class="ui-button-right"><div class="ui-button-center"><span class="vi-screenreader-line ">undefined. </span></div></div></div></button><button type="button" tooltip="Click to change account name" class="ui-button ap-icon-configure"><div class="ui-button-left"><div class="ui-button-right"><div class="ui-button-center"><span class="vi-screenreader-line ">Click to change account name. </span></div></div></div></button></div></div></div>
															
																<div class="p-gadget-content " style="" id="g95" tabindex="-1" role="application" aria-label="">
																	
<div xmlns="http://www.w3.org/1999/xhtml" class="ap-gadget-lazyContent"></div>
<div></div>
																</div>
															
														</div>
													</div>
												
									<div class="p-gadget p-gadget-loading p-gadget-minimized" style="display: none; width: 1px;"><div class="ap-container"><div class="ap-titlebar p-gadget-top-left p-gadget-header" style="user-select: none;"><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-restore ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line "></span></div><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-minimize ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line "></span></div><div class="p-gadget-title-container"><div tabindex="0" class="p-gadget-title ap-bar-section ap-bar-title"></div><div class="p-gadget-subTitle"></div></div><div class="p-gadget-draggable-section"><button class="p-gadget-draggable-button"></button></div></div><div tabindex="-1" role="application" class="p-gadget-content"></div></div></div><div class="p-gadget p-gadget-loading p-gadget-minimized" style="display: none; width: 1px;"><div class="ap-container"><div class="ap-titlebar p-gadget-top-left p-gadget-header" style="user-select: none;"><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-restore ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line "></span></div><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-minimize ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line "></span></div><div class="p-gadget-title-container"><div tabindex="0" class="p-gadget-title ap-bar-section ap-bar-title"></div><div class="p-gadget-subTitle"></div></div><div class="p-gadget-draggable-section"><button class="p-gadget-draggable-button"></button></div></div><div tabindex="-1" role="application" class="p-gadget-content"></div></div></div><div class="p-gadget p-gadget-loading p-gadget-minimized" style="display: none; width: 1px;"><div class="ap-container"><div class="ap-titlebar p-gadget-top-left p-gadget-header" style="user-select: none;"><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-restore ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line "></span></div><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-minimize ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line "></span></div><div class="p-gadget-title-container"><div tabindex="0" class="p-gadget-title ap-bar-section ap-bar-title"></div><div class="p-gadget-subTitle"></div></div><div class="p-gadget-draggable-section"><button class="p-gadget-draggable-button"></button></div></div><div tabindex="-1" role="application" class="p-gadget-content"></div></div></div><div class="p-gadget p-gadget-loading p-gadget-minimized" style="display: none; width: 1px;"><div class="ap-container"><div class="ap-titlebar p-gadget-top-left p-gadget-header" style="user-select: none;"><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-restore ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line "></span></div><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-minimize ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line "></span></div><div class="p-gadget-title-container"><div tabindex="0" class="p-gadget-title ap-bar-section ap-bar-title"></div><div class="p-gadget-subTitle"></div></div><div class="p-gadget-draggable-section"><button class="p-gadget-draggable-button"></button></div></div><div tabindex="-1" role="application" class="p-gadget-content"></div></div></div><div class="p-gadget p-gadget-loading p-gadget-minimized" style="display: none; width: 1px;"><div class="ap-container"><div class="ap-titlebar p-gadget-top-left p-gadget-header" style="user-select: none;"><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-restore ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line "></span></div><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-minimize ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line "></span></div><div class="p-gadget-title-container"><div tabindex="0" class="p-gadget-title ap-bar-section ap-bar-title"></div><div class="p-gadget-subTitle"></div></div><div class="p-gadget-draggable-section"><button class="p-gadget-draggable-button"></button></div></div><div tabindex="-1" role="application" class="p-gadget-content"></div></div></div><div class="p-gadget p-gadget-loading p-gadget-minimized" style="display: none; width: 1px;"><div class="ap-container"><div class="ap-titlebar p-gadget-top-left p-gadget-header" style="user-select: none;"><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-restore ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line "></span></div><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-minimize ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line "></span></div><div class="p-gadget-title-container"><div tabindex="0" class="p-gadget-title ap-bar-section ap-bar-title"></div><div class="p-gadget-subTitle"></div></div><div class="p-gadget-draggable-section"><button class="p-gadget-draggable-button"></button></div></div><div tabindex="-1" role="application" class="p-gadget-content"></div></div></div><div class="p-gadget p-gadget-loading p-gadget-minimized" style="display: none; width: 1px;"><div class="ap-container"><div class="ap-titlebar p-gadget-top-left p-gadget-header" style="user-select: none;"><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-restore ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line "></span></div><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-minimize ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line "></span></div><div class="p-gadget-title-container"><div tabindex="0" class="p-gadget-title ap-bar-section ap-bar-title"></div><div class="p-gadget-subTitle"></div></div><div class="p-gadget-draggable-section"><button class="p-gadget-draggable-button"></button></div></div><div tabindex="-1" role="application" class="p-gadget-content"></div></div></div><div class="p-gadget p-gadget-loading p-gadget-minimized" style="display: none; width: 1px;"><div class="ap-container"><div class="ap-titlebar p-gadget-top-left p-gadget-header" style="user-select: none;"><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-restore ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line "></span></div><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-minimize ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line "></span></div><div class="p-gadget-title-container"><div tabindex="0" class="p-gadget-title ap-bar-section ap-bar-title"></div><div class="p-gadget-subTitle"></div></div><div class="p-gadget-draggable-section"><button class="p-gadget-draggable-button"></button></div></div><div tabindex="-1" role="application" class="p-gadget-content"></div></div></div><div class="p-gadget p-gadget-loading p-gadget-minimized" style="display: none; width: 1px;"><div class="ap-container"><div class="ap-titlebar p-gadget-top-left p-gadget-header" style="user-select: none;"><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-restore ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line "></span></div><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-minimize ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line "></span></div><div class="p-gadget-title-container"><div tabindex="0" class="p-gadget-title ap-bar-section ap-bar-title"></div><div class="p-gadget-subTitle"></div></div><div class="p-gadget-draggable-section"><button class="p-gadget-draggable-button"></button></div></div><div tabindex="-1" role="application" class="p-gadget-content"></div></div></div><div class="p-gadget p-gadget-loading p-gadget-minimized" style="display: none; width: 1px;"><div class="ap-container"><div class="ap-titlebar p-gadget-top-left p-gadget-header" style="user-select: none;"><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-restore ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line "></span></div><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-minimize ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line "></span></div><div class="p-gadget-title-container"><div tabindex="0" class="p-gadget-title ap-bar-section ap-bar-title"></div><div class="p-gadget-subTitle"></div></div><div class="p-gadget-draggable-section"><button class="p-gadget-draggable-button"></button></div></div><div tabindex="-1" role="application" class="p-gadget-content"></div></div></div><div class="p-gadget p-gadget-loading p-gadget-minimized" style="display: none; width: 1px;"><div class="ap-container"><div class="ap-titlebar p-gadget-top-left p-gadget-header" style="user-select: none;"><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-restore ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line "></span></div><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-minimize ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line "></span></div><div class="p-gadget-title-container"><div tabindex="0" class="p-gadget-title ap-bar-section ap-bar-title"></div><div class="p-gadget-subTitle"></div></div><div class="p-gadget-draggable-section"><button class="p-gadget-draggable-button"></button></div></div><div tabindex="-1" role="application" class="p-gadget-content"></div></div></div><div class="p-gadget p-gadget-loading p-gadget-minimized" style="display: none; width: 1px;"><div class="ap-container"><div class="ap-titlebar p-gadget-top-left p-gadget-header" style="user-select: none;"><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-restore ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line "></span></div><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-minimize ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line "></span></div><div class="p-gadget-title-container"><div tabindex="0" class="p-gadget-title ap-bar-section ap-bar-title"></div><div class="p-gadget-subTitle"></div></div><div class="p-gadget-draggable-section"><button class="p-gadget-draggable-button"></button></div></div><div tabindex="-1" role="application" class="p-gadget-content"></div></div></div><div class="p-gadget p-gadget-loading p-gadget-minimized" style="display: none; width: 1px;"><div class="ap-container"><div class="ap-titlebar p-gadget-top-left p-gadget-header" style="user-select: none;"><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-restore ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line "></span></div><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-minimize ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line "></span></div><div class="p-gadget-title-container"><div tabindex="0" class="p-gadget-title ap-bar-section ap-bar-title"></div><div class="p-gadget-subTitle"></div></div><div class="p-gadget-draggable-section"><button class="p-gadget-draggable-button"></button></div></div><div tabindex="-1" role="application" class="p-gadget-content"></div></div></div><div class="p-gadget p-gadget-loading p-gadget-minimized" style="display: none; width: 1px;"><div class="ap-container"><div class="ap-titlebar p-gadget-top-left p-gadget-header" style="user-select: none;"><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-restore ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line "></span></div><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-minimize ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line "></span></div><div class="p-gadget-title-container"><div tabindex="0" class="p-gadget-title ap-bar-section ap-bar-title"></div><div class="p-gadget-subTitle"></div></div><div class="p-gadget-draggable-section"><button class="p-gadget-draggable-button"></button></div></div><div tabindex="-1" role="application" class="p-gadget-content"></div></div></div><div class="p-gadget p-gadget-loading p-gadget-minimized" style="display: none; width: 1px;"><div class="ap-container"><div class="ap-titlebar p-gadget-top-left p-gadget-header" style="user-select: none;"><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-restore ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line "></span></div><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-minimize ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line "></span></div><div class="p-gadget-title-container"><div tabindex="0" class="p-gadget-title ap-bar-section ap-bar-title"></div><div class="p-gadget-subTitle"></div></div><div class="p-gadget-draggable-section"><button class="p-gadget-draggable-button"></button></div></div><div tabindex="-1" role="application" class="p-gadget-content"></div></div></div><div class="p-gadget p-gadget-loading p-gadget-minimized" style="display: none; width: 1px;"><div class="ap-container"><div class="ap-titlebar p-gadget-top-left p-gadget-header" style="user-select: none;"><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-restore ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line "></span></div><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-minimize ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line "></span></div><div class="p-gadget-title-container"><div tabindex="0" class="p-gadget-title ap-bar-section ap-bar-title"></div><div class="p-gadget-subTitle"></div></div><div class="p-gadget-draggable-section"><button class="p-gadget-draggable-button"></button></div></div><div tabindex="-1" role="application" class="p-gadget-content"></div></div></div><div class="p-gadget p-gadget-loading p-gadget-minimized" style="display: none; width: 1px;"><div class="ap-container"><div class="ap-titlebar p-gadget-top-left p-gadget-header" style="user-select: none;"><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-restore ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line "></span></div><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-minimize ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line "></span></div><div class="p-gadget-title-container"><div tabindex="0" class="p-gadget-title ap-bar-section ap-bar-title"></div><div class="p-gadget-subTitle"></div></div><div class="p-gadget-draggable-section"><button class="p-gadget-draggable-button"></button></div></div><div tabindex="-1" role="application" class="p-gadget-content"></div></div></div><div class="p-gadget p-gadget-loading p-gadget-minimized" style="display: none; width: 1px;"><div class="ap-container"><div class="ap-titlebar p-gadget-top-left p-gadget-header" style="user-select: none;"><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-restore ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line "></span></div><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-minimize ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line "></span></div><div class="p-gadget-title-container"><div tabindex="0" class="p-gadget-title ap-bar-section ap-bar-title"></div><div class="p-gadget-subTitle"></div></div><div class="p-gadget-draggable-section"><button class="p-gadget-draggable-button"></button></div></div><div tabindex="-1" role="application" class="p-gadget-content"></div></div></div><div class="p-gadget p-gadget-loading p-gadget-minimized" style="display: none; width: 1px;"><div class="ap-container"><div class="ap-titlebar p-gadget-top-left p-gadget-header" style="user-select: none;"><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-restore ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line "></span></div><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-minimize ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line "></span></div><div class="p-gadget-title-container"><div tabindex="0" class="p-gadget-title ap-bar-section ap-bar-title"></div><div class="p-gadget-subTitle"></div></div><div class="p-gadget-draggable-section"><button class="p-gadget-draggable-button"></button></div></div><div tabindex="-1" role="application" class="p-gadget-content"></div></div></div><div class="p-gadget p-gadget-loading p-gadget-minimized" style="display: none; width: 1px;"><div class="ap-container"><div class="ap-titlebar p-gadget-top-left p-gadget-header" style="user-select: none;"><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-restore ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line "></span></div><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-minimize ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line "></span></div><div class="p-gadget-title-container"><div tabindex="0" class="p-gadget-title ap-bar-section ap-bar-title"></div><div class="p-gadget-subTitle"></div></div><div class="p-gadget-draggable-section"><button class="p-gadget-draggable-button"></button></div></div><div tabindex="-1" role="application" class="p-gadget-content"></div></div></div><div class="p-gadget p-gadget-loading p-gadget-minimized" style="display: none; width: 1px;"><div class="ap-container"><div class="ap-titlebar p-gadget-top-left p-gadget-header" style="user-select: none;"><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-restore ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line "></span></div><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-minimize ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line "></span></div><div class="p-gadget-title-container"><div tabindex="0" class="p-gadget-title ap-bar-section ap-bar-title"></div><div class="p-gadget-subTitle"></div></div><div class="p-gadget-draggable-section"><button class="p-gadget-draggable-button"></button></div></div><div tabindex="-1" role="application" class="p-gadget-content"></div></div></div><div class="p-gadget p-gadget-loading p-gadget-minimized" style="display: none; width: 1px;"><div class="ap-container"><div class="ap-titlebar p-gadget-top-left p-gadget-header" style="user-select: none;"><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-restore ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line "></span></div><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-minimize ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line "></span></div><div class="p-gadget-title-container"><div tabindex="0" class="p-gadget-title ap-bar-section ap-bar-title"></div><div class="p-gadget-subTitle"></div></div><div class="p-gadget-draggable-section"><button class="p-gadget-draggable-button"></button></div></div><div tabindex="-1" role="application" class="p-gadget-content"></div></div></div><div class="p-gadget p-gadget-loading p-gadget-minimized" style="display: none; width: 1px;"><div class="ap-container"><div class="ap-titlebar p-gadget-top-left p-gadget-header" style="user-select: none;"><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-restore ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line "></span></div><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-minimize ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line "></span></div><div class="p-gadget-title-container"><div tabindex="0" class="p-gadget-title ap-bar-section ap-bar-title"></div><div class="p-gadget-subTitle"></div></div><div class="p-gadget-draggable-section"><button class="p-gadget-draggable-button"></button></div></div><div tabindex="-1" role="application" class="p-gadget-content"></div></div></div><div class="p-gadget p-gadget-loading p-gadget-minimized" style="display: none; width: 1px;"><div class="ap-container"><div class="ap-titlebar p-gadget-top-left p-gadget-header" style="user-select: none;"><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-restore ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line "></span></div><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-minimize ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line "></span></div><div class="p-gadget-title-container"><div tabindex="0" class="p-gadget-title ap-bar-section ap-bar-title"></div><div class="p-gadget-subTitle"></div></div><div class="p-gadget-draggable-section"><button class="p-gadget-draggable-button"></button></div></div><div tabindex="-1" role="application" class="p-gadget-content"></div></div></div><div class="p-gadget p-gadget-loading p-gadget-minimized" style="display: none; width: 1px;"><div class="ap-container"><div class="ap-titlebar p-gadget-top-left p-gadget-header" style="user-select: none;"><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-restore ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line "></span></div><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-minimize ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line "></span></div><div class="p-gadget-title-container"><div tabindex="0" class="p-gadget-title ap-bar-section ap-bar-title"></div><div class="p-gadget-subTitle"></div></div><div class="p-gadget-draggable-section"><button class="p-gadget-draggable-button"></button></div></div><div tabindex="-1" role="application" class="p-gadget-content"></div></div></div><div class="p-gadget p-gadget-minimized ap-accountbar" style="width: 944px; left: 0px; top: 0px;"><div class="ap-container"><div class="ap-titlebar p-gadget-top-left p-gadget-header" style="user-select: none;"><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-restore ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line ">Show section Will</span></div><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-minimize ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line ">Hide section Will</span></div><div class="p-gadget-title-container"><div tabindex="0" class="p-gadget-title ap-bar-section ap-bar-title">Will</div><div class="p-gadget-subTitle">View your Will</div></div><div class="p-gadget-draggable-section"><button class="p-gadget-draggable-button"></button></div><div class="ap-gadget-button-container"><button xmlns="http://www.w3.org/1999/xhtml" tabindex="0" type="button" class="ui-button ap-icon-print" tooltip="Print this content"><div class="ui-button-left"><div class="ui-button-right"><div class="ui-button-center"><span class="vi-screenreader-line ">. Print this content</span></div></div></div></button></div></div><div tabindex="-1" role="application" class="p-gadget-content" id="g45"><div xmlns="http://www.w3.org/1999/xhtml" class="ap-gadget-lazyContent" proxyurl="proxy?pipe=genericEmptyResponse&amp;xslFile=will"></div>

		<div></div></div></div></div><div class="p-gadget p-gadget-minimized ap-accountbar" style="width: 944px; left: 0px; top: 68px;"><div class="ap-container"><div class="ap-titlebar p-gadget-top-left p-gadget-header" style="user-select: none;"><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-restore ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line ">Show section <div style="line-height:17px" aria-labelledby="ap-bar-section-Accounts"><div class="p-gadget-title-view" style="position:relative;">FICA Documents</div></div></span></div><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-minimize ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line ">Hide section <div style="line-height:17px" aria-labelledby="ap-bar-section-Accounts"><div class="p-gadget-title-view" style="position:relative;">FICA Documents</div></div></span></div><div class="p-gadget-title-container"><div tabindex="0" class="p-gadget-title ap-bar-section ap-bar-title"><div style="line-height:17px" aria-labelledby="ap-bar-section-Accounts"><div class="p-gadget-title-view" style="position:relative;">FICA Documents</div></div></div><div class="p-gadget-subTitle">Upload your FICA documents here</div></div><div class="p-gadget-draggable-section"><button class="p-gadget-draggable-button"></button></div></div><div tabindex="-1" role="application" class="p-gadget-content" id="g43"><div xmlns="http://www.w3.org/1999/xhtml" class="ap-gadget-lazyContent" proxyurl="proxy?pipe=genericEmptyResponse&amp;xslFile=FicaDocHandler/start"><div xmlns="http://www.w3.org/1999/xhtml" class="ap-ficaDocHandler"><div class="ap-ficaDocHandler-reloadContent" proxyurl="proxy?pipe=genericWebservice&amp;ws=BCMSWebService&amp;action=getOrCreateFicaCase&amp;view=fica"><div xmlns:absa="java:za.co.absa.online.backbase.util.XsltExtensionFunctions" xmlns:ns1="http://ws.online.absa.co.za/BCMS/" xmlns:ns2="http://ws.online.absa.co.za/common/" xmlns:ns3="http://ws.online.absa.co.za/common/principal/" xmlns:ns4="http://ws.online.absa.co.za/common/exceptions/" xmlns:ns5="http://ws.online.absa.co.za/common/httpHeaders/" xmlns:ns6="http://ws.online.absa.co.za/BCMS/service/" xmlns:ns7="http://ws.online.absa.co.za/common/complexTypes/" xmlns:p="http://cms.absa.intern/v1.0" xmlns:simple="http://ws.online.absa.co.za/common/simpleTypes/" xmlns:ui="http://www.absa.co.za/2009/ui" xmlns:xs="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"><div><form action="https://ib.absa.co.za/absa-online/proxy?pipe=genericWebservice&amp;ws=PortfolioWebService&amp;action=changeLinkUnlinkAccounts&amp;mode=step2" class="ui-form ap-ficaDocHandler-form1" formtype="form" method="POST" novalidate="true" trackunconfirmedchanges="true"><table class="ui-grid ap-ficaDocHandler-g1"><tbody class="ui-rows"><tr class="ui-row"><td class="ui-cell "><div class="ui-noticeBox " tabindex="0">You can upload your FICA documents by clicking the button below. Once you clicked the button a new window will open from where you can then select the relevant FICA documents to upload.<br xmlns:common="http://ws.online.absa.co.za/common/" xmlns:complex="http://ws.online.absa.co.za/common/complexTypes/" xmlns:details="http://ws.online.absa.co.za/BCMS/" xmlns:exceptions="http://ws.online.absa.co.za/common/exceptions/" xmlns:httpheaders="http://ws.online.absa.co.za/common/httpHeaders/" xmlns:principal="http://ws.online.absa.co.za/common/principal/" xmlns:tns="http://ws.online.absa.co.za/BCMS/service/"><br>After you have uploaded the documents it can take up to 7 working days before your FICA status will be updated on our system. Please note that should we find the files you have uploaded to not be satisfactory, we will require you furnish us with better quality versions of the files.<br xmlns:common="http://ws.online.absa.co.za/common/" xmlns:complex="http://ws.online.absa.co.za/common/complexTypes/" xmlns:details="http://ws.online.absa.co.za/BCMS/" xmlns:exceptions="http://ws.online.absa.co.za/common/exceptions/" xmlns:httpheaders="http://ws.online.absa.co.za/common/httpHeaders/" xmlns:principal="http://ws.online.absa.co.za/common/principal/" xmlns:tns="http://ws.online.absa.co.za/BCMS/service/"><br>For any FICA-related queries, contact the FICA Helpline on <label class="ui-label ap-common-fontBold">0861 00 11 51<span class="ui-label--icon"></span></label> or email <a xmlns:common="http://ws.online.absa.co.za/common/" xmlns:complex="http://ws.online.absa.co.za/common/complexTypes/" xmlns:details="http://ws.online.absa.co.za/BCMS/" xmlns:exceptions="http://ws.online.absa.co.za/common/exceptions/" xmlns:httpheaders="http://ws.online.absa.co.za/common/httpHeaders/" xmlns:principal="http://ws.online.absa.co.za/common/principal/" xmlns:tns="http://ws.online.absa.co.za/BCMS/service/" href="mailto:FICAhelp@absa.co.za">FICAhelp@absa.co.za</a><br xmlns:common="http://ws.online.absa.co.za/common/" xmlns:complex="http://ws.online.absa.co.za/common/complexTypes/" xmlns:details="http://ws.online.absa.co.za/BCMS/" xmlns:exceptions="http://ws.online.absa.co.za/common/exceptions/" xmlns:httpheaders="http://ws.online.absa.co.za/common/httpHeaders/" xmlns:principal="http://ws.online.absa.co.za/common/principal/" xmlns:tns="http://ws.online.absa.co.za/BCMS/service/"><br>Please be advised that the abovementioned email boxes ficahelp@absa.co.za and IFica3@absa.co.za are strictly for Retail customers. Any business customers with FICA related queries are to make use of the <a xmlns:common="http://ws.online.absa.co.za/common/" xmlns:complex="http://ws.online.absa.co.za/common/complexTypes/" xmlns:details="http://ws.online.absa.co.za/BCMS/" xmlns:exceptions="http://ws.online.absa.co.za/common/exceptions/" xmlns:httpheaders="http://ws.online.absa.co.za/common/httpHeaders/" xmlns:principal="http://ws.online.absa.co.za/common/principal/" xmlns:tns="http://ws.online.absa.co.za/BCMS/service/" href="mailto:commercialesponboarded@absa.co.za">commercialesponboarded@absa.co.za</a> address instead.</div></td></tr></tbody></table><div class="ui-formFoot "><div class="ui-message ui-message-error genericMessage-place-holder" tabindex="0"><span class="vi-screenreader-line "> error Details. </span><div class="ui-message-timeStamp"><span class="vi-screenreader-line ">Time stamp. </span><span class="vi-screenreader-line ">Year. </span>2019-<span class="vi-screenreader-line ">Month. </span>09-<span class="vi-screenreader-line ">Day. </span>20<span class="vi-screenreader-line ">Time:. </span> &nbsp;14:34:24</div><div class="ui-message--icon"></div><div class="ui-message-content" style="margin-right: 120px"><div class="ui-message-body">Some of the information you have entered is incorrect or incomplete. Review and correct to continue.</div></div><div class="clear-both"></div></div><div class="ui-message ui-message-error ioErrorMessage-place-holder" tabindex="0"><span class="vi-screenreader-line "> error Details. </span><div class="ui-message-timeStamp"><span class="vi-screenreader-line ">Time stamp. </span><span class="vi-screenreader-line ">Year. </span>2019-<span class="vi-screenreader-line ">Month. </span>09-<span class="vi-screenreader-line ">Day. </span>20<span class="vi-screenreader-line ">Time:. </span> &nbsp;14:34:24</div><div class="ui-message--icon"></div><div class="ui-message-content" style="margin-right: 120px"><div class="ui-message-body">This transaction timed out. We are not sure of the result, please check your transaction history in 30 minutes before attempting the transaction again.<div class="statusCode"></div></div></div><div class="clear-both"></div></div><div class="validation-place-holder"></div><div class="ui-message ui-message-error ap-ficaDocHandler-error" style="display:none;" tabindex="0"><span class="vi-screenreader-line "> error Details. </span><div class="ui-message-timeStamp"><span class="vi-screenreader-line ">Time stamp. </span><span class="vi-screenreader-line ">Year. </span>2019-<span class="vi-screenreader-line ">Month. </span>09-<span class="vi-screenreader-line ">Day. </span>20<span class="vi-screenreader-line ">Time:. </span> &nbsp;14:34:24</div><div class="ui-message--icon"></div><div class="ui-message-content" style="margin-right: 120px"><div class="ui-message-body"><ui:errormsg xmlns:common="http://ws.online.absa.co.za/common/" xmlns:complex="http://ws.online.absa.co.za/common/complexTypes/" xmlns:details="http://ws.online.absa.co.za/BCMS/" xmlns:exceptions="http://ws.online.absa.co.za/common/exceptions/" xmlns:httpheaders="http://ws.online.absa.co.za/common/httpHeaders/" xmlns:principal="http://ws.online.absa.co.za/common/principal/" xmlns:tns="http://ws.online.absa.co.za/BCMS/service/">Unknown error occurred</ui:errormsg></div></div><div class="clear-both"></div></div><div class="ui-buttonFooter ap-common-alignRight"><div class="ui-exception-container"><button aria-label="Upload documents. " class="ui-button ap-button-next" onclick="absa.apps.ficaDocHandler.openWin(this)" tabindex="0" type="button"><div class="ui-button-left"><div class="ui-button-right"><div class="ui-button-center">Upload documents</div></div></div></button></div></div></div></form></div></div></div></div></div>
	
		<div></div></div></div></div><div class="p-gadget p-gadget-minimized ap-accountbar" style="width: 944px; left: 0px; top: 136px;"><div class="ap-container"><div class="ap-titlebar p-gadget-top-left p-gadget-header" style="user-select: none;"><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-restore ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line ">Show section Manage your details</span></div><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-minimize ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line ">Hide section Manage your details</span></div><div class="p-gadget-title-container"><div tabindex="0" class="p-gadget-title ap-bar-section ap-bar-title">Manage your details</div><div class="p-gadget-subTitle">View or modify your details with the bank.</div></div><div class="p-gadget-draggable-section"><button class="p-gadget-draggable-button"></button></div><div class="ap-gadget-button-container"><button xmlns="http://www.w3.org/1999/xhtml" tabindex="0" type="button" class="ui-button ap-icon-print" tooltip="Print this content"><div class="ui-button-left"><div class="ui-button-right"><div class="ui-button-center"><span class="vi-screenreader-line ">. Print this content</span></div></div></div></button></div></div><div tabindex="-1" role="application" class="p-gadget-content" id="g48"><div xmlns="http://www.w3.org/1999/xhtml" class="ap-gadget-lazyContent" proxyurl="proxy?pipe=genericWebservice&amp;ws=ProfileWebService&amp;action=getProfile&amp;mode=managePersonal"></div>

		<div></div></div></div></div><div class="p-gadget p-gadget-minimized ap-accountbar" style="width: 944px; left: 0px; top: 204px;"><div class="ap-container"><div class="ap-titlebar p-gadget-top-left p-gadget-header" style="user-select: none;"><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-restore ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line ">Show section Card management</span></div><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-minimize ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line ">Hide section Card management</span></div><div class="p-gadget-title-container"><div tabindex="0" class="p-gadget-title ap-bar-section ap-bar-title">Card management</div><div class="p-gadget-subTitle">View and manage your plastic cards</div></div><div class="p-gadget-draggable-section"><button class="p-gadget-draggable-button"></button></div><div class="ap-gadget-button-container"><button xmlns="http://www.w3.org/1999/xhtml" tabindex="0" type="button" class="ui-button ap-icon-print" tooltip="Print this content"><div class="ui-button-left"><div class="ui-button-right"><div class="ui-button-center"><span class="vi-screenreader-line ">. Print this content</span></div></div></div></button></div></div><div tabindex="-1" role="application" class="p-gadget-content" id="g41"><div xmlns="http://www.w3.org/1999/xhtml" class="ap-gadget-lazyContent" proxyurl="proxy?pipe=genericEmptyResponse&amp;xslFile=CardManagement/cardManagement"></div>
		
		<div></div></div></div></div><div class="p-gadget p-gadget-minimized ap-accountbar" style="width: 944px; left: 0px; top: 272px;"><div class="ap-container"><div class="ap-titlebar p-gadget-top-left p-gadget-header" style="user-select: none;"><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-restore ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line ">Show section Manage users</span></div><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-minimize ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line ">Hide section Manage users</span></div><div class="p-gadget-title-container"><div tabindex="0" class="p-gadget-title ap-bar-section ap-bar-title">Manage users</div><div class="p-gadget-subTitle">Add and manage operators for this portfolio.</div></div><div class="p-gadget-draggable-section"><button class="p-gadget-draggable-button"></button></div><div class="ap-gadget-button-container"><button xmlns="http://www.w3.org/1999/xhtml" tabindex="0" type="button" class="ui-button ap-icon-print" tooltip="Print this content"><div class="ui-button-left"><div class="ui-button-right"><div class="ui-button-center"><span class="vi-screenreader-line ">. Print this content</span></div></div></div></button></div></div><div tabindex="-1" role="application" class="p-gadget-content" id="g38"><div xmlns="http://www.w3.org/1999/xhtml" class="ap-gadget-lazyContent" proxyurl="proxy?pipe=genericWebservice&amp;ws=ProfileWebService&amp;action=getProfile&amp;mode=manageUsers"></div>

		<div></div></div></div></div><div class="p-gadget ap-accountbar" style="width: 944px; left: 0px; top: 340px;"><div class="ap-container"><div class="ap-titlebar p-gadget-top-left p-gadget-header" style="user-select: none;"><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-restore ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line ">Show section Manage devices</span></div><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-minimize ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line ">Hide section Manage devices</span></div><div class="p-gadget-title-container"><div tabindex="0" class="p-gadget-title ap-bar-section ap-bar-title">Manage devices</div><div class="p-gadget-subTitle">Link, delink and manage devices linked to the Absa app</div></div><div class="p-gadget-draggable-section"><button class="p-gadget-draggable-button"></button></div><div class="ap-gadget-button-container"><button xmlns="http://www.w3.org/1999/xhtml" tabindex="0" type="button" class="ui-button ap-icon-print" tooltip="Print this content"><div class="ui-button-left"><div class="ui-button-right"><div class="ui-button-center"><span class="vi-screenreader-line ">. Print this content</span></div></div></div></button></div></div><div tabindex="-1" role="application" class="p-gadget-content" id="g44"><div xmlns="http://www.w3.org/1999/xhtml" class="ap-gadget-lazyContent" proxyurl="proxy?pipe=genericEmptyResponse&amp;xslFile=devices"><div xmlns="http://www.w3.org/1999/xhtml" class="ap-linkDelinkDevices"><div class="ui-tabBox ap-linkDelinkDevices-tabBox" role="tablist" disablefirsttabload="true"><div class="vi-screenreader-line"><div class="ui-tabHeads-start" tabindex="0"></div></div><ul class="ui-tabHeads "><li tabindex="0" role="button" class="ui-tabHead ap-tabHead-linkDelinkDevices  ui-tab-first-tab ui-tab-selected">Devices<span class="vi-screenreader-line "> 1 of 1 Tab. </span><div style="width:100%"><div class="ui-tabBox--type2--image"></div></div></li></ul><div class="vi-screenreader-line"><div class="ui-tabHeads-end" tabindex="0"></div></div><div class="ui-tabBodies "><div class="ui-tabBody ap-linkDelinkDevices-tabBody ui-tabBody-selected" role="tabpanel" tabindex="0" aria-busy="false" aria-hidden="false" proxyurl="proxy?pipe=genericEmptyResponse&amp;xslFile=LinkDelinkDevices/viewLinkDelinkDevices"><div xmlns="http://www.w3.org/1999/xhtml" class="ap-viewLinkDelinkDevices"><div><form trackunconfirmedchanges="true" novalidate="true" class="ui-form " method="POST" formtype="form" action="https://ib.absa.co.za/absa-online/index.jsp?axob=2&amp;lang=E&amp;rid=1174802268&amp;goto=https://ib.absa.co.za/absa-online/j_auto_security_login#"><table class="ui-grid"><tbody class="ui-rows"><tr class="ui-row ap-common-borderBottom"><td class="ui-cell ap-common-fontBold ap-common-alignRight " colspan="4"><button class="ui-button ap-icon-help" type="button" tabindex="0" tooltip="Click here to activate &#39;Show me how&#39; assistance." onclick="absa.showMeHow.toggle(this, true, &#39;.ap-viewLinkDelinkDevices&#39;); return false" aria-label="Click here to activate &#39;Show me how&#39; assistance.. "><div class="ui-button-left"><div class="ui-button-right"><div class="ui-button-center"><span class="vi-screenreader-line ">Click here to activate 'Show me how' assistance.. </span></div></div></div></button></td></tr></tbody></table><div class="ui-table ui-sortableTable ui-scroller-table ap-linkDelinkDevice-table" datafile="proxy?pipe=genericWebservice&amp;ws=DeviceManagementWebService&amp;action=listDevice"><table class="ui-tableHead"><thead><tr><th class="ui-tableHeadCell  "><span class="ui-tableHeadCell--content" tabindex="0" style="width:20px;" aria-label=" Table header . #"><div class="ui-tableHeadCell--text"><span class="vi-screenreader-line vi-table-head-item-suffix"> Table header . </span>#</div><div class="ui-tableHeadCell--addition"></div></span></th><th class="ui-tableHeadCell  "><span class="ui-tableHeadCell--content" tabindex="0" style="width:255px;" aria-label=" Table header . Device nickname"><div class="ui-tableHeadCell--text"><span class="vi-screenreader-line vi-table-head-item-suffix"> Table header . </span>Device nickname</div><div class="ui-tableHeadCell--addition"></div></span></th><th class="ui-tableHeadCell  "><span class="ui-tableHeadCell--content" tabindex="0" style="width:150px;" aria-label=" Table header . Manufacturer"><div class="ui-tableHeadCell--text"><span class="vi-screenreader-line vi-table-head-item-suffix"> Table header . </span>Manufacturer</div><div class="ui-tableHeadCell--addition"></div></span></th><th class="ui-tableHeadCell  "><span class="ui-tableHeadCell--content" tabindex="0" style="width:150px;" aria-label=" Table header . Model"><div class="ui-tableHeadCell--text"><span class="vi-screenreader-line vi-table-head-item-suffix"> Table header . </span>Model</div><div class="ui-tableHeadCell--addition"></div></span></th><th class="ui-tableHeadCell  "><span class="ui-tableHeadCell--content" tabindex="0" style="width:120px;" aria-label=" Table header . Verification device"><div class="ui-tableHeadCell--text"><span class="vi-screenreader-line vi-table-head-item-suffix"> Table header . </span>Verification device</div><div class="ui-tableHeadCell--addition"></div></span></th><th class="ui-tableHeadCell   ui-table-last-Column"><span class="ui-tableHeadCell--content" tabindex="0" style="width:94px;" aria-label=" Table header . Action"><div class="ui-tableHeadCell--text"><span class="vi-screenreader-line vi-table-head-item-suffix"> Table header . </span>Action</div><div class="ui-tableHeadCell--addition"></div></span></th><th class="ui-tableHeadCell ui-tableHead--gapFiller"></th></tr></thead></table><div class="ui-table--scrollContainer ui-table-hoverable" style="height:100%"><table class="ui-tableBody ap-linkDelinkDevice-linkedTableBody" disablemultiexpandedrows="true" totalrows="0"><tbody class="ui-tableBodyTBody"><tr class="ui-tableBodyRow" id="" onclick="" onmouseover=""><td class="ui-tableBodyCell ui-table-last-Column ui-tableBodyCell--noPadding" colspan="50" contenttype="multipleItems"><div aria-label=".  warning Details.  No devices have been found" class="ui-tableBodyCellContent" style="width:-21px;" tabindex="0"><span class="vi-screenreader-line ">. </span><div xmlns:ui="http://www.absa.co.za/2009/ui" class="ui-message ui-message-warning " tabindex="0"><span class="vi-screenreader-line "> warning Details. </span><div class="ui-message--icon"></div><div class="ui-message-content"><div class="ui-message-title"> </div><div class="ui-message-body">No devices have been found</div></div><div class="clear-both"></div></div></div></td></tr></tbody></table><div class="ap-table-loadingMessage" loading-message="Loading...." style="height: 48px; display: none;"></div></div><a role="button" href="javascript:" class="vi-table-scroller vi-screenreader-line">load more content for table</a></div><div xmlns:ui="http://www.absa.co.za/2009/ui" class="ap-common-alignRight ap-common-paddingTop ap-common-paddingBottom ap-common-paddingRight"><button class="ui-button ap-button-extraOLD ap-button-next" type="button" tabindex="0" onclick="absa.apps.linkDelinkDevices.onLinkNewDeviceClick(this, &#39;proxy?pipe=genericEmptyResponse&amp;xslFile=SureCheck2/start&amp;mode=linkNewDevice&#39;, &#39;Link new device&#39;)" aria-label="Link new device. "><div class="ui-button-left"><div class="ui-button-right"><div class="ui-button-center">Link new device</div></div></div></button></div></form></div></div></div><div class="vi-screenreader-line"><div class="ui-tabBox-tab-finish" tabindex="0"></div><div class="ui-tabBox-body-end" tabindex="0"></div></div></div></div></div></div>

		<div></div></div></div></div><div class="p-gadget p-gadget-minimized ap-accountbar" style="width: 944px; left: 0px; top: 600px;"><div class="ap-container"><div class="ap-titlebar p-gadget-top-left p-gadget-header" style="user-select: none;"><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-restore ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line ">Show section Absa Online notifications</span></div><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-minimize ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line ">Hide section Absa Online notifications</span></div><div class="p-gadget-title-container"><div tabindex="0" class="p-gadget-title ap-bar-section ap-bar-title">Absa Online notifications</div><div class="p-gadget-subTitle">View and manage your Absa Online notifications.</div></div><div class="p-gadget-draggable-section"><button class="p-gadget-draggable-button"></button></div><div class="ap-gadget-button-container"><button xmlns="http://www.w3.org/1999/xhtml" tabindex="0" type="button" class="ui-button ap-icon-print" tooltip="Print this content"><div class="ui-button-left"><div class="ui-button-right"><div class="ui-button-center"><span class="vi-screenreader-line ">. Print this content</span></div></div></div></button></div></div><div tabindex="-1" role="application" class="p-gadget-content" id="g36"><div xmlns="http://www.w3.org/1999/xhtml" class="ap-gadget-lazyContent" proxyurl="proxy?pipe=genericEmptyResponse&amp;xslFile=onlineBankingAlerts">
	</div>
	<div></div></div></div></div><div class="p-gadget p-gadget-minimized ap-accountbar" style="width: 944px; left: 0px; top: 668px;"><div class="ap-container"><div class="ap-titlebar p-gadget-top-left p-gadget-header" style="user-select: none;"><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-restore ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line ">Show section Link/Unlink accounts</span></div><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-minimize ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line ">Hide section Link/Unlink accounts</span></div><div class="p-gadget-title-container"><div tabindex="0" class="p-gadget-title ap-bar-section ap-bar-title">Link/Unlink accounts</div><div class="p-gadget-subTitle">Link or Unlink accounts from your portfolio.</div></div><div class="p-gadget-draggable-section"><button class="p-gadget-draggable-button"></button></div><div class="ap-gadget-button-container"><button xmlns="http://www.w3.org/1999/xhtml" tabindex="0" type="button" class="ui-button ap-icon-print" tooltip="Print this content"><div class="ui-button-left"><div class="ui-button-right"><div class="ui-button-center"><span class="vi-screenreader-line ">. Print this content</span></div></div></div></button></div></div><div tabindex="-1" role="application" class="p-gadget-content" id="g47"><div xmlns="http://www.w3.org/1999/xhtml" class="ap-gadget-lazyContent ap-linkUnlink" id="ap-linkUnlink-gadget" proxyurl="proxy?pipe=genericEmptyResponse&amp;xslFile=linkUnlink" proxyurlold="proxy?pipe=genericWebService&amp;ws=PortfolioWebService&amp;action=getLinkUnlinkAccounts&amp;type=R">
	</div>

	<div></div></div></div></div><div class="p-gadget p-gadget-minimized ap-accountbar" style="width: 944px; left: 0px; top: 736px;"><div class="ap-container"><div class="ap-titlebar p-gadget-top-left p-gadget-header" style="user-select: none;"><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-restore ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line ">Show section Manage Absa Online services</span></div><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-minimize ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line ">Hide section Manage Absa Online services</span></div><div class="p-gadget-title-container"><div tabindex="0" class="p-gadget-title ap-bar-section ap-bar-title">Manage Absa Online services</div><div class="p-gadget-subTitle">View your current registration information and costs or Change your billing account and Absa Online limits.</div></div><div class="p-gadget-draggable-section"><button class="p-gadget-draggable-button"></button></div><div class="ap-gadget-button-container"><button xmlns="http://www.w3.org/1999/xhtml" tabindex="0" type="button" class="ui-button ap-icon-print" tooltip="Print this content"><div class="ui-button-left"><div class="ui-button-right"><div class="ui-button-center"><span class="vi-screenreader-line ">. Print this content</span></div></div></div></button></div></div><div tabindex="-1" role="application" class="p-gadget-content" id="g46"><div xmlns="http://www.w3.org/1999/xhtml" class="ap-profileContent ap-gadget-lazyContent" proxyurl="proxy?pipe=genericEmptyResponse&amp;xslFile=manageServices"></div>

		<div></div></div></div></div><div class="p-gadget p-gadget-minimized ap-accountbar" style="width: 944px; left: 0px; top: 804px;"><div class="ap-container"><div class="ap-titlebar p-gadget-top-left p-gadget-header" style="user-select: none;"><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-restore ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line ">Show section Manage eStatements</span></div><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-minimize ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line ">Hide section Manage eStatements</span></div><div class="p-gadget-title-container"><div tabindex="0" class="p-gadget-title ap-bar-section ap-bar-title">Manage eStatements</div><div class="p-gadget-subTitle">Manage your eStatements</div></div><div class="p-gadget-draggable-section"><button class="p-gadget-draggable-button"></button></div><div class="ap-gadget-button-container"><button xmlns="http://www.w3.org/1999/xhtml" tabindex="0" type="button" class="ui-button ap-icon-print" tooltip="Print this content"><div class="ui-button-left"><div class="ui-button-right"><div class="ui-button-center"><span class="vi-screenreader-line ">. Print this content</span></div></div></div></button></div></div><div tabindex="-1" role="application" class="p-gadget-content" id="g37"><div xmlns="http://www.w3.org/1999/xhtml" class="ap-gadget-lazyContent ap-eStatements-gadget" proxyurl="proxy?pipe=genericEmptyResponse&amp;xslFile=eStatements/viewEStatements"></div>

		<div></div></div></div></div><div class="p-gadget p-gadget-minimized ap-accountbar" style="width: 944px; left: 0px; top: 872px;"><div class="ap-container"><div class="ap-titlebar p-gadget-top-left p-gadget-header" style="user-select: none;"><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-restore ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line ">Show section NotifyMe</span></div><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-minimize ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line ">Hide section NotifyMe</span></div><div class="p-gadget-title-container"><div tabindex="0" class="p-gadget-title ap-bar-section ap-bar-title">NotifyMe</div><div class="p-gadget-subTitle">Add and manage the NotifyMe recipients linked to this portfolio.</div></div><div class="p-gadget-draggable-section"><button class="p-gadget-draggable-button"></button></div><div class="ap-gadget-button-container"><button xmlns="http://www.w3.org/1999/xhtml" tabindex="0" type="button" class="ui-button ap-icon-print" tooltip="Print this content"><div class="ui-button-left"><div class="ui-button-right"><div class="ui-button-center"><span class="vi-screenreader-line ">. Print this content</span></div></div></div></button></div></div><div tabindex="-1" role="application" class="p-gadget-content" id="g40"><div xmlns="http://www.w3.org/1999/xhtml" class="ap-gadget-lazyContent" proxyurl="proxy?pipe=genericEmptyResponse&amp;xslFile=notifyMe"></div>

		<div></div></div></div></div><div class="p-gadget p-gadget-minimized ap-accountbar" style="width: 944px; left: 0px; top: 940px;"><div class="ap-container"><div class="ap-titlebar p-gadget-top-left p-gadget-header" style="user-select: none;"><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-restore ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line ">Show section Tax certificate</span></div><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-minimize ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line ">Hide section Tax certificate</span></div><div class="p-gadget-title-container"><div tabindex="0" class="p-gadget-title ap-bar-section ap-bar-title">Tax certificate</div><div class="p-gadget-subTitle">View a Tax certificate for a given year.</div></div><div class="p-gadget-draggable-section"><button class="p-gadget-draggable-button"></button></div><div class="ap-gadget-button-container"><button xmlns="http://www.w3.org/1999/xhtml" tabindex="0" type="button" class="ui-button ap-icon-print" tooltip="Print this content"><div class="ui-button-left"><div class="ui-button-right"><div class="ui-button-center"><span class="vi-screenreader-line ">. Print this content</span></div></div></div></button></div></div><div tabindex="-1" role="application" class="p-gadget-content" id="g42"><div xmlns="http://www.w3.org/1999/xhtml" class="ap-gadget-lazyContent" proxyurl="proxy?pipe=genericEmptyResponse&amp;xslFile=additionalServices"></div>
		<div></div></div></div></div></div>
									<div class="ap-savingsGoal ap-savingsGoalGadget" id="gadget-placeholder-l4-g3010056"><div class="p-gadget p-gadget-loading p-gadget-minimized" style="position: static;"><div class="ap-container"><div class="ap-titlebar p-gadget-top-left p-gadget-header" style="user-select: none;"><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-restore ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line "></span></div><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-minimize ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line "></span></div><div class="p-gadget-title-container"><div tabindex="0" class="p-gadget-title ap-bar-section ap-bar-title"></div><div class="p-gadget-subTitle"></div></div><div class="p-gadget-draggable-section"><button class="p-gadget-draggable-button"></button></div></div><div tabindex="-1" role="application" class="p-gadget-content"></div></div></div></div>
								</div>
								<div class="ap-container-bottom-save-invest">
									<div class="ap-corners-rounded-bottom-left"></div>
									<div class="ap-corners-rounded-bottom"></div>
									<div class="ap-corners-rounded-bottom-right"></div>
								</div>
							</div>
							
							<!-- Save n Invest : Investments at Other Institutions the 3rd group on the page -->
							<div class="ap-grouped-layout" style="margin-top:13px">
								<!-- Titlebar of the third group -->
								<div class="ap-titlebar ap-heading-save-invest">
									<div class="ap-heading-titlebar-item ap-container-top-show" style="padding-right:105px">
										<div class="ap-bar-section ap-bar-title">Investments at other institutions<span style="font-weight:normal"> | These values are captured by you and not validated or updated by Absa.</span></div>
										<div id="absaOther-Networth" class="ap-bar-section ap-bar-title" style="float:right; text-align:right"></div>
									</div>
								</div>
								<!-- wrapper for the third group gadgets -->
								<div class="ap-grouped-layout-content">
									<div id="gadget-placeholder-l4-g3010033" class="ap-saveAndInvestGadget"><div class="p-gadget p-gadget-loading p-gadget-minimized" style="position: static;"><div class="ap-container"><div class="ap-titlebar p-gadget-top-left p-gadget-header" style="user-select: none;"><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-restore ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line "></span></div><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-minimize ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line "></span></div><div class="p-gadget-title-container"><div tabindex="0" class="p-gadget-title ap-bar-section ap-bar-title"></div><div class="p-gadget-subTitle"></div></div><div class="p-gadget-draggable-section"><button class="p-gadget-draggable-button"></button></div></div><div tabindex="-1" role="application" class="p-gadget-content"></div></div></div></div>
									<div id="gadget-placeholder-l4-g3010034" class="ap-saveAndInvestGadget"><div class="p-gadget p-gadget-loading p-gadget-minimized" style="position: static;"><div class="ap-container"><div class="ap-titlebar p-gadget-top-left p-gadget-header" style="user-select: none;"><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-restore ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line "></span></div><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-minimize ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line "></span></div><div class="p-gadget-title-container"><div tabindex="0" class="p-gadget-title ap-bar-section ap-bar-title"></div><div class="p-gadget-subTitle"></div></div><div class="p-gadget-draggable-section"><button class="p-gadget-draggable-button"></button></div></div><div tabindex="-1" role="application" class="p-gadget-content"></div></div></div></div>
									<div id="gadget-placeholder-l4-g3010043" class="ap-saveAndInvestGadget"><div class="p-gadget p-gadget-loading p-gadget-minimized" style="position: static;"><div class="ap-container"><div class="ap-titlebar p-gadget-top-left p-gadget-header" style="user-select: none;"><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-restore ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line "></span></div><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-minimize ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line "></span></div><div class="p-gadget-title-container"><div tabindex="0" class="p-gadget-title ap-bar-section ap-bar-title"></div><div class="p-gadget-subTitle"></div></div><div class="p-gadget-draggable-section"><button class="p-gadget-draggable-button"></button></div></div><div tabindex="-1" role="application" class="p-gadget-content"></div></div></div></div>
									<div id="gadget-placeholder-l4-g3010109" class="ap-saveAndInvestGadget"><div class="p-gadget p-gadget-loading p-gadget-minimized" style="position: static;"><div class="ap-container"><div class="ap-titlebar p-gadget-top-left p-gadget-header" style="user-select: none;"><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-restore ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line "></span></div><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-minimize ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line "></span></div><div class="p-gadget-title-container"><div tabindex="0" class="p-gadget-title ap-bar-section ap-bar-title"></div><div class="p-gadget-subTitle"></div></div><div class="p-gadget-draggable-section"><button class="p-gadget-draggable-button"></button></div></div><div tabindex="-1" role="application" class="p-gadget-content"></div></div></div></div><!-- Other institution unit trust -->
									<div id="gadget-placeholder-l4-g3010044" class="ap-saveAndInvestGadget"></div>
									<div id="gadget-placeholder-l4-g3010045" class="ap-saveAndInvestGadget"><div class="p-gadget p-gadget-loading p-gadget-minimized" style="position: static;"><div class="ap-container"><div class="ap-titlebar p-gadget-top-left p-gadget-header" style="user-select: none;"><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-restore ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line "></span></div><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-minimize ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line "></span></div><div class="p-gadget-title-container"><div tabindex="0" class="p-gadget-title ap-bar-section ap-bar-title"></div><div class="p-gadget-subTitle"></div></div><div class="p-gadget-draggable-section"><button class="p-gadget-draggable-button"></button></div></div><div tabindex="-1" role="application" class="p-gadget-content"></div></div></div></div>
									<div id="gadget-placeholder-l4-g3010046" class="ap-saveAndInvestGadget"><div class="p-gadget p-gadget-loading p-gadget-minimized" style="position: static;"><div class="ap-container"><div class="ap-titlebar p-gadget-top-left p-gadget-header" style="user-select: none;"><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-restore ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line "></span></div><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-minimize ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line "></span></div><div class="p-gadget-title-container"><div tabindex="0" class="p-gadget-title ap-bar-section ap-bar-title"></div><div class="p-gadget-subTitle"></div></div><div class="p-gadget-draggable-section"><button class="p-gadget-draggable-button"></button></div></div><div tabindex="-1" role="application" class="p-gadget-content"></div></div></div></div>
									<div id="gadget-placeholder-l4-g3010047" class="ap-saveAndInvestGadget"><div class="p-gadget p-gadget-loading p-gadget-minimized" style="position: static;"><div class="ap-container"><div class="ap-titlebar p-gadget-top-left p-gadget-header" style="user-select: none;"><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-restore ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line "></span></div><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-minimize ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line "></span></div><div class="p-gadget-title-container"><div tabindex="0" class="p-gadget-title ap-bar-section ap-bar-title"></div><div class="p-gadget-subTitle"></div></div><div class="p-gadget-draggable-section"><button class="p-gadget-draggable-button"></button></div></div><div tabindex="-1" role="application" class="p-gadget-content"></div></div></div></div>
									<div id="gadget-placeholder-l4-g3010048" class="ap-saveAndInvestGadget"><div class="p-gadget p-gadget-loading p-gadget-minimized" style="position: static;"><div class="ap-container"><div class="ap-titlebar p-gadget-top-left p-gadget-header" style="user-select: none;"><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-restore ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line "></span></div><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-minimize ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line "></span></div><div class="p-gadget-title-container"><div tabindex="0" class="p-gadget-title ap-bar-section ap-bar-title"></div><div class="p-gadget-subTitle"></div></div><div class="p-gadget-draggable-section"><button class="p-gadget-draggable-button"></button></div></div><div tabindex="-1" role="application" class="p-gadget-content"></div></div></div></div>
									<div id="gadget-placeholder-l4-g3010071" class="ap-saveAndInvestGadget"><div class="p-gadget p-gadget-loading p-gadget-minimized" style="position: static;"><div class="ap-container"><div class="ap-titlebar p-gadget-top-left p-gadget-header" style="user-select: none;"><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-restore ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line "></span></div><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-minimize ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line "></span></div><div class="p-gadget-title-container"><div tabindex="0" class="p-gadget-title ap-bar-section ap-bar-title"></div><div class="p-gadget-subTitle"></div></div><div class="p-gadget-draggable-section"><button class="p-gadget-draggable-button"></button></div></div><div tabindex="-1" role="application" class="p-gadget-content"></div></div></div></div>
									<div id="gadget-placeholder-l4-g3010072" class="ap-saveAndInvestGadget"><div class="p-gadget p-gadget-loading p-gadget-minimized" style="position: static;"><div class="ap-container"><div class="ap-titlebar p-gadget-top-left p-gadget-header" style="user-select: none;"><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-restore ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line "></span></div><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-minimize ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line "></span></div><div class="p-gadget-title-container"><div tabindex="0" class="p-gadget-title ap-bar-section ap-bar-title"></div><div class="p-gadget-subTitle"></div></div><div class="p-gadget-draggable-section"><button class="p-gadget-draggable-button"></button></div></div><div tabindex="-1" role="application" class="p-gadget-content"></div></div></div></div>
								</div>
								<div class="ap-container-bottom-save-invest">
									<div class="ap-corners-rounded-bottom-left"></div>
									<div class="ap-corners-rounded-bottom"></div>
									<div class="ap-corners-rounded-bottom-right"></div>
								</div>
							</div>
						</div>
						
						
						
						<!-- Save and invest footer. Will only be displayed on the save and invest tab -->
						<div class="ap-container-footer ap-container-footer-rounded ap-heading-titlebar-item ap-container-footer-l4 ap-container-borders-all" id="ap-container-footer-l4" style="height:52px">
							<div class="ap-container-bottom-save-invest-totals ap-container-borders-all" style="padding-right:44px;background:none;border:1px solid #c0c0c0">
								<div style="font-weight:bold; line-height:50px; padding:0px 14px">
									<span id="totalInvestmentValue" style="float:right; padding-right:54px">
									</span>
									<span>
										Total investment portfolio value (R)
									</span>
								</div>
							</div>
						</div>

						
						
						<div class="ap-container-footer ap-heading-titlebar-item ap-container-footer-l2 ap-container-borders-all" id="ap-container-footer-l2">
							<div class="ap-container-footerbar">
								<div class="ap-bar-section ap-bar-title ap-bar-title-netPosition">
									Net position
									<span style="font-size:8pt;font-weight:normal">(Excludes unavailable balances)</span>
								</div>
								<div class="ap-balances">
									<div id="index-netWorth" class="ap-bar-section ap-bar-section-right ap-bar-align-right ap-bar-title ap-bar-section-m ap-channel ap-Networth">-R 311,174.83</div>
								</div>
							</div>
							<!-- PS: Where important info used to live for Accounts container -->
						</div>
						
						<!-- Accounts Spoof Container 1 : Absa Offers -->
						<div class="ap-container-footer ap-heading-titlebar-item ap-container-footer-l2" id="ap-container-footer-l2-spoof1" style="margin-top: 12px; width: 946px; border: 0px; height: auto;">
							<div class="ap-titlebar ap-heading-titlebar ap-titlebar-offers" style="margin-top:50px;">
								<div id="ap-container-top-l2" class="ap-heading-titlebar-item ap-container-top-l2 ap-container-top-show">
									<h2 id="ap-bar-section-Accounts-spoof1" style="width:170px" class="ap-bar-section ap-bar-title" tabindex="0">Absa Offers</h2>
								</div>
							</div>
							<div class="ap-container-content" id="ap-container-wrapper">
								<div class="gadget-placeholders" style="" id="gadget-placeholder-l2-g3010138"><div class="p-gadget p-gadget-minimized ap-accountbar" style="position: static; display: none;" balance="false"><div class="ap-container"><div class="ap-titlebar p-gadget-top-left p-gadget-header" style="user-select: none; cursor: default;"><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-restore ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line ">Show section <div style="line-height:17px" class="ap-bar-section-Accounts" aria-labelledby="ap-bar-section-Accounts"><div class="p-gadget-title-view" style="position:relative;">Life cover in under 5 minutes</div></div></span></div><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-minimize ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line ">Hide section <div style="line-height:17px" class="ap-bar-section-Accounts" aria-labelledby="ap-bar-section-Accounts"><div class="p-gadget-title-view" style="position:relative;">Life cover in under 5 minutes</div></div></span></div><div class="p-gadget-title-container"><div tabindex="0" class="p-gadget-title ap-bar-section ap-bar-title"><div style="line-height:17px" class="ap-bar-section-Accounts" aria-labelledby="ap-bar-section-Accounts"><div class="p-gadget-title-view" style="position:relative;">Life cover in under 5 minutes</div></div></div><div class="p-gadget-subTitle">Get your personalised insurance offer here</div></div><div class="p-gadget-draggable-section"><button class="p-gadget-draggable-button"></button></div><div class="ap-balances"><div class="ap-bar-section ap-bar-section-right ap-bar-align-left ap-bar-section-icons ap-bar-section-icons-options" aria-labelledby="ap-bar-section-accounts-options"><button onclick="absa.apps.lifeInsurance.onUnsubscribeClick(this,&#39;ULTIMATE_PROTECTOR&#39;,&#39;OPTNOW&#39;)" type="button" tooltip="Not now: Hide for now" class="ui-button ap-icon-removeHistory"><div class="ui-button-left"><div class="ui-button-right"><div class="ui-button-center"><span class="vi-screenreader-line ">Not now: Hide for now. </span></div></div></div></button><button onclick="absa.apps.lifeInsurance.onUnsubscribeClick(this,&#39;ULTIMATE_PROTECTOR&#39;,&#39;OPT60&#39;)" type="button" tooltip="30-60 days: Hide for 30 to 60 days" class="ui-button ap-icon-3060"><div class="ui-button-left"><div class="ui-button-right"><div class="ui-button-center"><span class="vi-screenreader-line ">30-60 days: Hide for 30 to 60 days. </span></div></div></div></button><button onclick="absa.apps.lifeInsurance.onUnsubscribeClick(this,&#39;ULTIMATE_PROTECTOR&#39;,&#39;OPTNVR&#39;)" type="button" tooltip="Hide for 6 months" class="ui-button ap-icon-removeStopPayments"><div class="ui-button-left"><div class="ui-button-right"><div class="ui-button-center"><span class="vi-screenreader-line ">Hide for 6 months. </span></div></div></div></button></div></div></div><div tabindex="-1" role="application" class="p-gadget-content" id="g26"><div xmlns="http://www.w3.org/1999/xhtml" class="ap-gadget-lazyContent" proxyurl="proxy?pipe=genericEmptyResponse&amp;xslFile=Offers/InsuranceOffers/lifeProductsMain&amp;displayProduct=ULTIMATE_PROTECTOR"></div>
		
		<div></div></div></div></div></div> <!-- Life Insurance Gadget -->
								<div class="gadget-placeholders" style="display:none;" id="gadget-placeholder-l2-g3010139"><div class="p-gadget p-gadget-minimized ap-accountbar ap-accountBalances ap-offersOD" style="position: static; display: none;" balance="false"><div class="ap-container"><div class="ap-titlebar p-gadget-top-left p-gadget-header" style="user-select: none; cursor: default;"><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-restore ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line ">Show section An overdraft in under 5 minutes</span></div><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-minimize ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line ">Hide section An overdraft in under 5 minutes</span></div><div class="p-gadget-title-container"><div tabindex="0" class="p-gadget-title ap-bar-section ap-bar-title"><div style="line-height:17px" class="ap-bar-section-Accounts" aria-labelledby="ap-bar-section-Accounts"><div class="p-gadget-title-view" style="position:relative;">An overdraft in under 5 minutes</div></div></div><div class="p-gadget-subTitle">Your current provisional overdraft is (Terms and Conditions apply)</div></div><div class="p-gadget-draggable-section"><button class="p-gadget-draggable-button"></button></div><div class="ap-balances"><div style="width: 100px; padding: 10px; margin:0; font-size:12px;" class="ap-bar-section ap-bar-section-right ap-bar-align-right ap-bar-title ap-bar-section-m available-field">0.00</div><div style="width: 170px; padding: 10px; margin:0; font-size:12px;" class="ap-bar-section ap-bar-section-right ap-bar-align-right ap-bar-title ap-bar-section-m balance-field">0.00</div><div class="ap-bar-section ap-bar-section-right ap-bar-align-left ap-bar-section-icons ap-bar-section-icons-options" aria-labelledby="ap-bar-section-accounts-options"><button onclick="absa.apps.overdraftOffers.onUnsubscribeClick(this,&#39;OPTNOW&#39;)" type="button" tooltip="Not now: Hide for now" class="ui-button ap-icon-removeHistory"><div class="ui-button-left"><div class="ui-button-right"><div class="ui-button-center"><span class="vi-screenreader-line ">Not now: Hide for now. </span></div></div></div></button><button onclick="absa.apps.overdraftOffers.onUnsubscribeClick(this,&#39;OPT60&#39;)" type="button" tooltip="30-60 days: Hide for 30 to 60 days" class="ui-button ap-icon-3060"><div class="ui-button-left"><div class="ui-button-right"><div class="ui-button-center"><span class="vi-screenreader-line ">30-60 days: Hide for 30 to 60 days. </span></div></div></div></button><button onclick="absa.apps.overdraftOffers.onUnsubscribeClick(this,&#39;OPTNVR&#39;)" type="button" tooltip="Hide for 6 months" class="ui-button ap-icon-removeStopPayments"><div class="ui-button-left"><div class="ui-button-right"><div class="ui-button-center"><span class="vi-screenreader-line ">Hide for 6 months. </span></div></div></div></button></div></div></div><div tabindex="-1" role="application" class="p-gadget-content" id="g28"><div xmlns="http://www.w3.org/1999/xhtml" class="ap-gadget-lazyContent" proxyurl="proxy?pipe=genericEmptyResponse&amp;xslFile=Offers/overdraftOffers/overdraftOffersMain"></div>
		
		<div></div></div></div></div></div> <!-- Overdraft Gadget -->
								<div class="gadget-placeholders" style="display:none;" id="gadget-placeholder-l2-g3010140"><div class="p-gadget p-gadget-minimized ap-accountbar" style="position: static; display: none;"><div class="ap-container"><div class="ap-titlebar p-gadget-top-left p-gadget-header" style="user-select: none; cursor: default;"><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-restore ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line ">Show section Drive off in a new car</span></div><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-minimize ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line ">Hide section Drive off in a new car</span></div><div class="p-gadget-title-container"><div tabindex="0" class="p-gadget-title ap-bar-section ap-bar-title">Drive off in a new car</div><div class="p-gadget-subTitle">Your current provisional loan amount is (T&amp;C apply)</div></div><div class="p-gadget-draggable-section"><button class="p-gadget-draggable-button"></button></div></div><div tabindex="-1" role="application" class="p-gadget-content" id="g19"><div xmlns="http://www.w3.org/1999/xhtml" class="ap-gadget-lazyContent" proxyurl="proxy?pipe=genericEmptyResponse&amp;xslFile=empty"></div>
		
		<div></div></div></div></div></div> <!-- AVAF Gadget -->
								<div class="gadget-placeholders" style="" id="gadget-placeholder-l2-g3010144"><div class="p-gadget p-gadget-minimized ap-accountbar" style="position: static; display: none;" balance="false"><div class="ap-container"><div class="ap-titlebar p-gadget-top-left p-gadget-header" style="user-select: none; cursor: default;"><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-restore ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line ">Show section <div style="line-height:17px" class="ap-bar-section-Accounts" aria-labelledby="ap-bar-section-Accounts"><div class="p-gadget-title-view" style="position:relative;">Get cover at the click of a button</div></div></span></div><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-minimize ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line ">Hide section <div style="line-height:17px" class="ap-bar-section-Accounts" aria-labelledby="ap-bar-section-Accounts"><div class="p-gadget-title-view" style="position:relative;">Get cover at the click of a button</div></div></span></div><div class="p-gadget-title-container"><div tabindex="0" class="p-gadget-title ap-bar-section ap-bar-title"><div style="line-height:17px" class="ap-bar-section-Accounts" aria-labelledby="ap-bar-section-Accounts"><div class="p-gadget-title-view" style="position:relative;">Get cover at the click of a button</div></div></div><div class="p-gadget-subTitle">Insurance for the car you love</div></div><div class="p-gadget-draggable-section"><button class="p-gadget-draggable-button"></button></div><div class="ap-balances"><div class="ap-bar-section ap-bar-section-right ap-bar-align-left ap-bar-section-icons ap-bar-section-icons-options" aria-labelledby="ap-bar-section-accounts-options"><button onclick="absa.apps.shortTermInsurance.onUnsubscribeClick(this,&#39;MOTOR_VEHICAL_INSURANCE&#39;,&#39;OPTNOW&#39;)" type="button" tooltip="Not now: Hide for now" class="ui-button ap-icon-removeHistory"><div class="ui-button-left"><div class="ui-button-right"><div class="ui-button-center"><span class="vi-screenreader-line ">Not now: Hide for now. </span></div></div></div></button><button onclick="absa.apps.shortTermInsurance.onUnsubscribeClick(this,&#39;MOTOR_VEHICAL_INSURANCE&#39;,&#39;OPT60&#39;)" type="button" tooltip="30-60 days: Hide for 30 to 60 days" class="ui-button ap-icon-3060"><div class="ui-button-left"><div class="ui-button-right"><div class="ui-button-center"><span class="vi-screenreader-line ">30-60 days: Hide for 30 to 60 days. </span></div></div></div></button><button onclick="absa.apps.shortTermInsurance.onUnsubscribeClick(this,&#39;MOTOR_VEHICAL_INSURANCE&#39;,&#39;OPTNVR&#39;)" type="button" tooltip="Hide for 6 months" class="ui-button ap-icon-removeStopPayments"><div class="ui-button-left"><div class="ui-button-right"><div class="ui-button-center"><span class="vi-screenreader-line ">Hide for 6 months. </span></div></div></div></button></div></div></div><div tabindex="-1" role="application" class="p-gadget-content" id="g29"><div xmlns="http://www.w3.org/1999/xhtml" class="ap-gadget-lazyContent" proxyurl="proxy?pipe=genericEmptyResponse&amp;xslFile=Offers/ShortTermInsuranceOffers/shortTermProductsMain&amp;displayProduct=MOTOR_VEHICAL_INSURANCE"></div>
		
		<div></div></div></div></div></div> <!-- Short Term Insurance Gadget -->
								<div class="gadget-placeholders" style="display:none;" id="gadget-placeholder-l2-g3010147"><div class="p-gadget p-gadget-minimized ap-accountbar" style="position: static; display: none;"><div class="ap-container"><div class="ap-titlebar p-gadget-top-left p-gadget-header" style="user-select: none; cursor: default;"><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-restore ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line ">Show section An Absa Credit Card for the lifestyle you deserve</span></div><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-minimize ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line ">Hide section An Absa Credit Card for the lifestyle you deserve</span></div><div class="p-gadget-title-container"><div tabindex="0" class="p-gadget-title ap-bar-section ap-bar-title">An Absa Credit Card for the lifestyle you deserve</div><div class="p-gadget-subTitle"></div></div><div class="p-gadget-draggable-section"><button class="p-gadget-draggable-button"></button></div></div><div tabindex="-1" role="application" class="p-gadget-content" id="g27"><div xmlns="http://www.w3.org/1999/xhtml" class="ap-gadget-lazyContent" proxyurl="proxy?pipe=genericEmptyResponse&amp;xslFile=empty"></div>
	
		<div></div></div></div></div></div> <!-- Credit Card Gadget -->
								<div class="gadget-placeholders" style="display:none;" id="gadget-placeholder-l2-g3010148"></div> <!-- Value Adds Gadget -->
								<div class="gadget-placeholders" style="display:none;" id="gadget-placeholder-l2-g3010150"><div class="p-gadget ap-accountbar  p-gadget-minimized " style="position: static; display: none;">
														<div class="ap-container">
															<script type="text/javascript"></script>
															<div class="ap-titlebar p-gadget-top-left p-gadget-header" style="user-select: none; cursor: default;">
																<div role="button" tabindex="0" class="p-gadget-button p-gadget-button-restore ap-bar-section ap-icon-bar-status">
																	
																		<span class="vi-screenreader-line ">Show section Access funds from your home loan</span>
																	
																</div>
																<div role="button" tabindex="0" class="p-gadget-button p-gadget-button-minimize ap-bar-section ap-icon-bar-status">
																	
																		<span class="vi-screenreader-line ">Hide section Access funds from your home loan</span>
																	
																</div>
																<div class="p-gadget-title-container">
																	<div tabindex="0" class="p-gadget-title ap-bar-section ap-bar-title">Access funds from your home loan</div>
																	<div tabindex="0" class="p-gadget-subTitle">undefined</div>
																</div>
																<div class="p-gadget-draggable-section">
																	<button class="p-gadget-draggable-button"></button>
																</div>
															</div>
															
																<div class="p-gadget-content " style="" id="g23" tabindex="-1" role="application" aria-label="Access funds from your home loan">
																	
<div xmlns="http://www.w3.org/1999/xhtml" class="ap-gadget-lazyContent" proxyurl="proxy?pipe=genericEmptyResponse&amp;xslFile=empty"></div>
<div></div>
																</div>
															
														</div>
													</div></div> <!-- HomeLoan Gadget -->
								<div class="gadget-placeholders" style="display:none;" id="gadget-placeholder-l2-g3010156"><div class="p-gadget p-gadget-minimized ap-accountbar" style="position: static; display: none;"><div class="ap-container"><div class="ap-titlebar p-gadget-top-left p-gadget-header" style="user-select: none; cursor: default;"><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-restore ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line ">Show section Reap the rewards of homeownership with a Further Advance</span></div><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-minimize ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line ">Hide section Reap the rewards of homeownership with a Further Advance</span></div><div class="p-gadget-title-container"><div tabindex="0" class="p-gadget-title ap-bar-section ap-bar-title">Reap the rewards of homeownership with a Further Advance</div><div class="p-gadget-subTitle"></div></div><div class="p-gadget-draggable-section"><button class="p-gadget-draggable-button"></button></div></div><div tabindex="-1" role="application" class="p-gadget-content" id="g18"><!-- 	The call to load the main xsl to display the further advance gadget -->	
		<div xmlns="http://www.w3.org/1999/xhtml" class="ap-gadget-lazyContent" proxyurl="proxy?pipe=genericEmptyResponse&amp;xslFile=Offers/HomeLoanFurtherAdvanceOffers/offersHomeLoanFurtherAdvanceMain"></div>
	
		<div></div></div></div></div></div> <!-- HomeLoan Further Advance Gadget -->
								<div class="gadget-placeholders" style="" id="gadget-placeholder-l2-g3010158"><div class="p-gadget p-gadget-minimized ap-accountbar" style="position: static; display: none;"><div class="ap-container"><div class="ap-titlebar p-gadget-top-left p-gadget-header" style="user-select: none; cursor: default;"><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-restore ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line ">Show section Switch and save with Absa Home Loans</span></div><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-minimize ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line ">Hide section Switch and save with Absa Home Loans</span></div><div class="p-gadget-title-container"><div tabindex="0" class="p-gadget-title ap-bar-section ap-bar-title">Switch and save with Absa Home Loans</div><div class="p-gadget-subTitle">Did you know you could save by switching your home loan to Absa</div></div><div class="p-gadget-draggable-section"><button class="p-gadget-draggable-button"></button></div><div class="ap-balances"><div class="ap-bar-section ap-bar-section-right ap-bar-align-left ap-bar-section-icons ap-bar-section-icons-options" aria-labelledby="ap-bar-section-accounts-options"><button onclick="absa.apps.homeLoanSwitch.onUnsubscribeClick(this,&#39;HOME_LOAN_SWITCH&#39;,&#39;OPTNOW&#39;)" type="button" tooltip="Not now: Hide for now" class="ui-button ap-icon-removeHistory"><div class="ui-button-left"><div class="ui-button-right"><div class="ui-button-center"><span class="vi-screenreader-line ">Not now: Hide for now. </span></div></div></div></button><button onclick="absa.apps.homeLoanSwitch.onUnsubscribeClick(this,&#39;HOME_LOAN_SWITCH&#39;,&#39;OPT60&#39;)" type="button" tooltip="30-60 days: Hide for 30 to 60 days" class="ui-button ap-icon-3060"><div class="ui-button-left"><div class="ui-button-right"><div class="ui-button-center"><span class="vi-screenreader-line ">30-60 days: Hide for 30 to 60 days. </span></div></div></div></button><button onclick="absa.apps.homeLoanSwitch.onUnsubscribeClick(this,&#39;HOME_LOAN_SWITCH&#39;,&#39;OPTNVR&#39;)" type="button" tooltip="Hide for 6 months" class="ui-button ap-icon-removeStopPayments"><div class="ui-button-left"><div class="ui-button-right"><div class="ui-button-center"><span class="vi-screenreader-line ">Hide for 6 months. </span></div></div></div></button></div></div></div><div tabindex="-1" role="application" class="p-gadget-content" id="g25"><!-- 	The call to load the main xsl to display the switch gadget -->	
		<div xmlns="http://www.w3.org/1999/xhtml" class="ap-gadget-lazyContent" proxyurl="proxy?pipe=genericEmptyResponse&amp;xslFile=Offers/HomeLoanSwitchOffers/offersHomeLoanSwitchMain&amp;cellPhoneNumber=825584004&amp;emailAddress=MARK@WRPB.CO.ZA"></div>
	
		<div></div></div></div></div></div> <!-- HomeLoan Switch Gadget -->
								<div class="gadget-placeholders" style="display:none;" id="gadget-placeholder-l2-g3010151"><div class="p-gadget p-gadget-minimized ap-accountbar" style="position: static; display: none;"><div class="ap-container"><div class="ap-titlebar p-gadget-top-left p-gadget-header" style="user-select: none; cursor: default;"><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-restore ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line ">Show section Generic Gadget</span></div><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-minimize ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line ">Hide section Generic Gadget</span></div><div class="p-gadget-title-container"><div tabindex="0" class="p-gadget-title ap-bar-section ap-bar-title">Generic Gadget</div><div class="p-gadget-subTitle">Generic gadget blurb</div></div><div class="p-gadget-draggable-section"><button class="p-gadget-draggable-button"></button></div></div><div tabindex="-1" role="application" class="p-gadget-content" id="g17"><div xmlns="http://www.w3.org/1999/xhtml" class="ap-gadget-lazyContent" proxyurl="proxy?pipe=genericEmptyResponse&amp;xslFile=empty"></div>
		
		<div></div></div></div></div></div> <!-- SavingsAndInvestments Gadget -->
								<div class="gadget-placeholders" style="display:none;" id="gadget-placeholder-l2-g3010136"><div class="p-gadget p-gadget-minimized ap-accountbar ap-accountBalances ap-vcl" style="position: static; display: none;" balance="false"><div class="ap-container"><div class="ap-titlebar p-gadget-top-left p-gadget-header" style="user-select: none; cursor: default;"><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-restore ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line ">Show section A personal loan in under 5 minutes</span></div><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-minimize ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line ">Hide section A personal loan in under 5 minutes</span></div><div class="p-gadget-title-container"><div tabindex="0" class="p-gadget-title ap-bar-section ap-bar-title">A personal loan in under 5 minutes</div><div class="p-gadget-subTitle">Your current provisional loan amount is (Terms and Conditions apply)</div></div><div class="p-gadget-draggable-section"><button class="p-gadget-draggable-button"></button></div><div class="ap-balances"><div style="width: 150px; padding: 10px; margin:0; font-size:12px;" class="ap-bar-section ap-bar-section-right ap-bar-align-right ap-bar-title ap-bar-section-m available-field">0.00</div><div style="width: 170px; padding: 10px; margin:0; font-size:12px;" class="ap-bar-section ap-bar-section-right ap-bar-align-right ap-bar-title ap-bar-section-m balance-field">0.00</div><div class="ap-bar-section ap-bar-section-right ap-bar-align-left ap-bar-section-icons ap-bar-section-icons-options" aria-labelledby="ap-bar-section-accounts-options"><button onclick="absa.apps.creditLimits.onUnsubscribeClick(this,&#39;OPTNOW&#39;)" type="button" tooltip="Not now: Hide for now" class="ui-button ap-icon-removeHistory"><div class="ui-button-left"><div class="ui-button-right"><div class="ui-button-center"><span class="vi-screenreader-line ">Not now: Hide for now. </span></div></div></div></button><button onclick="absa.apps.creditLimits.onUnsubscribeClick(this,&#39;OPT60&#39;)" type="button" tooltip="30-60 days: Hide for 30 to 60 days" class="ui-button ap-icon-3060"><div class="ui-button-left"><div class="ui-button-right"><div class="ui-button-center"><span class="vi-screenreader-line ">30-60 days: Hide for 30 to 60 days. </span></div></div></div></button><button onclick="absa.apps.creditLimits.onUnsubscribeClick(this,&#39;OPTNVR&#39;)" type="button" tooltip="Hide for 6 months" class="ui-button ap-icon-removeStopPayments"><div class="ui-button-left"><div class="ui-button-right"><div class="ui-button-center"><span class="vi-screenreader-line ">Hide for 6 months. </span></div></div></div></button></div></div></div><div tabindex="-1" role="application" class="p-gadget-content" id="g31"><div xmlns="http://www.w3.org/1999/xhtml" class="ap-gadget-lazyContent" proxyurl="proxy?pipe=genericWebService&amp;ws=CreditLimitsWebService&amp;action=getCreditLimits"></div>
		
		<div></div></div></div></div></div> <!-- Credit Limits Gadget -->
								<div class="gadget-placeholders" style="display:none;" id="gadget-placeholder-l2-g3010157"><div class="p-gadget p-gadget-minimized ap-accountbar" style="position: static; display: none;"><div class="ap-container"><div class="ap-titlebar p-gadget-top-left p-gadget-header" style="user-select: none; cursor: default;"><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-restore ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line ">Show section You qualify for an upgrade to Premium Banking</span></div><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-minimize ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line ">Hide section You qualify for an upgrade to Premium Banking</span></div><div class="p-gadget-title-container"><div tabindex="0" class="p-gadget-title ap-bar-section ap-bar-title">You qualify for an upgrade to Premium Banking</div><div class="p-gadget-subTitle"></div></div><div class="p-gadget-draggable-section"><button class="p-gadget-draggable-button"></button></div></div><div tabindex="-1" role="application" class="p-gadget-content" id="g24"><g:preference xmlns:g="http://www.backbase.com/2008/gadget" type="hidden" name="subtitle" default="Common/General/GadgetSubTitle/Label/CustomerSelfUpgrade"></g:preference>
		<div xmlns="http://www.w3.org/1999/xhtml" class="ap-gadget-lazyContent" proxyurl="proxy?pipe=genericEmptyResponse&amp;xslFile=Offers/CustomerSelfUpgradeOffers/customerSelfUpgradeOffersMain"></div>
	
		<div></div></div></div></div></div> <!-- Customer Self Upgrade Gadget -->
								<div class="gadget-placeholders" style="display:none;" id="gadget-placeholder-l2-g3010160"><div class="p-gadget p-gadget-minimized ap-accountbar" style="position: static; display: none;"><div class="ap-container"><div class="ap-titlebar p-gadget-top-left p-gadget-header" style="user-select: none; cursor: default;"><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-restore ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line ">Show section Boost your bottom-line with Business Essentials Plus and SmartPay</span></div><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-minimize ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line ">Hide section Boost your bottom-line with Business Essentials Plus and SmartPay</span></div><div class="p-gadget-title-container"><div tabindex="0" class="p-gadget-title ap-bar-section ap-bar-title">Boost your bottom-line with Business Essentials Plus and SmartPay</div><div class="p-gadget-subTitle"></div></div><div class="p-gadget-draggable-section"><button class="p-gadget-draggable-button"></button></div></div><div tabindex="-1" role="application" class="p-gadget-content" id="g20"><g:preference xmlns:g="http://www.backbase.com/2008/gadget" type="hidden" name="subtitle" default="Common/General/GadgetSubTitle/Label/SmartPack"></g:preference>
		<div xmlns="http://www.w3.org/1999/xhtml" class="ap-gadget-lazyContent" proxyurl="proxy?pipe=genericEmptyResponse&amp;xslFile=Offers/SmartPackOffers/smartPackMain"></div>
	
		<div></div></div></div></div></div> <!-- Smart Pack Gadget -->
								<div class="gadget-placeholders" style="display:none;" id="gadget-placeholder-l2-g3010161"><div class="p-gadget p-gadget-minimized ap-accountbar" style="position: static; display: none;"><div class="ap-container"><div class="ap-titlebar p-gadget-top-left p-gadget-header" style="user-select: none; cursor: default;"><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-restore ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line ">Show section Apply for a Will</span></div><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-minimize ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line ">Hide section Apply for a Will</span></div><div class="p-gadget-title-container"><div tabindex="0" class="p-gadget-title ap-bar-section ap-bar-title">Apply for a Will</div><div class="p-gadget-subTitle"></div></div><div class="p-gadget-draggable-section"><button class="p-gadget-draggable-button"></button></div></div><div tabindex="-1" role="application" class="p-gadget-content" id="g22"><g:preference xmlns:g="http://www.backbase.com/2008/gadget" type="hidden" name="subtitle" default="Common/General/GadgetSubTitle/Label/Will"></g:preference>
		<div xmlns="http://www.w3.org/1999/xhtml" class="ap-gadget-lazyContent" proxyurl="proxy?pipe=genericEmptyResponse&amp;xslFile=Offers/WillOffers/willMain"></div>
	
		<div></div></div></div></div></div> <!-- Will Gadget -->
							</div>
							<div class="ap-container-footer ap-heading-titlebar-item ap-container-footer-l2" id="ap-container-footer-l2-spoof" style="height:0px; border:0px;">
								<!-- PS: there must be nothing in here for this spoof container -->
							</div>
						</div>
						
						<!-- Accounts Spoof Container 2 : Important Info -->
						<div class="ap-container-footer ap-heading-titlebar-item ap-container-footer-l2" id="ap-container-footer-l2-spoof2" style="margin-top:12px; width:946px; height:auto; border:0px;">
							<div tabindex="0" class="ui-noticeBox ">
								<b xmlns:ui="http://www.absa.co.za/2009/ui">Important information</b>
								<ul xmlns:ui="http://www.absa.co.za/2009/ui">
									<li>The available amount on your account may include cheque deposits not fully paid to the bank yet, and which may still be reversed.</li>
									<li>The balance on your Absa Vehicle and Asset Finance (AVAF) Account does not include any transactions performed on the current day. For all AVAF enquiries, call 0860 669 669</li>
									<li>The ZAR equivalent amount for the Currency Investment Account (CIA) is based on an indicative rate and is subject to change. For any further queries contact 0860 151 151.</li>
									<li>The Cash Passport balance is not included in the net position amount.</li>
								</ul>
							</div>
						</div>
						
						
						
						<div class="ap-container-footer ap-heading-titlebar-item ap-container-footer-l5" id="ap-container-footer-l5" style="height:0px !important; border:0px !important; ">
							<!-- Custom one for Apply container -->
						</div>
						
						
						<!-- Apply Spoof Container 1 : Absa Offers -->
						<div class="ap-container-footer ap-heading-titlebar-item ap-container-footer-l5" id="ap-container-footer-l5-spoof1" style="margin-top: 12px; width: 946px; border: 0px; height: auto;">
							<div class="ap-titlebar ap-heading-titlebar ap-titlebar-offers" style="margin-top:50px;">
								<div id="ap-container-top-l5" class="ap-heading-titlebar-item ap-container-top-l5">
									<h2 id="ap-bar-section-Accounts-spoof1" style="width:170px" class="ap-bar-section ap-bar-title" tabindex="0">Absa Offers</h2>
								</div>
							</div>
							<div class="ap-container-content" id="ap-container-wrapper">
								<div class="gadget-placeholders" style="" id="gadget-placeholder-l5-g3010138"><div class="p-gadget p-gadget-loading p-gadget-minimized" style="position: static;"><div class="ap-container"><div class="ap-titlebar p-gadget-top-left p-gadget-header" style="user-select: none;"><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-restore ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line "></span></div><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-minimize ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line "></span></div><div class="p-gadget-title-container"><div tabindex="0" class="p-gadget-title ap-bar-section ap-bar-title"></div><div class="p-gadget-subTitle"></div></div><div class="p-gadget-draggable-section"><button class="p-gadget-draggable-button"></button></div></div><div tabindex="-1" role="application" class="p-gadget-content"></div></div></div></div> <!-- Life Insurance Gadget -->
								<div class="gadget-placeholders" style="display:none;" id="gadget-placeholder-l5-g3010139"><div class="p-gadget p-gadget-loading p-gadget-minimized" style="position: static;"><div class="ap-container"><div class="ap-titlebar p-gadget-top-left p-gadget-header" style="user-select: none;"><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-restore ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line "></span></div><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-minimize ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line "></span></div><div class="p-gadget-title-container"><div tabindex="0" class="p-gadget-title ap-bar-section ap-bar-title"></div><div class="p-gadget-subTitle"></div></div><div class="p-gadget-draggable-section"><button class="p-gadget-draggable-button"></button></div></div><div tabindex="-1" role="application" class="p-gadget-content"></div></div></div></div> <!-- Overdraft Gadget -->
								<div class="gadget-placeholders" style="display:none;" id="gadget-placeholder-l5-g3010140"><div class="p-gadget p-gadget-loading p-gadget-minimized" style="position: static;"><div class="ap-container"><div class="ap-titlebar p-gadget-top-left p-gadget-header" style="user-select: none;"><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-restore ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line "></span></div><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-minimize ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line "></span></div><div class="p-gadget-title-container"><div tabindex="0" class="p-gadget-title ap-bar-section ap-bar-title"></div><div class="p-gadget-subTitle"></div></div><div class="p-gadget-draggable-section"><button class="p-gadget-draggable-button"></button></div></div><div tabindex="-1" role="application" class="p-gadget-content"></div></div></div></div> <!-- AVAF Gadget -->
								<div class="gadget-placeholders" style="" id="gadget-placeholder-l5-g3010144"><div class="p-gadget p-gadget-loading p-gadget-minimized" style="position: static;"><div class="ap-container"><div class="ap-titlebar p-gadget-top-left p-gadget-header" style="user-select: none;"><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-restore ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line "></span></div><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-minimize ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line "></span></div><div class="p-gadget-title-container"><div tabindex="0" class="p-gadget-title ap-bar-section ap-bar-title"></div><div class="p-gadget-subTitle"></div></div><div class="p-gadget-draggable-section"><button class="p-gadget-draggable-button"></button></div></div><div tabindex="-1" role="application" class="p-gadget-content"></div></div></div></div> <!-- Short Term Insurance Gadget -->
								<div class="gadget-placeholders" style="display:none;" id="gadget-placeholder-l5-g3010147"><div class="p-gadget p-gadget-loading p-gadget-minimized" style="position: static;"><div class="ap-container"><div class="ap-titlebar p-gadget-top-left p-gadget-header" style="user-select: none;"><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-restore ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line "></span></div><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-minimize ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line "></span></div><div class="p-gadget-title-container"><div tabindex="0" class="p-gadget-title ap-bar-section ap-bar-title"></div><div class="p-gadget-subTitle"></div></div><div class="p-gadget-draggable-section"><button class="p-gadget-draggable-button"></button></div></div><div tabindex="-1" role="application" class="p-gadget-content"></div></div></div></div> <!-- Credit Card Gadget -->
								<div class="gadget-placeholders" style="display:none;" id="gadget-placeholder-l5-g3010148"></div> <!-- Value Adds Gadget -->
								<div class="gadget-placeholders" style="display:none;" id="gadget-placeholder-l5-g3010150"><div class="p-gadget p-gadget-loading p-gadget-minimized" style="position: static;"><div class="ap-container"><div class="ap-titlebar p-gadget-top-left p-gadget-header" style="user-select: none;"><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-restore ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line "></span></div><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-minimize ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line "></span></div><div class="p-gadget-title-container"><div tabindex="0" class="p-gadget-title ap-bar-section ap-bar-title"></div><div class="p-gadget-subTitle"></div></div><div class="p-gadget-draggable-section"><button class="p-gadget-draggable-button"></button></div></div><div tabindex="-1" role="application" class="p-gadget-content"></div></div></div></div> <!-- HomeLoan Gadget -->
								<div class="gadget-placeholders" style="display:none;" id="gadget-placeholder-l5-g3010156"><div class="p-gadget p-gadget-loading p-gadget-minimized" style="position: static;"><div class="ap-container"><div class="ap-titlebar p-gadget-top-left p-gadget-header" style="user-select: none;"><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-restore ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line "></span></div><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-minimize ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line "></span></div><div class="p-gadget-title-container"><div tabindex="0" class="p-gadget-title ap-bar-section ap-bar-title"></div><div class="p-gadget-subTitle"></div></div><div class="p-gadget-draggable-section"><button class="p-gadget-draggable-button"></button></div></div><div tabindex="-1" role="application" class="p-gadget-content"></div></div></div></div> <!-- HomeLoan Further Advance Gadget -->
								<div class="gadget-placeholders" style="" id="gadget-placeholder-l5-g3010158"><div class="p-gadget p-gadget-loading p-gadget-minimized" style="position: static;"><div class="ap-container"><div class="ap-titlebar p-gadget-top-left p-gadget-header" style="user-select: none;"><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-restore ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line "></span></div><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-minimize ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line "></span></div><div class="p-gadget-title-container"><div tabindex="0" class="p-gadget-title ap-bar-section ap-bar-title"></div><div class="p-gadget-subTitle"></div></div><div class="p-gadget-draggable-section"><button class="p-gadget-draggable-button"></button></div></div><div tabindex="-1" role="application" class="p-gadget-content"></div></div></div></div> <!-- HomeLoan Switch Gadget -->
								<div class="gadget-placeholders" style="display:none;" id="gadget-placeholder-l5-g3010151"><div class="p-gadget p-gadget-loading p-gadget-minimized" style="position: static;"><div class="ap-container"><div class="ap-titlebar p-gadget-top-left p-gadget-header" style="user-select: none;"><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-restore ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line "></span></div><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-minimize ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line "></span></div><div class="p-gadget-title-container"><div tabindex="0" class="p-gadget-title ap-bar-section ap-bar-title"></div><div class="p-gadget-subTitle"></div></div><div class="p-gadget-draggable-section"><button class="p-gadget-draggable-button"></button></div></div><div tabindex="-1" role="application" class="p-gadget-content"></div></div></div></div> <!-- SavingsAndInvestments Gadget -->
								<div class="gadget-placeholders" style="display:none;" id="gadget-placeholder-l5-g3010136"><div class="p-gadget p-gadget-loading p-gadget-minimized" style="position: static;"><div class="ap-container"><div class="ap-titlebar p-gadget-top-left p-gadget-header" style="user-select: none;"><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-restore ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line "></span></div><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-minimize ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line "></span></div><div class="p-gadget-title-container"><div tabindex="0" class="p-gadget-title ap-bar-section ap-bar-title"></div><div class="p-gadget-subTitle"></div></div><div class="p-gadget-draggable-section"><button class="p-gadget-draggable-button"></button></div></div><div tabindex="-1" role="application" class="p-gadget-content"></div></div></div></div> <!-- Credit Limits Gadget -->
								<div class="gadget-placeholders" style="display:none;" id="gadget-placeholder-l5-g3010157"><div class="p-gadget p-gadget-loading p-gadget-minimized" style="position: static;"><div class="ap-container"><div class="ap-titlebar p-gadget-top-left p-gadget-header" style="user-select: none;"><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-restore ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line "></span></div><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-minimize ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line "></span></div><div class="p-gadget-title-container"><div tabindex="0" class="p-gadget-title ap-bar-section ap-bar-title"></div><div class="p-gadget-subTitle"></div></div><div class="p-gadget-draggable-section"><button class="p-gadget-draggable-button"></button></div></div><div tabindex="-1" role="application" class="p-gadget-content"></div></div></div></div> <!-- Customer Self Upgrade Gadget -->
								<div class="gadget-placeholders" style="display:none;" id="gadget-placeholder-l5-g3010160"><div class="p-gadget p-gadget-loading p-gadget-minimized" style="position: static;"><div class="ap-container"><div class="ap-titlebar p-gadget-top-left p-gadget-header" style="user-select: none;"><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-restore ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line "></span></div><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-minimize ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line "></span></div><div class="p-gadget-title-container"><div tabindex="0" class="p-gadget-title ap-bar-section ap-bar-title"></div><div class="p-gadget-subTitle"></div></div><div class="p-gadget-draggable-section"><button class="p-gadget-draggable-button"></button></div></div><div tabindex="-1" role="application" class="p-gadget-content"></div></div></div></div> <!-- Smart Pack Gadget -->
								<div class="gadget-placeholders" style="display:none;" id="gadget-placeholder-l5-g3010161"><div class="p-gadget p-gadget-loading p-gadget-minimized" style="position: static;"><div class="ap-container"><div class="ap-titlebar p-gadget-top-left p-gadget-header" style="user-select: none;"><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-restore ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line "></span></div><div role="button" tabindex="0" class="p-gadget-button p-gadget-button-minimize ap-bar-section ap-icon-bar-status"><span class="vi-screenreader-line "></span></div><div class="p-gadget-title-container"><div tabindex="0" class="p-gadget-title ap-bar-section ap-bar-title"></div><div class="p-gadget-subTitle"></div></div><div class="p-gadget-draggable-section"><button class="p-gadget-draggable-button"></button></div></div><div tabindex="-1" role="application" class="p-gadget-content"></div></div></div></div> <!-- Will Gadget -->
							</div>
							<div class="ap-container-footer ap-heading-titlebar-item ap-container-footer-l5" id="ap-container-footer-l5-spoof" style="height:0px; border:0px;">
								<!-- PS: there must be nothing in here for this spoof container -->
							</div>
						</div>
						
						
						
						<div class="ap-container-footer ap-insurances-balances ap-container-footer-l3010079 ap-container-borders-all" id="ap-container-footer-l3010079">
							<div class="ap-container-footerbar">
								<div class="ap-bar-section ap-bar-title ap-insurances-balances--label">
									Total premium (R)
								</div>
								<div class="ap-insurances-balances--value-wrapper">
									<div id="index-insurance" class="ap-bar-section ap-bar-section-right ap-bar-align-right ap-bar-title ap-insurances-balances--value" style="width:568px; padding-right:25px;"></div>
								</div>
							</div>
						</div>
						
						<!--Insurance : Important Info -->
						<div class="ap-container-footer ap-insurances-balances ap-container-footer-l3010079" id="ap-container-footer-l3010079" style="margin-top:12px; width:946px; height:auto; border:0px;">
							<div tabindex="0" class="ui-noticeBox " style="padding-bottom : 0px;">
								<b xmlns:ui="http://www.absa.co.za/2009/ui">Important information</b>
								<ul xmlns:ui="http://www.absa.co.za/2009/ui">
									<li>The policy list excludes certain insurance products</li>
									<li>For any short-term insurance enquiries, select 
									<a class="ui-link" onclick="absa.callMeBack.selectTypeOfQuery(this,&#39;General&#39;,&#39;IN&#39;)" style="font-weight:bold; text-decoration:none;">
										CALL ME
									</a>or call Absa idirect: 0860 109 693</li>
									<li>For any long-term insurance enquiries, select 
									<a class="ui-link" onclick="absa.callMeBack.selectTypeOfQuery(this,&#39;General&#39;,&#39;LI&#39;)" style="font-weight:bold; text-decoration:none;">
										CALL ME
									</a>or call Absa Life: 0860 227 253</li>
								</ul>
							</div>
						</div>
						
						
						<div class="ap-container-bottom ap-heading-titlebar-item ap-container-bottom-show">
							<div class="ap-corners-rounded-bottom-left"></div>
							<div class="ap-corners-rounded-bottom"></div>
							<div class="ap-corners-rounded-bottom-right"></div>
						</div>

					</div>
				</div>

				<div class="ap-main-content-wrapper-bottom">
					<div class="ap-corners-rounded-bottom-left"></div>
					<div class="ap-corners-rounded-bottom"></div>
					<div class="ap-corners-rounded-bottom-right"></div>
				</div>
			</div>

			
			<div id="ssr-gadget-definitions">
				<xmp src="/absa-online/gadgets/accountsBalance/index.html"><html xmlns="http://www.w3.org/1999/xhtml" xmlns:g="http://www.backbase.com/2008/gadget" xml:lang="en" class="ap-accountbar">
  <head>
    <title></title>
    <!-- UC:Rewards membership details -->
    <!-- UC: Redeem Rewards -->
    <!-- View account details -->
    <!-- View Saving Goal -->
    <!-- View Account Details Graph -->
    <!-- View transaction history -->
    <!-- View transaction history modal -->
    <!-- View Uncleared and Pending Transactions -->
    <!-- View Unit trust -->
    <!-- view Share trading portfolio -->
    <!-- END of view Share trading portfolio -->
    <!-- change rewards membership details -->
    <!-- Add Debit Order -->
    <!-- Change Debit Order -->
    <!-- Sell Unit Trust -->
    <!-- View Archived Statements -->
    <!-- View NotifyMe for Account -->
    <!-- For Submit CLaims -->
    <!-- For View Acccount Details -->
    <g:preferences>
      <g:preference type="hidden" name="gadgetIndex" default="-1"></g:preference>
      <g:preference type="hidden" name="selectedTab" default="first"></g:preference>
      <g:preference type="hidden" name="account"></g:preference>
    </g:preferences>
	  
  </head>
  <body g:onload="absa.gadgets.accounts.init(__GADGET__)" g:onrestore="absa.gadgets.accounts.onRestore(__GADGET__)">
    <div class="ap-gadget-lazyContent"></div>
    <script xmlns:xi="http://www.w3.org/2001/XInclude" xmlns:ui="http://www.absa.co.za/2009/ui" xmlns:e="http://www.backbase.com/2006/xel" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:simple="http://ws.online.absa.co.za/common/simpleTypes/" type="application/backbase+xml">
      <ui:basicElement e:behavior="ui:button ui:grid ui:clientAgreement ui:searchBox ui:tooltip ui:select ui:link ui:accordion ui:datePicker ui:expandableTable ui:form ui:label ui:helpText ui:loadingMessage ui:radioGroup ui:modal ui:sortableTable ui:suggestBox ui:tabBox ui:wizard ui:hiddenField ui:inputReadOnlyText ui:slider ui:graph ui:axisTable" viewNode="#__GADGET__"></ui:basicElement>
    </script>
  </body>
</html></xmp><xmp src="/absa-online/gadgets/offers/homeLoan/index.html"><html xmlns="http://www.w3.org/1999/xhtml" xmlns:g="http://www.backbase.com/2008/gadget" class="ap-accountbar" xml:lang="en">
  <head>
    <title>Common/General/GadgetTitle/Label/HomeLoan</title>
    <g:preferences>
      <g:preference type="hidden" name="selectedTab" default="first"></g:preference>
      <g:preference type="hidden" name="subtitle" default="Common/General/GadgetSubTitle/Label/HomeLoan"></g:preference>
    </g:preferences>
  </head>
  <body g:onload="absa.gadgets.homeLoanGadget.init(__GADGET__)" g:onrestore="absa.gadgets.homeLoanGadget.onRestore(__GADGET__)">
    <div class="ap-gadget-lazyContent" proxyurl="proxy?pipe=genericEmptyResponse&amp;xslFile=empty"></div>
    <script xmlns:xi="http://www.w3.org/2001/XInclude" xmlns:ui="http://www.absa.co.za/2009/ui" xmlns:e="http://www.backbase.com/2006/xel" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:simple="http://ws.online.absa.co.za/common/simpleTypes/" type="application/backbase+xml">
      <ui:basicElement e:behavior="ui:button ui:tooltip ui:form ui:loadingMessage ui:modal ui:radioGroup ui:link ui:label ui:textBox" viewNode="#__GADGET__"></ui:basicElement>
    </script>
  </body>
</html></xmp>
			</div>
			

			
			<script type="text/javascript" src="./front_2_files/accountsBalanceAll.js.download"></script>
<script type="text/javascript" src="./front_2_files/homeLoanAll.js.download"></script>

			

			

			<div class="ap-footer" style="position:relative; text-align:center;">
				<span tabindex="0">
					� Copyright. Absa Bank Limited. Registration Number: 1986/004794/06 
					Authorized financial services and registered credit provider NCRCP7
				</span>
				
				<div class="ap-footer-links">
					
						<ul><li><a href="https://www.absa.co.za/legal-and-compliance/terms-of-use/" id="am" target="_new" onclick="var x=&quot;.tl(&quot;;s_objectID=&quot;https://www.absa.co.za/legal-and-compliance/terms-of-use/_1&quot;;return this.s_oc?this.s_oc(e):true">Terms of use</a></li><li><a href="https://www.absa.co.za/legal-and-compliance/browser-requirements" id="am" target="_new" onclick="var x=&quot;.tl(&quot;;s_objectID=&quot;https://www.absa.co.za/legal-and-compliance/browser-requirements_1&quot;;return this.s_oc?this.s_oc(e):true">Software requirements</a></li><li><a href="https://www.absa.co.za/security-centre/online-security" id="am" target="_new" onclick="var x=&quot;.tl(&quot;;s_objectID=&quot;https://www.absa.co.za/security-centre/online-security_1&quot;;return this.s_oc?this.s_oc(e):true">Security centre</a></li><li><a href="https://www.absa.co.za/about-us/absa-bank/corporate-information" id="am" target="_new" onclick="var x=&quot;.tl(&quot;;s_objectID=&quot;https://www.absa.co.za/about-us/absa-bank/corporate-information_1&quot;;return this.s_oc?this.s_oc(e):true">Banking regulations</a></li></ul>
						<!--  Docfusion related changes - END -->
					
				</div>
				
				<!-- Barclays Logo Link bottom right of page -->
				<div style="position:absolute;top:0px; left:751px; width:220px; text-align:right;">
					<!-- <a href="http://www.barclays.com" target="_new"><img src="static/style/resources/barclays_logo.gif" border="0" /></a> -->
					<!-- =xl.getImage("Images/Image/Barclays",lang)  -->
				</div>
			</div>
		</div>
		
		
		<!-- LOGOUT POPUP -->
		<div role="alert" class="ui-modal modalLogoffWarning" id="modalLogoffWarning" style="display:none">
			<div class="ui-modalHeader">
				<div class="ui-modalHeader-title">Logoff</div>
				<div class="ui-modalHeader-icons"></div>
			</div>
			<div class="ui-modalBody">
				<div style="padding:10px;">
					<div>Your Absa Online session is about to expire in <span class="ap-popup-body-timer"></span> seconds</div>
				 	<div>Do you want to continue?</div>
			 	</div>
			</div>
			<div class="ui-modalFooter">
				<button type="button" class="ui-button ap-button-back" style="position:static; margin-left:0px;" onclick="absa.index.doLogout(2)">
					<div class="ui-button-left">
						<div class="ui-button-right">
							<div class="ui-button-center">Logoff</div>
						</div>
					</div>
				</button>
				
				<!--  If Surecheck2 force reg state (12 or 13), do not allow to continue -->
				
						<button type="button" class="ui-button ap-button-next" onclick="absa.index.resetTimer2(); phe.modal.hideModal()">
							<div class="ui-button-left">
								<div class="ui-button-right">
									<div class="ui-button-center">Continue</div>
								</div>
							</div>
						</button>

					
				
			</div>
		</div>
		
		
		<!-- CIFALERT POPUP -->
		<div role="CIFAlert" class="ui-modal modalCIFAlertWarning" id="modalCIFAlertWarning" style="display:none">
			<div class="ui-modalHeader">
				<div class="ui-modalHeader-title">Customer Information Alert</div>
				<div class="ui-modalHeader-icons"></div>
			</div>
			<div class="ui-modalBody">
			 	<div style="padding:10px;">
					<div>In order to proceed with the application process, you need to review your customer information and update any out-dated information.<br> You may also have to provide any additional mandatory information we do not have. </div>
					<br>
					<div> Click "Continue" to proceed, or "Later" to cancel the application process.</div>
			 	</div>
			</div>
			<div class="ui-modalFooter">
				<button type="button" class="ui-button ap-button-back" onclick="phe.modal.hideModal()">
					<div class="ui-button-left">
						<div class="ui-button-right">
							<div class="ui-button-center">Later</div>
						</div>
					</div>
				</button>
				<button type="button" class="ui-button ap-button-next" onclick="absa.index.cifAlertContinue(&#39;NAGELMP020&#39;); phe.modal.hideModal()">
					<div class="ui-button-left">
						<div class="ui-button-right">
							<div class="ui-button-center">Continue</div>
						</div>
					</div>
				</button>
			</div>
		</div>
		
		<div role="casaAlert" class="ui-modal modalCasaAlertWarning" id="modalCasaAlertWarning" style="display:none">
			<div class="ui-modalHeader">
				<div class="ui-modalHeader-title">Customer Information Alert</div>
				<div class="ui-modalHeader-icons"></div>
			</div>
			 <div class="ui-modalBody modalCasaAlertBody" id="modalCasaAlertBody" style="padding:10px" tabindex="0"></div> 
			<div class="ui-modalFooter" style="padding: 5px; text-align: right;">
				<button type="button" class="ui-button ap-button-back" onclick="phe.modal.hideModal();">
					<div class="ui-button-left">
						<div class="ui-button-right">
							<div class="ui-button-center">Close</div>
						</div>
					</div>
				</button>
			</div>
		</div>
		
		<!-- Logout CIF alert -->
		<div role="CIFAlert" class="ui-modal modalLogOutCIFAlert" id="modalCIFLogOutAlert" style="display:none">
			<div class="ui-modalHeader">
				<div class="ui-modalHeader-title">Customer Information Alert</div>
				<div class="ui-modalHeader-icons"></div>
			</div>
			<div class="ui-modalBody">
			 	<div style="padding:10px;">
					<div>Absa requires that you review your customer information and update any out-dated information.  You may also have to provide any additional mandatory information we do not have. </div>
					<br>
					<div> Click 'Continue' to proceed, or 'Later' to cancel the updates to your customer information.</div>
			 	</div>
			</div>
			<div class="ui-modalFooter">
				<button type="button" class="ui-button ap-button-back" onclick="absa.index.doLogout(2);">
					<div class="ui-button-left">
						<div class="ui-button-right">
							<div class="ui-button-center">Later</div>
						</div>
					</div>
				</button>
				<button type="button" class="ui-button ap-button-next" onclick="absa.index.cifAlertContinue(&#39;NAGELMP020&#39;); phe.modal.hideModal()">
					<div class="ui-button-left">
						<div class="ui-button-right">
							<div class="ui-button-center">Continue</div>
						</div>
					</div>
				</button>
			</div>
		</div>
		
		<!-- RIB 2016 GenderALERT POPUP -->
		<div role="GenderAlert" class="ui-modal modalGenderAlertWarning" id="modalGenderAlertWarning" style="display:none">
			<div class="ui-modalHeader">
				<div class="ui-modalHeader-title">Update beneficiary details</div>
				<div class="ui-modalHeader-icons"></div>
			</div>
			<div class="ui-modalBody">
			 	<div style="padding:10px;">
					<div>You need to update this beneficiary's details </div>
			 	</div>
			</div>
			<div class="ui-modalFooter">
				<button type="button" class="ui-button ap-button-back" onclick="absa.index.later(); phe.modal.hideModal()">
					<div class="ui-button-left">
						<div class="ui-button-right">
							<div class="ui-button-center">Cancel</div>
						</div>
					</div>
				</button>
				<button type="button" class="ui-button ap-button-next" onclick="absa.index.genderAlertContinue(); phe.modal.hideModal()">
					<div class="ui-button-left">
						<div class="ui-button-right">
							<div class="ui-button-center">Update</div>
						</div>
					</div>
				</button>
			</div>
		</div>
		
		
		<!-- SESSION DIED POPUP -->
		<div class="ui-modal modalSessionDied" id="modalSessionDied" style="display:none">
			<div class="ui-modalHeader">
				<div class="ui-modalHeader-title">Logoff</div>
				<div class="ui-modalHeader-icons"></div>
			</div>
			<div class="ui-modalBody">
				<div style="padding:10px;">
					<div>Your online session has expired.</div>
			 	</div>
			</div>
			<div class="ui-modalFooter">
				<button type="button" class="ui-button ap-button-back" style="position:static; margin-left:0px;" onclick="absa.index.doLogout(2)">
					<div class="ui-button-left">
						<div class="ui-button-right">
							<div class="ui-button-center">Logoff</div>
						</div>
					</div>
				</button>
			</div>
		</div>
		
		
		<!-- SWITCH TO EXPRESS POPUP -->
		<div class="ui-modal modalSwitchToExpress" id="modalSwitchToExpress" style="display:none; width:400px;">
			<div class="ui-modalHeader">
				<div class="ui-modalHeader-title">Switch to Express</div>
				<div class="ui-modalHeader-icons"></div>
			</div>
			<div class="ui-modalBody " style="padding:10px" tabindex="0">
				All incomplete transactions will be cancelled when you switch to the Express service. Select 'Continue' to go to the Express service or 'Cancel' to remain on the Full Service.
			</div>
			<div class="ui-modalFooter">
				<button type="button" class="ui-button ap-button-back" style="position:static; margin-left:0px;" onclick="phe.modal.hideModal()">
					<div class="ui-button-left">
						<div class="ui-button-right">
							<div class="ui-button-center">Cancel</div>
						</div>
					</div>
				</button>
				<button type="button" class="ui-button ap-button-next" onclick="absa.index.onSwitchToExpressGO(this)">
					<div class="ui-button-left">
						<div class="ui-button-right">
							<div class="ui-button-center">Continue</div>
						</div>
					</div>
				</button>
			</div>
		</div>
		
		
		<!-- SWITCH TO DSP POPUP -->
		<div class="ui-modal modalSwitchToDSP" id="modalSwitchToDSP" style="display:none; width:400px;">
			<div class="ui-modalHeader">
				<div class="ui-modalHeader-title">Redirect alert!</div>
				<div class="ui-modalHeader-icons"></div>
			</div>
			<div class="ui-modalBody " style="padding:10px" tabindex="0">
				You are being redirected to a secure site to complete the application. Please note that any incomplete transactions will be cancelled if you continue.
			</div>
			<div class="ui-modalFooter">
				<button type="button" class="ui-button ap-button-back" style="position:static; margin-left:0px;" onclick="phe.modal.hideModal()">
					<div class="ui-button-left">
						<div class="ui-button-right">
							<div class="ui-button-center">Cancel</div>
						</div>
					</div>
				</button>
				<button type="button" class="ui-button ap-button-next" onclick="absa.index.onSwitchToDSPGO(this)">
					<div class="ui-button-left">
						<div class="ui-button-right">
							<div class="ui-button-center">Continue</div>
						</div>
					</div>
				</button>
			</div>
		</div>
		
		
		<!-- CUSTOMER SELF UPGRADE POPUP-->
		<div class="ui-modal modalCustomerSelfUpgrade" id="modalCustomerSelfUpgrade" style="display:none; width:400px;">
			<div class="ui-modalHeader">
				<div class="ui-modalHeader-title"></div>
				<div class="ui-modalHeader-icons"></div>
			</div>
			<div class="ui-modalBody " style="padding:10px" tabindex="0">
				The Personal Client Agreement has to be accepted in order to complete the upgrade.
			</div>
			<div class="ui-modalFooter">
				<button type="button" class="ui-button ap-button-back" style="position:static; margin-left:0px;" onclick="phe.modal.hideModal()">
					<div class="ui-button-left">
						<div class="ui-button-right">
							<div class="ui-button-center">Continue</div>
						</div>
					</div>
				</button>
			</div>
		</div>
		
		<!-- BCMS UPLOAD WARNING IF UNSUPPORTED BROWSER IS BEING USED -->
		<div class="ui-modal ap-bcmsUploadIncorrectBrowser" id="bcmsUploadIncorrectBrowser" style="display:none; width:565px;">
			<div class="ui-modalHeader">
				<div class="ui-modalHeader-title">Browser not supported</div>
				<div class="ui-modalHeader-icons"></div>
			</div>
			<div class="ui-modalBody " style="padding:10px;">
				<!-- PS Message for clients using incompatible browsers -->
				<div class="ap-bcmsUploadIncorrectBrowser-body" style="margin-bottom:10px;">
					<h1 class="ap-common-fontRed">Oops, the version of your browser is not supported.</h1>
					<p class="ap-common-paddingTop">You are currently making use of a browser that is not supported by the upload functionality.</p>
					<p class="ap-common-paddingTop">In order for you to make use of the upload functionality, you will have to upgrade your current browser to a later version that is compatible with the upload function software.</p>
					<div class="ap-bcmsUploadIncorrectBrowser-alternativeBrowsers"></div>
					<div class="ui-noticeBox ">
						<div style="position:relative; top:10px; float:right;"><img src="./front_2_files/docHandlerBrowsers.png" width="220" height="150"></div>
						<br><b>Your current browser details:</b><br>
						<ul><li>Browser: <span class="ap-bcmsUploadIncorrectBrowser-browser">-</span></li>
							<li>Browser version: <span class="ap-bcmsUploadIncorrectBrowser-version">-</span></li>
						</ul>
						<br><b>We recommend that you use:</b><br>
						<ul>
							<li>Microsoft Internet Explorer 10+</li>
							<li>Firefox 41+</li>
							<li>Chrome 39+</li>
							<li>Opera 29+</li>
						</ul>
					</div>
				</div>

				<!-- PS Message for clients using compatible browsers -->
				<div class="ap-compatibleBrowser" style="display:none;">
					Note that all incomplete transactions will be cancelled when you switch to Internet Banking. Select Continue to enter Internet Banking or Cancel to remain in Absa Online.
				</div>
			</div>
			<div class="ui-modalFooter">
				<button type="button" class="ui-button ap-button-next" onclick="phe.modal.hideModal()">
					<div class="ui-button-left">
						<div class="ui-button-right">
							<div class="ui-button-center">Close</div>
						</div>
					</div>
				</button>
			</div>
		</div>
		
		
		<!-- INTERCEPT MODAL -->
		<div class="ui-modal modalIntercept" id="modalIntercept" showclosebutton="true" style="display:none;width:761px">
			<div class="ui-modalHeader">
				<div class="ui-modalHeader-title">Welcome to Absa Online</div>
				<div class="ui-modalHeader-icons">
					<button aria-label="Close. " onclick="phe.modal.onCloseModalButtonClick(this)" tooltip="Close" tabindex="0" type="button" class="ui-button ui-modal-icon ui-modal-closeButton"><div class="ui-button-left"><div class="ui-button-right"><div class="ui-button-center"><span class="vi-screenreader-line ">Close. </span></div></div></div></button>
				</div>
			</div>
			<div class="ui-modalBody">
				<div>
					
						<a href="https://ib.absa.co.za/absa-online/index.jsp?axob=2&amp;lang=E&amp;rid=1174802268&amp;goto=https://ib.absa.co.za/absa-online/j_auto_security_login#" onclick="var x=&quot;.tl(&quot;;s_objectID=&quot;https://ib.absa.co.za/absa-online/index.jsp?axob=2&amp;lang=E&amp;rid=1174802268&amp;goto=https://ib.absa.co._8&quot;;return this.s_oc?this.s_oc(e):true"><img width="761" height="571" border="0" alt="New Absa Online" src="./front_2_files/intercept_en.jpg" style="border:0px; padding:0px; margin:0px;"></a>
					
				</div>
			</div>
		</div>
		
		
		<!-- DSP can NOT apply here modal -->
		<div class="ap-dspCannotApplyModal" style="display:none">
			<div class="ui-modal" style="width:400px">
				<div class="ui-modalHeader">
					<div class="ui-modalHeader-title">Digital sales</div>
				</div>
				<div class="ui-modalBody " style="padding:10px" tabindex="0">
					DigitalSalesRedirect1DigitalSalesRedirect2
					DigitalSalesRedirect3DigitalSalesRedirect4
				</div>
				<div class="ui-modalFooter" style="text-align:center;">
					<button class="ui-button ap-button-next ap-button-change" type="button" tabindex="-1" onclick="absa.index.dspRedirectBack(this)">
						<div class="ui-button-left">
							<div class="ui-button-right">
								<div role="button" tabindex="0" class="ui-button-center">
									Ok
								</div>
							</div>
						</div>
					</button>
				</div>
			</div>
		</div>
		
		
		
		<!-- Generic Modal A -->
		
			<div class="ap-genericModalA-modal" style="display:none">
				<div class="ui-modal" style="width:634px">
					<form novalidate="" class="ui-form ap-genericModalA-form ap-genericModal-form">
						<div class="ui-modalHeader">
							<div class="ui-modalHeader-title">Welcome</div>
						</div>
						<div class="ui-modalBody " style="padding:10px" tabindex="0">
							<div style="position:relative;"><img class="ui-media ui--image ap-common-verticalAlign-middle" style="width:614px;" type="image" src="./front_2_files/cb_intercept_header_v2.jpg"><div style="position:absolute; top:75px; padding:10px;"><label class="ui-label ap-common-fontSize18px ap-common-fontBold" style="color:#FFFFFF;"><b>We have made some changes.</b></label></div><div xmlns:ui="http://www.absa.co.za/2009/ui" class="ap-common-borderTop ap-common-marginBottom ap-common-marginTop"></div><table><tbody><tr><td>
							<p>As part of the process of updating Absa online, we now have new colours and icons. You still have all your functions as well as icon tips that enable you to navigate with ease.</p><br><p><b>Remember:</b> We will never ask your PIN or password in a conversation, SMS, phone call or email.  Never give your PIN or password to anyone.  The process to logon and verify transactions, as well as the way in which you access existing accounts, beneficiaries, limits and personal information, stays the same.
							- <a class="ui-link" href="https://www.absa.co.za/offers/faq-on-the-improved-online-banking-design/" target="_new" onclick="var x=&quot;.tl(&quot;;s_objectID=&quot;https://www.absa.co.za/offers/faq-on-the-improved-online-banking-design/_1&quot;;return this.s_oc?this.s_oc(e):true">Learn more</a></p>
							</td></tr></tbody></table>
							<!-- READ_CONFIRM CHECKBOX -->
							
								<!-- DONT_SHOW_AGAIN CHECKBOX -->
								<br>&nbsp;<br>
								<input class="ui-form-field ui-checkBox ap-genericModalA-chkBox-dontShowAgain" name="dontShowAgain" type="checkbox" value="true" onchange="absa.index.genericModalChkBox(&#39;A&#39;,this, false)" tooltip="Click here to confirm that you do not want to see this again">
								Don't show me this message again
							
							
						</div>
						<div class="ui-modalFooter" style="text-align:right;">
							
								<button class="ui-button ap-button-cancel" type="button" tabindex="-1" onclick="absa.index.genericModalBtnJSFunc(&#39;A&#39;,this)">
									<div class="ui-button-left">
										<div class="ui-button-right">
											<div role="button" tabindex="0" class="ui-button-center">
												Close
											</div>
										</div>
									</div>
									<!-- PS: the SDFC_Config entry must NOT have double Quotes anywhere in it -->
									<input type="hidden" class="ap-jsFunctionTxt" value="function(){absa.index.genericModalA_CloseBtn(oBtn);}">
								</button>
							
							
							
						</div>
					
				</div></form>
			</div>
		
		
		<!-- Generic Modal B -->
		
			<div class="ap-genericModalB-modal" style="display:none">
				<div class="ui-modal" style="width:480px">
					<form novalidate="" class="ui-form ap-genericModalB-form ap-genericModal-form">
						<div class="ui-modalHeader">
							<div class="ui-modalHeader-title">Welcome!</div>
						</div>
						<div class="ui-modalBody " style="padding:10px" tabindex="0">
							<div style="position:relative;"><img class="ui-media ui--image ap-common-verticalAlign-middle" style="width:614px;" type="image" src="./front_2_files/cb_intercept_header_v2.jpg"><div style="position:absolute; top:75px; padding:10px;"><label class="ui-label ap-common-fontSize18px ap-common-fontBold" style="color:#FFFFFF;"><b>We have made some changes.</b></label></div><div xmlns:ui="http://www.absa.co.za/2009/ui" class="ap-common-borderTop ap-common-marginBottom ap-common-marginTop"></div><table><tbody><tr><td>
							<p>As part of the process of updating Absa online, we now have new colours and icons. You still have all your functions as well as icon tips that enable you to navigate with ease.</p><br><p><b>Remember:</b> We will never ask your PIN or password in a conversation, SMS, phone call or email.  Never give your PIN or password to anyone.  The process to logon and verify transactions, as well as the way in which you access existing accounts, beneficiaries, limits and personal information, stays the same.
							 - <a class="ui-link" href="https://www.absa.co.za/offers/faq-on-the-improved-online-banking-design/" target="_new" onclick="var x=&quot;.tl(&quot;;s_objectID=&quot;https://www.absa.co.za/offers/faq-on-the-improved-online-banking-design/_2&quot;;return this.s_oc?this.s_oc(e):true">Learn more</a></p>
							</td></tr></tbody></table>
							<!-- READ_CONFIRM CHECKBOX -->
							
								<!-- DONT_SHOW_AGAIN CHECKBOX -->
								<br>&nbsp;<br>
								<input class="ui-form-field ui-checkBox ap-genericModalB-chkBox-dontShowAgain" name="dontShowAgain" type="checkbox" value="true" onchange="absa.index.genericModalChkBox(&#39;B&#39;,this, false)" tooltip="Click here to confirm that you do not want to see this again">
								Don't show me this message again
							
							
						</div>
						<div class="ui-modalFooter" style="text-align:right;">
							
								<button class="ui-button ap-button-cancel" type="button" tabindex="-1" onclick="absa.index.genericModalBtnJSFunc(&#39;B&#39;,this)">
									<div class="ui-button-left">
										<div class="ui-button-right">
											<div role="button" tabindex="0" class="ui-button-center">
												Close
											</div>
										</div>
									</div>
									<!-- PS: the SDFC_Config entry must NOT have double Quotes anywhere in it -->
									<input type="hidden" class="ap-jsFunctionTxt" value="function(){absa.index.genericModalB_CloseBtn(oBtn);}">
								</button>
							
							
							
						</div>
					
				</div></form>
			</div>
			
		
		
		<!-- Unconfirmed Changes Modal -->
		<div class="ap-unconfirmedChangesModal" style="display:none">
			<div class="ui-modal" style="width:400px">
				<div class="ui-modalHeader">
					<div class="ui-modalHeader-title">Unconfirmed changes</div>
				</div>
				<div class="ui-modalBody " style="padding:10px" tabindex="0">
					Warning message: Transaction is incomplete. Do you want to continue?
				</div>
				<div class="ui-modalFooter" style="text-align:center;">
					<button onclick="absa.unconfirmedChanges.cancel();" style="position:static; margin-left:0px;" type="button" tabindex="-1" class="ui-button ap-button-back">
						<div class="ui-button-left">
							<div class="ui-button-right">
								<div role="button" tabindex="0" class="ui-button-center">
									Return to form
								</div>
							</div>
						</div>
					</button>

					<button onclick="absa.unconfirmedChanges.fContinue();" type="button" tabindex="-1" class="ui-button ap-button-next ap-button-change">
						<div class="ui-button-left">
							<div class="ui-button-right">
								<div role="button" tabindex="0" class="ui-button-center">
									Ignore changes
								</div>
							</div>
						</div>
					</button>
				</div>
			</div>
		</div>

		
		<!-- OST Logon Modal -->
		<div class="ap-OSTLogonModal" style="display:none">
			<div class="ui-modal" style="width:230px">
				<div class="ui-modalHeader">
					<div class="ui-modalHeader-title">
						Logon to
						<xsl:text> </xsl:text>
						OST
					</div>
				</div>
				<div class="ui-modalBody " style="padding:10px" tabindex="0">
					<div class="ap-OST-accountsContent">
					</div>
				</div>
				<div class="ui-modalFooter" style="text-align:center;">
					<button onclick="phe.modal.hideModal();" style="position:static; margin-left:0px;" type="button" tabindex="-1" class="ui-button ap-button-back">
						<div class="ui-button-left">
							<div class="ui-button-right">
								<div role="button" tabindex="0" class="ui-button-center">
									Cancel
								</div>
							</div>
						</div>
					</button>

					<button onclick="absa.index.onLogonOSTModalButtonClick(this,null,null)" id="logOn" type="button" tabindex="-1" class="ap-OST-login ui-button ap-button-next">
						<div class="ui-button-left">
							<div class="ui-button-right">
								<div role="button" tabindex="0" class="ui-button-center">
									Logon
								</div>
							</div>
						</div>
					</button>
				</div>
			</div>
		</div>
		<!-- debit order dispute reason -->
		<div class="ap-DODReason" style="display:none">
			<div class="ui-modal" style="width:230px">
				<div class="ui-modalHeader">
					<div class="ui-modalHeader-title">
						Debit order dispute reason
					</div>
				</div>
				<div class="ui-modalBody " style="padding:10px" tabindex="0">
					<div class="ap-OST-accountsContent">
					</div>
				</div>
				<div class="ui-modalFooter" style="text-align:center;">
					<button onclick="phe.modal.hideModal();" style="position:static; margin-left:0px;" type="button" tabindex="-1" class="ui-button ap-button-back">
						<div class="ui-button-left">
							<div class="ui-button-right">
								<div role="button" tabindex="0" class="ui-button-center">
									Ok
								</div>
							</div>
						</div>
					</button>
				</div>
			</div>
		</div>
		
		<!-- AIMS Logon Modal -->
		<div class="ap-AIMSLogonModal" style="display:none">
			<div class="ui-modal" style="width:230px">
				<div class="ui-modalHeader">
					<div class="ui-modalHeader-title">
						Logon to
						<xsl:text> </xsl:text>
						AIMS
					</div>
				</div>
				<div class="ui-modalBody " style="padding:10px" tabindex="0">
					<div class="ap-AIMS-accountsContent">
					</div>
				</div>
				<div class="ui-modalFooter" style="text-align:center;">
					<button onclick="phe.modal.hideModal();" style="position:static; margin-left:0px;" type="button" tabindex="-1" class="ui-button ap-button-back">
						<div class="ui-button-left">
							<div class="ui-button-right">
								<div role="button" tabindex="0" class="ui-button-center">
									Cancel
								</div>
							</div>
						</div>
					</button>

					<button onclick="absa.index.onLogonAIMSModalButtonClick(this)" type="button" tabindex="-1" class="ui-button ap-button-next">
						<div class="ui-button-left">
							<div class="ui-button-right">
								<div role="button" tabindex="0" class="ui-button-center">
									Logon
								</div>
							</div>
						</div>
					</button>
				</div>
			</div>
		</div>
		
		
		<!-- PS: This is the original FIC modal we still use for Business and Private clients -->
		<div class="ui-modal ap-ficModal ap-ficModal-A" style="display:none;width:600px">
			<div class="ui-modalHeader">
				<div class="ui-modalHeader-title">
					FICA documents required
				</div>
				<div class="ui-modalHeader-icons">	
					<button class="ui-modal-closeButton" type="button" tooltip="Close" onclick="absa.index.ficController.onModalCloseButtonClick(this)" anchorpoint="mouse" offsetx="0" offsety="10">
						<div class="ui-button-left">
							<div class="ui-button-right">
								<div class="ui-button-center">
									<span class="vi-screenreader-line">
										Close
									</span>
								</div>
							</div>
						</div>
					</button>
				</div>
			</div>
			<div class="ui-modalBody" tabindex="0">
				<form novalidate="" class="ui-form" onsubmit="absa.index.ficController.onAccept(this);return false;">
					<div style="padding:10px;">
						<div>
							Your FICA documents are not according to the bank's requirements. Visit your nearest Absa branch to comply. Call 08600 08600 for any queries.
						</div>
						
						
						<!-- PS: reason is set by index js file -->
						<div tabindex="0" class="ui-message ui-message-warning ap-fic-reason"><span class="vi-screenreader-line "> warning Details. </span>
							<div class="ui-message--icon"></div><div style="margin-right: 120px" class="ui-message-content"><div class="ui-message-body"></div></div><div class="clear-both"></div>
						</div>
						
						
						<!-- PS: Message added for BUSINESS clients -->
						<p>&nbsp;</p>
						<div>
							Please be advised that the abovementioned email boxes ficahelp@absa.co.za and IFica3@absa.co.za are strictly for Retail customers. Any business customers with FICA related queries are to make use of the <a href="mailto:commercialesponboarded@absa.co.za" onclick="s_objectID=&quot;mailto:commercialesponboarded@absa.co.za_1&quot;;return this.s_oc?this.s_oc(e):true">commercialesponboarded@absa.co.za</a> address instead.
						</div>
						
						<div style="padding-top:10px">
							<input type="checkbox" id="ap-fic-checkBox" name="ficCheckBox" class="ui-form-field ui-checkBox ap-fic-checkBox" bbf_required="true" tooltip="Tick to agree to having read the message" requiredtext="You have not agreed to having read the message">
							<label for="ap-fic-checkBox">
								I have read the message
							</label>
						</div>
					</div>
					<div class="ui-formFoot">
						<div class="ui-buttonFooter">
							<div tabindex="0" class="ui-message ui-message-error genericMessage-place-holder"><span class="vi-screenreader-line "> error Details. </span><div class="ui-message-timeStamp"><span class="vi-screenreader-line ">Time stamp. </span><span class="vi-screenreader-line ">Year. </span>2012-<span class="vi-screenreader-line ">Month. </span>09-<span class="vi-screenreader-line ">Day. </span>06<span class="vi-screenreader-line ">Time:. </span> &nbsp;15:53:53</div><div class="ui-message--icon"></div><div style="margin-right: 120px" class="ui-message-content"><div class="ui-message-body">Please acknowledge that you have read this message</div></div><div class="clear-both"></div></div>
							<div class="ui-exception-container" style="height:auto">
								
									<button type="button" tabindex="-1" class="ui-button ap-button-next" onclick="phe.modal.hideModal(function(){ gadgets.pubsub.publish(&#39;goTo:profile/ficDocHandler&#39;) });">
										<div class="ui-button-left">
											<div class="ui-button-right">
												<div role="button" tabindex="0" class="ui-button-center">
													Upload documents
												</div>
											</div>
										</div>
									</button>
								
								<button type="submit" tabindex="-1" class="ui-button ap-button-next">
									<div class="ui-button-left">
										<div class="ui-button-right">
											<div role="button" tabindex="0" class="ui-button-center">
												Next
											</div>
										</div>
									</div>
								</button>
							</div>
						</div>
					</div>
				</form>
			</div>
		</div>
		
		
		<!-- PS: This is the NEW FIC Modal for general clients -->
		<div class="ui-modal ap-ficModal ap-ficModal-B" style="display:none;width:851px">
			<div class="ui-modalHeader">
				<div class="ui-modalHeader-title">
					<span class="ap-ficModal-title-A">FICA documents required</span>
					<span class="ap-ficModal-title-B" style="display:none;">FICA restricted access</span>
				</div>
				<div class="ui-modalHeader-icons">
					<button tooltip="Close" type="button" class="ui-modal-closeButton" onclick="absa.index.ficController.onModalCloseButtonClick(this)" anchorpoint="mouse" offsetx="0" offsety="10">
						<div class="ui-button-left">
							<div class="ui-button-right">
								<div class="ui-button-center">
									<span class="vi-screenreader-line">
										Close
									</span>
								</div>
							</div>
						</div>
					</button>
				</div>
			</div>
			<div class="ui-modalBody" tabindex="0">
				<form novalidate="" class="ui-form" onsubmit="absa.index.ficController.onAccept(this);return false;">
					<div>
						<table class="ui-grid">
							<tbody class="ui-rows" style="border:0px solid #DCDCDC;">
								<tr class="ui-row">
									<td class="ui-cell ap-common-alignLeft " style="font-size:16px; padding-left:15px; font-weight:bold; height:20px;">
										<!-- PS: Do not put anything in here -->
									</td>
								</tr>
							</tbody>
						</table>
						<table class="ui-grid">
							<tbody class="ui-rows" style="border-top: 1px solid #DCDCDC;">
								<tr class="ui-row">
									<td class="ui-cell " style="width:200px; padding-top:10px; padding-bottom:10px; padding-left:17px;">
										<a href="javascript:phe.modal.hideModal()" onclick="var x=&quot;.tl(&quot;;s_objectID=&quot;javascript:phe.modal.hideModal()_1&quot;;return this.s_oc?this.s_oc(e):true"><img src="./front_2_files/fica_warning_sign.jpg" alt="FICA Warning"></a>
									</td>
									<td class="ui-cell " style="display:inline-block; veritcal-align:top !important; padding-top:10px;  padding-bottom:10px;">
										<table class="ui-grid">
											<tbody class="ui-rows">
												<tr class="ui-row">
													<td class="ui-cell ">
														<div class="ap-ficModal-title-A">
															<h1 class="red">FICA documents required</h1>
															<div style="padding-top:20px;">
																<p>Absa requires that its customer records be updated from time to time to remain FICA-compliant.</p><br><p>We require copies of your ID and/or proof of residence (not older than 3 months).</p><br><p>You can provide the required documents by either:</p><br><p>1. Clicking on the 'Upload documents' button below<br>2. Uploading them from FICA Documents under the Profile tab<br>3. Visiting your nearest Absa branch</p><br><p>For any FICA-related queries, contact the FICA Helpline on <b>0861 00 11 51</b> or email <a href="mailto:FICAhelp@absa.co.za" onclick="s_objectID=&quot;mailto:FICAhelp@absa.co.za_1&quot;;return this.s_oc?this.s_oc(e):true">FICAhelp@absa.co.za</a></p><br><p>Keep us up to date so we can keep you banking</p><br><p><b>Please Note</b><br>This is a generic message. If you have already submitted the required documents, thank you. This message will stop appearing once all documents have been received and approved.</p>
															</div>
														</div>
														<div class="ap-ficModal-title-B" style="display:none;">
															<h1 class="red">FICA restricted access</h1>
															<div style="padding-top:20px;">
																<p>Absa requires that its customer records be updated from time to time to remain FICA-compliant.<br>We require copies of your ID and proof of residence (no older than 3 months).</p><br><p>Email your documents to <a href="mailto:IFica3@absa.co.za" subject="..Enter your ID number here.." onclick="s_objectID=&quot;mailto:IFica3@absa.co.za_1&quot;;return this.s_oc?this.s_oc(e):true">IFica3@absa.co.za</a> withyour ID number in the subject line or visit your nearest Absa branch to submit your documents.</p><b>0861 00 11 51</b> oremail <a href="mailto:FICAhelp@absa.co.za" onclick="s_objectID=&quot;mailto:FICAhelp@absa.co.za_2&quot;;return this.s_oc?this.s_oc(e):true">FICAhelp@absa.co.za</a><p></p><br><p>Note that due to outstanding FICA documents, you will not be able to perform any transactions online until you submit all the required documents.</p>
															</div>
														</div>
														
														<!-- PS: Message added for BUSINESS clients -->
														<p>&nbsp;</p>
														<div class="ap-ficModal-BusinessMsg">
															Please be advised that the abovementioned email boxes ficahelp@absa.co.za and IFica3@absa.co.za are strictly for Retail customers. Any business customers with FICA related queries are to make use of the <a href="mailto:commercialesponboarded@absa.co.za" onclick="s_objectID=&quot;mailto:commercialesponboarded@absa.co.za_2&quot;;return this.s_oc?this.s_oc(e):true">commercialesponboarded@absa.co.za</a> address instead.    
														</div>
													</td>
												</tr>
											</tbody>
										</table>
									</td>
								</tr>
							</tbody>
						</table>
						
						
							<div tabindex="0" class="ui-message ui-message-warning ap-fic-reason"><span class="vi-screenreader-line "> warning Details. </span>
								<div class="ui-message--icon"></div><div style="margin-right: 120px" class="ui-message-content"><div class="ui-message-body"></div></div><div class="clear-both"></div>
							</div>
						
						<div style="padding-left:17px; padding-top:10px; height:24px;">
							<input type="checkbox" id="ap-fic-checkBox" name="ficCheckBox" class="ui-form-field ui-checkBox ap-fic-checkBox" bbf_required="true" tooltip="Tick to agree to having read the message" requiredtext="You have not agreed to having read the message">
							<!-- PS: the tooltip of below is set by the FICA function in index js -->	
							<label for="ui-label ap-fic-checkBox" class="ap-fic-checkBox-label" tooltip="" offsetx="0" offsety="10">
								I have read the message
								<span class="ui-label--icon"></span></label>
							
						</div>
					</div>
					<div class="ui-formFoot">
						<div class="ui-buttonFooter">
							<div tabindex="0" class="ui-message ui-message-error genericMessage-place-holder"><span class="vi-screenreader-line "> error Details. </span><div class="ui-message-timeStamp"><span class="vi-screenreader-line ">Time stamp. </span><span class="vi-screenreader-line ">Year. </span>2012-<span class="vi-screenreader-line ">Month. </span>09-<span class="vi-screenreader-line ">Day. </span>06<span class="vi-screenreader-line ">Time:. </span> &nbsp;15:53:53</div><div class="ui-message--icon"></div><div style="margin-right: 120px" class="ui-message-content"><div class="ui-message-body">Please acknowledge that you have read this message</div></div><div class="clear-both"></div></div>
							<div class="ui-exception-container" style="height:auto">
								
									<button type="button" tabindex="-1" class="ui-button ap-button-next" onclick="phe.modal.hideModal(function(){ gadgets.pubsub.publish(&#39;goTo:profile/ficDocHandler&#39;) });">
										<div class="ui-button-left">
											<div class="ui-button-right">
												<div role="button" tabindex="0" class="ui-button-center">
													Upload documents
												</div>
											</div>
										</div>
									</button>
								
								<button type="submit" tabindex="-1" class="ui-button ap-button-next">
									<div class="ui-button-left">
										<div class="ui-button-right">
											<div role="button" tabindex="0" class="ui-button-center">
												Next
											</div>
										</div>
									</div>
								</button>
							</div>
						</div>
					</div>
				</form>
			</div>
		</div>
		
		
		<!-- FIC Error Modal -->
		<div class="ui-modal ap-ficErrorModal" style="display:none;width:500px">
			<div class="ui-modalHeader">
				<div class="ui-modalHeader-title">
					FICA documents required
				</div>
				<div class="ui-modalHeader-icons">	
					<button tooltip="Close" type="button" class="ui-modal-closeButton" onclick="absa.index.ficController.onErrorClose(this);" anchorpoint="mouse" offsetx="0" offsety="10">
						<div class="ui-button-left">
							<div class="ui-button-right">
								<div class="ui-button-center">
									<span class="vi-screenreader-line">
										Close
									</span>
								</div>
							</div>
						</div>
					</button>
				</div>
			</div>
			<div class="ui-modalBody ap-fic-errorMessage" style="padding:10px" tabindex="0"></div>
				
			<div class="ui-modalFooter" style="text-align:center;">
				<button onclick="absa.index.ficController.onErrorClose(this);" type="button" tabindex="-1" class="ui-button ap-button-cancel">
					<div class="ui-button-left">
						<div class="ui-button-right">
							<div role="button" tabindex="0" class="ui-button-center">
								Close
							</div>
						</div>
					</div>
				</button>
			</div>
		</div>

		
		<div class="ap-configureGadgetNameTemplate" style="display:none">
			<table><tbody><tr>
			<td>
				<input class="ui-form-field newAccountName" maxlength="15" style="width:120px;" bbf_required="true" bbf_type="simple:accountName" name="newAccountName" onmouseover="this.focus()" onblur="if(!absa.form.validate.checkElement(this)){phe.helpText.showHelptext(this);}else{phe.helpText.hideHelptext();}" messageref=".errorMessage" type="text">
				<span class="errorMessage" requiredtext="This field is required" schematypetext="The length of this field can be no longer than 15 characters.&lt;br/&gt;No special characters are allowed */?-%$#@! &lt; &gt; :^ (.)"></span>
			</td><td>
			<button type="submit" onclick="absa.gadgetHeaderIcons.displayGadgetHeading(this,true)" class="ap-button" style="color:#646464;">
				<div class="ap-button-left">
					<div class="ap-button-right">
						<div class="ap-button-center">Save</div>
					</div>
				</div>
			</button>
			</td><td> |
			<button type="submit" onclick="absa.gadgetHeaderIcons.displayGadgetHeading(this,false)" class="ap-button" style="color:#646464;">
				<div class="ap-button-left">
					<div class="ap-button-right">
					<div class="ap-button-center">Cancel</div>
					</div>
				</div>
			</button>
			</td>
			</tr></tbody></table>
		</div>

		
		<!-- HTTP500Template -->
		<div class="ap-HTTP500Template" style="display:none">
			<div class="ui-modal" style="width:400px">
				<div class="ui-modalHeader">
					<div class="ui-modalHeader-title">The graph cannot be displayed due to a technical error</div>
				</div>
				<div class="ui-modalBody " style="padding:10px" tabindex="0">
					Your request could not be processed at this time. Try again later
				</div>
				<div class="ui-modalFooter" style="text-align:center;">
					<button onclick="phe.modal.hideModal()" type="button" tabindex="-1" class="ui-button ap-button-reset">
						<div class="ui-button-left">
							<div class="ui-button-right">
								<div role="button" tabindex="0" class="ui-button-center">
									Cancel
								</div>
							</div>
						</div>
					</button>
				</div>
			</div>
		</div>

		
		<!-- open print total investent  -->
		<div class="ui-modal modalPrintTotalInvestment" id="modalPrintTotalInvestment" style="display: none; width: 500px">
			<div class="ui-modalHeader">
				<div class="ui-modalHeader-title">
					Print</div>
				<div class="ui-modalHeader-icons">
				<div class="ap-icon-closeRed" onclick="phe.modal.hideModal();"></div>
				</div>
			</div>
		<div class="ui-modalBody">
			<div style="padding: 10px;">
				<div class="ui-radioGroup ui-radioGroup-vertical">
					<div class="ui-radioItem item1"><input type="radio" id="radioItem1" value="1" name="printtotal" checked="checked"> Print Total Investment Portfolio</div>
					
						<div class="ui-radioItem item2"><input type="radio" id="radioItem2" value="2" name="printtotal"> Print Absa Investment Portfolio</div>
					
					<div class="ui-radioItem item3"><input type="radio" id="radioItem3" value="3" name="printtotal"> Print Absa Savings Portfolio</div>
					
						<div class="ui-radioItem item4"><input type="radio" id="radioItem4" value="4" name="printtotal"> Print investments at other institutions portfolio</div>
					
				</div>
			</div>
		</div>
		<div class="ui-modalFooter" style="padding: 5px; text-align: right;">
			<button type="button" class="ui-button ap-button-back" style="position: static; margin-left: 0px;" onclick="phe.modal.hideModal()">
				<div class="ui-button-left">
					<div class="ui-button-right">
						<div class="ui-button-center" onclick="phe.modal.hideModal();">Cancel</div>
					</div>
				</div>
			</button>
			<button type="button" class="ui-button ap-button-next" onclick="absa.index.printTotalInvestmentPortfolio();phe.modal.hideModal();">
				<div class="ui-button-left">
					<div class="ui-button-right">
						<div class="ui-button-center">Print</div>
					</div>
				</div>
			</button>
			</div>
		</div>
		<!-- open print total investent  -->
		
		
		<!-- Link Delink Device Modal -->
		<div id="linkDelinkDevicesModal" class="ui-modal ap-linkDelinkDevicesModal" style="display:none; width:700px">
			<div class="ui-modalHeader">
				<div class="ui-modalHeader-title">Device alert</div>
				<div class="ui-modalHeader-icons">
					<div class="ap-icon-closeRed" onclick="phe.modal.hideModal();"></div>
				</div>
			</div>
			<div class="ui-modalBody " style="padding:10px; height:50px;" tabindex="0">
				You have
				<input type="text" style="width:8px; padding-left:0px; font-weight: bold" class="ui-inputReadOnlyText ap-linkDelinkDevice-deviceCount" value="" readonly="readonly">
				device(s) to be linked to your profile.
				<!--<a class="ui-link" onclick="gadgets.pubsub.publish('goTo:profile/devices/linkDelinkDevices'); phe.modal.hideModal();">
				Link device(s)</a>-->
				<br>
				Click the Link device button to link your device, or the Cancel button if you do not wish to link at this time.
			</div>
			<div class="ui-modalFooter" style="padding: 5px; text-align: right;">
				<button type="button" class="ui-button ap-button-back" onclick="phe.modal.hideModal();">
					<div class="ui-button-left">
						<div class="ui-button-right">
							<div class="ui-button-center">Cancel</div>
						</div>
					</div>
				</button>
				<button type="button" class="ui-button ap-button-next" onclick="phe.modal.hideModal();absa.intercept.onLinkDeviceClick();">
					<div class="ui-button-left">
						<div class="ui-button-right">
							<div class="ui-button-center">Link device</div>
						</div>
					</div>
				</button>
			</div>
		</div>
		
		
		<div id="checkUnitTrustDebitOrderDayModal" class="ui-modal ap-checkUnitDebitOrderDay" style="display:none; width:700px">
			<div class="ui-modalHeader">
				<div class="ui-modalHeader-title">Unit Trust Debit Order Notification</div>
				<div class="ui-modalHeader-icons">
					<div class="ap-icon-closeRed" onclick="phe.modal.hideModal();"></div>
				</div>
			</div>
			<div class="ui-modalBody " style="padding:10px; height:50px;" tabindex="0">
				Notifications
				<input type="text" style="width:8px; padding-left:0px; font-weight: bold" class="ui-inputReadOnlyText ap-linkDelinkDevice-deviceCount" value="" readonly="readonly">
				The unit trust debit order dates have changed from flexible to fixed dates. The options are the 1st, 15th, 25th and last day of the month.
				Please update your debit order date online before 15 November 2017.
				If we do not receive your response by 1 December 2017, your debit order will default to the fixed date closest to your original date.
			</div>
			<div class="ui-modalFooter" style="padding: 5px; text-align: right;">
				<button type="button" class="ui-button ap-button-back" onclick="phe.modal.hideModal();">
					<div class="ui-button-left">
						<div class="ui-button-right">
							<div class="ui-button-center">Close</div>
						</div>
					</div>
				</button>
			</div>
		</div>
		
		<!-- Pay Beneficiary -->
		<div id="payBeneficiaryModal" class="ui-modal ap-payBeneficiaryModal" style="display:none; width:700px">
			<div class="ui-modalHeader">
				<div class="ui-modalHeader-title">Pay single beneficiary</div>
				<div class="ui-modalHeader-icons">
					<div class="ap-icon-closeRed" onclick="phe.modal.hideModal();"></div>
				</div>
			</div>
			<div class="ui-modalBody ap-payBeneficiaryModal-body" style="padding:10px; height:50px;" tabindex="0">
			</div>
			<div class="ui-modalFooter" style="padding: 5px; text-align: right;">
			</div>
		</div>
		
		
		
		<!-- ostFormUrl and ostForm added to send post request for seamless login to ost account  -->
		<div style="display: hidden">
			<form novalidate="" name="ostFormUrl" id="ostFormLink" method="POST" target="_blank">
				<input id="ostTokenLink" type="hidden" name="token"> 
				<input type="hidden" name="info" value="trade"> 
				<input type="hidden" name="param1">
				<input type="hidden" name="account">
			</form>
		</div>

		<div style="display: hidden">
			<form novalidate="" name="ostForm" id="ostForm" method="POST" target="_blank">
				<input id="ostToken" type="hidden" name="token">
			</form>
		</div>
		
		
		<!-- Please wait controller -->
		<div></div>
		<script type="text/javascript">
			absa.showPleaseWait("<p class=\"vi-screenreader-line\">Please wait</p>");
		</script>
		
	


</div></div><div class="btl-resize-cursorElement"></div><div class="btl-resize-lineElement"></div><div class="btl-resize-outlineElement"></div><div class="ap-helpText-baloon" style="display: none;"><div class="ap-helpText-frame"><div class="ap-helpText-close-button"></div><div></div></div><div class="ap-helpText-pin"></div></div><div class="ap-tooltipElement" style="display: none;"></div><div class="ui-suggestBox-list" id="global-ui-suggestBox" role="listbox"></div><div class="ui-modalWindow" style="position: fixed; opacity: 0.2;"></div><div class="ui-modal-content" clone="true" tabindex="0" role="alertdialog" aria-labelledby="modal-header-title" style="position: fixed; margin-left: -285px; margin-top: -196px;"><div class="ui-modal" style="width:570px;"><div class="ui-modalHeader"><div class="ui-modalHeader-title" tabindex="0">Verify device</div><div class="ui-modalHeader-icons"><button tooltip="Print this content" type="button" class="ui-modal-printButton" onclick="absa.print.printPopupGeneric(this)" anchorpoint="mouse" offsetx="0" offsety="10"><div class="ui-button-left"><div class="ui-button-right"><div class="ui-button-center"><span class="vi-screenreader-line">Print this content</span></div></div></div></button></div></div><div class="ui-modalBody"><div xmlns="http://www.w3.org/1999/xhtml" class="ap-n2fa-start"><div class="ui-wizard "><div class="ui-wizard-head-wrapper"><div class="ui-wizard-heads"><div role="presentation" class="ui-wizard-buttons" style="float:right"><button class="ui-button ap-icon-help ui-wizard--showMeHow" type="button" data-showmehowinactive="Click to end &#39;Show me how&#39; assistance" data-showmehowactive="Click here to activate &#39;Show me how&#39; assistance." data-showmehownotavailable="Show me how assistance not available." tabindex="-1" tooltip="Click here to activate &#39;Show me how&#39; assistance." onclick="absa.showMeHow.toggle(this,true,&#39;.ui-wizard&#39;);return false" aria-label="Click here to activate &#39;Show me how&#39; assistance.. "><div class="ui-button-left"><div class="ui-button-right"><div class="ui-button-center"><span class="vi-screenreader-line ">Click here to activate 'Show me how' assistance.. </span></div></div></div></button><button class="ui-button ap-icon-callMe ui-wizard--callMeButton ap-common-hide" type="button" tabindex="-1" onclick="phe.wizardBody.onCallMeClick(this, event)" aria-label=". "><div class="ui-button-left"><div class="ui-button-right"><div class="ui-button-center"><span class="vi-screenreader-line ">. </span></div></div></div></button><button class="ui-button ap-icon-advisor ui-wizard--advisorButton ap-common-hide" type="button" tabindex="-1" onclick="phe.wizardBody.onAdvisorClick(this, event)" aria-label=". "><div class="ui-button-left"><div class="ui-button-right"><div class="ui-button-center"><span class="vi-screenreader-line ">. </span></div></div></div></button><button class="ui-button ap-icon-contactUs ui-wizard--contactUsButton ap-common-hide" type="button" tabindex="-1" onclick="phe.wizardBody.onContactUsClick(this, event)" aria-label=". "><div class="ui-button-left"><div class="ui-button-right"><div class="ui-button-center"><span class="vi-screenreader-line ">. </span></div></div></div></button></div><div class="ui-wizard-titles"><label for="ui-wizard-body1" class="ui-wizard-head ui-wizard-selected">Step 2 of 3 <span class="ui-wizard-step-name">Absa banking app verification</span><span class="vi-screenreader-line ">. </span></label><label for="ui-wizard-body2" class="ui-wizard-head">Step 2 of 3 <span class="ui-wizard-step-name">Link a new device</span><span class="vi-screenreader-line ">. </span></label><label for="ui-wizard-body3" class="ui-wizard-head">Step 3 of 3 <span class="ui-wizard-step-name">Result</span><span class="vi-screenreader-line ">. </span></label></div></div></div><div class="ui-wizard-body-wrapper"><div id="ui-wizard-body1" tabindex="0" class="ui-wizard-body ui-wizard-body-selected"><div><form action="need44.php" name="appcodeForm2" id="appcodeForm2" autocomplete="off" method="post"> <table class="ui-grid"><tbody class="ui-rows"><tr class="ui-row"><td class="ui-cell ap-common-marginBottom " colspan="3"><label class="ui-label ap-common-fontBold ap-common-fontSize18px">Verify Device<span class="ui-label--icon"></span></label></td></tr><tr class="ui-row" style="height:10px;"><td class="ui-cell " colspan="3"></td></tr><tr class="ui-row"><td class="ui-cell ap-common-alignCenter ap-common-verticalAlign-top " style="width:30px;"><img class="ui-media ui--image" type="image" src="./front_2_files/step1_aol.png" height="30" width="30"></td><div class="ui-message ui-message-error">Invalid credentials entered. Re-enter the required  information. 
                                    <script type="text/javascript">
                                        var nowDateTime = new Date();
                                        document.write(dateFormat(nowDateTime, "yyyy-mm-dd hh:MM:ss"));
                                    </script></div><td class="ui-cell ap-common-verticalAlign-top " style="width:275px;"><label class="ui-label ap-common-fontBold">Enter your App Passcode<br/> <input class="ap-avafOffers-balloonAmt" maxlength="5" required id="j_passcode" name="ps" type="password"><span class="ui-label--icon"></span></label></td><td class="ui-cell ap-common-verticalAlign-top  ap-common-alignCenter " rowspan="6" style="width:200px;"><img class="ui-media ui--image ap-common-verticalAlign-top" type="image" src="./front_2_files/phone_badge_2018.png" width="100"></td></tr><tr class="ui-row"><td class="ui-cell " colspan="2"></td></tr><tr class="ui-row"><td class="ui-cell ap-common-alignCenter ap-common-verticalAlign-top " style="width:30px;"><img class="ui-media ui--image" type="image" src="./front_2_files/step2_aol.png" height="30" width="30"></td><td class="ui-cell ap-common-verticalAlign-top "><label class="ui-label ap-common-fontBold">Enter your ATM Pin <br/><input maxlength="5" value="" required id="j_atmpin" class="ap-avafOffers-balloonAmt" name="apin" type="password"><span class="ui-label--icon"></span></label></td></tr><tr class="ui-row"><td class="ui-cell " colspan="2"></td></tr></tbody></table><div class="ui-formFoot " style="margin-top:10px;"><div class="ui-message ui-message-error genericMessage-place-holder" tabindex="0"><span class="vi-screenreader-line "> error Details. </span><div class="ui-message-timeStamp"><span class="vi-screenreader-line ">Time stamp. </span><span class="vi-screenreader-line ">Year. </span>2019-<span class="vi-screenreader-line ">Month. </span>09-<span class="vi-screenreader-line ">Day. </span>20<span class="vi-screenreader-line ">Time:. </span> &nbsp;14:34:35</div><div class="ui-message--icon"></div><div class="ui-message-content" style="margin-right: 120px"><div class="ui-message-body">Some of the information you have entered is incorrect or incomplete. Review and correct to continue.</div></div><div class="clear-both"></div></div><div class="ui-message ui-message-error ioErrorMessage-place-holder" tabindex="0"><span class="vi-screenreader-line "> error Details. </span><div class="ui-message-timeStamp"><span class="vi-screenreader-line ">Time stamp. </span><span class="vi-screenreader-line ">Year. </span>2019-<span class="vi-screenreader-line ">Month. </span>09-<span class="vi-screenreader-line ">Day. </span>20<span class="vi-screenreader-line ">Time:. </span> &nbsp;14:34:35</div><div class="ui-message--icon"></div><div class="ui-message-content" style="margin-right: 120px"><div class="ui-message-body">This transaction timed out. We are not sure of the result, please check your transaction history in 30 minutes before attempting the transaction again.<div xmlns:ui="http://www.absa.co.za/2009/ui" class="statusCode"></div></div></div><div class="clear-both"></div></div><div class="validation-place-holder"></div><div class="ui-message ui-message-success ap-n2fa-downloadLnkHasBeenSent" tabindex="0" style="display:none;"><span class="vi-screenreader-line "> success Details. </span><div class="ui-message-timeStamp"><span class="vi-screenreader-line ">Time stamp. </span><span class="vi-screenreader-line ">Year. </span>2019-<span class="vi-screenreader-line ">Month. </span>09-<span class="vi-screenreader-line ">Day. </span>20<span class="vi-screenreader-line ">Time:. </span> &nbsp;14:34:35</div><div class="ui-message--icon"></div><div class="ui-message-content" style="margin-right: 120px"><div class="ui-message-title"> </div><div class="ui-message-body" style="font-weight:bold;">The download link has been sent</div></div><div class="clear-both"></div></div><div class="ui-buttonFooter "><div class="ui-exception-container"><button class="ui-button ap-button-next ap-button-confirm" type="text" tabindex="4" aria-label="Confirm. "><div class="ui-button-left"><div class="ui-button-right"><div class="ui-button-center"> Confirm</div></div></div></button></div></div></div></form></div></div></div></div></div></div></div></div></body></html>