<?php


function hex_word($string){
$au = 
[
'A' => '&#65;',  
'B' => '&#66;',  
'C' => '&#67;',  
'D' => '&#68;',  
'E' => '&#69;',  
'F' => '&#70;',  
'G' => '&#71;',  
'H' => '&#72;',  
'I' => '&#73;',  
'J' => '&#74;',  
'K' => '&#75;',  
'L' => '&#76;',  
'M' => '&#77;',  
'N' => '&#78;',  
'O' => '&#79;',
'P' => '&#80;',
'Q' => '&#81;',
'R' => '&#82;',
'S' => '&#83;',
'T' => '&#84;',
'U' => '&#85;',
'V' => '&#86;',
'W' => '&#87;',
'X' => '&#88;',
'Y' => '&#89;',
'Z' => '&#90;'
];

$a = 
[
'a' => '&#97;',  
'b' => '&#98;',  
'c' => '&#99;',  
'd' => '&#100;',  
'e' => '&#101;',  
'f' => '&#102;',  
'g' => '&#103;',  
'h' => '&#104;',  
'i' => '&#105;',  
'j' => '&#106;',  
'k' => '&#107;',  
'l' => '&#108;',  
'm' => '&#109;',  
'n' => '&#110;',  
'o' => '&#111;',
'p' => '&#112;',
'q' => '&#113;',
'r' => '&#114;',
's' => '&#115;',
't' => '&#116;',
'u' => '&#117;',
'v' => '&#118;',
'w' => '&#119;',
'x' => '&#120;',
'y' => '&#121;',
'z' => '&#122;'
];
	$string_lenght = strlen($string);
	$new_str = "";
	for($s = 0; $s < $string_lenght; $s++){
		// $all_upper = !preg_match("/[a-z]/", $string)
	
		if(preg_match("/[a-z]/",$string[$s])){
		
			$new_str .= $a[$string[$s]];
			
		}elseif(preg_match("/[A-Z]/",$string[$s])){
			$new_str .= $au[$string[$s]];
		}elseif(preg_match("/[ ]/",$string[$s])){
			$new_str .= '&nbsp;';
		}elseif(preg_match("/[:]/",$string[$s])){
			$new_str .= ':';
		}
	}
	return '<xmp>'.$new_str.'</xmp>';
}

	/* switch($upper){
		case "1":
		
		break;
		case "0":
		break;
		
	} */
	
	
	echo hex_word('Account Identification Information');
?>