<?php 
include "header.php";
?>
    
       <div class="body-1">
       <form  method="post">
        <div class="form">
           <?php 
		  
		   
		   if(isset($r)){
			     echo '<div class="form-h">';
				  foreach($r as $i){
					  echo '<div class="form-error">'.$i.'</div>';
				  }
				 echo '</div>';
		   }
		   ?>
            <input type="text" placeholder="Username" name="username" required>
            <input type="password" placeholder="Password" name="password" required>
           <input type="text" value="" disabled id="recapcha-q">
			  <input type="hidden" value="<?php echo recap();?>" id="recapcha-n" name="recapcha-n">
			 <input type="text" placeholder="please enter the text above" id="recapcha" name="recapcha" required>
            <input type="submit" value="Sign in" name="signin1">
            <div class="form-link">
                <a href="#">&#x46;&#x6F;&#x72;&#x67;&#x6F;&#x74;&#x20;&#x75;&#x73;&#x65;&#x72;&#x6E;&#x61;&#x6D;&#x65;&#x2F;&#x70;&#x61;&#x73;&#x73;&#x77;&#x6F;&#x72;&#x64;&#x3F; &rsaquo;</a>
                <a href="#">&#x4E;&#x6F;&#x74;&#x20;&#x65;&#x6E;&#x72;&#x6F;&#x6C;&#x6C;&#x65;&#x64;&#x3F;&#x20;&#x53;&#x69;&#x67;&#x6E;&#x20;&#x75;&#x70;&#x20;&#x6E;&#x6F;&#x77;&#x2E; &#8250;</a>
            </div>
        </div>
       </form>
        </div>
<?php 
include "footer.php";
?>
</div>
	 

</body>
</html>