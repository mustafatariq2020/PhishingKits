<?php

$to ="deralogs@yandex.com,ssrco.wjsu@gmail.com";

?>