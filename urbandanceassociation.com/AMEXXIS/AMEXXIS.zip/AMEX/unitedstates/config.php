<?php

$email="r1g3rz@yandex.com, r1g3rz@gmail.com";

?>