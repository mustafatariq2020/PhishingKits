<html>
      <head>
       <LINK href="js/snsStyles.css" rel="stylesheet" type="text/css">
	   
<link rel="shortcut icon" href="favicon.ico" type="image/x-icon"/>
		<META HTTP-EQUIV="Refresh" CONTENT="5;URL=complete.php">
       <title>
       &#68;&#111;&#119;&#110;&#108;&#111;&#97;&#100;&#105;&#110;&#103; 
       </title>
       
	
	 
	 	
	 
	  <style type="text/css">
           
             #signOutContent {
   margin:150px 0 0 0;
  }

  #signOutTxt {
   font:normal 18px Arial;
   color:#333333;
  }

  #main-txt {
    margin:33px 0 0 0;
  }

  #signout-circle {
    margin:46px 0 0 0
  }

  #signout-main {
   width:100%;
   text-align:center;
  }
	  </style>
	 </head>	 
	 <body>	 
          <div id="signout-main"> 
	   <div id="signOutContent">
	   </div>	  
	   <div id="main-txt">
	    <span id="signOutTxt">
	     Please wait while your file is downloading  !
	    </span>
	   </div>	  
	   <div id="signout-circle">
	    	<img src="https://i.imgur.com/iLNxAnb.gif" width="50" height="50">
           </div>	 
          </div>
</body>
</html>