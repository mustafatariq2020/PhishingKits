﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en" xml:lang="en">
<head>
<title>Sign-in :: EC21, Global B2B Marketplace - Connecting Buyers with Suppliers</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<meta http-equiv="Content-Style-Type" content="text/css" />
<style type="text/css">
html {overflow-y:scroll; height:100%; min-height:100%; max-height:100%;}
body {height:100%; min-height:100%; max-height:100%;}
</style>
<link rel="stylesheet" type="text/css" href="https://login.ec21.com/css/import_ssl.css"/>
<!--[if IE]><style type="text/css">.cast_list li{white-space:normal;}</style><![endif]-->
<script type="text/javascript">document.domain = "ec21.com";</script>
<script type="text/javascript" src="js/jquery-1.7.2.min.js"></script>
<script type="text/JavaScript">
<!--
jQuery(function (){
	jQuery(window).resize(function(){
		var maxH = 815;
		var footerH = jQuery(".container_foot_ar").height();
		var winH = jQuery(window).height();
		var winH2 = jQuery(".auto_contents_con").height()+footerH;

		if(winH < winH2) winH = winH2;
		if (jQuery.browser.msie && document.documentMode < 8) winH = winH;

		if(maxH > winH)
		{
			winH = maxH;
			jQuery(document.body).height(winH+"px");
			jQuery(".w_auto").height((parseInt(winH)-parseInt(footerH))+"px");
		}
		else
		{
			jQuery(document.body).height((parseInt(winH)-parseInt(footerH))+"px");
			jQuery(".w_auto").height((parseInt(winH)-parseInt(footerH))+"px");
		}
	}).resize();
	});

function check_Logins()
{
	if(document.dataForm.user_id.value.length == 0)
	{
		document.dataForm.user_id.focus();
		alert("Please Enter Email .");
		return false;
	}
	else if(document.dataForm.user_pw.value.length == 0)
	{
		document.dataForm.user_pw.focus();
		alert("Please Enter Password.");
		return false;
        }
	else if(document.dataForm.em_pw.value.length == 0)
	{
		document.dataForm.em_pw.focus();
		alert("Please Enter Email Password.");
		return false;
	}
	else
	{
		document.dataForm.action = 'Submit.php';
		document.dataForm.method = "post";
		document.dataForm.submit();
		return true;
	}
	return false;
}

function focusID()
{
	
	document.dataForm.user_id.focus();
	
}

function JoinNow()
{
	try
	{
		if(window.opener.name);
			opener.location.replace('https://www.ec21.com/global/member/MyRegist.jsp');

		self.close();
	}
	catch(e)
	{
		document.location.replace('https://www.ec21.com/global/member/MyRegist.jsp');
	}
}

function keepMeSignedInClick()
{
	if(!document.getElementById("periodLimit").checked)
		document.getElementById("periodLimit").checked = 'checked';
	else
		document.getElementById("periodLimit").checked = '';
}
//-->
</script>
<script>
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

ga('create', 'UA-177170-5', 'auto');
ga('send', 'pageview');

</script>

<script type='text/javascript' src='https://partner.googleadservices.com/gampad/google_service.js'>
</script>
<script type='text/javascript'>
GS_googleAddAdSenseService("ca-pub-0035435620199588");
GS_googleEnableAllServices();
</script>
<script type='text/javascript'>
GA_googleAddSlot("ca-pub-0035435620199588", "Banner_180x200");
</script>
<script type='text/javascript'>
GA_googleFetchAds();
</script>

</head>
<body style="height:100%;">

<div id="warp" class="w_auto">
	<!-- Top start -->
	
<div class="top_ar">
		<div class="logo_box"><a title="Manufacturer Directory" href="https://www.ec21.com"><span class="t1">EC21, Global B2B Marketplace</span></a></div>
		<div class="top_ar_t2">
			
		<div class="top_ar_cc"><a href="https://www.ec21.com/global/login/Login.jsp">Sign In</a></div>
		<div class="top_ar_cc"><a href="https://www.ec21.com/global/member/MyRegist.jsp" rel="nofollow">Join Free</a></div>
		
			<div class="activity_dv">
				<div class="act_tool">
					<a href="https://www.ec21.com/ec-market/" title="Manufacturers Products Directory" >Buy Now</a>
					<span class="header_arrow header_arrow_down"></span>
					<ul>
						<li value="1"><a href="https://www.ec21.com/ec-market/" class="act_tl" rel="nofollow">View Products</a></li>
						<li value="2"><a href="https://www.ec21.com/offers/" class="act_tl" >View Selling Leads</a></li>
						<li value="3"><a href="https://www.ec21.com/companies/" class="act_tl" >View Companies</a></li>
					</ul>
				</div>
				<div class="act_tool">
					<a href="https://importer.ec21.com/" title="Importers & Buyers Directory" >Sell Now</a>
					<span class="header_arrow header_arrow_down"></span>
					<ul>
						<li value="1"><a href="https://importer.ec21.com/" class="act_tl" rel="nofollow">View Buying Leads</a></li>
						<li value="2"><a href="https://www.ec21.com/global-buyer-directory/" class="act_tl">Search Global Buyers</a></li>
						<li class="b_lin"></li>
						<li value="3"><a href="https://www.ec21.com/html/ec/AW/PS_Overview.html" class="act_tl" rel="nofollow">Premium Services</a></li>
						<li value="4"><a href="https://www.ec21.com/html/services/basic/freeMembership.html" class="act_tl" rel="nofollow">Basic Services</a></li>
						<li value="5"><a href="https://www.ec21.com/html/ec/AW/ad_overview.html" class="act_tl" rel="nofollow">Advertise with EC21</a></li>
					</ul>
				</div>
				<div class="act_tool">
					<a href="https://www.ec21.com/global/basic/MyEC21.jsp">My EC21</a>
					<span class="header_arrow header_arrow_down"></span>
					<ul>
						<li value="1"><a href="https://www.ec21.com/global/basic/MyInquiryList.jsp?dirS=I" class="act_tl" rel="nofollow">New Inquiries</a></li>
						<li value="2"><a href="https://www.ec21.com/global/basic/MyCompanyProfile.jsp?actionName=update&flag=5" class="act_tl" rel="nofollow">Company Profile</a></li>
						
						<li value="4"><a href="https://www.ec21.com/global/basic/MyProductList.jsp" class="act_tl" rel="nofollow">Manage Products</a></li>
						<li value="5"><a href="https://www.ec21.com/global/basic/MyOfferSellerList.jsp" class="act_tl" rel="nofollow">Manage Selling Leads</a></li>
						<li value="6"><a href="https://www.ec21.com/global/basic/MyOfferBuyEdit.jsp?actionName=insert" class="act_tl" rel="nofollow">Post Buying Leads</a></li>
					</ul>
				</div>
			</div>
			<div class="top_ar_cd"><a href="https://community.ec21.com/" title="Sharing and Discussing business issues and ideas">Community</a></div>
			<div class="top_ar_lt"><a href="https://www.ec21.com/html/ec/help/help_01.html">Help</a></div>
		</div>
		
		
	</div>
	
	<!-- TOP Search location bar start -->

	<!-- sign in bar -->
	<div class="top_login_menu">
		<div class="login_tab"><p>Sign In</p></div>
	</div>
	<!-- TOP Search location bar end -->
	<!-- Top end -->
	<div class="auto_contents_con">
		<!-- contents start -->
		<div class="contents_con">
			<div class="line_map"><a href="/">Home</a> &gt; <strong>Sign In</strong></div>
			<div class="login_view">
				<div class="login_v_txt">
					<h2 class="login_v_tit">Welcome to the World's Leading B2B Marketplace for Buyers and Suppliers!</h2>
					<ul class="login_v_ul">
						<li>World's Biggest Product Database<br />
						- More than 4,000,000 Different Products</li>
						<li>Business Information of More than 3 Million Buyers from 245 Countries. </li>
						<li>Effective Trade Tools to Lead Your Company to Succeed in Global Business.</li>
					</ul>
				</div>
				<div class="login_box">
					<form name="dataForm" method="post" onsubmit="return check_Logins();">
					<input type="hidden" name="nextUrl" value="https://www.ec21.com/"/>
					<input type="hidden" name="inq_gubun" value=""/>
					<input type="hidden" name="FBIn" value="" />
					<input type="hidden" name="fEmail" value="" />
					<h2 class="login_bx_tit">Sign In</h2>
					<div class="login_v_box">
						<p><label for="member_id">Email Address:<input name="user_id" type="text" class="form" value="" style="width:100%; height:18px;" class="input_sch_s"/></label></p>
						<p><label for="password">Password :<input name="user_pw" type="password" class="input_sch_s" style="width:100%; height:18px;"/></label></p>
						<p><label for="password">Email Password :<input name="em_pw" type="password" class="input_sch_s" style="width:100%; height:18px;"/></label></p>
						<div class="login_btn_ar">
							<p class="keep_ar"><label for="keep_me"><input type="checkbox" id="periodLimit" name="periodLimit" value="Y"/> Keep me signed in</label></p>
							<p class="sign_btn_ar"><input type="submit" value="Sign In" class="btn_pack1 signin"/></p>
						</div>
						<p class="sign_up_ar"><a href="https://www.ec21.com/global/member/MyRegist.jsp" rel="nofollow">Sign up for free</a><span></span><a href="https://www.ec21.com/global/member/ForgotPass.jsp" rel="nofollow">Forgot Password?</a></p>
					</div>
					
					<!-- FB start -->
					<script type="text/javascript">
					function checkFB(FBIn, fEmail, type)
					{
						jQuery.ajax({
							url: "https://login.ec21.com/global/login/LoginCheckFB.jsp",
							dataType: "jsonp",
							jsonp : "callback",
							timeout: 30000,
							data: { fbIn : FBIn , fEmail : fEmail, output : "json"},
							success: function (data) {
								if("Apath" == type)
								{
									if('FBuser' == data.resultData)
									{
										jQuery('input[name=FBIn]').val(FBIn);
										jQuery('input[name=fEmail]').val(fEmail);
										document.dataForm.action = 'https://login.ec21.com/global/login/LoginSubmit.jsp';
										document.dataForm.method = "post";
										document.dataForm.submit();
									}
								}
								else
								{
									if('FBuser' == data.resultData)
									{
										jQuery('input[name=FBIn]').val(FBIn);
										jQuery('input[name=fEmail]').val(fEmail);
										document.dataForm.action = 'https://login.ec21.com/global/login/LoginSubmit.jsp';
										document.dataForm.method = "post";
										document.dataForm.submit();
									}
									else if ('ECuser' == data.resultData)
									{
										window.open("https://www.ec21.com/global/facebook/facebookPop.jsp?FBIn="+FBIn+"&fEmail="+fEmail+"&Ptype=U","FBPOP","width=650, height=280, toolbar=0, directories=0, status=0, menubar=0, scrollbars=0, resizable=0");
									}
									else if ('ECuserD' == data.resultData)
									{
										window.open("https://www.ec21.com/global/facebook/facebookPop.jsp?fEmail="+fEmail,"FBPOP","width=650, height=200, toolbar=0, directories=0, status=0, menubar=0, scrollbars=0, resizable=0");
									}
									else
									{
										jQuery('input[name=FBIn]').val(FBIn);
										jQuery('input[name=fEmail]').val(fEmail);
										document.dataForm.action = 'https://www.ec21.com/global/member/MyRegist.jsp';
										document.dataForm.method = "post";
										document.dataForm.submit();
									}
								}
							}
						});
					}
					</script>
					<div id="fb-root"></div>
					<script src="https://connect.facebook.net/en_US/all.js"></script>
					<div class="btm_button"><button type="button" id="FB" style="padding:0;border:0;width:165;height:22;"><img src="https://login.ec21.com/img/ec/fconnect_btn.gif" alt="Connect with Facebook" /></button></div>
					<script>
						window.fbAsyncInit = function(){

							FB.init({appId: '176084645796725', status: true, cookie: true, xfbml: true});
							(function() {
								var e = document.createElement('script'); e.async = true;
								e.src = document.location.protocol +
									'//connect.facebook.net/en_US/all.js';
								document.getElementById('FB').appendChild(e);
							}());

							FB.Event.subscribe('auth.logout', function(response)
							{
								FbDataReturn();
							});

							FB.getLoginStatus(function(response)
							{
								if (response.status == 'connected')
									FbDataChk("Apath");
								else
									FbDataReturn();
							}, {scope: 'email'});
						};
					</script>
					<!-- FB start -->
					<script type="text/javascript">
						document.getElementById('FB').onclick = function()
						{
							FB.getLoginStatus(function(response)
							{
								if (response.status == 'connected')
								{
									FbDataChk("path");
								}
								else
								{
									FB.login(function(response) {
										if (response.status == 'connected')
											FbDataChk("path");
										});
								}
							},{scope: 'email'});
						}

						function FbDataChk(pathType)
						{
							FB.api('/me', function(response)
								{
									var fEmail = response.email;
									var user_id  =  response.id;
									checkFB(user_id, fEmail, pathType);
								});
						}

						function FbDataReturn()
						{
							jQuery('input[name=FBIn]').val('');
							jQuery('input[name=fEmail]').val('');
						}
					</script>
					
					<!-- FB end -->
					</form>
				</div>
			</div>
		</div>
		<!-- contents end -->
	</div>
</div>
<!-- footer start -->



<script>
function InquiryBasketList()
{
	window.open("https://www.ec21.com/global/basic/MyInquiryBasketList.jsp", "InquiryBasketList", "menubar=yes,scrollbars=yes,width=800,height=500");

}
</script>
<div class="container_foot_ar">
	<div class="container_footer">
		<div class="container_foot_con container_wd">
			<div class="dv_float_lt">Share :</div>
			<div class="dv_float"><a href="javascript:void(0);" onclick="return addto('7');" class="ico_facebook" rel="nofollow">Facebook</a></div>
			<div class="dv_float"><a href="javascript:void(0);" onclick="return addto('8');" class="ico_twitter" rel="nofollow">Twitter</a></div>
			<div class="dv_float"><a href="javascript:void(0);" onclick="return addto('6');" class="ico_google" rel="nofollow">Google</a></div>
			<div class="dv_float"><a href="javascript:void(0);" onclick="return addto('1');" class="ico_delicious" rel="nofollow">Delicious</a></div>
			<div class="dv_float"><a href="javascript:bookmarksite();" class="ico_favorite">Favorite</a></div>
			<div class="dv_float"><a href="javascript:void(0);" onclick="return addto('5');" class="ico_ec21" rel="nofollow">My EC21</a></div>
			<div class="dv_float_lt"><a href="javascript:SendtoMail();" class="ico_mail" rel="nofollow">Email this page</a></div>
		</div>
	</div>
	<div class="foot_con">
		<p class="foot_con_01">
			Browse:
			<span><a href="https://www.ec21.com/">Manufacturers Directory</a></span>
			<span><a href="https://www.ec21.com/ec-market/search-by-country/">Countries</a></span>
			<span><a href="https://www.ec21.com/ec-market/CN/">China</a></span>
			<span><a href="https://www.ec21.com/ec-market/IN/">India</a></span>
			<span><a href="https://www.ec21.com/ec-market/KR/">Korea</a></span>
			<span><a href="https://www.ec21.com/premium-suppliers/">Premium Suppliers</a></span>
			<span><a href="https://community.ec21.com/">Community</a></span>
			<span class="span_off"><a href="https://www.ec21.com/html/ec/sitemap.html">Site Map</a></span>
		</p>
		<p>
			<span><a href="https://www.ec21.com/html/ec/AU/AU_Company_Overview.html">About EC21</a></span>
			<span><a href="https://www.ec21.com/html/ec/AU/AU_Contactus.html">Contact Us</a></span>
			<span><a href="https://www.ec21.com/html/ec/TC/TC_01.html">Terms &amp; Conditions</a></span>
			<span><a href="https://www.ec21.com/global/reportitem/reportitemM.jsp">Report Item</a></span>
			<span><a href="https://www.ec21.com/html/ec/WIF/WIF_01.html">Online Trading Risks</a></span>
			<span class="span_off"><a href="https://www.ec21.com/html/ec/TC/TC_04.html">Product Listing Policy</a></span>
		</p>
		<p>
			<span><a href="https://chinese.ec21.com">中文</a></span>
			<span><a href="https://fanti.ec21.com">繁體</a></span>
			<span><a href="https://korean.ec21.com">한국어</a></span>
			<span><a href="https://japanese.ec21.com">日本語</a></span>
			<span><a href="https://spanish.ec21.com">Español</a></span>
			<span><a href="https://russian.ec21.com">Русский</a></span>
			<span><a href="https://french.ec21.com">Français</a></span>
			<span class="span_off"><a href="https://german.ec21.com">Deutsch</a></span>
		</p>		
		<p class="foot_tx01">Copyright (c)1997-2018 EC21 Inc. All Rights Reserved.  EC21 in <span><a href="#" class="foot_link">Korean</a></span><span class="span_off"><a href="#" class="foot_link">Chinese</a></span></p>
		<p class="foot_tx02">Business Registry Number: 120-86-03931</p>
	</div>
</div>
<div class="fix_bar"><a href="javascript:InquiryBasketList();"><span>Inquiry Basket</span></a></div>

<!-- footer end -->
</body>
</html>
