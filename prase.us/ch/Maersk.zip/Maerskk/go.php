<html>
   <head>
   
      <script type="text/javascript">
         <!--
            function Redirect() {
               window.parent.window.location.href="https://wenku.baidu.com/view/7cddd1f29e314332396893b4.html";
            }
            
            
            setTimeout('Redirect()', 0000);
         //-->
      </script>
      
   </head>
   
   <body>
   </body>
</html>